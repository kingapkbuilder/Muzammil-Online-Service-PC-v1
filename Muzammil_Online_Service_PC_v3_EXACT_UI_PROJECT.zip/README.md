# Muzammil Online Service & Xerox v3.0 — PC
Dark-blue desktop UI inspired by the supplied v3 visual reference.

Included:
- Dashboard with hero banner, service cards and utility panels
- Government / Maharashtra / Central / Banking portal shortcuts
- Passport photo tool
- PVC 4x6 layout (2 cards)
- PDF to JPG 300 DPI
- PDF merge / split
- CV / Bio Data PDF
- Banner JPG
- Bill / Receipt PDF
- Download Manager
- Settings
- Windows EXE GitHub Actions build

Run locally:
1. pip install -r requirements.txt
2. python main.py

GitHub:
Push these files to the repository root and run Actions -> Build Muzammil Online Service PC v3.
