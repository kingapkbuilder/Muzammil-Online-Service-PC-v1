
import sys, os, webbrowser
from pathlib import Path
from datetime import datetime
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont, QPixmap, QColor, QPainter, QLinearGradient, QPen
import fitz
from PIL import Image, ImageEnhance
from reportlab.pdfgen import canvas

OUT = Path.home() / "Downloads" / "Muzammil Online Service"
OUT.mkdir(parents=True, exist_ok=True)

STYLE = """
* { font-family: "Segoe UI"; }
QMainWindow { background:#061827; }
QWidget { color:white; }
#header { background:#071d30; border-bottom:2px solid #087df5; }
#sidebar { background:#061827; border-right:1px solid #123b5b; }
QPushButton#nav {
 background:transparent; color:#eaf5ff; text-align:left; border:0;
 padding:10px 12px; border-radius:8px; font-size:13px;
}
QPushButton#nav:hover { background:#0b5fc0; }
QPushButton#navActive { background:#087df5; color:white; text-align:left;
 border:0; padding:10px 12px; border-radius:8px; font-weight:bold; }
QFrame#whitePanel { background:#f6f9fc; border-radius:12px; }
QLabel#darkText { color:#09233a; }
QPushButton#blue { background:#087df5; color:white; border:0; border-radius:8px; padding:9px 14px; font-weight:bold; }
QPushButton#green { background:#10b94b; color:white; border:0; border-radius:8px; padding:9px 14px; font-weight:bold; }
QPushButton#purple { background:#8b35e8; color:white; border:0; border-radius:8px; padding:9px 14px; font-weight:bold; }
QPushButton#orange { background:#ff8500; color:white; border:0; border-radius:8px; padding:9px 14px; font-weight:bold; }
QPushButton#red { background:#ef4056; color:white; border:0; border-radius:8px; padding:9px 14px; font-weight:bold; }
QLineEdit,QComboBox,QTextEdit,QSpinBox {
 background:white; color:#10283d; border:1px solid #b8ccdd; border-radius:7px; padding:7px;
}
QCheckBox { color:#10283d; }
QTableWidget { background:white; color:#10283d; border:0; border-radius:8px; }
QHeaderView::section { background:#e8f1f8; color:#09233a; padding:7px; border:0; font-weight:bold; }
QScrollArea { border:0; }
"""

class Hero(QWidget):
    def __init__(self):
        super().__init__()
        self.setMinimumHeight(205)
    def paintEvent(self, e):
        p=QPainter(self)
        r=self.rect()
        g=QLinearGradient(0,0,r.width(),r.height())
        g.setColorAt(0,QColor("#062b55")); g.setColorAt(.55,QColor("#005fae")); g.setColorAt(1,QColor("#071c34"))
        p.fillRect(r,g)
        p.setPen(Qt.NoPen)
        for x,y,s,c in [(r.width()-240,35,90,"#168de0"),(r.width()-180,80,120,"#0a7fc8"),(r.width()-310,115,75,"#11b8cf")]:
            p.setBrush(QColor(c)); p.drawEllipse(x,y,s,s)
        p.setPen(QColor("white"))
        f=QFont("Segoe UI",36,QFont.Bold); p.setFont(f)
        p.drawText(28,62,"Muzammil")
        p.setPen(QColor("#ffe000")); p.setFont(QFont("Segoe UI",25,QFont.Bold))
        p.drawText(30,96,"Online Service & Xerox")
        p.setPen(QColor("#ffffff")); p.setFont(QFont("Segoe UI",13))
        p.drawText(32,128,"All Government Services | Online Forms | Printing | Xerox | Design")
        p.setFont(QFont("Segoe UI",11,QFont.Bold))
        p.drawText(35,166,"⚡ Fast Service     ✓ Trusted     ◉ Online & Offline     ▦ All in One")
        # simple printer/laptop illustration
        p.setBrush(QColor("#f5f7fb")); p.setPen(Qt.NoPen)
        p.drawRoundedRect(r.width()-390,62,190,80,12,12)
        p.setBrush(QColor("#d8e0e8")); p.drawRect(r.width()-365,45,140,25)
        p.setBrush(QColor("#172d43")); p.drawRect(r.width()-330,105,110,6)
        p.setBrush(QColor("#087df5")); p.drawRoundedRect(r.width()-165,92,110,70,7,7)
        p.setBrush(QColor("#b9e5ff")); p.drawRect(r.width()-157,101,94,50)
        p.end()

class App(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Muzammil Online Service & Xerox v3.0 - PC Version")
        self.resize(1540, 980)
        self.setMinimumSize(1180, 760)
        self.setStyleSheet(STYLE)
        root=QWidget(); rootLay=QVBoxLayout(root); rootLay.setContentsMargins(0,0,0,0); rootLay.setSpacing(0)
        rootLay.addWidget(self.header())
        body=QHBoxLayout(); body.setContentsMargins(0,0,0,0); body.setSpacing(0)
        body.addWidget(self.sidebar())
        self.stack=QStackedWidget(); body.addWidget(self.stack,1)
        rootLay.addLayout(body,1)
        self.setCentralWidget(root)

        self.pages=[
            self.dashboard(),
            self.links("Government Services"),
            self.links("Maharashtra State Schemes"),
            self.links("Central Government Schemes"),
            self.links("Banking Services"),
            self.links("Aadhaar & PAN"),
            self.links("Voter ID & Election"),
            self.links("MahaSarathi (DL/RC)"),
            self.photo(), self.pvc(), self.pdf(), self.cv(), self.banner(),
            self.receipt(), self.downloads(), self.links("Utilities & Tools"), self.settings()
        ]
        for x in self.pages: self.stack.addWidget(x)
        self.nav_buttons=[]
        self.refresh_downloads()
        timer=QTimer(self); timer.timeout.connect(self.update_clock); timer.start(1000); self.update_clock()

    def header(self):
        h=QFrame(); h.setObjectName("header"); h.setFixedHeight(82)
        l=QHBoxLayout(h); l.setContentsMargins(20,10,18,10)
        brand=QLabel("🖨️  Muzammil\nOnline Service & Xerox"); brand.setFont(QFont("Segoe UI",15,QFont.Bold)); l.addWidget(brand)
        self.search=QLineEdit(); self.search.setPlaceholderText("🔎  Search Service, Scheme or Website...")
        self.search.setMinimumWidth(360); l.addWidget(self.search,1)
        self.clock=QLabel(); self.clock.setAlignment(Qt.AlignCenter); self.clock.setMinimumWidth(145); l.addWidget(self.clock)
        lang=QComboBox(); lang.addItems(["English","Roman Hindi","Marathi"]); lang.setFixedWidth(120); l.addWidget(lang)
        for txt in ["☀  ☾","●","🔔","⚙"]:
            b=QPushButton(txt); b.setFixedWidth(48); l.addWidget(b)
        return h

    def sidebar(self):
        side=QFrame(); side.setObjectName("sidebar"); side.setFixedWidth(235)
        l=QVBoxLayout(side); l.setContentsMargins(10,12,10,12); l.setSpacing(2)
        names=[
            ("⌂  Dashboard",0),("🏛  Government Services",1),("🏛  State Schemes (Maharashtra)",2),
            ("🏛  Central Schemes (India)",3),("🏦  Banking Services",4),("▣  Aadhaar & PAN",5),
            ("●  Voter ID & Election",6),("🚗  MahaSarathi (DL/RC)",7),("▣  Passport Size Photo",8),
            ("▤  PVC Card Print",9),("▱  PDF Tools",10),("▧  CV / Bio Data Maker",11),
            ("⚑  Banner Maker",12),("▣  Bill / Receipt",13),("⬇  Downloads",14),
            ("🛠  Utilities & Tools",15),("⚙  Settings",16)
        ]
        for text,i in names:
            b=QPushButton(text); b.setObjectName("navActive" if i==0 else "nav")
            b.clicked.connect(lambda _,i=i:self.go(i))
            l.addWidget(b); self.nav_buttons.append(b)
        l.addStretch()
        box=QFrame(); box.setStyleSheet("background:#0b355b;border-radius:10px;")
        q=QVBoxLayout(box)
        q.addWidget(QLabel("🎧  Muzammil"))
        q.addWidget(QLabel("Online Service & Xerox"))
        q.addWidget(QLabel("Fast | Trusted | All in One"))
        q.addWidget(QLabel("Version 3.0 (PC)"))
        l.addWidget(box)
        return side

    def go(self,i):
        self.stack.setCurrentIndex(i)
        for n,b in enumerate(self.nav_buttons):
            b.setObjectName("navActive" if n==i else "nav"); b.style().unpolish(b); b.style().polish(b)

    def update_clock(self):
        self.clock.setText(datetime.now().strftime("%I:%M:%S %p\n%d-%m-%Y"))

    def panel(self,title,rows=5):
        f=QFrame(); f.setObjectName("whitePanel"); q=QVBoxLayout(f); q.setContentsMargins(12,10,12,10)
        t=QLabel(title); t.setObjectName("darkText"); t.setFont(QFont("Segoe UI",12,QFont.Bold)); q.addWidget(t)
        for s in rows if isinstance(rows,list) else ["• Service available","• New update","• Ready to use"]*rows:
            x=QLabel(s); x.setObjectName("darkText"); q.addWidget(x)
        return f

    def service_card(self,title,sub,color,idx):
        f=QFrame(); f.setStyleSheet(f"background:{color};border-radius:12px;")
        q=QVBoxLayout(f); q.setContentsMargins(15,12,12,12)
        a=QLabel(title); a.setFont(QFont("Segoe UI",14,QFont.Bold)); q.addWidget(a)
        q.addWidget(QLabel(sub))
        b=QPushButton("Open  →"); b.clicked.connect(lambda:self.go(idx)); q.addWidget(b)
        return f

    def dashboard(self):
        w=QWidget(); l=QVBoxLayout(w); l.setContentsMargins(12,10,12,12); l.setSpacing(9)
        l.addWidget(Hero())
        grid=QGridLayout(); grid.setSpacing(8)
        cards=[
            ("Government Services","All Portals & Forms","#10b94b",1),
            ("State Schemes","Maharashtra","#ff7d16",2),
            ("Central Schemes","India","#087df5",3),
            ("Banking Services","All Bank Links","#8b35e8",4),
            ("Aadhaar / PAN","All Related Services","#ef268b",5),
            ("Voter ID & Election","Voter Portal","#13a9d8",6),
            ("MahaSarathi","DL | RC | LL | Others","#f0c400",7),
            ("Passport Size Photo","Crop | Resize | Print","#10b94b",8),
            ("PVC Card Print","4x6 Layout | 8.5 x 5.5 cm","#ef4056",9),
        ]
        for i,c in enumerate(cards): grid.addWidget(self.service_card(*c),i//5,i%5)
        l.addLayout(grid)

        row=QHBoxLayout(); row.setSpacing(8)
        row.addWidget(self.panel("🔔  Recent Updates",[
            "25-09-2026     MahaSarathi Portal Working Fine   🟢 New",
            "24-09-2026     PM Awas Yojana Update",
            "23-09-2026     ABHA Card Download Issue",
            "22-09-2026     PDF to JPG High Quality Added",
            "21-09-2026     New PVC Card Layout Templates"
        ]),2)
        row.addWidget(self.panel("⭐  Important Schemes",[
            "🟠  PM Kisan Yojana       ›","🟠  PM Solar Yojana       ›",
            "🟠  PM Mudra Yojana       ›","🟠  PM Awas Yojana        ›","🔵  E Shram Card           ›"
        ]),1)
        row.addWidget(self.panel("🛠  Tools & Utilities",[
            "📷 Passport Size Photo     |  🪪 PVC Card Print",
            "📄 PDF to JPG              |  📑 PDF Merge / Split",
            "🧾 Receipt / Bill Maker     |  📝 CV / Bio Data",
            "🎨 Banner Maker             |  🗂 Downloads"
        ]),2)
        row.addWidget(self.panel("⬇  Download Manager",[
            "aadhaar_card.jpg        JPG       Completed",
            "pan_card.pdf            PDF       Completed",
            "photo_sheet.jpg         JPG       Completed",
            "cv_file.pdf             PDF       Completed"
        ]),2)
        l.addLayout(row)

        tools=QHBoxLayout(); tools.setSpacing(8)
        tools.addWidget(self.photo_preview_panel(),2)
        tools.addWidget(self.pvc_preview_panel(),2)
        tools.addWidget(self.pdf_preview_panel(),2)
        l.addLayout(tools)
        return w

    def photo_preview_panel(self):
        f=QFrame(); f.setObjectName("whitePanel"); q=QVBoxLayout(f)
        title=QLabel("📷  Passport Size Photo"); title.setObjectName("darkText"); title.setFont(QFont("Segoe UI",12,QFont.Bold)); q.addWidget(title)
        line=QHBoxLayout()
        box=QLabel("Photo Preview"); box.setAlignment(Qt.AlignCenter); box.setStyleSheet("color:#52708a;border:2px dashed #9bb0c0;border-radius:8px;"); box.setMinimumHeight(130); line.addWidget(box,1)
        opts=QVBoxLayout()
        for s in ["Photo Size: 3.5 x 4.5 cm","Layout: A4 (Multiple Photos)","Background: White","☑ Auto Crop","☑ Enhance Quality"]: 
            x=QLabel(s); x.setObjectName("darkText"); opts.addWidget(x)
        line.addLayout(opts,1); q.addLayout(line)
        b=QPushButton("Open Photo    Preview & Print    Save JPG/PDF"); b.setObjectName("blue"); b.clicked.connect(lambda:self.go(8)); q.addWidget(b)
        return f

    def pvc_preview_panel(self):
        f=QFrame(); f.setObjectName("whitePanel"); q=QVBoxLayout(f)
        t=QLabel("🪪  PVC Card Print (4x6 Layout)"); t.setObjectName("darkText"); t.setFont(QFont("Segoe UI",12,QFont.Bold)); q.addWidget(t)
        x=QLabel("┌─────────────────────┐\n│      CARD 1         │\n└─────────────────────┘\n\n┌─────────────────────┐\n│      CARD 2         │\n└─────────────────────┘")
        x.setObjectName("darkText"); x.setAlignment(Qt.AlignCenter); q.addWidget(x)
        b=QPushButton("Preview   |   Print   |   Save JPG/PDF"); b.setObjectName("green"); b.clicked.connect(lambda:self.go(9)); q.addWidget(b)
        return f

    def pdf_preview_panel(self):
        f=QFrame(); f.setObjectName("whitePanel"); q=QVBoxLayout(f)
        t=QLabel("📄  PDF to JPG Converter"); t.setObjectName("darkText"); t.setFont(QFont("Segoe UI",12,QFont.Bold)); q.addWidget(t)
        x=QLabel("☁\nDrag & Drop PDF File Here\nor\nChoose PDF File\n\nOutput: JPG (High Quality)   DPI: 300"); x.setObjectName("darkText"); x.setAlignment(Qt.AlignCenter); x.setStyleSheet("border:1px dashed #a8bdce;border-radius:8px;padding:10px;"); q.addWidget(x)
        b=QPushButton("Convert to JPG"); b.setObjectName("green"); b.clicked.connect(self.pdfjpg); q.addWidget(b)
        return f

    def title(self,a,b=""):
        w=QWidget(); l=QVBoxLayout(w); l.setContentsMargins(12,15,12,8)
        x=QLabel(a); x.setFont(QFont("Segoe UI",25,QFont.Bold)); l.addWidget(x)
        y=QLabel(b); y.setStyleSheet("color:#8eafc7"); l.addWidget(y); return w

    def links(self,name):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(self.title(name,"Quick access to services and official portals"))
        p=QFrame(); p.setObjectName("whitePanel"); g=QGridLayout(p)
        sites=[
            ("MahaSarathi","https://transport.maharashtra.gov.in/"),("Aadhaar Portal","https://uidai.gov.in/"),
            ("PAN Suvidha","https://www.pan.utiitsl.com/"),("Voter ID","https://voters.eci.gov.in/"),
            ("e-Shram","https://eshram.gov.in/"),("CSC Registration","https://register.csc.gov.in/"),
            ("Udyam Registration","https://udyamregistration.gov.in/"),("ABHA Card","https://abha.abdm.gov.in/"),
            ("PM Kisan","https://pmkisan.gov.in/"),("PM Solar","https://pmsuryaghar.gov.in/"),
            ("PM Mudra","https://www.mudra.org.in/"),("PM Awas","https://pmaymis.gov.in/")
        ]
        for i,(a,u) in enumerate(sites):
            b=QPushButton("🔗 "+a); b.setObjectName("blue"); b.clicked.connect(lambda _,u=u:webbrowser.open(u)); g.addWidget(b,i//3,i%3)
        l.addWidget(p); l.addStretch(); return w

    def photo(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(self.title("Passport Size Photo","Crop | Resize | Print | Save JPG/PDF"))
        p=QFrame(); p.setObjectName("whitePanel"); g=QGridLayout(p)
        self.pp=QLabel("No photo selected"); self.pp.setAlignment(Qt.AlignCenter); self.pp.setMinimumSize(380,480); self.pp.setStyleSheet("color:#52708a;border:2px dashed #9bb0c0")
        g.addWidget(self.pp,0,0,7,1)
        b=QPushButton("📷 Open Photo"); b.setObjectName("blue"); b.clicked.connect(self.pickphoto); g.addWidget(b,0,1)
        self.en=QCheckBox("Enhance Quality"); self.en.setChecked(True); g.addWidget(self.en,1,1)
        b=QPushButton("Preview & Print"); b.setObjectName("green"); g.addWidget(b,2,1)
        b=QPushButton("💾 Save as JPG"); b.setObjectName("purple"); b.clicked.connect(self.savephoto); g.addWidget(b,3,1)
        l.addWidget(p); l.addStretch(); return w

    def pickphoto(self):
        p,_=QFileDialog.getOpenFileName(self,"Choose Photo","","Images (*.jpg *.jpeg *.png *.webp)")
        if p:
            self.photo_path=p; self.pp.setPixmap(QPixmap(p).scaled(self.pp.size(),Qt.KeepAspectRatio,Qt.SmoothTransformation))

    def savephoto(self):
        if not hasattr(self,"photo_path"): return QMessageBox.warning(self,"Photo","Pehle photo select karo.")
        im=Image.open(self.photo_path).convert("RGB")
        if self.en.isChecked(): im=ImageEnhance.Sharpness(im).enhance(1.4)
        im.thumbnail((413,531)); out=OUT/"passport_photo.jpg"; im.save(out,quality=98,dpi=(300,300))
        QMessageBox.information(self,"Saved",str(out)); self.refresh_downloads()

    def pvc(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(self.title("PVC Card Print (4x6 Layout)","Card 8.5 × 5.5 cm • 2 Top & Bottom"))
        p=QFrame(); p.setObjectName("whitePanel"); g=QGridLayout(p)
        self.c1=QLineEdit(); self.c2=QLineEdit()
        self.c1.setPlaceholderText("Card 1 image"); self.c2.setPlaceholderText("Card 2 image")
        for r,e in [(0,self.c1),(1,self.c2)]:
            b=QPushButton("Choose Card"); b.setObjectName("blue"); b.clicked.connect(lambda _,e=e:self.pickcard(e)); g.addWidget(e,r,0); g.addWidget(b,r,1)
        b=QPushButton("🖨 Create 4x6 + Preview"); b.setObjectName("green"); b.clicked.connect(self.makepvc); g.addWidget(b,2,1)
        l.addWidget(p); l.addStretch(); return w

    def pickcard(self,e):
        p,_=QFileDialog.getOpenFileName(self,"Choose Card","","Images (*.jpg *.jpeg *.png)")
        if p: e.setText(p)

    def makepvc(self):
        ps=[e.text() for e in [self.c1,self.c2] if e.text()]
        if not ps: return QMessageBox.warning(self,"PVC","Card images select karo.")
        im=Image.new("RGB",(1200,1800),"white")
        for i,p in enumerate(ps[:2]):
            x=Image.open(p).convert("RGB"); x.thumbnail((950,650)); im.paste(x,((1200-x.width)//2,100+i*830))
        jpg=OUT/"pvc_4x6.jpg"; pdf=OUT/"pvc_4x6.pdf"; im.save(jpg,quality=98,dpi=(300,300)); im.save(pdf,resolution=300)
        QMessageBox.information(self,"Saved",f"{jpg}\n{pdf}"); self.refresh_downloads()

    def pdf(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(self.title("PDF Tools","PDF → JPG 300 DPI | Merge | Split"))
        p=QFrame(); p.setObjectName("whitePanel"); g=QGridLayout(p)
        for i,(t,fn,c) in enumerate([("PDF → JPG (300 DPI)",self.pdfjpg,"blue"),("Merge PDF",self.merge,"green"),("Split PDF",self.split,"orange")]):
            b=QPushButton(t); b.setObjectName(c); b.clicked.connect(fn); g.addWidget(b,0,i)
        l.addWidget(p); l.addStretch(); return w

    def pdfjpg(self):
        p,_=QFileDialog.getOpenFileName(self,"PDF","","PDF (*.pdf)")
        if not p:return
        try:
            d=fitz.open(p); folder=OUT/(Path(p).stem+"_JPG"); folder.mkdir(exist_ok=True)
            for i,page in enumerate(d): page.get_pixmap(dpi=300,alpha=False).save(str(folder/f"page_{i+1}.jpg"))
            QMessageBox.information(self,"Done",str(folder)); self.refresh_downloads()
        except Exception as e: QMessageBox.critical(self,"PDF Error",str(e))

    def merge(self):
        fs,_=QFileDialog.getOpenFileNames(self,"PDFs","","PDF (*.pdf)")
        if len(fs)<2:return
        out=OUT/"merged.pdf"; d=fitz.open()
        for f in fs:d.insert_pdf(fitz.open(f))
        d.save(out); QMessageBox.information(self,"Saved",str(out)); self.refresh_downloads()

    def split(self):
        p,_=QFileDialog.getOpenFileName(self,"PDF","","PDF (*.pdf)")
        if not p:return
        d=fitz.open(p); folder=OUT/(Path(p).stem+"_split"); folder.mkdir(exist_ok=True)
        for i in range(len(d)):
            x=fitz.open(); x.insert_pdf(d,from_page=i,to_page=i); x.save(str(folder/f"page_{i+1}.pdf"))
        QMessageBox.information(self,"Saved",str(folder)); self.refresh_downloads()

    def cv(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(self.title("CV / Bio Data Maker","A4 professional PDF"))
        p=QFrame(); p.setObjectName("whitePanel"); g=QGridLayout(p)
        self.cvname=QLineEdit(); self.cvname.setPlaceholderText("Full Name")
        self.cvbody=QTextEdit(); self.cvbody.setPlaceholderText("Education | Experience | Skills | Address")
        g.addWidget(self.cvname,0,0,1,2); g.addWidget(self.cvbody,1,0,1,2)
        b=QPushButton("Save CV as PDF"); b.setObjectName("purple"); b.clicked.connect(self.savecv); g.addWidget(b,2,1)
        l.addWidget(p); l.addStretch(); return w

    def savecv(self):
        out=OUT/"cv_biodata.pdf"; c=canvas.Canvas(str(out)); c.setFont("Helvetica-Bold",22); c.drawString(50,800,self.cvname.text() or "Name")
        c.setFont("Helvetica",11); y=760
        for x in self.cvbody.toPlainText().splitlines(): c.drawString(50,y,x[:110]); y-=18
        c.save(); QMessageBox.information(self,"Saved",str(out)); self.refresh_downloads()

    def banner(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(self.title("Banner Maker","Create and save a professional JPG banner"))
        p=QFrame(); p.setObjectName("whitePanel"); g=QGridLayout(p)
        self.bt=QLineEdit("Muzammil Online Service & Xerox"); self.bs=QLineEdit("Online Forms | Printing | Xerox | Design")
        self.bw=QSpinBox(); self.bw.setRange(600,3000); self.bw.setValue(1600)
        self.bh=QSpinBox(); self.bh.setRange(200,1500); self.bh.setValue(500)
        for row,label,widget in [(0,"Title",self.bt),(1,"Subtitle",self.bs),(2,"Width",self.bw),(3,"Height",self.bh)]:
            g.addWidget(QLabel(label),row,0); g.addWidget(widget,row,1)
        b=QPushButton("Create Banner JPG"); b.setObjectName("blue"); b.clicked.connect(self.make_banner); g.addWidget(b,4,1)
        l.addWidget(p); l.addStretch(); return w

    def make_banner(self):
        from PIL import Image,ImageDraw,ImageFont
        W,H=self.bw.value(),self.bh.value(); im=Image.new("RGB",(W,H),(5,37,67)); d=ImageDraw.Draw(im)
        d.rectangle((10,10,W-10,H-10),outline=(0,150,255),width=max(3,W//300))
        try:
            fb=ImageFont.truetype("DejaVuSans-Bold.ttf",max(24,W//20)); fn=ImageFont.truetype("DejaVuSans.ttf",max(16,W//42))
        except: fb=fn=None
        d.text((50,H//4),self.bt.text(),fill="white",font=fb); d.text((55,H//2),self.bs.text(),fill=(255,220,0),font=fn)
        out=OUT/"banner.jpg"; im.save(out,quality=98,dpi=(150,150)); QMessageBox.information(self,"Banner Saved",str(out)); self.refresh_downloads()

    def receipt(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(self.title("Bill / Receipt Maker","Create and save a printable A4 receipt PDF"))
        p=QFrame(); p.setObjectName("whitePanel"); g=QGridLayout(p)
        self.rc=QLineEdit(); self.rc.setPlaceholderText("Customer Name"); self.rd=QLineEdit(); self.rd.setPlaceholderText("Description")
        self.ra=QLineEdit(); self.ra.setPlaceholderText("Amount"); self.rn=QLineEdit(); self.rn.setPlaceholderText("Receipt Number")
        g.addWidget(self.rc,0,0); g.addWidget(self.rn,0,1); g.addWidget(self.rd,1,0); g.addWidget(self.ra,1,1)
        b=QPushButton("Save Receipt PDF"); b.setObjectName("green"); b.clicked.connect(self.make_receipt); g.addWidget(b,2,1)
        l.addWidget(p); l.addStretch(); return w

    def make_receipt(self):
        out=OUT/"receipt.pdf"; c=canvas.Canvas(str(out),pagesize=(595,842)); c.setFont("Helvetica-Bold",22); c.drawString(50,790,"Muzammil Online Service & Xerox")
        c.setFont("Helvetica",12); c.drawString(50,750,"Receipt No: "+self.rn.text()); c.drawString(50,720,"Customer: "+self.rc.text()); c.drawString(50,690,"Description: "+self.rd.text()); c.drawString(50,660,"Amount: Rs. "+self.ra.text()); c.line(50,640,545,640); c.drawString(50,600,"Thank you."); c.save()
        QMessageBox.information(self,"Receipt Saved",str(out)); self.refresh_downloads()

    def downloads(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(self.title("Download Manager","Files generated by the application"))
        self.table=QTableWidget(0,4); self.table.setHorizontalHeaderLabels(["File","Type","Size","Status"]); self.table.horizontalHeader().setStretchLastSection(True); l.addWidget(self.table)
        return w

    def refresh_downloads(self):
        if not hasattr(self,"table"): return
        self.table.setRowCount(0)
        for p in sorted(OUT.iterdir(),key=lambda x:x.stat().st_mtime,reverse=True):
            r=self.table.rowCount(); self.table.insertRow(r)
            size=f"{p.stat().st_size/1024:.0f} KB" if p.is_file() else "Folder"
            vals=[p.name, p.suffix.upper().replace(".","") or "Folder", size, "Completed"]
            for c,v in enumerate(vals): self.table.setItem(r,c,QTableWidgetItem(v))

    def settings(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(self.title("Settings","Application settings"))
        p=QFrame(); p.setObjectName("whitePanel"); q=QVBoxLayout(p)
        q.addWidget(QLabel("Downloads folder: "+str(OUT)))
        b=QPushButton("Open Downloads Folder"); b.setObjectName("blue"); b.clicked.connect(lambda:os.startfile(OUT)); q.addWidget(b)
        q.addWidget(QLabel("Theme: Dark Blue • Language: English / Roman Hindi / Marathi"))
        q.addWidget(QLabel("All generated files are stored locally."))
        l.addWidget(p); l.addStretch(); return w

app=QApplication(sys.argv)
win=App(); win.show()
sys.exit(app.exec())
