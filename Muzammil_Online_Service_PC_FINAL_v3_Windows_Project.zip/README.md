# Muzammil Online Service & Xerox — FINAL PC Version

Windows desktop application with the same dark-blue service-center style.

Working modules:
- Dashboard and navigation
- Government/Maharashtra/Central/Banking portal links
- Passport photo processing and JPG output
- PVC 4x6 two-card layout and JPG/PDF output
- PDF to JPG at 300 DPI
- PDF merge and split
- CV/Bio Data PDF
- Banner Maker JPG
- Bill/Receipt PDF
- Download Manager
- Settings/local folders
- GitHub Actions Windows EXE packaging

Build:
1. Extract this project into the repository root.
2. Keep `main.py`, `requirements.txt`, and `.github/workflows/build-windows.yml` at root.
3. Run GitHub Actions workflow.
