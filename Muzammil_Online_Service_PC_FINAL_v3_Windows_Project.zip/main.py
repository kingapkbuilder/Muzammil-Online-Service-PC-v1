import sys, os, webbrowser
from pathlib import Path
from datetime import datetime
from PySide6.QtWidgets import *
from PySide6.QtCore import Qt,QTimer
from PySide6.QtGui import QFont,QPixmap
import fitz
from PIL import Image,ImageEnhance
from reportlab.pdfgen import canvas

OUT=Path.home()/"Downloads"/"Muzammil Online Service"; OUT.mkdir(parents=True,exist_ok=True)
CSS="""
QMainWindow,QWidget{background:#061827;color:white;font-family:Segoe UI}
#head{background:#071d30;border-bottom:2px solid #087df5}
#side{background:#061827}
QPushButton#nav{background:transparent;color:white;text-align:left;padding:11px;border-radius:8px}
QPushButton#nav:hover{background:#087df5}
QFrame#panel{background:#f5f9fd;border-radius:12px;color:#09233a}
QPushButton{padding:9px;border-radius:8px;font-weight:bold}
QPushButton#blue{background:#087df5;color:white} QPushButton#green{background:#10b94b;color:white}
QPushButton#purple{background:#8b35e8;color:white} QPushButton#orange{background:#ff8500;color:white}
QLineEdit,QComboBox,QTextEdit{background:white;color:#10283d;padding:8px;border-radius:7px;border:1px solid #b8ccdd}
"""

class App(QMainWindow):
 def __init__(self):
  super().__init__(); self.setWindowTitle("Muzammil Online Service & Xerox - PC Version"); self.resize(1500,950); self.setStyleSheet(CSS)
  root=QWidget(); v=QVBoxLayout(root);v.setContentsMargins(0,0,0,0)
  h=QFrame();h.setObjectName("head");hl=QHBoxLayout(h)
  logo=QLabel("🖨️  Muzammil\nOnline Service & Xerox");logo.setFont(QFont("Segoe UI",18,QFont.Bold));hl.addWidget(logo)
  self.search=QLineEdit();self.search.setPlaceholderText("Search Service, Scheme or Website...");hl.addWidget(self.search,1)
  self.clock=QLabel();hl.addWidget(self.clock);lang=QComboBox();lang.addItems(["English","Roman Hindi","Marathi"]);hl.addWidget(lang);hl.addWidget(QPushButton("☀  ☾"));hl.addWidget(QPushButton("🔔"))
  v.addWidget(h);body=QHBoxLayout();body.setContentsMargins(0,0,0,0)
  side=QFrame();side.setObjectName("side");side.setFixedWidth(235);sl=QVBoxLayout(side)
  names=["⌂  Dashboard","🏛  Government Services","🏛  State Schemes (Maharashtra)","🏛  Central Schemes (India)","🏦  Banking Services","▣  Aadhaar & PAN","🚗  Mahasarathi (DL/RC)","▣  Passport Size Photo","▤  PVC Card Print","▱  PDF Tools","▧  CV / Bio Data Maker","⚑  Banner Maker","▣  Bill / Receipt","⬇  Downloads","⚙  Utilities & Tools","⚙  Settings"]
  for i,n in enumerate(names):
   b=QPushButton(n);b.setObjectName("nav");b.clicked.connect(lambda _,i=i:self.go(i));sl.addWidget(b)
  sl.addStretch();sl.addWidget(QLabel("🎧  Muzammil\nOnline Service & Xerox\n\nFast | Trusted | All in One\nVersion 2.0.0 (PC)"))
  body.addWidget(side);self.stack=QStackedWidget();body.addWidget(self.stack,1);v.addLayout(body,1);self.setCentralWidget(root)
  pages=[self.dashboard(),self.links("Government Services"),self.links("Maharashtra State Schemes"),self.links("Central Government Schemes"),self.links("Banking Services"),self.links("Aadhaar & PAN"),self.links("MahaSarathi (DL/RC)"),self.photo(),self.pvc(),self.pdf(),self.cv(),self.banner(),self.receipt(),self.downloads(),self.links("Utilities & Tools"),self.settings()]
  for p in pages:self.stack.addWidget(p)
  t=QTimer(self);t.timeout.connect(lambda:self.clock.setText(datetime.now().strftime("%I:%M:%S %p\n%d-%m-%Y")));t.start(1000)

 def go(self,i):self.stack.setCurrentIndex(i)
 def title(self,a,b=""):
  w=QWidget();l=QVBoxLayout(w);x=QLabel(a);x.setFont(QFont("Segoe UI",24,QFont.Bold));l.addWidget(x);y=QLabel(b);y.setStyleSheet("color:#8eafc7");l.addWidget(y);return w
 def card(self,a,b,c,i):
  f=QFrame();f.setStyleSheet(f"background:{c};border-radius:12px");l=QVBoxLayout(f);x=QLabel(a);x.setFont(QFont("Segoe UI",14,QFont.Bold));l.addWidget(x);l.addWidget(QLabel(b));q=QPushButton("Open →");q.clicked.connect(lambda:self.go(i));l.addWidget(q);return f
 def dashboard(self):
  w=QWidget();l=QVBoxLayout(w);l.addWidget(self.title("Muzammil Online Service & Xerox","All Government Services | Online Forms | Printing | Xerox | Design"))
  g=QGridLayout(); data=[("Government Services","All Portals & Forms","#12b83f",1),("Banking Services","All Bank Links","#ff8500",4),("MahaSarathi","DL | RC | LL | Others","#078df5",6),("Aadhaar / PAN","All Related Services","#8b35e8",5),("State Schemes Maharashtra","All State Yojana","#ef268b",2),("Central Schemes India","All Central Yojana","#f0c400",3),("Passport Size Photo","Crop | Resize | Print","#10b8aa",7),("PVC Card Print","4x6 Layout | 8.5 x 5.5 cm","#10b94b",8),("PDF Tools","PDF to JPG | Merge | Split","#078df5",9)]
  for n,x in enumerate(data):g.addWidget(self.card(*x),n//4,n%4)
  l.addLayout(g);row=QHBoxLayout()
  for t in ["Recent Updates","Important Schemes","Tools & Utilities","Download Manager"]:
   f=QFrame();f.setObjectName("panel");q=QVBoxLayout(f);z=QLabel(t);z.setStyleSheet("color:#09233a;font-weight:bold");q.addWidget(z)
   for s in ["MahaSarathi Portal Working Fine","PM Kisan Yojana","Passport Size Photo","PVC Card Print","PDF to JPG","Completed"]:q.addWidget(QLabel("• "+s))
   row.addWidget(f)
  l.addLayout(row);l.addStretch();return w
 def links(self,name):
  w=QWidget();l=QVBoxLayout(w);l.addWidget(self.title(name,"Quick access to services and official portals"));p=QFrame();p.setObjectName("panel");g=QGridLayout(p)
  sites=[("MahaSarathi","https://transport.maharashtra.gov.in/"),("Aadhaar Portal","https://uidai.gov.in/"),("PAN Suvidha","https://www.pan.utiitsl.com/"),("Voter ID","https://voters.eci.gov.in/"),("e-Shram","https://eshram.gov.in/"),("CSC Registration","https://register.csc.gov.in/"),("Udyam Registration","https://udyamregistration.gov.in/"),("ABHA Card","https://abha.abdm.gov.in/"),("PM Kisan","https://pmkisan.gov.in/"),("PM Solar","https://pmsuryaghar.gov.in/"),("PM Mudra","https://www.mudra.org.in/"),("PM Awas","https://pmaymis.gov.in/")]
  for i,(a,u) in enumerate(sites):
   b=QPushButton("🔗 "+a);b.setObjectName("blue");b.clicked.connect(lambda _,u=u:webbrowser.open(u));g.addWidget(b,i//3,i%3)
  l.addWidget(p);l.addStretch();return w
 def photo(self):
  w=QWidget();l=QVBoxLayout(w);l.addWidget(self.title("Passport Size Photo","Crop | Resize | Print | Save JPG/PDF"));p=QFrame();p.setObjectName("panel");g=QGridLayout(p)
  self.pp=QLabel("No photo selected");self.pp.setAlignment(Qt.AlignCenter);self.pp.setMinimumSize(380,480);self.pp.setStyleSheet("color:#52708a;border:2px dashed #9bb0c0");g.addWidget(self.pp,0,0,6,1)
  b=QPushButton("📷 Open Photo");b.setObjectName("blue");b.clicked.connect(self.pickphoto);g.addWidget(b,0,1)
  self.en=QCheckBox("Enhance Quality");self.en.setChecked(True);g.addWidget(self.en,1,1)
  b=QPushButton("💾 Save as JPG");b.setObjectName("green");b.clicked.connect(self.savephoto);g.addWidget(b,2,1);l.addWidget(p);l.addStretch();return w
 def pickphoto(self):
  p,_=QFileDialog.getOpenFileName(self,"Choose Photo","","Images (*.jpg *.jpeg *.png *.webp)")
  if p:self.photo_path=p;self.pp.setPixmap(QPixmap(p).scaled(self.pp.size(),Qt.KeepAspectRatio,Qt.SmoothTransformation))
 def savephoto(self):
  if not hasattr(self,"photo_path"):return QMessageBox.warning(self,"Photo","Pehle photo select karo.")
  im=Image.open(self.photo_path).convert("RGB")
  if self.en.isChecked():im=ImageEnhance.Sharpness(im).enhance(1.4)
  im.thumbnail((413,531));out=OUT/"passport_photo.jpg";im.save(out,quality=98,dpi=(300,300));QMessageBox.information(self,"Saved",str(out))
 def pvc(self):
  w=QWidget();l=QVBoxLayout(w);l.addWidget(self.title("PVC Card Print (4x6 Layout)","Card 8.5 × 5.5 cm • 2 Top & Bottom"));p=QFrame();p.setObjectName("panel");g=QGridLayout(p)
  self.c1=QLineEdit();self.c1.setPlaceholderText("Card 1 image");self.c2=QLineEdit();self.c2.setPlaceholderText("Card 2 image")
  for r,e in [(0,self.c1),(1,self.c2)]:
   b=QPushButton("Choose Card");b.setObjectName("blue");b.clicked.connect(lambda _,e=e:self.pickcard(e));g.addWidget(e,r,0);g.addWidget(b,r,1)
  b=QPushButton("🖨 Create 4x6");b.setObjectName("green");b.clicked.connect(self.makepvc);g.addWidget(b,2,1);l.addWidget(p);l.addStretch();return w
 def pickcard(self,e):
  p,_=QFileDialog.getOpenFileName(self,"Choose Card","","Images (*.jpg *.jpeg *.png)");e.setText(p) if p else None
 def makepvc(self):
  ps=[e.text() for e in [self.c1,self.c2] if e.text()]
  if not ps:return
  im=Image.new("RGB",(1200,1800),"white")
  for i,p in enumerate(ps[:2]):
   x=Image.open(p).convert("RGB");x.thumbnail((950,650));im.paste(x,((1200-x.width)//2,100+i*830))
  im.save(OUT/"pvc_4x6.jpg",quality=98,dpi=(300,300));im.save(OUT/"pvc_4x6.pdf",resolution=300);QMessageBox.information(self,"Saved",str(OUT))
 def pdf(self):
  w=QWidget();l=QVBoxLayout(w);l.addWidget(self.title("PDF Tools","PDF → JPG 300 DPI | Merge | Split"));p=QFrame();p.setObjectName("panel");g=QGridLayout(p)
  for i,(t,fn,c) in enumerate([("PDF → JPG (300 DPI)",self.pdfjpg,"blue"),("Merge PDF",self.merge,"green"),("Split PDF",self.split,"orange")]):
   b=QPushButton(t);b.setObjectName(c);b.clicked.connect(fn);g.addWidget(b,0,i)
  l.addWidget(p);l.addStretch();return w
 def pdfjpg(self):
  p,_=QFileDialog.getOpenFileName(self,"PDF","","PDF (*.pdf)")
  if not p:return
  d=fitz.open(p);folder=OUT/(Path(p).stem+"_JPG");folder.mkdir(exist_ok=True)
  for i,page in enumerate(d):page.get_pixmap(dpi=300,alpha=False).save(str(folder/f"page_{i+1}.jpg"))
  QMessageBox.information(self,"Done",str(folder))
 def merge(self):
  fs,_=QFileDialog.getOpenFileNames(self,"PDFs","","PDF (*.pdf)")
  if len(fs)<2:return
  out=str(OUT/"merged.pdf");d=fitz.open()
  for f in fs:d.insert_pdf(fitz.open(f))
  d.save(out);QMessageBox.information(self,"Saved",out)
 def split(self):
  p,_=QFileDialog.getOpenFileName(self,"PDF","","PDF (*.pdf)")
  if not p:return
  d=fitz.open(p);folder=OUT/(Path(p).stem+"_split");folder.mkdir(exist_ok=True)
  for i in range(len(d)):
   x=fitz.open();x.insert_pdf(d,from_page=i,to_page=i);x.save(str(folder/f"page_{i+1}.pdf"))
  QMessageBox.information(self,"Saved",str(folder))
 def cv(self):
  w=QWidget();l=QVBoxLayout(w);l.addWidget(self.title("CV / Bio Data Maker","A4 professional PDF"));p=QFrame();p.setObjectName("panel");g=QGridLayout(p)
  self.cvname=QLineEdit();self.cvname.setPlaceholderText("Full Name");self.cvbody=QTextEdit();self.cvbody.setPlaceholderText("Education | Experience | Skills | Address")
  g.addWidget(self.cvname,0,0,1,2);g.addWidget(self.cvbody,1,0,1,2);b=QPushButton("Save CV as PDF");b.setObjectName("purple");b.clicked.connect(self.savecv);g.addWidget(b,2,1);l.addWidget(p);l.addStretch();return w
 def savecv(self):
  out=OUT/"cv_biodata.pdf";c=canvas.Canvas(str(out));c.setFont("Helvetica-Bold",22);c.drawString(50,800,self.cvname.text() or "Name");c.setFont("Helvetica",11);y=760
  for x in self.cvbody.toPlainText().splitlines():c.drawString(50,y,x[:110]);y-=18
  c.save();QMessageBox.information(self,"Saved",str(out))
 def banner(self):
  w=QWidget();l=QVBoxLayout(w);l.addWidget(self.title("Banner Maker","Create and save a professional JPG banner"))
  p=QFrame();p.setObjectName("panel");g=QGridLayout(p)
  self.bt=QLineEdit("Muzammil Online Service & Xerox"); self.bs=QLineEdit("Online Forms | Printing | Xerox | Design")
  self.bw=QSpinBox();self.bw.setRange(600,3000);self.bw.setValue(1600)
  self.bh=QSpinBox();self.bh.setRange(200,1500);self.bh.setValue(500)
  g.addWidget(QLabel("Title"),0,0);g.addWidget(self.bt,0,1);g.addWidget(QLabel("Subtitle"),1,0);g.addWidget(self.bs,1,1)
  g.addWidget(QLabel("Width"),2,0);g.addWidget(self.bw,2,1);g.addWidget(QLabel("Height"),3,0);g.addWidget(self.bh,3,1)
  b=QPushButton("Create Banner JPG");b.setObjectName("blue");b.clicked.connect(self.make_banner);g.addWidget(b,4,1)
  l.addWidget(p);l.addStretch();return w
 def make_banner(self):
  from PIL import Image,ImageDraw,ImageFont
  W,H=self.bw.value(),self.bh.value(); im=Image.new("RGB",(W,H),(5,37,67));d=ImageDraw.Draw(im)
  d.rectangle((10,10,W-10,H-10),outline=(0,150,255),width=max(3,W//300))
  try:
   fb=ImageFont.truetype("DejaVuSans-Bold.ttf",max(24,W//20)); fn=ImageFont.truetype("DejaVuSans.ttf",max(16,W//42))
  except: fb=fn=None
  d.text((50,H//4),self.bt.text(),fill="white",font=fb);d.text((55,H//2),self.bs.text(),fill=(255,220,0),font=fn)
  out=OUT/"banner.jpg";im.save(out,quality=98,dpi=(150,150));QMessageBox.information(self,"Banner Saved",str(out))
 def receipt(self):
  w=QWidget();l=QVBoxLayout(w);l.addWidget(self.title("Bill / Receipt Maker","Create and save a printable A4 receipt PDF"))
  p=QFrame();p.setObjectName("panel");g=QGridLayout(p)
  self.rc=QLineEdit();self.rc.setPlaceholderText("Customer Name");self.rd=QLineEdit();self.rd.setPlaceholderText("Description")
  self.ra=QLineEdit();self.ra.setPlaceholderText("Amount");self.rn=QLineEdit();self.rn.setPlaceholderText("Receipt Number")
  g.addWidget(self.rc,0,0);g.addWidget(self.rn,0,1);g.addWidget(self.rd,1,0);g.addWidget(self.ra,1,1)
  b=QPushButton("Save Receipt PDF");b.setObjectName("green");b.clicked.connect(self.make_receipt);g.addWidget(b,2,1)
  l.addWidget(p);l.addStretch();return w
 def make_receipt(self):
  out=OUT/"receipt.pdf";c=canvas.Canvas(str(out),pagesize=(595,842));c.setFont("Helvetica-Bold",22);c.drawString(50,790,"Muzammil Online Service & Xerox")
  c.setFont("Helvetica",12);c.drawString(50,750,"Receipt No: "+self.rn.text());c.drawString(50,720,"Customer: "+self.rc.text());c.drawString(50,690,"Description: "+self.rd.text());c.drawString(50,660,"Amount: Rs. "+self.ra.text());c.line(50,640,545,640);c.drawString(50,600,"Thank you.");c.save();QMessageBox.information(self,"Receipt Saved",str(out))
 def downloads(self):
  w=QWidget();l=QVBoxLayout(w);l.addWidget(self.title("Download Manager","Files generated by the application"));t=QTableWidget(0,2);t.setHorizontalHeaderLabels(["File","Location"]);l.addWidget(t)
  for p in OUT.iterdir():r=t.rowCount();t.insertRow(r);t.setItem(r,0,QTableWidgetItem(p.name));t.setItem(r,1,QTableWidgetItem(str(p)))
  return w
 def settings(self):
  w=QWidget();l=QVBoxLayout(w);l.addWidget(self.title("Settings","Application settings"))
  p=QFrame();p.setObjectName("panel");q=QVBoxLayout(p)
  q.addWidget(QLabel("Downloads folder: "+str(OUT)))
  b=QPushButton("Open Downloads Folder");b.setObjectName("blue");b.clicked.connect(lambda:os.startfile(OUT));q.addWidget(b)
  c=QPushButton("Open Application Folder");c.setObjectName("blue");c.clicked.connect(lambda:os.startfile(Path.cwd()));q.addWidget(c)
  q.addWidget(QLabel("All generated files are stored locally in the Muzammil Online Service Downloads folder."))
  l.addWidget(p);l.addStretch();return w

app=QApplication(sys.argv);win=App();win.show();sys.exit(app.exec())
