import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Initialize Google Gen AI
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// In-Memory Live Operator Sessions Tracker
interface LiveSession {
  sessionId: string;
  username: string;
  displayName: string;
  role: 'admin' | 'operator';
  phone: string;
  deviceType: 'pc' | 'mobile';
  deviceId: string;
  deviceName: string;
  currentTab: string;
  currentTask?: string;
  loginTime: string;
  lastHeartbeat: string;
  validityExpiresAt: string;
  ipAddress?: string;
}

const liveSessions = new Map<string, LiveSession>();
const operatorBroadcasts = new Map<string, { message: string; timestamp: number }>();

// Live Operator Heartbeat endpoint
app.post('/api/live/heartbeat', (req, res) => {
  const { 
    sessionId, 
    username, 
    displayName, 
    role, 
    phone, 
    deviceType, 
    deviceId, 
    deviceName, 
    currentTab, 
    currentTask, 
    validityExpiresAt 
  } = req.body;

  if (!username || !deviceId) {
    return res.status(400).json({ error: 'Missing session parameters' });
  }

  const key = `${username}_${deviceId}`;
  const now = new Date().toISOString();

  liveSessions.set(key, {
    sessionId: sessionId || key,
    username,
    displayName: displayName || username,
    role: role || 'operator',
    phone: phone || '',
    deviceType: deviceType || 'pc',
    deviceId,
    deviceName: deviceName || 'Workstation',
    currentTab: currentTab || 'Dashboard',
    currentTask: currentTask || 'Active',
    loginTime: liveSessions.get(key)?.loginTime || now,
    lastHeartbeat: now,
    validityExpiresAt: (role === 'admin' || username === 'admin') ? 'Lifetime (Never Expires)' : (validityExpiresAt || '2026-12-31'),
    ipAddress: req.ip || req.socket.remoteAddress
  });

  // Check if there is an active broadcast or force-disconnect for this user
  const broadcast = operatorBroadcasts.get(username);
  let alertMsg = null;
  if (broadcast && Date.now() - broadcast.timestamp < 30000) {
    alertMsg = broadcast.message;
  }

  return res.json({ 
    success: true, 
    activeCount: liveSessions.size,
    broadcastMessage: alertMsg
  });
});

// Get all Live Operator Sessions (for Master Admin live monitor)
app.get('/api/live/sessions', (_req, res) => {
  const now = Date.now();
  const activeList: (LiveSession & { isOnline: boolean; lastActiveSecondsAgo: number })[] = [];

  // Filter out sessions dead for over 60 seconds
  for (const [key, session] of liveSessions.entries()) {
    const lastTime = new Date(session.lastHeartbeat).getTime();
    const diffSec = Math.round((now - lastTime) / 1000);

    if (diffSec > 180) {
      liveSessions.delete(key);
    } else {
      activeList.push({
        ...session,
        isOnline: diffSec < 20,
        lastActiveSecondsAgo: diffSec
      });
    }
  }

  return res.json({ 
    sessions: activeList,
    totalActive: activeList.filter(s => s.isOnline).length
  });
});

// Master Admin Force Disconnect endpoint
app.post('/api/live/terminate', (req, res) => {
  const { username, deviceId } = req.body;
  if (!username) return res.status(400).json({ error: 'Username required' });

  if (deviceId) {
    liveSessions.delete(`${username}_${deviceId}`);
  } else {
    for (const key of liveSessions.keys()) {
      if (key.startsWith(`${username}_`)) {
        liveSessions.delete(key);
      }
    }
  }

  operatorBroadcasts.set(username, {
    message: 'FORCE_DISCONNECTED_BY_ADMIN',
    timestamp: Date.now()
  });

  return res.json({ success: true, message: `Operator ${username} session terminated` });
});

// Master Admin Broadcast Alert to Operator
app.post('/api/live/broadcast', (req, res) => {
  const { username, message } = req.body;
  if (!username || !message) return res.status(400).json({ error: 'Missing username or message' });

  operatorBroadcasts.set(username, {
    message,
    timestamp: Date.now()
  });

  return res.json({ success: true });
});

// In-App Web Portal Proxy (fetches websites or documents safely without X-Frame-Options blocking)
app.get('/api/portal-proxy', async (req, res) => {
  const targetUrl = req.query.url as string;
  if (!targetUrl) {
    return res.status(400).send('Missing target URL');
  }

  try {
    const fetchResponse = await fetch(targetUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      }
    });

    const contentType = fetchResponse.headers.get('content-type') || 'text/html';
    res.setHeader('Content-Type', contentType);
    // Remove frame restricting headers so it renders inside the app
    res.removeHeader('X-Frame-Options');
    res.removeHeader('Content-Security-Policy');

    if (contentType.includes('text/html')) {
      let html = await fetchResponse.text();
      // Inject base tag so relative assets resolve properly
      const baseTag = `<base href="${new URL(targetUrl).origin}/" />`;
      html = html.replace('<head>', `<head>${baseTag}`);
      return res.send(html);
    } else {
      const buffer = await fetchResponse.arrayBuffer();
      return res.send(Buffer.from(buffer));
    }
  } catch (err: any) {
    return res.status(500).send(`Unable to load portal: ${err.message}`);
  }
});

// AI Assistant Endpoint for citizen schemes
app.post('/api/assistant', async (req, res) => {
  const { prompt } = req.body;
  if (!prompt) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  if (!ai) {
    return res.json({
      reply: null,
      message: 'Server Gemini API key not initialized'
    });
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: `You are the AI Digital Assistant for Muzammil Online Service (a premier CSC & Cyber Cafe in Maharashtra, India).
You provide accurate, polite, and practical guidance in Hindi, English, or Hinglish to operators and citizens for:
- Majhi Ladki Bahin Yojana, PM-KISAN, Ayushman Bharat (PM-JAY), PM Surya Ghar, PM Awas, Ration Card
- Aadhaar update/download, PAN card (New 49A / Correction / Link), Voter ID, Driving Licence (Sarathi/Parivahan)
- Mahadbt scholarships, Aaple Sarkar revenue certificates (Income, Caste, Domicile, Non-Creamy Layer, 7/12)
- PVC card printing (CR-80 standard 85.6x54mm, 4x6 300 DPI) and passport photo specifications.
Always provide clear bullet points: 1) Eligibility, 2) Required Documents Checklist, 3) Official Portal Procedure, and 4) Important Deadlines / Tips. Keep the tone helpful, professional, and cyber cafe oriented.`
      }
    });

    const reply = response.text || '';
    return res.json({ reply });
  } catch (error: any) {
    console.error('Gemini error:', error);
    return res.json({
      reply: null,
      error: error.message || 'Gemini API call failed'
    });
  }
});

// Endpoint to download original complete project source ZIP
app.get('/api/download-zip', async (_req, res) => {
  try {
    const { default: JSZip } = await import('jszip');
    const fs = await import('fs');
    const zip = new JSZip();

    function addDirToZip(dirPath: string, zipFolder: any) {
      const entries = fs.readdirSync(dirPath, { withFileTypes: true });
      for (const entry of entries) {
        const fullPath = path.join(dirPath, entry.name);
        if (entry.name === 'node_modules' || entry.name === '.git') {
          continue;
        }
        if (entry.isDirectory()) {
          const subFolder = zipFolder.folder(entry.name);
          addDirToZip(fullPath, subFolder);
        } else {
          const fileData = fs.readFileSync(fullPath);
          zipFolder.file(entry.name, fileData);
        }
      }
    }

    addDirToZip(__dirname, zip);

    const zipBuffer = await zip.generateAsync({
      type: 'nodebuffer',
      compression: 'DEFLATE',
      compressionOptions: { level: 9 }
    });

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="Muzammil-Online-Service-PC-v3-Final.zip"');
    return res.send(zipBuffer);
  } catch (err: any) {
    console.error('ZIP generation error:', err);
    return res.status(500).json({ error: 'Failed to generate project ZIP: ' + err.message });
  }
});

// Alias for V3 & V2 ZIP download
app.get('/api/download-zip-v3', async (_req, res) => {
  res.redirect('/api/download-zip');
});

app.get('/api/download-zip-v2', async (_req, res) => {
  res.redirect('/api/download-zip');
});

// Endpoint to download GitHub Actions Workflow YAML file
app.get('/api/download/workflow-yml', (_req, res) => {
  const filePath = path.join(__dirname, '.github', 'workflows', 'build-windows-exe.yml');
  if (fs.existsSync(filePath)) {
    res.setHeader('Content-Type', 'text/yaml');
    res.setHeader('Content-Disposition', 'attachment; filename="build-windows-exe.yml"');
    return res.sendFile(filePath);
  }
  return res.status(404).send('Workflow file not found');
});

// Endpoint to download Standalone Node.js Runner Script (run-pc.js)
app.get('/api/download/pc-node-runner', (_req, res) => {
  const filePath = path.join(__dirname, 'run-pc.js');
  if (fs.existsSync(filePath)) {
    res.setHeader('Content-Type', 'application/javascript');
    res.setHeader('Content-Disposition', 'attachment; filename="run-pc.js"');
    return res.sendFile(filePath);
  }
  return res.status(404).send('Node runner file not found');
});

// Endpoint to download PC 1-Click Launcher (START-WORKSTATION.bat)
app.get('/api/download/pc-launcher', (_req, res) => {
  const filePath = path.join(__dirname, 'START-WORKSTATION.bat');
  if (fs.existsSync(filePath)) {
    res.setHeader('Content-Type', 'application/x-bat');
    res.setHeader('Content-Disposition', 'attachment; filename="START-WORKSTATION.bat"');
    return res.sendFile(filePath);
  }
  return res.status(404).send('Launcher file not found');
});

// Endpoint to download PC .EXE Builder (CREATE-EXE-SETUP.bat)
app.get('/api/download/pc-exe-builder', (_req, res) => {
  const filePath = path.join(__dirname, 'CREATE-EXE-SETUP.bat');
  if (fs.existsSync(filePath)) {
    res.setHeader('Content-Type', 'application/x-bat');
    res.setHeader('Content-Disposition', 'attachment; filename="CREATE-EXE-SETUP.bat"');
    return res.sendFile(filePath);
  }
  return res.status(404).send('EXE builder file not found');
});

// Mount Vite middleware in development
if (process.env.NODE_ENV !== 'production') {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa'
  });
  app.use(vite.middlewares);
} else {
  app.use(express.static(path.join(__dirname, 'dist')));
  app.get('*', (_req, res) => {
    res.sendFile(path.join(__dirname, 'dist', 'index.html'));
  });
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running at http://0.0.0.0:${PORT}`);
});
