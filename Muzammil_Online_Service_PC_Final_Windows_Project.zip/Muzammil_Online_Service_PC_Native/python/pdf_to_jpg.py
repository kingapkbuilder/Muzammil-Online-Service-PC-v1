import sys, os
try:
    import fitz
except Exception as e:
    print(f"PyMuPDF unavailable: {e}")
    sys.exit(2)

def main():
    if len(sys.argv) < 3:
        print('Usage: pdf_to_jpg.exe input.pdf output_dir')
        return 1
    src, out = sys.argv[1], sys.argv[2]
    os.makedirs(out, exist_ok=True)
    doc = fitz.open(src)
    for i, page in enumerate(doc):
        pix = page.get_pixmap(dpi=300, alpha=False)
        path = os.path.join(out, f"page_{i+1:03d}.jpg")
        pix.save(path, jpg_quality=100)
        print(path)
    doc.close()
    return 0
if __name__ == '__main__': raise SystemExit(main())
