#define MyAppName "Muzammil Online Service"
#define MyAppVersion "1.0.0"
#define MyPublisher "Muzammil Online Service"
#define MyExeName "Muzammil Online Service.exe"

[Setup]
AppId={{D9E0C8F2-0F2C-4A4D-9A37-7D4A4D7D9A20}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyPublisher}
DefaultDirName={autopf}\Muzammil Online Service
DefaultGroupName={#MyAppName}
OutputDir=installer_output
OutputBaseFilename=Muzammil-Online-Service-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64
UninstallDisplayIcon={app}\{#MyExeName}

[Files]
Source: "..\build\Muzammil Online Service.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\build\pdf_to_jpg.exe"; DestDir: "{app}\tools"; Flags: ignoreversion

[Icons]
Name: "{autodesktop}\Muzammil Online Service"; Filename: "{app}\{#MyExeName}"
Name: "{group}\Muzammil Online Service"; Filename: "{app}\{#MyExeName}"
Name: "{group}\Uninstall Muzammil Online Service"; Filename: "{uninstallexe}"

[Run]
Filename: "{app}\{#MyExeName}"; Description: "Launch Muzammil Online Service"; Flags: nowait postinstall skipifsilent
