# Muzammil Online Service - Native Windows Project

Native Windows desktop project for building a proper Windows installer.

## Structure
- `src/main.cpp` - native Win32 C++ desktop application
- `python/pdf_to_jpg.py` - Python/PyMuPDF PDF-to-JPG engine
- `installer/MuzammilOnlineService.iss` - Inno Setup installer script

The GitHub Actions workflow is intentionally provided as a separate file and must be placed at `.github/workflows/build-windows.yml` in the GitHub repository.
