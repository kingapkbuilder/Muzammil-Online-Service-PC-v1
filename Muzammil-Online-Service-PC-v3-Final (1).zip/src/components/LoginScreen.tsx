import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  User, 
  KeyRound, 
  LogIn, 
  Laptop, 
  AlertCircle,
  Eye,
  EyeOff,
  Smartphone,
  Cpu
} from 'lucide-react';
import { ShopSettings, UserAccount } from '../types';
import { authenticateOperator, getHardwareDeviceId, getHardwareDeviceName } from '../utils/deviceSecurity';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface LoginScreenProps {
  settings: ShopSettings;
  onLoginSuccess: (user: UserAccount) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  settings,
  onLoginSuccess
}) => {
  const [usernameInput, setUsernameInput] = useState<string>('');
  const [passwordInput, setPasswordInput] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [deviceError, setDeviceError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const { isInstallable, install } = usePWAInstall();
  const currentDeviceId = getHardwareDeviceId();
  const currentDeviceName = getHardwareDeviceName();

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setDeviceError(null);
    setIsLoading(true);

    const cleanUsername = usernameInput.trim().toLowerCase();
    const cleanPassword = passwordInput.trim();

    if (!cleanUsername) {
      setErrorMessage('Kripya apna Operator Username enter karein.');
      setIsLoading(false);
      return;
    }

    if (!cleanPassword) {
      setErrorMessage('Kripya Password enter karein.');
      setIsLoading(false);
      return;
    }

    // Authenticate through Device Security Engine (Strict 1 ID = 1 Device)
    const result = authenticateOperator(cleanUsername, cleanPassword);

    setTimeout(() => {
      setIsLoading(false);
      if (result.success && result.user) {
        onLoginSuccess(result.user);
      } else {
        if (result.deviceLockedToOther) {
          setDeviceError(result.error || 'This Operator ID is bound to another device.');
        } else {
          setErrorMessage(result.error || 'Login failed. Please verify credentials.');
        }
      }
    }, 250);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-blue-500 selection:text-white relative overflow-hidden font-sans">
      {/* Background ambient lighting */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-b from-blue-600/15 via-indigo-600/5 to-transparent blur-3xl pointer-events-none" />

      {/* Top Header Branding Bar */}
      <header className="border-b border-slate-900 bg-slate-950/80 backdrop-blur-md px-6 py-4 flex items-center justify-between z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-blue-500/20 border border-blue-400/30">
            <span className="font-extrabold text-white text-base tracking-tighter">MOS</span>
          </div>
          <div>
            <h1 className="font-bold text-white text-sm tracking-tight">Muzammil Online service pc</h1>
            <p className="text-[11px] text-slate-400">{settings.shopName} • Staff Workstation</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Internal Staff Badge */}
          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-full text-[11px] text-amber-300 font-semibold">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>Master Admin & Operator Only</span>
          </div>

          {/* Current Device Hardware Badge */}
          <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 bg-slate-900 border border-slate-800 rounded-full text-[11px] text-slate-400">
            <Cpu className="w-3.5 h-3.5 text-blue-400" />
            <span>This Device:</span>
            <span className="font-mono text-slate-200 font-bold">{currentDeviceId}</span>
          </div>

          <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-[11px] text-emerald-400 font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Security Gate Active</span>
          </div>
        </div>
      </header>

      {/* Main Center Login Card */}
      <main className="flex-1 flex items-center justify-center p-4 z-10">
        <div className="w-full max-w-md">
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl space-y-6">
            {/* Header info */}
            <div className="text-center space-y-2">
              <div className="w-14 h-14 bg-gradient-to-tr from-blue-600/20 via-indigo-600/20 to-blue-500/20 border border-blue-500/30 rounded-2xl flex items-center justify-center mx-auto text-blue-400 shadow-inner">
                <Lock className="w-7 h-7" />
              </div>
              <h2 className="text-xl font-extrabold text-white tracking-tight">Operator Authentication</h2>
              <p className="text-xs text-slate-400">
                Authorized Shop Operators Only • Customer self-registration is disabled
              </p>
            </div>

            {/* Device Lock Error Banner (If ID is used on another machine) */}
            {deviceError && (
              <div className="p-4 rounded-2xl bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs space-y-2 animate-in fade-in zoom-in-95">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-white font-bold mb-1">🚨 SINGLE DEVICE SECURITY ENFORCED:</strong>
                    <p className="text-slate-300 leading-relaxed whitespace-pre-line">{deviceError}</p>
                  </div>
                </div>
                <div className="pt-2 border-t border-rose-500/20 text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Your Machine ID:</span>
                  <code className="text-rose-300 font-mono font-bold bg-slate-950 px-2 py-0.5 rounded">{currentDeviceId}</code>
                </div>
              </div>
            )}

            {/* General Error Banner */}
            {errorMessage && !deviceError && (
              <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2.5 animate-in fade-in">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Login Form */}
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              {/* Username Input */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 block">
                  Operator Username / ID
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    required
                    autoFocus
                    value={usernameInput}
                    onChange={(e) => {
                      setUsernameInput(e.target.value);
                      setErrorMessage('');
                      setDeviceError(null);
                    }}
                    placeholder="e.g. admin or operator1"
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-950/80 border border-slate-800 rounded-xl text-white text-xs font-medium placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all font-mono"
                  />
                </div>
              </div>

              {/* Password Input */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 block">
                  Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                    <KeyRound className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={passwordInput}
                    onChange={(e) => {
                      setPasswordInput(e.target.value);
                      setErrorMessage('');
                      setDeviceError(null);
                    }}
                    placeholder="Enter operator password"
                    className="w-full pl-10 pr-10 py-2.5 bg-slate-950/80 border border-slate-800 rounded-xl text-white text-xs font-medium placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-500 hover:text-slate-300 transition-colors"
                    tabIndex={-1}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed mt-2"
              >
                {isLoading ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    <LogIn className="w-4 h-4" />
                    <span>Authorize & Unlock Workstation</span>
                  </>
                )}
              </button>
            </form>

            {/* Device Hardware Info Box */}
            <div className="pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 space-y-1">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1">
                  <Laptop className="w-3.5 h-3.5 text-slate-400" /> Machine Fingerprint:
                </span>
                <span className="font-mono text-slate-300 font-semibold">{currentDeviceId}</span>
              </div>
              <p className="text-[10px] text-slate-500 leading-tight">
                🔒 Security Note: When an operator logs in, this ID is permanently tied to this machine. Only Master Admin can reset device binding.
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 px-6 py-3 text-center text-xs text-slate-400">
        <div>
          {settings.shopName} • {settings.address} • Phone: {settings.phone}
        </div>
      </footer>
    </div>
  );
};
