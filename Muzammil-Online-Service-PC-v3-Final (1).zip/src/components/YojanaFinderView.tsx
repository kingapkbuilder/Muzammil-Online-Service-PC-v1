import React, { useState } from 'react';
import { 
  Sparkles, 
  Search, 
  CheckCircle2, 
  ExternalLink, 
  Send, 
  Users, 
  Check, 
  Filter, 
  BookOpen, 
  HelpCircle,
  Award
} from 'lucide-react';
import { ShopSettings } from '../types';

interface YojanaFinderViewProps {
  settings: ShopSettings;
}

interface SchemeItem {
  id: string;
  name: string;
  marathiName: string;
  department: string;
  benefit: string;
  minAge: number;
  maxAge: number;
  gender: 'female' | 'male' | 'all';
  occupations: string[];
  maxIncome: number; // in rupees
  requiredDocs: string[];
  applyUrl: string;
  category: 'women' | 'farmer' | 'student' | 'pension' | 'health' | 'housing';
}

const SCHEMES_DATABASE: SchemeItem[] = [
  {
    id: 'ladki_bahin',
    name: 'Mukhyamantri Majhi Ladki Bahin Yojana',
    marathiName: 'मुख्यमंत्री माझी लाडकी बहीण योजना',
    department: 'Women & Child Development, Maharashtra',
    benefit: '₹1,500 Direct Cash Transfer every month (₹18,000 / year)',
    minAge: 21,
    maxAge: 65,
    gender: 'female',
    occupations: ['woman', 'housewife', 'unemployed', 'farmer'],
    maxIncome: 250000,
    requiredDocs: [
      'Aadhaar Card (Linked with Mobile)',
      'Bank Account Passbook (Aadhaar Seeding Active)',
      'Ration Card (Yellow or Orange)',
      'Swayam Ghoshna Patra / Income Certificate (< ₹2.5 Lakh)',
      'Voter Card / Domicile Certificate'
    ],
    applyUrl: 'https://ladakibahin.maharashtra.gov.in',
    category: 'women'
  },
  {
    id: 'pm_kisan',
    name: 'PM Kisan Samman Nidhi & Namo Shetkari',
    marathiName: 'पीएम किसान व नमो शेतकरी महासन्मान निधी',
    department: 'Ministry of Agriculture',
    benefit: '₹12,000 Per Year (₹6,000 Central + ₹6,000 Maharashtra State)',
    minAge: 18,
    maxAge: 99,
    gender: 'all',
    occupations: ['farmer'],
    maxIncome: 500000,
    requiredDocs: [
      'Aadhaar Card with eKYC',
      '7/12 Land Extract (Satbara Utara)',
      '8A Land Holding Extract',
      'Bank Passbook with NPCI / Aadhaar DBT Seeding'
    ],
    applyUrl: 'https://pmkisan.gov.in',
    category: 'farmer'
  },
  {
    id: 'mahadbt_scholarship',
    name: 'MahaDBT Post-Matric Scholarship & Freeship',
    marathiName: 'महाडीबीटी मॅट्रिकोत्तर शिष्यवृत्ती योजना',
    department: 'Social Justice & Tribal Welfare Dept, Maharashtra',
    benefit: '100% Tuition Fee Waiver + Maintenance Allowance (₹2,000 - ₹12,000)',
    minAge: 15,
    maxAge: 35,
    gender: 'all',
    occupations: ['student'],
    maxIncome: 800000,
    requiredDocs: [
      'Aadhaar Card',
      'Caste Certificate & Caste Validity',
      'Current Year Income Certificate (Tehsildar)',
      'Previous Year Marksheet (SSC / HSC / Degree)',
      'College Fee Receipt & Bonafide Certificate'
    ],
    applyUrl: 'https://mahadbt.maharashtra.gov.in',
    category: 'student'
  },
  {
    id: 'ayushman_bharat',
    name: 'Ayushman Bharat PM-JAY & MJPJAY Health Card',
    marathiName: 'आयुष्मान भारत व महात्मा फुले जन आरोग्य योजना',
    department: 'National Health Authority',
    benefit: '₹5,00,000 Cashless Free Hospitalization per family per year',
    minAge: 0,
    maxAge: 99,
    gender: 'all',
    occupations: ['all', 'farmer', 'student', 'woman', 'unemployed'],
    maxIncome: 250000,
    requiredDocs: [
      'Aadhaar Card with Biometric / OTP',
      'Active Ration Card (Yellow / Orange Priority Household)',
      'Mobile Number linked with Aadhaar'
    ],
    applyUrl: 'https://beneficiary.nha.gov.in',
    category: 'health'
  },
  {
    id: 'pm_awas',
    name: 'Pradhan Mantri Awas Yojana (PMAY-Gramin / Urban)',
    marathiName: 'प्रधानमंत्री आवास योजना (घरकुल योजना)',
    department: 'Ministry of Housing & Urban Affairs',
    benefit: '₹1.20 Lakh to ₹2.50 Lakh financial assistance for building Pucca House',
    minAge: 18,
    maxAge: 99,
    gender: 'all',
    occupations: ['farmer', 'unemployed', 'woman', 'housewife'],
    maxIncome: 300000,
    requiredDocs: [
      'Aadhaar Card of all family members',
      'Ration Card & Job Card (MGNREGA)',
      'Land Ownership Paper / Grampanchayat NOC',
      'Bank Account Passbook'
    ],
    applyUrl: 'https://pmayg.nic.in',
    category: 'housing'
  },
  {
    id: 'sanjay_gandhi_pension',
    name: 'Sanjay Gandhi Niradhar Anudan Yojana',
    marathiName: 'संजय गांधी निराधार अनुदान योजना',
    department: 'Revenue Dept, Maharashtra',
    benefit: '₹1,500 Monthly Pension for Widows, Destitute & Handicapped',
    minAge: 18,
    maxAge: 65,
    gender: 'all',
    occupations: ['woman', 'unemployed', 'housewife'],
    maxIncome: 50000,
    requiredDocs: [
      'Aadhaar Card & Domicile Certificate (15 Years in MH)',
      'Death Certificate of Husband (for Widows)',
      'Disability Certificate (>40% for Divyang)',
      'Tehsildar Income Certificate (< ₹50,000)',
      'Age Proof (School TC / Birth Certificate)'
    ],
    applyUrl: 'https://aaplesarkar.mahaonline.gov.in',
    category: 'pension'
  },
  {
    id: 'pm_vishwakarma',
    name: 'PM Vishwakarma Artisan Scheme',
    marathiName: 'पीएम विश्वकर्मा कौशल्य योजना',
    department: 'Ministry of MSME',
    benefit: '₹15,000 Free Toolkit Grant + ₹3,00,000 Loan at 5% interest + Free Training',
    minAge: 18,
    maxAge: 65,
    gender: 'all',
    occupations: ['artisan', 'farmer', 'unemployed'],
    maxIncome: 400000,
    requiredDocs: [
      'Aadhaar Card with Biometric Verification',
      'Bank Account Passbook',
      'Artisan Trade Certificate / Self-Declaration',
      'Mobile Linked with Aadhaar'
    ],
    applyUrl: 'https://pmvishwakarma.gov.in',
    category: 'farmer'
  }
];

export const YojanaFinderView: React.FC<YojanaFinderViewProps> = ({ settings }) => {
  // Filter inputs
  const [customerName, setCustomerName] = useState<string>('');
  const [customerMobile, setCustomerMobile] = useState<string>('');
  const [age, setAge] = useState<number>(24);
  const [gender, setGender] = useState<'female' | 'male' | 'all'>('female');
  const [occupation, setOccupation] = useState<string>('woman');
  const [annualIncome, setAnnualIncome] = useState<number>(150000);

  // Matching logic
  const matchedSchemes = SCHEMES_DATABASE.filter((s) => {
    // Age check
    if (age < s.minAge || age > s.maxAge) return false;
    // Gender check
    if (s.gender !== 'all' && s.gender !== gender) return false;
    // Income check
    if (annualIncome > s.maxIncome) return false;
    // Occupation check
    if (!s.occupations.includes('all') && !s.occupations.includes(occupation)) return false;

    return true;
  });

  const handleShareToWhatsApp = (scheme: SchemeItem) => {
    const text = `*${settings.shopName || 'Muzammil Online Service'} - Sarkari Yojana Alert*\n\n` +
      `Namaste ${customerName || 'Customer'},\n` +
      `Aapke liye sarkari yojana:\n` +
      `👉 *${scheme.name}*\n` +
      `(${scheme.marathiName})\n\n` +
      `💰 *Fayda / Benefit:* ${scheme.benefit}\n\n` +
      `📋 *Zaroori Dastavez (Documents):*\n` +
      scheme.requiredDocs.map(d => `• ${d}`).join('\n') + '\n\n' +
      `Form bharne ke liye hamari dukaan par aakar sampark karein:\n` +
      `📍 ${settings.address || 'Naya Munshi Shaban Nagar'}\n` +
      `📞 ${settings.phone || '9561460313'}`;

    const url = customerMobile.trim() 
      ? `https://wa.me/91${customerMobile.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(text)}`
      : `https://wa.me/?text=${encodeURIComponent(text)}`;

    window.open(url, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-amber-950 p-6 rounded-2xl border border-amber-500/20 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                Government Scheme Eligibility Engine
              </span>
              <span className="text-xs text-slate-400 font-mono">20+ Central & MH Schemes</span>
            </div>
            <h1 className="text-2xl font-black text-white mt-1 flex items-center gap-2">
              <Sparkles className="w-7 h-7 text-amber-400" />
              <span>Sarkari Yojana Eligibility Finder</span>
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Customer ki age, gender aur income daalkar turant pata karein wo kin-kin sarkari yojanao ka fayda le sakta hai.
            </p>
          </div>

          <div className="bg-slate-950/80 px-4 py-3 rounded-xl border border-amber-500/30 text-center">
            <div className="text-2xl font-black text-amber-400 font-mono">{matchedSchemes.length}</div>
            <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Eligible Schemes Found</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Customer Profile Inputs Left Column */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-lg">
            <h3 className="font-extrabold text-white text-sm flex items-center gap-2">
              <Filter className="w-4 h-4 text-amber-400" />
              <span>Customer Profile Filter</span>
            </h3>

            {/* Customer Name & Mobile */}
            <div className="space-y-2">
              <div className="space-y-1">
                <label className="text-[11px] text-slate-400 font-bold">Customer Name:</label>
                <input
                  type="text"
                  placeholder="e.g. Smt. Sunita Patil"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] text-slate-400 font-bold">WhatsApp Mobile Number:</label>
                <input
                  type="text"
                  placeholder="10 digit mobile"
                  value={customerMobile}
                  onChange={(e) => setCustomerMobile(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white font-mono"
                />
              </div>
            </div>

            {/* Gender */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Gender (लिंग):</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setGender('female')}
                  className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all ${
                    gender === 'female'
                      ? 'bg-rose-600/30 border-rose-500 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  👩 Female (महिला)
                </button>
                <button
                  onClick={() => setGender('male')}
                  className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all ${
                    gender === 'male'
                      ? 'bg-blue-600/30 border-blue-500 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  👨 Male (पुरुष)
                </button>
              </div>
            </div>

            {/* Age Slider */}
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-bold text-slate-300">
                <span>Age (वय):</span>
                <span className="text-amber-400 font-mono">{age} Years</span>
              </div>
              <input
                type="range"
                min="10"
                max="85"
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                className="w-full accent-amber-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            {/* Occupation */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Category / Occupation (व्यवसाय):</label>
              <select
                value={occupation}
                onChange={(e) => setOccupation(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
              >
                <option value="woman">Woman / Housewife (महिला / गृहिणी)</option>
                <option value="farmer">Farmer / Shetkari (शेतकरी / किसान)</option>
                <option value="student">Student / Vidyarthi (विद्यार्थी)</option>
                <option value="unemployed">Unemployed Youth (बेरोजगार तरुण)</option>
                <option value="artisan">Artisan / Karigar (कारागीर / विश्वकर्मा)</option>
              </select>
            </div>

            {/* Income */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">Annual Family Income (वार्षिक उत्पन्न):</label>
              <select
                value={annualIncome}
                onChange={(e) => setAnnualIncome(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
              >
                <option value={50000}>Under ₹50,000 (Very Poor / निराधार)</option>
                <option value={150000}>Under ₹1.5 Lakh (BPL / Priority Ration)</option>
                <option value={250000}>Under ₹2.5 Lakh (Ladki Bahin & Ayushman Eligible)</option>
                <option value={800000}>Under ₹8 Lakh (EBC & MahaDBT Scholarship Eligible)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Matching Schemes Right Column */}
        <div className="lg:col-span-8 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-white text-base">
              Eligible Schemes for {gender === 'female' ? 'Female' : 'Male'} ({age} yrs, ₹{(annualIncome / 1000).toFixed(0)}k income)
            </h3>
            <span className="text-xs font-bold text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-full border border-amber-500/20">
              {matchedSchemes.length} Yojana Eligible
            </span>
          </div>

          <div className="space-y-4">
            {matchedSchemes.map((scheme) => (
              <div 
                key={scheme.id}
                className="bg-slate-900 border border-slate-800 hover:border-amber-500/40 rounded-2xl p-5 space-y-3 shadow-lg transition-all"
              >
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-bold text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                      {scheme.department}
                    </span>
                    <h4 className="text-base font-black text-white mt-1">
                      {scheme.name}
                    </h4>
                    <p className="text-xs text-amber-300 font-semibold">
                      {scheme.marathiName}
                    </p>
                  </div>

                  <div className="text-right self-start">
                    <span className="text-xs font-black text-emerald-400 bg-emerald-500/10 px-3 py-1.5 rounded-xl border border-emerald-500/20 inline-block">
                      {scheme.benefit}
                    </span>
                  </div>
                </div>

                {/* Required Documents Checklist */}
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1.5">
                  <div className="text-[11px] font-bold text-slate-300 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Zaroori Dastavez (Required Documents):</span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-1.5 text-[11px] text-slate-400 pl-5">
                    {scheme.requiredDocs.map((doc, idx) => (
                      <div key={idx} className="flex items-center gap-1">
                        <span className="text-amber-400">•</span>
                        <span>{doc}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                  <a
                    href={scheme.applyUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-indigo-400 hover:text-indigo-300 hover:underline"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Official Portal Par Apply Karein</span>
                  </a>

                  <button
                    onClick={() => handleShareToWhatsApp(scheme)}
                    className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-1.5 px-3 rounded-xl shadow transition-colors flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>WhatsApp Details To Customer</span>
                  </button>
                </div>
              </div>
            ))}

            {matchedSchemes.length === 0 && (
              <div className="p-12 text-center bg-slate-900 border border-slate-800 rounded-2xl text-slate-500 space-y-2">
                <HelpCircle className="w-10 h-10 mx-auto text-slate-600" />
                <div className="text-sm font-bold text-white">No Schemes Matching This Exact Filter</div>
                <div className="text-xs text-slate-400">Try changing Age, Gender or Annual Income from the left filter.</div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
