import React, { useState } from 'react';
import { 
  Users, 
  Search, 
  Plus, 
  Send, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Trash2, 
  FileSpreadsheet,
  Edit,
  Phone,
  Volume2,
  Megaphone,
  Sparkles
} from 'lucide-react';
import { CustomerRecord, ShopSettings } from '../types';

interface CustomerCrmViewProps {
  customers: CustomerRecord[];
  settings: ShopSettings;
  onAddCustomer: (customer: CustomerRecord) => void;
  onUpdateStatus: (id: string, newStatus: CustomerRecord['status']) => void;
  onDeleteCustomer: (id: string) => void;
}

export const CustomerCrmView: React.FC<CustomerCrmViewProps> = ({
  customers,
  settings,
  onAddCustomer,
  onUpdateStatus,
  onDeleteCustomer
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showBroadcastModal, setShowBroadcastModal] = useState(false);
  const [broadcastMessage, setBroadcastMessage] = useState('🚨 Sarkari Bharti Alert: SSC GD & Maharashtra Police Bharti ke form shuru ho gaye hain! Muzammil Online Service par aakar form bharein.');

  // New customer form state
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [serviceType, setServiceType] = useState('Majhi Ladki Bahin Yojana');
  const [ackToken, setAckToken] = useState('');
  const [amount, setAmount] = useState<number>(100);
  const [notes, setNotes] = useState('');

  // Voice Token Speech Announcer
  const speakToken = (token: string, custName: string, lang: 'hi' | 'mr') => {
    if (!('speechSynthesis' in window)) {
      alert('Speech synthesis is not supported on this browser.');
      return;
    }
    window.speechSynthesis.cancel();
    const text = lang === 'mr'
      ? `टोकन क्रमांक ${token}, ${custName}, कृपया काउंटर नंबर एक वर या.`
      : `टोकन नंबर ${token}, ${custName}, कृपया काउंटर नंबर एक पर आएं.`;
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang === 'mr' ? 'mr-IN' : 'hi-IN';
    utterance.rate = 0.9;
    window.speechSynthesis.speak(utterance);
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newRec: CustomerRecord = {
      id: `cust-${Date.now()}`,
      name: name.trim(),
      mobile: mobile.trim() || 'N/A',
      serviceType: serviceType.trim(),
      ackToken: ackToken.trim() || `TOK-${Math.floor(10000 + Math.random() * 90000)}`,
      status: 'Pending',
      date: new Date().toISOString().slice(0, 10),
      amount: Number(amount) || 0,
      notes: notes.trim()
    };

    onAddCustomer(newRec);
    setShowAddModal(false);
    setName('');
    setMobile('');
    setAckToken('');
    setNotes('');
  };

  const filtered = customers.filter(c => {
    const matchesSearch = 
      c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.mobile.includes(searchTerm) ||
      c.serviceType.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.ackToken.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || c.status.toLowerCase() === statusFilter.toLowerCase();
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-4">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-extrabold text-white">Customer CRM & Job Tracker</h1>
            <span className="bg-blue-500/20 text-blue-400 border border-blue-500/30 text-xs px-2 py-0.5 rounded-full font-mono font-bold">
              {customers.length} Records
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Track customer applications, biometric verification status, delivery alerts & WhatsApp updates
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowBroadcastModal(true)}
            className="flex items-center gap-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs px-3 py-2 rounded-xl shadow transition-all"
            title="Send WhatsApp New Vacancy / Scheme Broadcast to Customers"
          >
            <Megaphone className="w-3.5 h-3.5" />
            <span>📢 Broadcast Alert</span>
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-105"
          >
            <Plus className="w-4 h-4" />
            <span>+ Add Customer Job</span>
          </button>
        </div>
      </div>

      {/* Filters & Search Row */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/80 border border-slate-800 p-3 rounded-xl">
        {/* Status Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto text-xs">
          {['all', 'Pending', 'Processing', 'Ready', 'Delivered'].map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
                statusFilter === st
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {st === 'all' ? 'All Jobs' : st}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by name, phone, token..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 w-full sm:w-64"
          />
        </div>
      </div>

      {/* Customers Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-md">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 font-mono">
              <tr>
                <th className="py-3 px-4">Token / Ack</th>
                <th className="py-3 px-4">Customer Name</th>
                <th className="py-3 px-4">Mobile</th>
                <th className="py-3 px-4">Service Applied</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Fee</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.map((c) => (
                <tr key={c.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-bold text-blue-400">{c.ackToken}</td>
                  <td className="py-3.5 px-4">
                    <div className="font-bold text-white">{c.name}</div>
                    {c.notes && <div className="text-[11px] text-slate-400 line-clamp-1">{c.notes}</div>}
                  </td>
                  <td className="py-3.5 px-4 font-mono text-slate-300">{c.mobile}</td>
                  <td className="py-3.5 px-4 font-medium text-slate-200">{c.serviceType}</td>
                  <td className="py-3.5 px-4 font-mono text-slate-400 text-[11px]">{c.date}</td>
                  <td className="py-3.5 px-4">
                    <select
                      value={c.status}
                      onChange={(e) => onUpdateStatus(c.id, e.target.value as any)}
                      className={`text-[11px] font-bold px-2 py-1 rounded-lg border focus:outline-none cursor-pointer ${
                        c.status === 'Ready'
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                          : c.status === 'Delivered'
                          ? 'bg-blue-500/20 text-blue-300 border-blue-500/40'
                          : c.status === 'Processing'
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                          : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                      }`}
                    >
                      <option value="Pending" className="bg-slate-900 text-rose-300">Pending</option>
                      <option value="Processing" className="bg-slate-900 text-amber-300">Processing</option>
                      <option value="Ready" className="bg-slate-900 text-emerald-300">Ready</option>
                      <option value="Delivered" className="bg-slate-900 text-blue-300">Delivered</option>
                    </select>
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono font-bold text-emerald-400">₹{c.amount}</td>
                  <td className="py-3.5 px-4 text-right space-x-1 whitespace-nowrap">
                    <button
                      onClick={() => speakToken(c.ackToken, c.name, 'hi')}
                      title="Speak Token in Hindi (Hindi Mein Aawaz Lagayein)"
                      className="px-2 py-1 rounded-lg bg-indigo-600/20 hover:bg-indigo-600/40 text-indigo-300 font-bold text-[10px] inline-flex items-center gap-1 transition-colors"
                    >
                      <Volume2 className="w-3 h-3 text-indigo-400" />
                      <span>हिंदी</span>
                    </button>
                    <button
                      onClick={() => speakToken(c.ackToken, c.name, 'mr')}
                      title="Speak Token in Marathi (Marathi Madhe Aawaj Dya)"
                      className="px-2 py-1 rounded-lg bg-orange-600/20 hover:bg-orange-600/40 text-orange-300 font-bold text-[10px] inline-flex items-center gap-1 transition-colors"
                    >
                      <Volume2 className="w-3 h-3 text-orange-400" />
                      <span>मराठी</span>
                    </button>
                    <a
                      href={`https://wa.me/91${c.mobile}?text=Namaskar%20${encodeURIComponent(c.name)},%20your%20${encodeURIComponent(c.serviceType)}%20application%20(Token:%20${c.ackToken})%20status%20is:%20${c.status}.%20Regards,%20${encodeURIComponent(settings.shopName)}.`}
                      target="_blank"
                      rel="noopener noreferrer"
                      title="WhatsApp Status Alert"
                      className="p-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/40 text-emerald-400 inline-block transition-colors"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </a>
                    <button
                      onClick={() => onDeleteCustomer(c.id)}
                      title="Delete Customer Record"
                      className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Customer Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="font-bold text-white text-base">New Customer Application Job</span>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-3 text-xs">
              <div>
                <label className="text-slate-300 font-semibold block mb-1">Customer Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Shaikh Sameer"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Mobile / WhatsApp *</label>
                <input
                  type="tel"
                  placeholder="10 digit number"
                  value={mobile}
                  onChange={(e) => setMobile(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Service Type</label>
                <input
                  type="text"
                  value={serviceType}
                  onChange={(e) => setServiceType(e.target.value)}
                  placeholder="e.g. Majhi Ladki Bahin Yojana, PAN Card"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Ack / Token No.</label>
                  <input
                    type="text"
                    value={ackToken}
                    onChange={(e) => setAckToken(e.target.value)}
                    placeholder="Auto-generated if blank"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Amount (₹)</label>
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Job Remarks / Details</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Aadhaar seeding pending in Bank of Maharashtra"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="pt-2 flex items-center gap-2">
                <button
                  type="submit"
                  className="flex-1 bg-blue-600 hover:bg-blue-500 text-white font-bold py-2.5 rounded-xl transition-colors"
                >
                  Save Customer Job
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 bg-slate-800 text-slate-300 rounded-xl hover:bg-slate-750"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Broadcast WhatsApp Alert Modal */}
      {showBroadcastModal && (
        <div className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <span className="font-extrabold text-white text-base flex items-center gap-2">
                <Megaphone className="w-5 h-5 text-emerald-400" />
                <span>Customer Broadcast WhatsApp Alert</span>
              </span>
              <button onClick={() => setShowBroadcastModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-400">
                Nayi vacancy, Ladki Bahin eKYC last date, ya camp ka message aapke registered customers ko WhatsApp par broadcast karein.
              </p>

              {/* Ready-made templates */}
              <div className="space-y-1">
                <label className="text-slate-300 font-bold">Fast Message Templates:</label>
                <div className="grid grid-cols-1 gap-1.5">
                  {[
                    { label: '🚨 SSC GD & Police Bharti Shuru', msg: '🚨 Sarkari Bharti Alert: SSC GD & Maharashtra Police Bharti online form shuru ho gaye hain! Apne zaroori documents lekar Muzammil Online Service par aayein.' },
                    { label: '🌸 Ladki Bahin eKYC Last Date', msg: '🌸 Alert: Mukhyamantri Majhi Ladki Bahin Yojana ki eKYC aur aavedan ki antim date pass aa gayi hai. Turant Muzammil Online Service par sampark karein.' },
                    { label: '🪪 Ayushman Card Camp (₹5 Lakh Free)', msg: '🪪 Free Health Cover: Ayushman Bharat Card par ₹5,00,000 ka ilaj muft! Apna Ration card aur Aadhaar lekar Muzammil Online Service par aakar card banwayein.' }
                  ].map((t, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setBroadcastMessage(t.msg)}
                      className="text-left p-2 rounded-lg bg-slate-950 border border-slate-800 hover:border-emerald-500/50 text-[11px] text-slate-300 hover:text-white transition-colors"
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-bold">Broadcast Message Content:</label>
                <textarea
                  rows={4}
                  value={broadcastMessage}
                  onChange={(e) => setBroadcastMessage(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white text-xs leading-relaxed"
                />
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-[11px] text-slate-400">
                Total <b>{customers.length} Customers</b> registered in your CRM.
              </div>

              <div className="pt-2 flex items-center gap-2">
                <a
                  href={`https://wa.me/?text=${encodeURIComponent(broadcastMessage + `\n\n- ${settings.shopName || 'Muzammil Online Service'}, Contact: ${settings.phone || '9561460313'}`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold py-2.5 rounded-xl shadow-lg transition-all text-center flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Broadcast on WhatsApp</span>
                </a>
                <button
                  type="button"
                  onClick={() => setShowBroadcastModal(false)}
                  className="px-4 py-2.5 bg-slate-800 text-slate-300 rounded-xl hover:bg-slate-700 font-bold"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
