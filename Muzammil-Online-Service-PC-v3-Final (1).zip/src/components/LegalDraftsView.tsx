import React, { useState } from 'react';
import { 
  FileText, 
  Printer, 
  Download, 
  Check, 
  Copy, 
  Building2, 
  UserCheck, 
  HelpCircle,
  FileCheck,
  Sparkles
} from 'lucide-react';
import { ShopSettings } from '../types';

interface LegalDraftsViewProps {
  settings: ShopSettings;
}

export const LegalDraftsView: React.FC<LegalDraftsViewProps> = ({ settings }) => {
  const [selectedFormat, setSelectedFormat] = useState<'swayam_ghoshna_marathi' | 'swayam_ghoshna_hindi' | 'gap_affidavit' | 'lost_doc'>('swayam_ghoshna_marathi');

  // Form Fields
  const [applicantName, setApplicantName] = useState<string>('Imran Khan');
  const [fatherName, setFatherName] = useState<string>('Rashid Khan');
  const [age, setAge] = useState<string>('24');
  const [aadhaarNo, setAadhaarNo] = useState<string>('XXXX-XXXX-1234');
  const [mobileNo, setMobileNo] = useState<string>('9561460313');
  const [address, setAddress] = useState<string>('Naya Munshi Shaban Nagar, Main Road');
  const [taluka, setTaluka] = useState<string>('Amravati');
  const [district, setDistrict] = useState<string>('Amravati');
  const [purpose, setPurpose] = useState<string>('उत्पन्नाचा दाखला (Income Certificate)');
  const [annualIncome, setAnnualIncome] = useState<string>('50,000');
  const [gapYears, setGapYears] = useState<string>('2023 to 2025');
  const [gapReason, setGapReason] = useState<string>('Preparation for Competitive Civil Services Examination');

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 p-6 rounded-2xl border border-emerald-500/20 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Aaple Sarkar & Legal Formats
              </span>
              <span className="text-xs text-slate-400 font-mono">1-Click Fast Generator</span>
            </div>
            <h1 className="text-2xl font-black text-white mt-1 flex items-center gap-2">
              <FileCheck className="w-7 h-7 text-emerald-400" />
              <span>Swayam Ghoshna Patra & Legal Drafts</span>
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Self-Declaration (Marathi / Hindi), Education Gap Certificate, aur Police Lost Document application.
            </p>
          </div>

          <button
            onClick={handlePrint}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs shadow-lg transition-all flex items-center gap-2 self-start md:self-auto"
          >
            <Printer className="w-4 h-4" />
            <span>Print Official A4 Sheet</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Options Form Column */}
        <div className="lg:col-span-4 space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-lg">
            <h3 className="font-extrabold text-white text-sm">Select Document Format</h3>

            <div className="grid grid-cols-1 gap-2">
              {[
                { id: 'swayam_ghoshna_marathi', label: 'स्वयंघोषणा पत्र (मराठी - उत्पन्न/जात दाखला)' },
                { id: 'swayam_ghoshna_hindi', label: 'स्वघोषणा पत्र (हिंदी - आय/जाति प्रमाण)' },
                { id: 'gap_affidavit', label: 'Education Gap Certificate Affidavit' },
                { id: 'lost_doc', label: 'Aadhaar / Mobile Lost Police Application' },
              ].map((f) => (
                <button
                  key={f.id}
                  onClick={() => setSelectedFormat(f.id as any)}
                  className={`p-3 rounded-xl text-left text-xs font-bold border transition-all ${
                    selectedFormat === f.id
                      ? 'bg-emerald-600/30 border-emerald-500 text-white shadow-md'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            <div className="border-t border-slate-800 pt-3 space-y-3">
              <h4 className="font-bold text-xs text-emerald-400">Customer Details (Auto-Fill)</h4>

              <div className="space-y-1">
                <label className="text-[11px] text-slate-400">Applicant Name (अर्जदाराचे नाव):</label>
                <input
                  type="text"
                  value={applicantName}
                  onChange={(e) => setApplicantName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] text-slate-400">Father's / Husband's Name:</label>
                <input
                  type="text"
                  value={fatherName}
                  onChange={(e) => setFatherName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-[11px] text-slate-400">Age (वय):</label>
                  <input
                    type="text"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] text-slate-400">Aadhaar No:</label>
                  <input
                    type="text"
                    value={aadhaarNo}
                    onChange={(e) => setAadhaarNo(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white font-mono"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] text-slate-400">Village / Address (पत्ता):</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-[11px] text-slate-400">Taluka (तालुका):</label>
                  <input
                    type="text"
                    value={taluka}
                    onChange={(e) => setTaluka(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] text-slate-400">District (जिल्हा):</label>
                  <input
                    type="text"
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white"
                  />
                </div>
              </div>

              {selectedFormat.includes('swayam_ghoshna') && (
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <label className="text-[11px] text-slate-400">हेतू (Purpose):</label>
                    <input
                      type="text"
                      value={purpose}
                      onChange={(e) => setPurpose(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] text-slate-400">वार्षिक उत्पन्न (₹):</label>
                    <input
                      type="text"
                      value={annualIncome}
                      onChange={(e) => setAnnualIncome(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white font-mono"
                    />
                  </div>
                </div>
              )}

              {selectedFormat === 'gap_affidavit' && (
                <div className="space-y-2">
                  <div className="space-y-1">
                    <label className="text-[11px] text-slate-400">Gap Years (e.g. 2023 to 2025):</label>
                    <input
                      type="text"
                      value={gapYears}
                      onChange={(e) => setGapYears(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[11px] text-slate-400">Gap Reason:</label>
                    <input
                      type="text"
                      value={gapReason}
                      onChange={(e) => setGapReason(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Live A4 Print Preview Right Column */}
        <div className="lg:col-span-8 flex justify-center">
          <div 
            id="printable-legal-draft" 
            className="w-[520px] bg-white text-slate-900 rounded-lg shadow-2xl p-8 border border-slate-300 min-h-[720px] flex flex-col justify-between text-xs leading-relaxed"
          >
            {/* MARATHI SWAYAM GHOSHNA PATRA */}
            {selectedFormat === 'swayam_ghoshna_marathi' && (
              <div className="space-y-4">
                <div className="text-center border-b-2 border-slate-900 pb-2">
                  <h2 className="text-base font-black tracking-wide">स्वयंघोषणा पत्र (Self Declaration)</h2>
                  <p className="text-[10px] text-slate-600 font-semibold">(शासकीय दाखले / उत्पन्नाचा दाखला / जात प्रमाणपत्रासाठी ग्राह्य)</p>
                </div>

                <div className="flex justify-between items-start pt-2">
                  <div className="space-y-0.5 text-[11px]">
                    <div><b>दिनांक:</b> {new Date().toLocaleDateString('en-GB')}</div>
                    <div><b>ठिकाण:</b> {taluka}, {district}</div>
                  </div>
                  <div className="w-20 h-24 border border-dashed border-slate-500 rounded flex items-center justify-center text-[9px] text-slate-400 text-center p-1">
                    येथे फोटो लावावा
                  </div>
                </div>

                <div className="space-y-3 text-[12px] leading-relaxed text-justify">
                  <p>
                    मी <b>{applicantName || '_______________________'}</b>, वय <b>{age}</b> वर्षे, राहणार <b>{address}</b>, 
                    तालुका <b>{taluka}</b>, जिल्हा <b>{district}</b>, आधार क्रमांक <b>{aadhaarNo}</b> याद्वारे जाहीर करतो/करते की:
                  </p>

                  <ol className="list-decimal pl-5 space-y-2">
                    <li>मी अर्ज सादर करीत असलेला हेतू <b>{purpose}</b> हा आहे.</li>
                    <li>माझ्या कुटुंबाचे सर्व मार्गांनी मिळून एकूण वार्षिक उत्पन्न अंदाजे रुपये <b>₹{annualIncome}/-</b> (अक्षरी: {annualIncome} रुपये) इतके आहे.</li>
                    <li>मी सादर केलेली वरील सर्व माहिती व दिलेले पुरावे माझ्या माहिती व समजुतीनुसार सत्य व बरोबर आहेत.</li>
                    <li>सदर माहिती खोटी अथवा चुकीची आढळल्यास भारतीय दंड संहितेनुसार मी कायदेशीर शिक्षेस पात्र राहीन याची मला पूर्ण जाणीव आहे.</li>
                  </ol>
                </div>

                <div className="pt-16 flex justify-between items-end border-t border-slate-200 mt-8">
                  <div className="text-[10px] text-slate-500">
                    <div>प्रमाणित केंद्र: <b>{settings.shopName || 'Muzammil Online Service'}</b></div>
                    <div>संपर्क: {settings.phone || '9561460313'}</div>
                  </div>
                  <div className="text-center space-y-1">
                    <div className="w-36 border-b border-slate-800" />
                    <div className="font-bold text-xs">अर्जदाराची सही / अंगठा</div>
                    <div className="text-[10px] text-slate-600">({applicantName})</div>
                  </div>
                </div>
              </div>
            )}

            {/* HINDI SWAYAM GHOSHNA PATRA */}
            {selectedFormat === 'swayam_ghoshna_hindi' && (
              <div className="space-y-4">
                <div className="text-center border-b-2 border-slate-900 pb-2">
                  <h2 className="text-base font-black tracking-wide">स्वघोषणा पत्र (Self Declaration Form)</h2>
                  <p className="text-[10px] text-slate-600 font-semibold">(सरकारी योजनाओं एवं प्रमाणपत्रों हेतु अधिकृत प्रारूप)</p>
                </div>

                <div className="flex justify-between items-start pt-2">
                  <div className="space-y-0.5 text-[11px]">
                    <div><b>दिनांक:</b> {new Date().toLocaleDateString('en-GB')}</div>
                    <div><b>स्थान:</b> {taluka}, {district}</div>
                  </div>
                  <div className="w-20 h-24 border border-dashed border-slate-500 rounded flex items-center justify-center text-[9px] text-slate-400 text-center p-1">
                    पासपोर्ट फोटो
                  </div>
                </div>

                <div className="space-y-3 text-[12px] leading-relaxed text-justify">
                  <p>
                    मैं <b>{applicantName || '_______________________'}</b>, सुपुत्र/सुपुत्री श्री <b>{fatherName}</b>, 
                    आयु <b>{age}</b> वर्ष, निवासी <b>{address}</b>, तहसील <b>{taluka}</b>, जिला <b>{district}</b>, 
                    आधार संख्या <b>{aadhaarNo}</b> यह घोषणा करता/करती हूँ कि:
                  </p>

                  <ol className="list-decimal pl-5 space-y-2">
                    <li>यह स्वघोषणा पत्र <b>{purpose}</b> हेतु प्रस्तुत किया जा रहा है।</li>
                    <li>मेरे परिवार की सभी स्रोतों से कुल वार्षिक आय रुपये <b>₹{annualIncome}/-</b> मात्र है।</li>
                    <li>प्रस्तुत किए गए सभी दस्तावेज एवं विवरण मेरी व्यक्तिगत जानकारी में पूर्णतः सत्य हैं।</li>
                    <li>यदि कोई भी जानकारी असत्य पाई जाती है तो विधिक कार्यवाही हेतु मैं स्वयं उत्तरदायी रहूँगा/रहूँगी।</li>
                  </ol>
                </div>

                <div className="pt-16 flex justify-between items-end border-t border-slate-200 mt-8">
                  <div className="text-[10px] text-slate-500">
                    <div>सेवा केंद्र: <b>{settings.shopName || 'Muzammil Online Service'}</b></div>
                    <div>हेल्पलाइन: {settings.phone || '9561460313'}</div>
                  </div>
                  <div className="text-center space-y-1">
                    <div className="w-36 border-b border-slate-800" />
                    <div className="font-bold text-xs">आवेदक के हस्ताक्षर</div>
                    <div className="text-[10px] text-slate-600">({applicantName})</div>
                  </div>
                </div>
              </div>
            )}

            {/* GAP AFFIDAVIT */}
            {selectedFormat === 'gap_affidavit' && (
              <div className="space-y-4">
                <div className="text-center border-b-2 border-slate-900 pb-2">
                  <h2 className="text-base font-black tracking-wide">AFFIDAVIT FOR GAP IN EDUCATION</h2>
                  <p className="text-[10px] text-slate-600 font-semibold">(Academic Admission Gap Certificate)</p>
                </div>

                <div className="space-y-3 text-[12px] leading-relaxed text-justify pt-3">
                  <p>
                    I, <b>{applicantName}</b>, Son/Daughter of <b>{fatherName}</b>, Aged <b>{age}</b> years, 
                    Resident of <b>{address}, {taluka}, {district}</b>, do hereby solemnly affirm and state on oath as under:
                  </p>

                  <ol className="list-decimal pl-5 space-y-2.5">
                    <li>That I am a permanent bonafide resident of the above-mentioned address.</li>
                    <li>That there is an academic gap period during the academic years <b>{gapYears}</b> in my educational career.</li>
                    <li>That during the said gap period, I was engaged in: <b>{gapReason}</b>.</li>
                    <li>That during this gap tenure, I did not take admission in any other course and was not involved in any unlawful or criminal activity.</li>
                    <li>That this affidavit is submitted for the purpose of seeking regular admission.</li>
                  </ol>
                </div>

                <div className="pt-20 flex justify-between items-end border-t border-slate-200 mt-10">
                  <div className="text-[10px] text-slate-500">
                    <div>Date: {new Date().toLocaleDateString('en-GB')}</div>
                    <div>Place: {taluka}</div>
                  </div>
                  <div className="text-center space-y-1">
                    <div className="w-40 border-b border-slate-800" />
                    <div className="font-bold text-xs">DEPONENT / CANDIDATE</div>
                    <div className="text-[10px] text-slate-600">({applicantName})</div>
                  </div>
                </div>
              </div>
            )}

            {/* LOST DOCUMENT POLICE COMPLAINT */}
            {selectedFormat === 'lost_doc' && (
              <div className="space-y-4">
                <div className="text-center border-b-2 border-slate-900 pb-2">
                  <h2 className="text-base font-black tracking-wide">DOCUMENT LOST INTIMATION LETTER</h2>
                  <p className="text-[10px] text-slate-600 font-semibold">(Police Station / Portal Application for Re-Issue)</p>
                </div>

                <div className="text-xs space-y-1 pt-2">
                  <div><b>To:</b> The Police Sub-Inspector / Station In-Charge,</div>
                  <div>Police Station, {taluka}, Dist: {district}</div>
                  <div className="pt-2 font-bold underline">Subject: Intimation regarding lost of original document (Aadhaar / Certificate).</div>
                </div>

                <div className="space-y-3 text-[12px] leading-relaxed text-justify pt-2">
                  <p>Respected Sir,</p>
                  <p>
                    I, <b>{applicantName}</b>, resident of <b>{address}</b>, Contact No: <b>{mobileNo}</b>, would like to inform that on <b>{new Date().toLocaleDateString('en-GB')}</b>, I accidentally misplaced/lost my original document around <b>{taluka} Market area</b>.
                  </p>
                  <p>
                    Despite best efforts, the said document could not be traced. I request you to kindly register this lost intimation report so that I can apply for a duplicate/re-issued copy from the concerned government department.
                  </p>
                </div>

                <div className="pt-20 flex justify-between items-end border-t border-slate-200 mt-10">
                  <div className="text-[10px] text-slate-500">
                    <div>Date: {new Date().toLocaleDateString('en-GB')}</div>
                    <div>Center: {settings.shopName || 'Muzammil Online Service'}</div>
                  </div>
                  <div className="text-center space-y-1">
                    <div className="w-36 border-b border-slate-800" />
                    <div className="font-bold text-xs">Applicant Signature</div>
                    <div className="text-[10px] text-slate-600">({applicantName})</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
