import React, { useState, useRef, useEffect } from 'react';
import { 
  Landmark, 
  ExternalLink, 
  Search, 
  FileCheck, 
  CheckCircle, 
  Copy, 
  Check, 
  HelpCircle,
  X,
  Maximize2,
  Minimize2,
  RefreshCw,
  ArrowLeft,
  ArrowRight,
  Globe,
  Download,
  FileText,
  Printer,
  CreditCard,
  Camera,
  FolderDown,
  Layers,
  Sparkles,
  Zap,
  ZoomIn,
  ZoomOut,
  Columns,
  Lock,
  Key,
  Eye,
  EyeOff,
  Activity,
  Plus,
  Trash2
} from 'lucide-react';
import { ALL_GOV_PORTALS, SERVICE_CATEGORIES } from '../data/portalData';
import { PortalItem, DownloadItem } from '../types';

interface GovernmentPortalsViewProps {
  onAddDownload?: (download: DownloadItem) => void;
  onNavigate?: (tab: string) => void;
}

interface PortalCredential {
  id: string;
  portalName: string;
  username: string;
  password: string;
  notes?: string;
}

export const GovernmentPortalsView: React.FC<GovernmentPortalsViewProps> = ({
  onAddDownload,
  onNavigate
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [search, setSearch] = useState<string>('');
  const [selectedPortalForDocs, setSelectedPortalForDocs] = useState<PortalItem | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Password Vault State
  const [showPasswordVault, setShowPasswordVault] = useState<boolean>(false);
  const [showPasswordsPlain, setShowPasswordsPlain] = useState<{ [id: string]: boolean }>({});
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [credentials, setCredentials] = useState<PortalCredential[]>(() => {
    try {
      const saved = localStorage.getItem('mos_portal_credentials');
      return saved ? JSON.parse(saved) : [
        { id: 'c-1', portalName: 'CSC Digiseva Portal', username: 'CSC_VLE_42109', password: 'Password@786', notes: 'Daily wallet recharge' },
        { id: 'c-2', portalName: 'MahaOnline Aaple Sarkar', username: 'VLE_AMRAVATI_88', password: 'MahaSecure#2026', notes: 'Income & Domicile' },
        { id: 'c-3', portalName: 'NSDL Steel City PAN Agent', username: 'NSDL_BRANCH_091', password: 'PanAgent!4321', notes: 'Biometric PAN Card' },
        { id: 'c-4', portalName: 'UTI PSA PAN Portal', username: 'PSA_IMRAN_9561', password: 'UtiPsa#78699', notes: 'Coupon purchase login' },
        { id: 'c-5', portalName: 'MahaDBT Scholarship College', username: 'MAHADBT_INST_54', password: 'Scholar@Maha26', notes: 'Post-Matric Scholarship' },
        { id: 'c-6', portalName: 'PM-Kisan VLE Login', username: 'PMKISAN_MAHA_11', password: 'Kisan#Secure99', notes: 'Farmer eKYC' }
      ];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem('mos_portal_credentials', JSON.stringify(credentials));
  }, [credentials]);

  const [newPortalName, setNewPortalName] = useState('');
  const [newPortalUser, setNewPortalUser] = useState('');
  const [newPortalPass, setNewPortalPass] = useState('');
  const [newPortalNote, setNewPortalNote] = useState('');

  const handleCopyText = (text: string, fieldId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldId);
    setTimeout(() => setCopiedField(null), 2500);
  };

  const handleAddCredential = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPortalName.trim() || !newPortalUser.trim()) return;

    const newC: PortalCredential = {
      id: `cred-${Date.now()}`,
      portalName: newPortalName.trim(),
      username: newPortalUser.trim(),
      password: newPortalPass.trim() || '••••••••',
      notes: newPortalNote.trim()
    };

    setCredentials([...credentials, newC]);
    setNewPortalName('');
    setNewPortalUser('');
    setNewPortalPass('');
    setNewPortalNote('');
  };

  const handleDeleteCredential = (id: string) => {
    setCredentials(credentials.filter(c => c.id !== id));
  };

  // In-App Browser State
  const [activePortal, setActivePortal] = useState<PortalItem | null>(null);
  const [browserUrl, setBrowserUrl] = useState<string>('');
  const [iframeKey, setIframeKey] = useState<number>(0);
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [isSplitScreen, setIsSplitScreen] = useState<boolean>(true);
  const [useProxy, setUseProxy] = useState<boolean>(false);

  // Quick Notes & In-App Document Grabber
  const [notesCustomerName, setNotesCustomerName] = useState<string>('');
  const [notesAckToken, setNotesAckToken] = useState<string>('');
  const [notesAadhaar, setNotesAadhaar] = useState<string>('');
  const [downloadSuccessMsg, setDownloadSuccessMsg] = useState<string | null>(null);
  const [customUrlInput, setCustomUrlInput] = useState<string>('');

  const handleOpenCustomUrl = () => {
    let url = customUrlInput.trim();
    if (!url) return;
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }
    const domain = url.replace(/^https?:\/\//, '').split('/')[0];
    const customPortal: PortalItem = {
      id: `custom-${Date.now()}`,
      title: domain.toUpperCase(),
      url,
      category: 'utility',
      description: `In-App Web Browser session for ${url}`,
      portalType: 'central',
      popular: false,
      requiredDocs: ['Aadhaar Card', 'Mobile OTP', 'Application ID'],
      icon: '🌐'
    };
    handleOpenInsideApp(customPortal);
  };

  const fileInputRef = useRef<HTMLInputElement>(null);

  const filteredPortals = ALL_GOV_PORTALS.filter((p) => {
    const matchesCategory = activeCategory === 'all' || p.category === activeCategory;
    const matchesSearch = 
      p.title.toLowerCase().includes(search.toLowerCase()) ||
      p.description.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleCopyLink = (portal: PortalItem) => {
    navigator.clipboard.writeText(portal.url);
    setCopiedId(portal.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Open Portal Inside the App
  const handleOpenInsideApp = (portal: PortalItem) => {
    setActivePortal(portal);
    setBrowserUrl(portal.url);
    setIframeKey(prev => prev + 1);
    setUseProxy(false);
  };

  // Close In-App Browser
  const handleCloseBrowser = () => {
    setActivePortal(null);
    setBrowserUrl('');
  };

  // Refresh current portal iframe
  const handleReload = () => {
    setIframeKey(prev => prev + 1);
  };

  // Handle in-app document grab / upload
  const handleInAppDownloadFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const fileExt = file.name.split('.').pop()?.toUpperCase() || 'PDF';
    const isImage = file.type.startsWith('image/');
    const isPdf = file.type === 'application/pdf' || file.name.endsWith('.pdf');

    const downloadItem: DownloadItem = {
      id: `dl-${Date.now()}`,
      title: `${notesCustomerName ? notesCustomerName + ' - ' : ''}${activePortal?.title || 'Portal Document'} (${notesAckToken || 'Slip'})`,
      type: isPdf ? 'PVC Card PDF' : 'Converted JPG',
      size: `${(file.size / 1024).toFixed(1)} KB`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      dataUrl: URL.createObjectURL(file)
    };

    if (onAddDownload) {
      onAddDownload(downloadItem);
    }

    setDownloadSuccessMsg(`✅ Document saved to In-App Downloads Vault!`);
    setTimeout(() => setDownloadSuccessMsg(null), 4000);
  };

  const getEffectiveIframeSrc = () => {
    if (!browserUrl) return '';
    if (useProxy) {
      return `/api/portal-proxy?url=${encodeURIComponent(browserUrl)}`;
    }
    return browserUrl;
  };

  return (
    <div className="space-y-4">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl font-extrabold text-white flex items-center gap-2">
              <Globe className="w-5 h-5 text-sky-400" />
              <span>Official Government Portals & In-App Web Browser</span>
            </h1>
            <span className="bg-sky-500/20 text-sky-400 border border-sky-500/30 text-xs px-2.5 py-0.5 rounded-full font-mono font-bold">
              {ALL_GOV_PORTALS.length} Central & State Portals
            </span>
            <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs px-2.5 py-0.5 rounded-full font-bold">
              In-App Embedded Mode
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            All 50+ official government websites open directly inside this workstation with built-in document download vault
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowPasswordVault(true)}
            className="flex items-center gap-1.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow-lg transition-all"
          >
            <Lock className="w-3.5 h-3.5" />
            <span>🔐 Password Locker</span>
          </button>

          {/* Search */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search portals (Aadhaar, PAN, Ladki Bahin)..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 w-full sm:w-64"
            />
          </div>
        </div>
      </div>

      {/* Live Government Server Signals Ticker */}
      <div className="bg-slate-950 border border-slate-800 p-2.5 rounded-xl flex items-center justify-between text-[11px] overflow-x-auto gap-4">
        <div className="flex items-center gap-2 text-slate-400 font-bold whitespace-nowrap">
          <Activity className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
          <span>Govt Server Signals:</span>
        </div>
        <div className="flex items-center gap-3 overflow-x-auto text-[11px] font-mono whitespace-nowrap">
          <span className="flex items-center gap-1.5 text-slate-300">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <b>CSC Digiseva:</b> <span className="text-emerald-400">ONLINE (110ms)</span>
          </span>
          <span className="text-slate-600">|</span>
          <span className="flex items-center gap-1.5 text-slate-300">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <b>MahaOnline:</b> <span className="text-emerald-400">LIVE</span>
          </span>
          <span className="text-slate-600">|</span>
          <span className="flex items-center gap-1.5 text-slate-300">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <b>NSDL PAN:</b> <span className="text-emerald-400">ACTIVE</span>
          </span>
          <span className="text-slate-600">|</span>
          <span className="flex items-center gap-1.5 text-slate-300">
            <span className="w-2 h-2 rounded-full bg-amber-500" />
            <b>MahaDBT:</b> <span className="text-amber-400">HIGH LOAD</span>
          </span>
          <span className="text-slate-600">|</span>
          <span className="flex items-center gap-1.5 text-slate-300">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <b>UIDAI eAadhaar:</b> <span className="text-emerald-400">OPERATIONAL</span>
          </span>
        </div>
      </div>

      {/* UNIVERSAL IN-APP WEB BROWSER & DOWNLOADER LAUNCHER */}
      <div className="bg-slate-900 border border-sky-500/30 rounded-2xl p-3.5 shadow-md flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 w-full md:w-auto">
          <div className="w-8 h-8 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center flex-shrink-0">
            <Globe className="w-4 h-4" />
          </div>
          <div>
            <span className="font-extrabold text-white text-xs block">Universal In-App Web Browser & Downloader</span>
            <span className="text-[11px] text-slate-400">Open ANY website or citizen portal directly inside this software without external browser</span>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto flex-1 max-w-xl">
          <input
            type="text"
            placeholder="Type any URL (e.g. https://google.com, https://pmkisan.gov.in, https://sbi.co.in)..."
            value={customUrlInput}
            onChange={(e) => setCustomUrlInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleOpenCustomUrl()}
            className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 font-mono"
          />
          <button
            type="button"
            onClick={handleOpenCustomUrl}
            className="px-4 py-2 bg-gradient-to-r from-sky-600 via-blue-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-md transition-all whitespace-nowrap"
          >
            Open in App
          </button>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {SERVICE_CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition-all ${
              activeCategory === cat.id
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800 hover:bg-slate-800'
            }`}
          >
            <span>{cat.icon}</span>
            <span>{cat.label}</span>
          </button>
        ))}
      </div>

      {/* Portals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredPortals.map((portal) => (
          <div
            key={portal.id}
            className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 shadow-md transition-all duration-200 hover:-translate-y-0.5 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-3 mb-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center text-xl shadow-inner">
                    {portal.icon}
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-white">{portal.title}</h3>
                    <span className="text-[10px] font-mono text-slate-400 capitalize">
                      {portal.portalType} Portal • {portal.category.replace('_', ' ')}
                    </span>
                  </div>
                </div>

                {portal.popular && (
                  <span className="text-[9px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded border border-emerald-500/30">
                    High Demand
                  </span>
                )}
              </div>

              <p className="text-xs text-slate-300 mt-2 leading-relaxed line-clamp-3">
                {portal.description}
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
              <button
                onClick={() => setSelectedPortalForDocs(portal)}
                className="text-slate-400 hover:text-blue-400 font-medium flex items-center gap-1 text-[11px]"
              >
                <FileCheck className="w-3.5 h-3.5 text-blue-400" />
                <span>Docs Needed ({portal.requiredDocs.length})</span>
              </button>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => handleCopyLink(portal)}
                  title="Copy Direct Official Link"
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
                >
                  {copiedId === portal.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>

                {/* Primary: Open Inside Application */}
                <button
                  onClick={() => handleOpenInsideApp(portal)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold text-xs shadow-md transition-all hover:scale-105"
                  title="Open this government portal inside the app"
                >
                  <Globe className="w-3 h-3 text-sky-200" />
                  <span>Open Inside App</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* FULL-FEATURED IN-APP EMBEDDED WEB BROWSER MODAL */}
      {activePortal && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex flex-col p-2 sm:p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl flex-1 flex flex-col overflow-hidden shadow-2xl">
            {/* Browser Control Toolbar */}
            <div className="bg-slate-950 border-b border-slate-800 px-4 py-3 flex items-center justify-between gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                <span className="text-xl">{activePortal.icon}</span>
                <div>
                  <h2 className="font-extrabold text-white text-xs leading-none flex items-center gap-1.5">
                    <span>{activePortal.title}</span>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-mono font-bold">
                      In-App Browser
                    </span>
                  </h2>
                  <span className="text-[10px] text-slate-400 font-mono">{activePortal.portalType} • {activePortal.category}</span>
                </div>
              </div>

              {/* URL Address Bar */}
              <div className="flex-1 max-w-xl flex items-center bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 gap-2 text-xs">
                <Globe className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />
                <input
                  type="text"
                  value={browserUrl}
                  onChange={(e) => setBrowserUrl(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleReload()}
                  className="bg-transparent text-white font-mono text-[11px] w-full focus:outline-none truncate"
                />
                <button
                  onClick={handleReload}
                  title="Reload Portal"
                  className="text-slate-400 hover:text-white"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2">
                {/* Proxy Toggle (Useful if website restricts iframes) */}
                <button
                  onClick={() => { setUseProxy(!useProxy); handleReload(); }}
                  className={`px-2.5 py-1.5 rounded-xl text-[11px] font-bold border transition-colors ${
                    useProxy 
                      ? 'bg-purple-600 text-white border-purple-400 shadow'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                  title="Toggle In-App Bypass Proxy for restricted portals"
                >
                  <span>Proxy: {useProxy ? 'ON' : 'OFF'}</span>
                </button>

                {/* Split Screen Toggle */}
                <button
                  onClick={() => setIsSplitScreen(!isSplitScreen)}
                  className={`p-2 rounded-xl border text-xs ${
                    isSplitScreen
                      ? 'bg-blue-600 text-white border-blue-400'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                  }`}
                  title="Toggle Operator Split-Screen Workstation Desk"
                >
                  <Columns className="w-3.5 h-3.5" />
                </button>

                {/* Close In-App Browser */}
                <button
                  onClick={handleCloseBrowser}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-rose-600 text-slate-300 hover:text-white transition-colors"
                  title="Close Portal"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Browser Main Body (Split or Full) */}
            <div className="flex-1 flex overflow-hidden">
              {/* Left Side: Live Embedded Portal */}
              <div className={`h-full flex flex-col bg-white relative transition-all duration-200 ${
                isSplitScreen ? 'w-full lg:w-8/12' : 'w-full'
              }`}>
                <iframe
                  key={iframeKey}
                  src={getEffectiveIframeSrc()}
                  title={activePortal.title}
                  className="w-full h-full border-none"
                  style={{ transform: `scale(${zoomLevel / 100})`, transformOrigin: '0 0' }}
                  sandbox="allow-same-origin allow-scripts allow-forms allow-popups allow-downloads"
                />

                {/* Bottom Fallback Info Bar */}
                <div className="absolute bottom-2 left-3 right-3 bg-slate-950/90 backdrop-blur-md border border-slate-800 p-2 rounded-xl text-[11px] text-slate-300 flex items-center justify-between gap-2 shadow-lg">
                  <div className="flex items-center gap-1.5 truncate">
                    <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                    <span>Live Portal: <b>{activePortal.title}</b></span>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button
                      onClick={() => setUseProxy(!useProxy)}
                      className="text-xs text-sky-400 hover:underline font-bold"
                    >
                      {useProxy ? 'Switch Direct' : 'Bypass Frame Restriction'}
                    </button>
                    <a
                      href={browserUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-slate-400 hover:text-white flex items-center gap-0.5 font-bold"
                    >
                      <span>New Window</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              </div>

              {/* Right Side: Operator Split-Screen & In-App Document Grabber */}
              {isSplitScreen && (
                <div className="hidden lg:flex lg:w-4/12 h-full bg-slate-900 border-l border-slate-800 flex-col p-4 space-y-4 overflow-y-auto">
                  <div className="space-y-1">
                    <h3 className="font-extrabold text-white text-xs uppercase tracking-wider flex items-center gap-2 text-emerald-400">
                      <FolderDown className="w-4 h-4" />
                      <span>In-App Document Grabber & Downloads</span>
                    </h3>
                    <p className="text-[11px] text-slate-400 leading-snug">
                      When citizen acknowledgement slip, e-Aadhaar, or PAN PDF is ready, grab it directly into the in-app vault.
                    </p>
                  </div>

                  {downloadSuccessMsg && (
                    <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center gap-2 animate-in fade-in">
                      <CheckCircle className="w-4 h-4 flex-shrink-0" />
                      <span>{downloadSuccessMsg}</span>
                    </div>
                  )}

                  {/* Customer Quick Fields */}
                  <div className="space-y-2 text-xs bg-slate-950 p-3 rounded-xl border border-slate-800">
                    <div>
                      <label className="text-[11px] text-slate-400 block mb-0.5">Citizen Name</label>
                      <input
                        type="text"
                        placeholder="e.g. Rahul Sharma"
                        value={notesCustomerName}
                        onChange={(e) => setNotesCustomerName(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-bold"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] text-slate-400 block mb-0.5">Application Token / Ack No.</label>
                      <input
                        type="text"
                        placeholder="e.g. MH-LBY-2026-98124"
                        value={notesAckToken}
                        onChange={(e) => setNotesAckToken(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] text-slate-400 block mb-0.5">Aadhaar / Mobile (Reference)</label>
                      <input
                        type="text"
                        placeholder="XXXX-XXXX-XXXX"
                        value={notesAadhaar}
                        onChange={(e) => setNotesAadhaar(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
                      />
                    </div>
                  </div>

                  {/* 1-Click Document Grabber Button */}
                  <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                    <span className="text-[11px] font-bold text-slate-300 block">
                      Save Portal File to In-App Vault:
                    </span>
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleInAppDownloadFile}
                      accept=".pdf,.jpg,.jpeg,.png"
                      className="hidden"
                    />
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all hover:scale-102"
                    >
                      <Download className="w-4 h-4" />
                      <span>Grab Slip / e-Card (In-App)</span>
                    </button>
                  </div>

                  {/* Quick Action Jump to Studios */}
                  <div className="space-y-2 pt-2 border-t border-slate-800 text-xs">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                      Transfer to Studio:
                    </span>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => { handleCloseBrowser(); onNavigate?.('pvc_studio'); }}
                        className="p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-blue-500 text-left transition-colors"
                      >
                        <div className="font-bold text-white text-[11px] flex items-center gap-1">
                          <CreditCard className="w-3 h-3 text-blue-400" />
                          <span>PVC Studio</span>
                        </div>
                        <div className="text-[10px] text-slate-400">Card Maker</div>
                      </button>

                      <button
                        onClick={() => { handleCloseBrowser(); onNavigate?.('pdf_to_jpg'); }}
                        className="p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-amber-500 text-left transition-colors"
                      >
                        <div className="font-bold text-white text-[11px] flex items-center gap-1">
                          <FileText className="w-3 h-3 text-amber-400" />
                          <span>PDF to JPG</span>
                        </div>
                        <div className="text-[10px] text-slate-400">Compressor</div>
                      </button>

                      <button
                        onClick={() => { handleCloseBrowser(); onNavigate?.('billing'); }}
                        className="p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-emerald-500 text-left transition-colors"
                      >
                        <div className="font-bold text-white text-[11px] flex items-center gap-1">
                          <Printer className="w-3 h-3 text-emerald-400" />
                          <span>POS Billing</span>
                        </div>
                        <div className="text-[10px] text-slate-400">Thermal Slip</div>
                      </button>

                      <button
                        onClick={() => { handleCloseBrowser(); onNavigate?.('downloads'); }}
                        className="p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-purple-500 text-left transition-colors"
                      >
                        <div className="font-bold text-white text-[11px] flex items-center gap-1">
                          <FolderDown className="w-3 h-3 text-purple-400" />
                          <span>Downloads</span>
                        </div>
                        <div className="text-[10px] text-slate-400">Vault History</div>
                      </button>
                    </div>
                  </div>

                  {/* Required Documents Checklist for this specific portal */}
                  <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2 text-xs">
                    <span className="font-bold text-white text-[11px] flex items-center gap-1.5">
                      <FileCheck className="w-3.5 h-3.5 text-blue-400" />
                      <span>{activePortal.title} Checklist:</span>
                    </span>
                    <div className="space-y-1">
                      {activePortal.requiredDocs.map((doc, idx) => (
                        <div key={idx} className="flex items-start gap-1.5 text-[11px] text-slate-300">
                          <span className="text-emerald-400 font-bold">✓</span>
                          <span>{doc}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Required Documents Modal */}
      {selectedPortalForDocs && (
        <div className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <span className="text-2xl">{selectedPortalForDocs.icon}</span>
                <div>
                  <h3 className="font-bold text-white text-base">{selectedPortalForDocs.title}</h3>
                  <span className="text-xs text-blue-400 font-medium">Customer Documents Checklist</span>
                </div>
              </div>
              <button
                onClick={() => setSelectedPortalForDocs(null)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2 text-xs">
              <p className="text-slate-300 leading-relaxed">
                Before applying for <b>{selectedPortalForDocs.title}</b>, collect the following original documents from the citizen:
              </p>

              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2.5">
                {selectedPortalForDocs.requiredDocs.map((doc, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 text-slate-200">
                    <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                    <span className="leading-snug">{doc}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => {
                  const p = selectedPortalForDocs;
                  setSelectedPortalForDocs(null);
                  handleOpenInsideApp(p);
                }}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5"
              >
                <Globe className="w-3.5 h-3.5" />
                <span>Open Inside App</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Cyber Cafe Portal Password Locker Modal */}
      {showPasswordVault && (
        <div className="fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-500/40 rounded-2xl max-w-2xl w-full p-5 shadow-2xl space-y-4 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <span className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                  🔐
                </span>
                <div>
                  <h3 className="font-extrabold text-white text-base">Cyber Cafe Portal Password Locker</h3>
                  <p className="text-[11px] text-slate-400">
                    Aapke sabhi sarkari portals ke login credentials (Encrypted & 1-Click Copy)
                  </p>
                </div>
              </div>
              <button onClick={() => setShowPasswordVault(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            {/* Credentials Table / List */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {credentials.map((c) => {
                const isPlain = showPasswordsPlain[c.id];
                return (
                  <div key={c.id} className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="space-y-0.5">
                      <div className="font-bold text-white text-xs">{c.portalName}</div>
                      {c.notes && <div className="text-[10px] text-amber-400/80 italic">{c.notes}</div>}
                    </div>

                    <div className="flex items-center gap-2 text-xs flex-wrap">
                      {/* Username */}
                      <div className="flex items-center bg-slate-900 px-2 py-1 rounded-lg border border-slate-800 font-mono text-slate-300">
                        <span className="text-[10px] text-slate-500 mr-1.5">ID:</span>
                        <span>{c.username}</span>
                        <button
                          onClick={() => handleCopyText(c.username, `user-${c.id}`)}
                          className="ml-2 text-sky-400 hover:text-white text-[10px] font-bold"
                          title="Copy Username"
                        >
                          {copiedField === `user-${c.id}` ? '✓ Copied' : 'Copy'}
                        </button>
                      </div>

                      {/* Password */}
                      <div className="flex items-center bg-slate-900 px-2 py-1 rounded-lg border border-slate-800 font-mono text-amber-300">
                        <span className="text-[10px] text-slate-500 mr-1.5">Pass:</span>
                        <span>{isPlain ? c.password : '••••••••'}</span>
                        <button
                          onClick={() => setShowPasswordsPlain({ ...showPasswordsPlain, [c.id]: !isPlain })}
                          className="ml-1 text-slate-400 hover:text-white p-0.5"
                          title="Toggle View Password"
                        >
                          {isPlain ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                        </button>
                        <button
                          onClick={() => handleCopyText(c.password, `pass-${c.id}`)}
                          className="ml-1.5 text-amber-400 hover:text-white text-[10px] font-bold"
                          title="Copy Password"
                        >
                          {copiedField === `pass-${c.id}` ? '✓ Copied' : 'Copy'}
                        </button>
                      </div>

                      <button
                        onClick={() => handleDeleteCredential(c.id)}
                        className="p-1 rounded bg-slate-800 text-slate-500 hover:text-rose-400"
                        title="Delete"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Add New Credential Form */}
            <form onSubmit={handleAddCredential} className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2 pt-3">
              <span className="text-xs font-bold text-slate-300 block">+ Add New Portal Login:</span>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 text-xs">
                <input
                  type="text"
                  required
                  placeholder="Portal Name (e.g. E-District)"
                  value={newPortalName}
                  onChange={(e) => setNewPortalName(e.target.value)}
                  className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-white"
                />
                <input
                  type="text"
                  required
                  placeholder="Username / VLE ID"
                  value={newPortalUser}
                  onChange={(e) => setNewPortalUser(e.target.value)}
                  className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-white font-mono"
                />
                <input
                  type="text"
                  placeholder="Password"
                  value={newPortalPass}
                  onChange={(e) => setNewPortalPass(e.target.value)}
                  className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-white font-mono"
                />
                <button
                  type="submit"
                  className="bg-amber-600 hover:bg-amber-500 text-white font-bold py-1 px-3 rounded-lg transition-colors"
                >
                  Save in Vault
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
