import React from 'react';
import { 
  CreditCard, 
  Camera, 
  Receipt, 
  FileImage, 
  FileText, 
  Users, 
  Landmark, 
  Sparkles, 
  Printer, 
  ExternalLink,
  CheckCircle2,
  TrendingUp,
  AlertCircle,
  Clock,
  ArrowRight,
  ShieldCheck,
  Send
} from 'lucide-react';
import { BillItem, CustomerRecord, ShopSettings } from '../types';
import { ALL_GOV_PORTALS } from '../data/portalData';

interface DashboardViewProps {
  bills: BillItem[];
  customers: CustomerRecord[];
  settings: ShopSettings;
  onNavigate: (tab: string) => void;
  onOpenQuickBill: () => void;
  onPrintBill: (bill: BillItem) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  bills,
  customers,
  settings,
  onNavigate,
  onOpenQuickBill,
  onPrintBill
}) => {
  // Calculations
  const todayStr = new Date().toISOString().slice(0, 10);
  const todayBills = bills.filter(b => b.createdAt.includes(todayStr) || b.createdAt.includes('2026-09-30'));
  const todayIncome = todayBills.reduce((acc, curr) => acc + (curr.total || 0), 0);
  const pendingJobs = customers.filter(c => c.status === 'Pending' || c.status === 'Processing');
  const popularPortals = ALL_GOV_PORTALS.filter(p => p.popular).slice(0, 8);

  const quickTools = [
    {
      id: 'pvc_studio',
      title: 'PVC Card Maker 4×6',
      sub: 'Standard CR-80 85.6×54mm • 300 DPI Live Zoom/Pan & Print',
      icon: CreditCard,
      color: 'from-blue-600 to-cyan-600',
      badge: 'Popular',
      badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-400/30'
    },
    {
      id: 'passport_studio',
      title: 'Passport Photo Studio',
      sub: '6, 8, 12, 16 Copies • Studio Background • Retouch • Name Stamp',
      icon: Camera,
      color: 'from-purple-600 to-pink-600',
      badge: '300 DPI',
      badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-400/30'
    },
    {
      id: 'billing',
      title: 'Billing & Thermal POS',
      sub: '58mm / 80mm POS Slip, A4 Invoice, WhatsApp Share & UPI QR',
      icon: Receipt,
      color: 'from-emerald-600 to-teal-600',
      badge: 'Fast POS',
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-400/30'
    },
    {
      id: 'pdf_to_jpg',
      title: 'PDF to High-Res JPG',
      sub: 'Password Unlock (e-Aadhaar/PAN), Multi-page 300 DPI & ZIP',
      icon: FileImage,
      color: 'from-amber-600 to-orange-600',
      badge: 'Unlocked',
      badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-400/30'
    },
    {
      id: 'biodata_maker',
      title: 'CV & BioData Maker',
      sub: 'Professional A4 Resume, Marriage BioData in Hindi & English',
      icon: FileText,
      color: 'from-indigo-600 to-violet-600',
      badge: '18+ Layouts',
      badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-400/30'
    },
    {
      id: 'ai_assistant',
      title: 'AI Scheme Assistant',
      sub: 'Instant Document Checklists, Eligibility Rules & Portal Steps',
      icon: Sparkles,
      color: 'from-amber-500 to-yellow-600',
      badge: 'Gemini AI',
      badgeColor: 'bg-amber-500/20 text-amber-200 border-amber-400/30'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner with Cyber Cafe Details & Quick Action */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 border border-blue-500/20 p-6 shadow-xl">
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              PC Operator Station Online • High Performance Workstation
            </div>
            <h1 className="text-2xl lg:text-3xl font-black text-white tracking-tight">
              {settings.shopName}
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              Complete digital citizen services suite: 300 DPI PVC card generation, instant passport photo sheets, official government scheme applications, and fast thermal POS billing.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={onOpenQuickBill}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm px-4 py-2.5 rounded-xl shadow-lg shadow-emerald-600/30 transition-all hover:scale-105 active:scale-95"
            >
              <Receipt className="w-4 h-4" />
              <span>+ New Customer Bill</span>
            </button>
            <button
              onClick={() => onNavigate('pvc_studio')}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm px-4 py-2.5 rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-105 active:scale-95"
            >
              <CreditCard className="w-4 h-4" />
              <span>Open PVC Studio</span>
            </button>
          </div>
        </div>

        {/* Decorative background grid */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#3b82f6_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" />
      </div>

      {/* Cyber Cafe Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md flex items-center justify-between">
          <div>
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Today's Revenue</span>
            <div className="text-2xl font-black text-emerald-400 mt-1">₹{todayIncome.toLocaleString('en-IN')}</div>
            <span className="text-[11px] text-slate-500 mt-0.5 block">{todayBills.length} service transactions</span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md flex items-center justify-between">
          <div>
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Total Bills Today</span>
            <div className="text-2xl font-black text-blue-400 mt-1">{todayBills.length}</div>
            <span className="text-[11px] text-slate-500 mt-0.5 block">Recorded in POS ledger</span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400">
            <Receipt className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md flex items-center justify-between">
          <div>
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Pending Customer Jobs</span>
            <div className="text-2xl font-black text-amber-400 mt-1">{pendingJobs.length}</div>
            <span className="text-[11px] text-slate-500 mt-0.5 block">Awaiting biometric / print</span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md flex items-center justify-between">
          <div>
            <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">Govt Portals Connected</span>
            <div className="text-2xl font-black text-purple-400 mt-1">{ALL_GOV_PORTALS.length}</div>
            <span className="text-[11px] text-slate-500 mt-0.5 block">Central & Maharashtra Portals</span>
          </div>
          <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
            <Landmark className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Cyber Cafe Quick Tools Workstation Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-white tracking-tight">Core PC Workstation Tools</h2>
            <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full font-mono">300 DPI</span>
          </div>
          <span className="text-xs text-slate-400">Optimized for keyboard, mouse & printer presets</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {quickTools.map((tool) => {
            const Icon = tool.icon;
            return (
              <div
                key={tool.id}
                onClick={() => onNavigate(tool.id)}
                className="group relative bg-slate-900/90 hover:bg-slate-800/90 border border-slate-800 hover:border-slate-700 rounded-2xl p-5 cursor-pointer transition-all duration-200 shadow-md hover:shadow-xl hover:-translate-y-1 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-tr ${tool.color} flex items-center justify-center text-white shadow-lg shadow-black/20 group-hover:scale-110 transition-transform`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md border ${tool.badgeColor}`}>
                      {tool.badge}
                    </span>
                  </div>
                  <h3 className="font-extrabold text-base text-white group-hover:text-blue-400 transition-colors">
                    {tool.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    {tool.sub}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs font-semibold text-blue-400 group-hover:text-blue-300">
                  <span>Launch Workspace</span>
                  <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Popular Citizen Services & Portals Row */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-white tracking-tight">Popular Government Portals & Schemes</h2>
            <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/30 font-medium">Direct Access</span>
          </div>
          <button 
            onClick={() => onNavigate('portals')}
            className="text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1"
          >
            <span>View All 50+ Portals</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {popularPortals.map((portal) => (
            <div
              key={portal.id}
              className="bg-slate-900/80 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 p-3.5 rounded-xl transition-all shadow-sm flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-xl">{portal.icon}</span>
                    <h4 className="text-xs font-bold text-slate-200 truncate">{portal.title}</h4>
                  </div>
                </div>
                <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                  {portal.description}
                </p>
              </div>

              <div className="mt-3 pt-2.5 border-t border-slate-800/60 flex items-center justify-between">
                <a
                  href={portal.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[11px] font-bold text-blue-400 hover:text-blue-300 inline-flex items-center gap-1"
                >
                  <span>Open Official</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
                <button
                  onClick={() => onNavigate('portals')}
                  className="text-[10px] text-slate-500 hover:text-slate-300"
                >
                  Docs Info
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Split Section: Recent Bills & Announcements */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Bills (2 columns) */}
        <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-md space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-base text-white">Recent Customer Billing Receipts</h3>
              <p className="text-xs text-slate-400">Quick print thermal slip or share via WhatsApp</p>
            </div>
            <button
              onClick={() => onNavigate('billing')}
              className="text-xs font-semibold text-blue-400 hover:text-blue-300"
            >
              Full Ledger →
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 font-mono">
                <tr>
                  <th className="py-2.5 px-3">Invoice</th>
                  <th className="py-2.5 px-3">Customer</th>
                  <th className="py-2.5 px-3">Service</th>
                  <th className="py-2.5 px-3 text-right">Amount</th>
                  <th className="py-2.5 px-3 text-center">Status</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {bills.slice(0, 5).map((bill) => (
                  <tr key={bill.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 px-3 font-mono font-bold text-slate-300">{bill.invoiceNo}</td>
                    <td className="py-3 px-3">
                      <div className="font-semibold text-white">{bill.customerName}</div>
                      <div className="text-[10px] text-slate-500 font-mono">{bill.customerMobile}</div>
                    </td>
                    <td className="py-3 px-3 text-slate-300 max-w-[160px] truncate">{bill.serviceName}</td>
                    <td className="py-3 px-3 text-right font-bold text-emerald-400 font-mono">₹{bill.total}</td>
                    <td className="py-3 px-3 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        bill.status === 'Paid' 
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' 
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      }`}>
                        {bill.status}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right space-x-1.5 whitespace-nowrap">
                      <button
                        onClick={() => onPrintBill(bill)}
                        title="Print Thermal Slip"
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white transition-colors"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                      <a
                        href={`https://wa.me/91${bill.customerMobile}?text=Hello%20${encodeURIComponent(bill.customerName)},%20your%20bill%20at%20${encodeURIComponent(settings.shopName)}%20for%20${encodeURIComponent(bill.serviceName)}%20is%20Rs.${bill.total}.%20Thank%20you!`}
                        target="_blank"
                        rel="noopener noreferrer"
                        title="Share on WhatsApp"
                        className="p-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/40 text-emerald-400 inline-block transition-colors"
                      >
                        <Send className="w-3.5 h-3.5" />
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Notices & CSC Operator Tips (1 column) */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-md space-y-4">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-400" />
            <h3 className="font-bold text-base text-white">Govt Scheme Notices</h3>
          </div>

          <div className="space-y-3 text-xs">
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-200 leading-relaxed">
              <span className="font-bold block text-amber-300 mb-1">📢 Majhi Ladki Bahin Yojana Alert:</span>
              Ensure the beneficiary's bank account has DBT / NPCI seeding active. If NPCI mapping is not done, monthly ₹1,500 instalment will fail.
            </div>

            <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-200 leading-relaxed">
              <span className="font-bold block text-blue-300 mb-1">🪪 PVC Card Printing Preset:</span>
              Use Standard 4×6 inch Photo Paper with 300 DPI mode on Epson L805 / Canon G3010 for crisp Aadhaar / PAN card prints.
            </div>

            <div className="p-3 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-200 leading-relaxed">
              <span className="font-bold block text-purple-300 mb-1">📸 SSC / Police Bharti Photos:</span>
              Exam notification requires Candidate Name & Date printed at the bottom of the passport photo. Use our Passport Studio preset!
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
