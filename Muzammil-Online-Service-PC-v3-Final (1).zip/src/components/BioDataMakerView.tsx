import React, { useState, useRef } from 'react';
import { 
  FileText, 
  Printer, 
  Download, 
  Upload, 
  Save, 
  FolderOpen, 
  Trash2, 
  User, 
  Briefcase, 
  GraduationCap, 
  Heart, 
  Mail, 
  Phone, 
  MapPin,
  Sparkles
} from 'lucide-react';
import { jsPDF } from 'jspdf';
import { BioDataForm } from '../types';
import { addDownloadRecord } from '../utils/storage';
import { printHtmlDocument } from '../utils/printer';

export const BioDataMakerView: React.FC = () => {
  const [formData, setFormData] = useState<BioDataForm>({
    template: 'biodata_hindi',
    fullName: 'Shaikh Sameer',
    dob: '15 August 1998',
    mobile: '9561460313',
    email: 'sameer.shaikh@gmail.com',
    education: 'B.Com Graduate (Pune University)',
    job: 'Digital Service Specialist & Accounts',
    income: '₹ 3,50,000 / Year',
    address: 'Naya Munshi Shaban Nagar, Main Road, Maharashtra',
    familyDetails: 'Father: Businessman\nMother: Homemaker\nBrothers: 1 Elder Brother (Married)\nSisters: 1 Younger Sister',
    customDetails: 'Height: 5 Ft 8 In\nBlood Group: B+ve\nHobbies: Reading, Technology, Sports',
    photo: null
  });

  const previewRef = useRef<HTMLDivElement | null>(null);

  const handleInputChange = (field: keyof BioDataForm, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      setFormData(prev => ({ ...prev, photo: event.target?.result as string }));
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleSaveDraft = () => {
    localStorage.setItem('mos_pc_biodata_draft', JSON.stringify(formData));
    alert('BioData / CV draft saved to local storage.');
  };

  const handleLoadDraft = () => {
    const raw = localStorage.getItem('mos_pc_biodata_draft');
    if (raw) {
      setFormData(JSON.parse(raw));
    } else {
      alert('No saved draft found.');
    }
  };

  const handleClear = () => {
    if (confirm('Clear all form fields?')) {
      setFormData({
        template: 'biodata_hindi',
        fullName: '',
        dob: '',
        mobile: '',
        email: '',
        education: '',
        job: '',
        income: '',
        address: '',
        familyDetails: '',
        customDetails: '',
        photo: null
      });
    }
  };

  // Direct Print
  const handlePrint = () => {
    const printArea = previewRef.current;
    if (!printArea) return;

    const pageStyle = `
      @page { size: A4; margin: 10mm; }
      body { font-family: 'Plus Jakarta Sans', system-ui, sans-serif; margin: 0; padding: 0; background: #fff; color: #000; }
      .print-container { width: 100%; max-width: 800px; margin: 0 auto; }
      table { width: 100%; border-collapse: collapse; }
      td { padding: 6px 4px; vertical-align: top; }
    `;

    const htmlBody = `
      <div class="print-container">
        ${printArea.innerHTML}
      </div>
    `;

    printHtmlDocument(htmlBody, `${formData.fullName || 'BioData'}_Print`, pageStyle);
  };

  // Download PDF
  const handleDownloadPDF = () => {
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    // Simple high quality PDF generation from details
    pdf.setFont('helvetica', 'bold');
    pdf.setFontSize(22);
    pdf.setTextColor(30, 58, 138);

    const titleText = formData.template.includes('biodata') ? 'BIODATA' : 'CURRICULUM VITAE';
    pdf.text(titleText, 105, 20, { align: 'center' });

    pdf.setFontSize(16);
    pdf.setTextColor(15, 23, 42);
    pdf.text(formData.fullName || 'Candidate Name', 105, 30, { align: 'center' });

    pdf.setFontSize(10);
    pdf.setTextColor(100, 116, 139);
    pdf.text(`Phone: ${formData.mobile} | Email: ${formData.email}`, 105, 36, { align: 'center' });

    pdf.setDrawColor(37, 99, 235);
    pdf.setLineWidth(0.5);
    pdf.line(20, 42, 190, 42);

    let y = 52;

    const addSection = (heading: string, content: string) => {
      if (!content.trim()) return;
      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(12);
      pdf.setTextColor(30, 58, 138);
      pdf.text(heading, 20, y);
      y += 6;

      pdf.setFont('helvetica', 'normal');
      pdf.setFontSize(10);
      pdf.setTextColor(30, 41, 59);

      const lines = pdf.splitTextToSize(content, 170);
      lines.forEach((line: string) => {
        pdf.text(line, 20, y);
        y += 5.5;
      });
      y += 4;
    };

    addSection('Personal Details', `Date of Birth: ${formData.dob}\nAddress: ${formData.address}`);
    addSection('Education & Qualifications', formData.education);
    addSection('Occupation & Income', `Occupation: ${formData.job}\nAnnual Income: ${formData.income}`);
    addSection('Family Background', formData.familyDetails);
    addSection('Additional Details', formData.customDetails);

    const fileName = `${formData.fullName.replace(/\s+/g, '_') || 'BioData'}_A4.pdf`;
    pdf.save(fileName);

    addDownloadRecord({
      id: `biodata-pdf-${Date.now()}`,
      title: fileName,
      type: 'BioData PDF',
      size: 'A4 Document',
      timestamp: new Date().toLocaleTimeString('en-IN')
    });
  };

  return (
    <div className="space-y-4">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-extrabold text-white">CV & BioData Maker Studio</h1>
            <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs px-2 py-0.5 rounded-full font-mono font-bold">
              Standard A4 Format
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Create professional job resumes and marriage biodatas in Hindi, English, and Islamic layouts with instant A4 live preview
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-105"
          >
            <Printer className="w-4 h-4" />
            <span>🖨️ Direct Print</span>
          </button>

          <button
            onClick={handleDownloadPDF}
            className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow-lg shadow-indigo-600/30 transition-all hover:scale-105"
          >
            <Download className="w-4 h-4" />
            <span>📄 Download PDF</span>
          </button>

          <button
            onClick={handleSaveDraft}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl border border-slate-700 text-xs font-semibold"
            title="Save Draft"
          >
            <Save className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Dual Pane: Form Editor on Left, Live A4 Document on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left Side: Form Editor (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Template Selector */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">Document Template</span>

            <div className="grid grid-cols-2 gap-2 text-xs">
              {[
                { id: 'biodata_hindi', label: 'Marriage BioData (Hindi)', icon: Heart },
                { id: 'biodata_english', label: 'Marriage BioData (Eng)', icon: Heart },
                { id: 'biodata_islamic', label: 'Islamic BioData', icon: Sparkles },
                { id: 'cv_modern', label: 'Professional Job Resume', icon: Briefcase }
              ].map((tmpl) => {
                const Icon = tmpl.icon;
                return (
                  <button
                    key={tmpl.id}
                    onClick={() => handleInputChange('template', tmpl.id)}
                    className={`p-2.5 rounded-xl border font-bold flex items-center gap-2 text-left transition-all ${
                      formData.template === tmpl.id
                        ? 'bg-indigo-600 text-white border-indigo-500 shadow-md'
                        : 'bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-800'
                    }`}
                  >
                    <Icon className="w-4 h-4 flex-shrink-0" />
                    <span className="text-[11px] leading-tight">{tmpl.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Form Fields */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">Candidate Particulars</span>
              <button onClick={handleClear} className="text-rose-400 hover:text-rose-300 text-[11px]">
                Clear Form
              </button>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Full Name *</label>
              <input
                type="text"
                value={formData.fullName}
                onChange={(e) => handleInputChange('fullName', e.target.value)}
                placeholder="Full Name"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white font-semibold text-sm"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Date of Birth</label>
                <input
                  type="text"
                  value={formData.dob}
                  onChange={(e) => handleInputChange('dob', e.target.value)}
                  placeholder="DD/MM/YYYY"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white font-mono"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Mobile / WhatsApp</label>
                <input
                  type="text"
                  value={formData.mobile}
                  onChange={(e) => handleInputChange('mobile', e.target.value)}
                  placeholder="Mobile number"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white font-mono"
                />
              </div>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Email Address</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                placeholder="email@example.com"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Education / Degrees</label>
              <input
                type="text"
                value={formData.education}
                onChange={(e) => handleInputChange('education', e.target.value)}
                placeholder="e.g. B.Com, MBA, ITI, 12th Pass"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Job / Occupation</label>
                <input
                  type="text"
                  value={formData.job}
                  onChange={(e) => handleInputChange('job', e.target.value)}
                  placeholder="e.g. Govt Employee, Business"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Annual Income</label>
                <input
                  type="text"
                  value={formData.income}
                  onChange={(e) => handleInputChange('income', e.target.value)}
                  placeholder="e.g. ₹ 4,00,000 / Year"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white font-mono"
                />
              </div>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Residential Address</label>
              <input
                type="text"
                value={formData.address}
                onChange={(e) => handleInputChange('address', e.target.value)}
                placeholder="Full residential address"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Family Details</label>
              <textarea
                rows={3}
                value={formData.familyDetails}
                onChange={(e) => handleInputChange('familyDetails', e.target.value)}
                placeholder="Father name, mother, brothers, sisters..."
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white resize-none"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Additional Information (Height, Gotra, Cast, Skills)</label>
              <textarea
                rows={2}
                value={formData.customDetails}
                onChange={(e) => handleInputChange('customDetails', e.target.value)}
                placeholder="Height, blood group, hobbies, computer skills..."
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white resize-none"
              />
            </div>

            {/* Photo upload */}
            <div>
              <label className="text-slate-400 block mb-1">Candidate Photograph</label>
              <div className="flex items-center gap-3">
                <label className="flex-1 flex items-center justify-center gap-2 py-2 px-3 bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold rounded-lg cursor-pointer border border-slate-700">
                  <Upload className="w-3.5 h-3.5 text-indigo-400" />
                  <span>{formData.photo ? 'Change Photo' : 'Upload Candidate Photo'}</span>
                  <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
                </label>
                {formData.photo && (
                  <button
                    onClick={() => setFormData(prev => ({ ...prev, photo: null }))}
                    className="p-2 text-rose-400 hover:bg-rose-500/10 rounded-lg"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Live A4 Document Preview (7 cols) */}
        <div className="lg:col-span-7 space-y-3">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
            <div className="flex items-center justify-between mb-3 text-xs">
              <span className="font-bold text-white flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-indigo-400" />
                <span>Live A4 Document Page Preview</span>
              </span>
              <span className="text-slate-400 font-mono">210mm × 297mm (Standard A4)</span>
            </div>

            {/* A4 Paper Box Container */}
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 overflow-auto flex justify-center shadow-inner">
              <div
                ref={previewRef}
                className="w-full max-w-[500px] bg-white text-slate-900 p-8 shadow-2xl rounded-sm border border-slate-300 font-sans text-xs leading-relaxed select-text"
                style={{ minHeight: '680px' }}
              >
                {/* Header Decoration */}
                <div className="text-center pb-4 border-b-2 border-indigo-700 mb-5 relative">
                  {formData.template === 'biodata_islamic' && (
                    <div className="text-base font-bold text-emerald-800 mb-1 font-serif">
                      بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
                    </div>
                  )}
                  {formData.template === 'biodata_hindi' && (
                    <div className="text-sm font-bold text-rose-800 mb-1">
                      ॥ श्री गणेशाय नमः ॥
                    </div>
                  )}

                  <h2 className="text-2xl font-black tracking-wider text-indigo-950 uppercase">
                    {formData.template.includes('biodata') ? 'BIO DATA' : 'CURRICULUM VITAE'}
                  </h2>
                  <div className="text-lg font-bold text-indigo-800 mt-1">{formData.fullName}</div>
                  <div className="text-[11px] text-slate-600 mt-0.5">
                    Phone: {formData.mobile} {formData.email ? `• Email: ${formData.email}` : ''}
                  </div>

                  {formData.photo && (
                    <div className="absolute right-0 top-0 w-24 h-32 border-2 border-slate-300 rounded p-1 bg-white shadow-sm">
                      <img src={formData.photo} alt="Photo" className="w-full h-full object-cover" />
                    </div>
                  )}
                </div>

                {/* Content Sections Table */}
                <div className="space-y-4">
                  <div>
                    <h4 className="font-bold text-indigo-900 uppercase text-[11px] tracking-wider border-b border-indigo-100 pb-1 mb-2">
                      Personal Details
                    </h4>
                    <table className="w-full text-xs">
                      <tbody>
                        <tr><td className="w-36 font-semibold text-slate-600 py-1">Full Name:</td><td className="font-bold text-slate-900">{formData.fullName}</td></tr>
                        <tr><td className="font-semibold text-slate-600 py-1">Date of Birth:</td><td>{formData.dob}</td></tr>
                        <tr><td className="font-semibold text-slate-600 py-1">Education:</td><td className="font-semibold text-slate-800">{formData.education}</td></tr>
                        <tr><td className="font-semibold text-slate-600 py-1">Occupation:</td><td>{formData.job}</td></tr>
                        <tr><td className="font-semibold text-slate-600 py-1">Annual Income:</td><td>{formData.income}</td></tr>
                        <tr><td className="font-semibold text-slate-600 py-1">Address:</td><td>{formData.address}</td></tr>
                      </tbody>
                    </table>
                  </div>

                  {formData.familyDetails && (
                    <div>
                      <h4 className="font-bold text-indigo-900 uppercase text-[11px] tracking-wider border-b border-indigo-100 pb-1 mb-2">
                        Family Details
                      </h4>
                      <div className="whitespace-pre-line text-slate-700 pl-1">
                        {formData.familyDetails}
                      </div>
                    </div>
                  )}

                  {formData.customDetails && (
                    <div>
                      <h4 className="font-bold text-indigo-900 uppercase text-[11px] tracking-wider border-b border-indigo-100 pb-1 mb-2">
                        Other Particulars
                      </h4>
                      <div className="whitespace-pre-line text-slate-700 pl-1">
                        {formData.customDetails}
                      </div>
                    </div>
                  )}
                </div>

                {/* Footer Signature */}
                <div className="mt-12 pt-6 flex justify-between items-end border-t border-slate-200 text-[11px] text-slate-500">
                  <div>Date: {new Date().toLocaleDateString('en-IN')}</div>
                  <div className="text-right">
                    <div className="h-8"></div>
                    <div className="border-t border-slate-400 w-32 text-center pt-1 font-semibold text-slate-800">
                      Signature
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
