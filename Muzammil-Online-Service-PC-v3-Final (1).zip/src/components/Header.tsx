import React, { useState, useEffect } from 'react';
import { 
  CreditCard, 
  Camera, 
  Receipt, 
  Maximize2, 
  Minimize2, 
  Search, 
  Command, 
  User, 
  Clock, 
  Sparkles, 
  HelpCircle, 
  LogOut, 
  Sliders,
  Laptop,
  Lock
} from 'lucide-react';
import { ShopSettings, UserAccount } from '../types';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface HeaderProps {
  settings: ShopSettings;
  user: UserAccount;
  activeTab: string;
  onNavigate: (tab: string) => void;
  onOpenLogin: () => void;
  onOpenShortcuts: () => void;
  onLogout: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  isSidebarCollapsed: boolean;
  onToggleSidebar: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  user,
  onNavigate,
  onOpenLogin,
  onOpenShortcuts,
  onLogout,
  searchQuery,
  onSearchChange,
  isSidebarCollapsed,
  onToggleSidebar
}) => {
  const [timeStr, setTimeStr] = useState('');
  const [dateStr, setDateStr] = useState('');
  const [isFullscreen, setIsFullscreen] = useState(false);

  const { isInstallable, install } = usePWAInstall();

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true }));
      setDateStr(now.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
        setIsFullscreen(false);
      }
    }
  };

  return (
    <header className="h-16 bg-slate-900 border-b border-slate-800 px-4 flex items-center justify-between gap-3 select-none flex-shrink-0 z-30 shadow-md no-print">
      {/* Left: Branding & Toggle */}
      <div className="flex items-center gap-3">
        <button 
          onClick={onToggleSidebar}
          title={isSidebarCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
          className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
        >
          <Sliders className="w-5 h-5 rotate-90" />
        </button>

        <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => onNavigate('dashboard')}>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-sky-400 flex items-center justify-center shadow-lg shadow-blue-500/20 overflow-hidden border border-blue-400/30">
            <img 
              src="/muzammil_app_icon.png" 
              alt="Logo" 
              className="w-full h-full object-cover"
              onError={(e) => {
                // Fallback icon if image not available
                (e.target as HTMLElement).style.display = 'none';
              }} 
            />
            <span className="text-white font-black text-lg">M</span>
          </div>
          <div className="hidden sm:block leading-tight">
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-base tracking-tight text-white">{settings.shopName}</span>
              <span className="text-[10px] font-bold uppercase tracking-wider bg-blue-500/20 text-blue-400 px-1.5 py-0.5 rounded border border-blue-500/30">
                PC Suite
              </span>
            </div>
            <p className="text-xs text-slate-400 truncate max-w-[220px]">{settings.tagline}</p>
          </div>
        </div>
      </div>

      {/* Center: Global Search Bar for PC */}
      <div className="flex-1 max-w-xl mx-2 hidden md:block">
        <div className="relative group">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 group-focus-within:text-blue-400 transition-colors" />
          <input
            id="pc-global-search"
            type="text"
            placeholder="Search 50+ Govt Portals, PVC Card, Passport, Bills... (Press / or Ctrl+K)"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full bg-slate-950/80 border border-slate-700/80 group-focus-within:border-blue-500 text-sm rounded-xl pl-9 pr-12 py-2 text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all shadow-inner"
          />
          <div className="absolute right-2.5 top-1/2 -translate-y-1/2 flex items-center gap-1 text-[11px] text-slate-400 bg-slate-800/80 px-1.5 py-0.5 rounded border border-slate-700/60 font-mono">
            <Command className="w-3 h-3" />
            <span>K</span>
          </div>
        </div>
      </div>

      {/* Right: Quick Action Buttons & Operator Profile */}
      <div className="flex items-center gap-2">
        {/* Quick Tools buttons */}
        <div className="hidden lg:flex items-center gap-1.5">
          <button
            onClick={() => onNavigate('billing')}
            className="flex items-center gap-1.5 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/30 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors"
            title="Fast Billing Desk (Ctrl + B)"
          >
            <Receipt className="w-3.5 h-3.5" />
            <span>+ Bill</span>
          </button>
          
          <button
            onClick={() => onNavigate('pvc_studio')}
            className="flex items-center gap-1.5 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 border border-blue-500/30 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors"
            title="PVC 4x6 Card Creator"
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>PVC 4×6</span>
          </button>

          <button
            onClick={() => onNavigate('passport_studio')}
            className="flex items-center gap-1.5 bg-purple-600/20 hover:bg-purple-600/30 text-purple-400 border border-purple-500/30 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors"
            title="Passport Photo Studio"
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Passport 8</span>
          </button>

          <button
            onClick={() => onNavigate('ai_assistant')}
            className="flex items-center gap-1.5 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors"
            title="AI Government Scheme Assistant"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>AI Guide</span>
          </button>
        </div>

        {/* Live Digital Clock for cyber cafe */}
        <div className="hidden xl:flex flex-col items-end px-3 py-1 bg-slate-950/60 rounded-lg border border-slate-800 font-mono">
          <div className="flex items-center gap-1 text-xs font-semibold text-slate-200">
            <Clock className="w-3 h-3 text-blue-400 animate-pulse" />
            <span>{timeStr}</span>
          </div>
          <span className="text-[10px] text-slate-500">{dateStr}</span>
        </div>

        {/* PWA Install Desktop App Button */}
        {isInstallable && (
          <button
            onClick={install}
            className="flex items-center gap-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs px-3 py-1.5 rounded-lg shadow-md transition-all hover:scale-105"
            title="Install Muzammil PC Suite on your Computer"
          >
            <Laptop className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Install PC App</span>
          </button>
        )}

        {/* Keyboard shortcuts helper */}
        <button
          onClick={onOpenShortcuts}
          title="Keyboard Shortcuts (?)"
          className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
        >
          <HelpCircle className="w-4 h-4" />
        </button>

        {/* Fullscreen Toggle */}
        <button
          onClick={toggleFullscreen}
          title={isFullscreen ? "Exit Fullscreen (Esc)" : "Fullscreen PC Mode (F11)"}
          className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
        >
          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>

        {/* Operator Profile Card & Station Lock */}
        <div className="flex items-center gap-1.5 pl-2 border-l border-slate-800">
          <button
            onClick={onOpenLogin}
            className="flex items-center gap-2 hover:bg-slate-800 p-1.5 rounded-xl transition-colors text-left"
            title="Switch Operator Profile"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-indigo-700 flex items-center justify-center text-white font-bold text-xs shadow-md">
              <User className="w-4 h-4" />
            </div>
            <div className="hidden 2xl:block leading-none">
              <div className="text-xs font-bold text-white truncate max-w-[120px]">{user.displayName || user.username}</div>
              <div className="text-[10px] text-emerald-400 font-mono mt-0.5 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
                <span>{user.role.toUpperCase()}</span>
              </div>
            </div>
          </button>

          <button
            onClick={onLogout}
            title="Lock PC Station & Logout"
            className="p-2 text-rose-400 hover:text-rose-200 hover:bg-rose-500/10 rounded-lg transition-colors"
          >
            <Lock className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
