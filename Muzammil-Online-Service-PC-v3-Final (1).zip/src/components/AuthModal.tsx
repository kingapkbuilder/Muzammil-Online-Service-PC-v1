import React, { useState } from 'react';
import { 
  Lock, 
  X, 
  LogIn, 
  KeyRound,
  User,
  AlertCircle
} from 'lucide-react';
import { UserAccount } from '../types';

interface AuthModalProps {
  currentUser: UserAccount;
  onSelectUser: (user: UserAccount) => void;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  currentUser,
  onSelectUser,
  onClose
}) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const handleManualLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    const cleanUser = username.trim().toLowerCase();
    const cleanPass = password.trim();

    if (!cleanUser) {
      setErrorMsg('Kripya username enter karein.');
      return;
    }
    if (!cleanPass) {
      setErrorMsg('Kripya password enter karein.');
      return;
    }

    if ((cleanUser === 'admin' || cleanUser === 'imran') && cleanPass === 'muzammil786') {
      const adminAccount: UserAccount = {
        username: cleanUser,
        displayName: 'Imran Khan',
        role: 'admin',
        phone: currentUser.phone,
        shopName: currentUser.shopName,
        isLoggedIn: true
      };
      onSelectUser(adminAccount);
      onClose();
      return;
    }

    if (cleanPass === 'muzammil786') {
      const opAccount: UserAccount = {
        username: cleanUser,
        displayName: cleanUser.toUpperCase(),
        role: 'operator',
        phone: currentUser.phone,
        shopName: currentUser.shopName,
        isLoggedIn: true
      };
      onSelectUser(opAccount);
      onClose();
      return;
    }

    setErrorMsg('Galat username ya password. Kripya check karein.');
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-white text-base">Operator Login</h3>
              <p className="text-xs text-slate-400">Switch operator session</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Clean Login Form */}
        <form onSubmit={handleManualLogin} className="space-y-3.5 text-xs">
          {errorMsg && (
            <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div>
            <label className="text-slate-300 font-semibold block mb-1">Username</label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                placeholder="Username enter karein"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-2.5 text-white text-xs focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div>
            <label className="text-slate-300 font-semibold block mb-1">Password</label>
            <div className="relative">
              <KeyRound className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                placeholder="Password enter karein"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-9 pr-3 py-2.5 text-white text-xs focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-bold py-2.5 rounded-xl transition-all shadow-md shadow-blue-600/30"
          >
            <LogIn className="w-4 h-4" />
            <span>Login to Station</span>
          </button>
        </form>
      </div>
    </div>
  );
};
