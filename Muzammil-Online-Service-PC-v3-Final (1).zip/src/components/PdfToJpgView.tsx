import React, { useState, useRef } from 'react';
import { 
  FileImage, 
  Upload, 
  Lock, 
  Unlock, 
  Download, 
  Printer, 
  FileArchive, 
  Check, 
  AlertCircle, 
  Loader2, 
  HelpCircle,
  Eye
} from 'lucide-react';
import * as pdfjsLib from 'pdfjs-dist';
import JSZip from 'jszip';
import { addDownloadRecord } from '../utils/storage';

// Configure PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.mjs`;

interface PageRenderItem {
  pageNum: number;
  dataUrl: string;
  width: number;
  height: number;
}

export const PdfToJpgView: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [password, setPassword] = useState<string>('');
  const [isPasswordRequired, setIsPasswordRequired] = useState<boolean>(false);
  const [dpi, setDpi] = useState<number>(300); // 150, 300, 400
  const [isRendering, setIsRendering] = useState<boolean>(false);
  const [renderProgress, setRenderProgress] = useState<string>('');
  const [renderedPages, setRenderedPages] = useState<PageRenderItem[]>([]);
  const [errorMessage, setErrorMessage] = useState<string>('');

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.type !== 'application/pdf' && !file.name.endsWith('.pdf')) {
      setErrorMessage('Please select a valid PDF file.');
      return;
    }
    setSelectedFile(file);
    setErrorMessage('');
    setIsPasswordRequired(false);
    setRenderedPages([]);
    processPDF(file, password);
  };

  const processPDF = async (file: File, pass: string) => {
    setIsRendering(true);
    setErrorMessage('');
    setRenderedPages([]);
    setRenderProgress('Reading PDF file...');

    try {
      const arrayBuffer = await file.arrayBuffer();
      const loadingTask = pdfjsLib.getDocument({
        data: arrayBuffer,
        password: pass || undefined
      });

      loadingTask.onPassword = (callback: any, reason: any) => {
        setIsPasswordRequired(true);
        setIsRendering(false);
        setRenderProgress('');
        if (reason === pdfjsLib.PasswordResponses.INCORRECT_PASSWORD) {
          setErrorMessage('Incorrect password. Please enter the correct password.');
        } else {
          setErrorMessage('This PDF is password protected. Enter password below to unlock.');
        }
      };

      const pdfDoc = await loadingTask.promise;
      setIsPasswordRequired(false);
      const totalPages = pdfDoc.numPages;
      const pagesArr: PageRenderItem[] = [];

      // Scale factor: standard PDF 72 DPI -> desired DPI
      // scale = dpi / 72 (e.g. 300 / 72 ≈ 4.166)
      const scale = dpi / 72;

      for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
        setRenderProgress(`Rendering Page ${pageNum} of ${totalPages} at ${dpi} DPI...`);
        const page = await pdfDoc.getPage(pageNum);
        const viewport = page.getViewport({ scale });

        const canvas = document.createElement('canvas');
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        const ctx = canvas.getContext('2d');

        if (ctx) {
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, canvas.width, canvas.height);

          await (page.render({
            canvasContext: ctx,
            viewport: viewport,
            canvas: canvas
          } as any)).promise;

          pagesArr.push({
            pageNum,
            dataUrl: canvas.toDataURL('image/jpeg', 0.96),
            width: viewport.width,
            height: viewport.height
          });
        }
      }

      setRenderedPages(pagesArr);
      setRenderProgress('');
    } catch (err: any) {
      console.error(err);
      if (err.name === 'PasswordException') {
        setIsPasswordRequired(true);
        setErrorMessage('This PDF is protected. Please enter password (e.g. Aadhaar: CAPITAL 4 letters of name + Birth Year).');
      } else {
        setErrorMessage(err.message || 'Failed to parse PDF.');
      }
    } finally {
      setIsRendering(false);
    }
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFile) return;
    processPDF(selectedFile, password);
  };

  // Download single page JPG
  const handleDownloadSingle = (page: PageRenderItem) => {
    const a = document.createElement('a');
    a.href = page.dataUrl;
    const fileName = `${selectedFile?.name.replace('.pdf', '') || 'Document'}_Page_${page.pageNum}_${dpi}DPI.jpg`;
    a.download = fileName;
    a.click();

    addDownloadRecord({
      id: `pdf-jpg-${Date.now()}-${page.pageNum}`,
      title: fileName,
      type: 'Converted JPG',
      size: `${Math.round(page.width)}×${Math.round(page.height)} px (${dpi} DPI)`,
      timestamp: new Date().toLocaleTimeString('en-IN')
    });
  };

  // Download all pages as a ZIP
  const handleDownloadAllZip = async () => {
    if (renderedPages.length === 0) return;
    setIsRendering(true);
    setRenderProgress('Creating ZIP archive of all pages...');

    try {
      const zip = new JSZip();
      const baseName = selectedFile?.name.replace('.pdf', '') || 'Document';

      renderedPages.forEach((p) => {
        // Strip data:image/jpeg;base64,
        const base64Data = p.dataUrl.split(',')[1];
        zip.file(`${baseName}_Page_${p.pageNum}.jpg`, base64Data, { base64: true });
      });

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      const zipName = `${baseName}_All_Pages_${dpi}DPI.zip`;
      a.download = zipName;
      a.click();
      URL.revokeObjectURL(url);

      addDownloadRecord({
        id: `pdf-zip-${Date.now()}`,
        title: zipName,
        type: 'Converted JPG',
        size: `${renderedPages.length} Pages in ZIP (${dpi} DPI)`,
        timestamp: new Date().toLocaleTimeString('en-IN')
      });
    } catch (e) {
      console.error(e);
    } finally {
      setIsRendering(false);
      setRenderProgress('');
    }
  };

  // Direct Print single page
  const handlePrintPage = (page: PageRenderItem) => {
    const printWin = window.open('', '_blank', 'width=800,height=950');
    if (!printWin) return;

    printWin.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Print Page ${page.pageNum}</title>
          <style>
            @page { size: auto; margin: 5mm; }
            body { margin: 0; padding: 0; display: flex; align-items: center; justify-content: center; background: #fff; }
            img { max-width: 100%; height: auto; display: block; image-rendering: -webkit-optimize-contrast; }
          </style>
        </head>
        <body>
          <img src="${page.dataUrl}" onload="window.print(); window.close();" />
        </body>
      </html>
    `);
    printWin.document.close();
  };

  return (
    <div className="space-y-4">
      {/* Header bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-extrabold text-white">PDF to HD JPG Converter Pro</h1>
            <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs px-2 py-0.5 rounded-full font-mono font-bold">
              Password Unlock & 300 DPI
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Convert e-Aadhaar, PAN cards, marksheet PDFs to high-resolution JPEGs with batch ZIP export
          </p>
        </div>

        {renderedPages.length > 0 && (
          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadAllZip}
              className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow-lg shadow-emerald-600/30 transition-all hover:scale-105"
            >
              <FileArchive className="w-4 h-4" />
              <span>Download All as ZIP ({renderedPages.length})</span>
            </button>
          </div>
        )}
      </div>

      {/* Main Dual-Pane: Left = File Upload & DPI settings, Right = Page Previews Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
        {/* Left Side: Upload & Password Tools (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          {/* File Upload Box */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">Select PDF Document</span>

            <label className="flex flex-col items-center justify-center border-2 border-dashed border-slate-700 hover:border-amber-500 p-5 rounded-xl cursor-pointer bg-slate-950/40 hover:bg-amber-950/10 transition-colors text-center">
              <FileImage className="w-8 h-8 text-amber-400 mb-2" />
              <span className="text-xs font-bold text-white">
                {selectedFile ? selectedFile.name : 'Choose or Drag PDF File'}
              </span>
              <span className="text-[11px] text-slate-400 mt-0.5">
                {selectedFile ? `${(selectedFile.size / 1024 / 1024).toFixed(2)} MB` : 'e-Aadhaar, PAN, Marksheets, Certificates'}
              </span>
              <input
                ref={fileInputRef}
                type="file"
                accept="application/pdf"
                onChange={handleFileChange}
                className="hidden"
              />
            </label>
          </div>

          {/* Password Unlock Box (If protected) */}
          {(isPasswordRequired || isPasswordRequired) && (
            <div className="bg-slate-900/90 border border-amber-500/40 rounded-2xl p-4 shadow-md space-y-3">
              <div className="flex items-center gap-2 text-amber-400">
                <Lock className="w-4 h-4" />
                <span className="text-xs font-bold uppercase tracking-wider">Password Protected PDF</span>
              </div>

              <form onSubmit={handlePasswordSubmit} className="space-y-2 text-xs">
                <div>
                  <label className="text-[11px] text-slate-300 block mb-1">Enter Password:</label>
                  <input
                    type="password"
                    placeholder="Enter document password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isRendering || !password}
                  className="w-full flex items-center justify-center gap-1.5 bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs py-2 rounded-xl transition-colors disabled:opacity-50"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  <span>Unlock & Convert PDF</span>
                </button>
              </form>

              {/* Password Hint Guide */}
              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-[11px] text-slate-400 space-y-1">
                <b className="text-slate-300 block">Common Password Formats:</b>
                <div>• <b>e-Aadhaar:</b> 1st 4 letters of name in CAPITAL + Birth Year (e.g. <code>IMRA1995</code>)</div>
                <div>• <b>e-PAN:</b> Date of Birth in DDMMYYYY format (e.g. <code>15081998</code>)</div>
              </div>
            </div>
          )}

          {/* Quality & DPI Selector */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">Output Resolution (DPI)</span>

            <div className="grid grid-cols-3 gap-2">
              {[
                { dpiVal: 150, label: '150 DPI', sub: 'Standard' },
                { dpiVal: 300, label: '300 DPI', sub: 'Print HD' },
                { dpiVal: 400, label: '400 DPI', sub: 'Ultra Clear' }
              ].map((item) => (
                <button
                  key={item.dpiVal}
                  onClick={() => {
                    setDpi(item.dpiVal);
                    if (selectedFile) processPDF(selectedFile, password);
                  }}
                  className={`p-2 rounded-xl text-xs font-bold border transition-all ${
                    dpi === item.dpiVal
                      ? 'bg-blue-600 text-white border-blue-500 shadow-md'
                      : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-750'
                  }`}
                >
                  <div>{item.label}</div>
                  <div className="text-[10px] font-normal opacity-80">{item.sub}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Side: Page Previews Grid (8 cols) */}
        <div className="lg:col-span-8 space-y-3">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl min-h-[460px]">
            <div className="flex items-center justify-between mb-3 text-xs">
              <span className="font-bold text-white flex items-center gap-1.5">
                <FileImage className="w-3.5 h-3.5 text-blue-400" />
                <span>Rendered Document Pages</span>
              </span>
              <span className="text-slate-400 font-mono">
                {renderedPages.length > 0 ? `${renderedPages.length} Pages Ready` : 'No file loaded'}
              </span>
            </div>

            {/* Error or Progress Alert */}
            {isRendering && (
              <div className="p-4 rounded-xl bg-blue-950/40 border border-blue-500/30 text-blue-300 flex items-center gap-3 text-xs">
                <Loader2 className="w-4 h-4 animate-spin text-blue-400" />
                <span>{renderProgress}</span>
              </div>
            )}

            {errorMessage && (
              <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/30 text-rose-300 flex items-center gap-2.5 text-xs mb-3">
                <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-400" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Empty State */}
            {!isRendering && renderedPages.length === 0 && !errorMessage && (
              <div className="h-80 flex flex-col items-center justify-center text-center p-6 border-2 border-dashed border-slate-800 rounded-xl">
                <FileImage className="w-12 h-12 text-slate-600 mb-2" />
                <span className="text-sm font-bold text-slate-400">No PDF Processed Yet</span>
                <p className="text-xs text-slate-500 max-w-sm mt-1">
                  Upload an e-Aadhaar, PAN card, or multi-page PDF on the left. High resolution 300 DPI pages will appear here.
                </p>
              </div>
            )}

            {/* Pages Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {renderedPages.map((page) => (
                <div
                  key={page.pageNum}
                  className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden p-3 shadow-md flex flex-col justify-between"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800/80 pb-2">
                      <span className="font-bold text-white">Page {page.pageNum}</span>
                      <span className="font-mono text-[11px] text-slate-500">
                        {Math.round(page.width)} × {Math.round(page.height)} px
                      </span>
                    </div>

                    <div className="bg-white rounded-lg overflow-hidden border border-slate-700 shadow-inner flex items-center justify-center p-1">
                      <img
                        src={page.dataUrl}
                        alt={`Page ${page.pageNum}`}
                        className="w-full h-auto object-contain max-h-[360px]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2 mt-3 pt-2.5 border-t border-slate-800/80">
                    <button
                      onClick={() => handleDownloadSingle(page)}
                      className="flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs py-2 rounded-lg transition-colors"
                      title="Download Page as HD JPG"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download JPG</span>
                    </button>

                    <button
                      onClick={() => handlePrintPage(page)}
                      className="flex items-center justify-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs py-2 rounded-lg border border-slate-700 transition-colors"
                      title="Print Page Directly"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Print Page</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
