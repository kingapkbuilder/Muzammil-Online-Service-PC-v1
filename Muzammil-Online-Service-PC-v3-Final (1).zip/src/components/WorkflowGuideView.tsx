import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Circle, 
  ArrowRight, 
  Printer, 
  FileText, 
  CreditCard, 
  Camera, 
  Users, 
  Sparkles, 
  Layers, 
  ShieldCheck, 
  HelpCircle,
  Clock,
  QrCode,
  DollarSign,
  FileCheck,
  Zap,
  Play,
  RotateCcw,
  Check,
  TrendingUp,
  Award
} from 'lucide-react';

interface WorkflowGuideViewProps {
  onNavigate?: (tab: string) => void;
}

interface ServiceBlueprint {
  id: string;
  name: string;
  category: string;
  icon: string;
  timeEstimate: string;
  suggestedRate: string;
  targetStudio: string;
  steps: {
    title: string;
    action: string;
    studioAction?: { label: string; tab: string };
  }[];
  docsRequired: string[];
  operatorTips: string;
}

const SERVICE_BLUEPRINTS: ServiceBlueprint[] = [
  {
    id: 'pvc_card',
    name: 'PVC Smart Card (Aadhaar, PAN, Voter, Ayushman)',
    category: 'Card Printing',
    icon: '💳',
    timeEstimate: '4-5 Minutes',
    suggestedRate: '₹60 - ₹80',
    targetStudio: 'pvc_studio',
    steps: [
      {
        title: 'Step 1: Download Original e-Card PDF',
        action: 'Download original e-Aadhaar from UIDAI or PAN PDF from NSDL/UTIITSL.',
        studioAction: { label: 'Open Govt Portals Hub', tab: 'portals' }
      },
      {
        title: 'Step 2: Auto-Crop Front & Back in PVC Studio',
        action: 'Upload front and back images to CR-80 85.6×54mm template with 300 DPI high-resolution.',
        studioAction: { label: 'Open PVC Card Studio', tab: 'pvc_studio' }
      },
      {
        title: 'Step 3: Direct Print on 4×6 Glossy Paper',
        action: 'Load 4×6 photo paper in Epson/Canon printer, hit Ctrl+P to send borderless print with center cutting line.'
      },
      {
        title: 'Step 4: Thermal Lamination & POS Billing',
        action: 'Pass through pouch laminator for waterproof finish and generate ₹70 thermal bill.',
        studioAction: { label: 'Open Fast Billing Desk', tab: 'billing' }
      }
    ],
    docsRequired: ['Aadhaar No. & OTP', 'Acknowledgement Slip', 'PAN / Voter / Ayushman ID'],
    operatorTips: 'Printer settings mein "Glossy Photo Paper - High Quality" select karein taaki PVC print fade na ho.'
  },
  {
    id: 'passport_photo',
    name: 'Urgent 8-Copy Passport Photos (4×6 Glossy Sheet)',
    category: 'Photo Studio',
    icon: '📸',
    timeEstimate: '3 Minutes',
    suggestedRate: '₹50 - ₹60',
    targetStudio: 'passport_studio',
    steps: [
      {
        title: 'Step 1: Capture or Upload Customer Photo',
        action: 'Take photo on phone/webcam or upload customer JPEG into Passport Studio.',
        studioAction: { label: 'Open Passport Studio', tab: 'passport_studio' }
      },
      {
        title: 'Step 2: Magic Wand / Pen Background Cutout',
        action: 'Use 1-Click Magic Cut or Vector Pen Tool to replace background with Official White or Studio Blue.'
      },
      {
        title: 'Step 3: Auto Beauty Skin Smoothing & Face Radiance',
        action: 'Click "Auto Studio Beauty" to brighten skin tones, soften blemishes, and enhance facial contrast.'
      },
      {
        title: 'Step 4: Direct Print Sheet (Ctrl + P)',
        action: 'Direct print 4×6 Landscape sheet with exact 8 pre-aligned copies and guide lines.'
      }
    ],
    docsRequired: ['Customer Presence / Photo', 'Exam Notification (if name & date stamp required)'],
    operatorTips: 'SSC GD aur Police Bharti ke liye "Exam Strip" enable karke candidate ka naam aur date stamp karein.'
  },
  {
    id: 'ladki_bahin',
    name: 'Majhi Ladki Bahin Yojana Online Application',
    category: 'Govt Schemes',
    icon: '🌸',
    timeEstimate: '7-9 Minutes',
    suggestedRate: '₹100',
    targetStudio: 'portals',
    steps: [
      {
        title: 'Step 1: Aadhaar Mobile Linking & Bank Status Check',
        action: 'Check if applicant mobile number is active for OTP and Aadhaar is NPCI-linked to bank account.',
        studioAction: { label: 'Open Govt Portals', tab: 'portals' }
      },
      {
        title: 'Step 2: Document Verification & Upload',
        action: 'Verify Domicile Certificate (or 15-year Ration card / Voter ID) and Income Certificate (under 2.5 Lakh).',
        studioAction: { label: 'Ask AI Scheme Guide', tab: 'ai_assistant' }
      },
      {
        title: 'Step 3: Portal Form Submission',
        action: 'Submit application on official portal, verify bank details (Hamipatra declaration), and download acknowledgement token.'
      },
      {
        title: 'Step 4: Issue Acknowledgement Print & CRM Entry',
        action: 'Print token slip for applicant and add customer in CRM for application tracking.',
        studioAction: { label: 'Open Customer CRM', tab: 'customers' }
      }
    ],
    docsRequired: ['Aadhaar Card', 'Ration Card / Domicile', 'Bank Passbook (NPCI linked)', 'Hamipatra Undertaking'],
    operatorTips: 'Bank account mein DBT/NPCI active hona zaroori hai tabhi monthly ₹1,500 direct aayega.'
  },
  {
    id: 'police_exam',
    name: 'SSC GD / Police Bharti Online Application',
    category: 'Recruitment Forms',
    icon: '👮',
    timeEstimate: '10-12 Minutes',
    suggestedRate: '₹120 - ₹150',
    targetStudio: 'portals',
    steps: [
      {
        title: 'Step 1: Check Age, Domicile & Education Criteria',
        action: 'Verify 10th/12th marksheet, category caste certificate, and non-creamy layer certificate.'
      },
      {
        title: 'Step 2: Prepare Form-Specification Photo & Signature',
        action: 'Generate passport photo with candidate name & photo date in Passport Studio; resize signature under 20KB.',
        studioAction: { label: 'Open Passport Studio', tab: 'passport_studio' }
      },
      {
        title: 'Step 3: Online Form Entry & Fee Payment',
        action: 'Fill registration, review preview with applicant, pay official exam fee via UPI/Netbanking.',
        studioAction: { label: 'Open Recruitment Portals', tab: 'portals' }
      },
      {
        title: 'Step 4: Print Confirmation Page & Slip',
        action: 'Print color confirmation slip, issue receipt with registration number, and save in CRM.'
      }
    ],
    docsRequired: ['10th Marksheet', 'Caste & Non-Creamy Layer Certificate', 'Passport Photo with Date', 'Signature'],
    operatorTips: 'Form submit karne se pehle candidate ke samne preview check karwayein taaki koi spelling mistake na ho.'
  },
  {
    id: 'biodata',
    name: 'Marriage BioData & Professional CV Resume',
    category: 'Document Creation',
    icon: '📄',
    timeEstimate: '6-8 Minutes',
    suggestedRate: '₹70 - ₹100',
    targetStudio: 'biodata_maker',
    steps: [
      {
        title: 'Step 1: Select Template',
        action: 'Choose from Modern Professional CV, Hindi Traditional BioData, or Islamic Marriage BioData.',
        studioAction: { label: 'Open BioData Maker', tab: 'biodata_maker' }
      },
      {
        title: 'Step 2: Enter Applicant Details',
        action: 'Fill personal info, qualification, job designation, family background, and contact details.'
      },
      {
        title: 'Step 3: Upload Studio Portrait',
        action: 'Attach high-resolution passport/portrait photo.'
      },
      {
        title: 'Step 4: Direct Print / PDF Export',
        action: 'Download 300 DPI A4 PDF and print physical copy on heavy 100 GSM bond paper.'
      }
    ],
    docsRequired: ['Applicant Details & DOB', 'Qualification & Experience Details', 'Family Details', 'Photo'],
    operatorTips: 'BioData hamesha 100 GSM white bond paper par print karein taaki presentation professional lage.'
  }
];

export const WorkflowGuideView: React.FC<WorkflowGuideViewProps> = ({ onNavigate }) => {
  const [selectedBlueprint, setSelectedBlueprint] = useState<string>('pvc_card');
  const [completedSteps, setCompletedSteps] = useState<Record<string, boolean>>({});

  // Daily Counter State
  const [todayCards, setTodayCards] = useState<number>(14);
  const [todayPhotos, setTodayPhotos] = useState<number>(8);
  const [todayForms, setTodayForms] = useState<number>(6);

  const activeBlueprint = SERVICE_BLUEPRINTS.find(b => b.id === selectedBlueprint) || SERVICE_BLUEPRINTS[0];

  const toggleStep = (stepKey: string) => {
    setCompletedSteps(prev => ({
      ...prev,
      [stepKey]: !prev[stepKey]
    }));
  };

  const handleLaunchStudio = (tab: string) => {
    if (onNavigate) {
      onNavigate(tab);
    }
  };

  const estimatedTodayTurnover = todayCards * 70 + todayPhotos * 50 + todayForms * 100;

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-md flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl font-extrabold text-white flex items-center gap-2">
              <ShieldCheck className="w-6 h-6 text-emerald-400" />
              <span>Cyber Cafe SOP & Daily Workflow Engine</span>
            </h1>
            <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs px-2.5 py-0.5 rounded-full font-mono font-bold">
              v98.0 Operational Standard
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            End-to-end service blueprints • Customer intake to 300 DPI printing • Rates, checklists & 1-click studio launchers
          </p>
        </div>

        {/* Daily Production Summary Bar */}
        <div className="flex items-center gap-3 bg-slate-950 border border-slate-800 p-2.5 rounded-xl text-xs flex-wrap">
          <div className="flex items-center gap-1.5 px-2 border-r border-slate-800">
            <span className="text-slate-400">Cards:</span>
            <span className="font-mono text-blue-400 font-bold">{todayCards}</span>
            <button onClick={() => setTodayCards(c => c + 1)} className="text-[10px] bg-slate-800 hover:bg-slate-700 px-1 rounded text-white">+</button>
          </div>
          <div className="flex items-center gap-1.5 px-2 border-r border-slate-800">
            <span className="text-slate-400">Photos:</span>
            <span className="font-mono text-purple-400 font-bold">{todayPhotos}</span>
            <button onClick={() => setTodayPhotos(p => p + 1)} className="text-[10px] bg-slate-800 hover:bg-slate-700 px-1 rounded text-white">+</button>
          </div>
          <div className="flex items-center gap-1.5 px-2 border-r border-slate-800">
            <span className="text-slate-400">Forms:</span>
            <span className="font-mono text-emerald-400 font-bold">{todayForms}</span>
            <button onClick={() => setTodayForms(f => f + 1)} className="text-[10px] bg-slate-800 hover:bg-slate-700 px-1 rounded text-white">+</button>
          </div>
          <div className="flex items-center gap-1 text-amber-300 font-bold font-mono pl-1">
            <span>Est: ₹{estimatedTodayTurnover.toLocaleString('en-IN')}</span>
          </div>
        </div>
      </div>

      {/* SERVICE BLUEPRINT SELECTOR TABS */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {SERVICE_BLUEPRINTS.map((bp) => {
          const isSelected = selectedBlueprint === bp.id;
          return (
            <button
              key={bp.id}
              onClick={() => setSelectedBlueprint(bp.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold border transition-all whitespace-nowrap flex-shrink-0 ${
                isSelected
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white border-blue-400 shadow-lg shadow-blue-600/30 scale-102'
                  : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <span className="text-base">{bp.icon}</span>
              <span>{bp.name}</span>
            </button>
          );
        })}
      </div>

      {/* SELECTED BLUEPRINT DETAIL VIEW */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Left: Step-by-Step Execution Plan (8 cols) */}
        <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <span className="text-3xl">{activeBlueprint.icon}</span>
              <div>
                <h2 className="text-base font-extrabold text-white">{activeBlueprint.name}</h2>
                <div className="flex items-center gap-3 text-xs text-slate-400 mt-0.5">
                  <span className="flex items-center gap-1 text-sky-400 font-medium">
                    <Clock className="w-3.5 h-3.5" />
                    <span>Est. Time: {activeBlueprint.timeEstimate}</span>
                  </span>
                  <span>•</span>
                  <span className="flex items-center gap-1 text-emerald-400 font-bold font-mono">
                    <DollarSign className="w-3.5 h-3.5" />
                    <span>Standard Rate: {activeBlueprint.suggestedRate}</span>
                  </span>
                </div>
              </div>
            </div>

            {/* Quick 1-Click Launch Button */}
            <button
              onClick={() => handleLaunchStudio(activeBlueprint.targetStudio)}
              className="flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs px-4 py-2 rounded-xl shadow-lg shadow-emerald-600/20 transition-all hover:scale-105 self-start sm:self-auto"
            >
              <Zap className="w-4 h-4" />
              <span>Launch Studio for this Service</span>
            </button>
          </div>

          {/* Steps List */}
          <div className="space-y-3">
            {activeBlueprint.steps.map((st, idx) => {
              const stepKey = `${activeBlueprint.id}-${idx}`;
              const isDone = !!completedSteps[stepKey];

              return (
                <div
                  key={idx}
                  className={`p-4 rounded-xl border transition-all space-y-2 ${
                    isDone 
                      ? 'bg-slate-950/40 border-emerald-500/40' 
                      : 'bg-slate-950 border-slate-800/80 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <span className={`w-6 h-6 rounded-lg flex items-center justify-center font-mono font-bold text-xs ${
                        isDone ? 'bg-emerald-500 text-slate-950' : 'bg-blue-600 text-white'
                      }`}>
                        {idx + 1}
                      </span>
                      <h3 className="font-extrabold text-white text-xs">{st.title}</h3>
                    </div>

                    <div className="flex items-center gap-2">
                      {st.studioAction && (
                        <button
                          onClick={() => handleLaunchStudio(st.studioAction!.tab)}
                          className="flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg bg-blue-600/20 text-blue-300 border border-blue-500/30 hover:bg-blue-600/30 transition-colors"
                        >
                          <Play className="w-3 h-3" />
                          <span>{st.studioAction.label}</span>
                        </button>
                      )}

                      <button
                        onClick={() => toggleStep(stepKey)}
                        className={`flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg border transition-all ${
                          isDone 
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                            : 'bg-slate-900 text-slate-400 border-slate-700 hover:text-white'
                        }`}
                      >
                        {isDone ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Circle className="w-3.5 h-3.5" />}
                        <span>{isDone ? 'Completed' : 'Mark Done'}</span>
                      </button>
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed pl-8">
                    {st.action}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Prerequisite Documents & Pro Operator Tips (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          {/* Required Documents Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-white uppercase tracking-wider">
              <FileCheck className="w-4 h-4 text-emerald-400" />
              <span>Customer Documents Checklist</span>
            </div>

            <div className="space-y-2 text-xs text-slate-300">
              {activeBlueprint.docsRequired.map((doc, i) => (
                <div key={i} className="flex items-start gap-2 bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-emerald-400 font-bold">✓</span>
                  <span>{doc}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Pro Operator Tip Card */}
          <div className="bg-gradient-to-br from-amber-950/20 via-slate-900 to-slate-900 border border-amber-500/30 rounded-2xl p-4 shadow-md space-y-2 text-xs">
            <div className="flex items-center gap-2 text-amber-300 font-bold uppercase tracking-wider">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Operator Golden Rule</span>
            </div>
            <p className="text-slate-300 leading-relaxed">
              {activeBlueprint.operatorTips}
            </p>
          </div>

          {/* Quick Studio Jump Deck */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md space-y-2.5">
            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
              Quick Workstation Launchers
            </span>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => handleLaunchStudio('pvc_studio')}
                className="p-2.5 rounded-xl bg-slate-950 hover:bg-blue-950/30 border border-slate-800 hover:border-blue-500/40 text-left transition-all group"
              >
                <div className="font-bold text-white group-hover:text-blue-400">PVC Studio</div>
                <div className="text-[10px] text-slate-400">300 DPI Cards</div>
              </button>

              <button
                onClick={() => handleLaunchStudio('passport_studio')}
                className="p-2.5 rounded-xl bg-slate-950 hover:bg-purple-950/30 border border-slate-800 hover:border-purple-500/40 text-left transition-all group"
              >
                <div className="font-bold text-white group-hover:text-purple-400">Passport Studio</div>
                <div className="text-[10px] text-slate-400">4×6 & A4 Sheet</div>
              </button>

              <button
                onClick={() => handleLaunchStudio('billing')}
                className="p-2.5 rounded-xl bg-slate-950 hover:bg-emerald-950/30 border border-slate-800 hover:border-emerald-500/40 text-left transition-all group"
              >
                <div className="font-bold text-white group-hover:text-emerald-400">Fast POS Billing</div>
                <div className="text-[10px] text-slate-400">Thermal Slips</div>
              </button>

              <button
                onClick={() => handleLaunchStudio('portals')}
                className="p-2.5 rounded-xl bg-slate-950 hover:bg-sky-950/30 border border-slate-800 hover:border-sky-500/40 text-left transition-all group"
              >
                <div className="font-bold text-white group-hover:text-sky-400">50+ Portals Hub</div>
                <div className="text-[10px] text-slate-400">Govt Schemes</div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
