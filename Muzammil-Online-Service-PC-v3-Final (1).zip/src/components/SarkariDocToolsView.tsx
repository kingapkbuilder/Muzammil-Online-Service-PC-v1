import React, { useState, useRef } from 'react';
import { 
  FileText, 
  Minimize2, 
  Copy, 
  Printer, 
  Download, 
  Check, 
  Upload, 
  ShieldCheck, 
  Layers, 
  Stamp, 
  AlertCircle,
  Sparkles,
  RefreshCw
} from 'lucide-react';
import { ShopSettings } from '../types';

interface SarkariDocToolsViewProps {
  settings: ShopSettings;
}

export const SarkariDocToolsView: React.FC<SarkariDocToolsViewProps> = ({ settings }) => {
  const [activeTool, setActiveTool] = useState<'compressor' | 'xerox_2in1' | 'digital_stamp'>('compressor');

  // --- 1. KB COMPRESSOR STATE ---
  const [compressorFile, setCompressorFile] = useState<File | null>(null);
  const [compressorPreview, setCompressorPreview] = useState<string | null>(null);
  const [originalSizeKb, setOriginalSizeKb] = useState<number>(0);
  const [targetKb, setTargetKb] = useState<number>(50);
  const [compressedBlob, setCompressedBlob] = useState<Blob | null>(null);
  const [compressedSizeKb, setCompressedSizeKb] = useState<number>(0);
  const [compressedPreview, setCompressedPreview] = useState<string | null>(null);
  const [isCompressing, setIsCompressing] = useState<boolean>(false);

  // --- 2. A4 2-IN-1 XEROX STATE ---
  const [frontImage, setFrontImage] = useState<string | null>(null);
  const [backImage, setBackImage] = useState<string | null>(null);
  const [xeroxMode, setXeroxMode] = useState<'bw' | 'color'>('bw');
  const [includeShopHeader, setIncludeShopHeader] = useState<boolean>(true);
  const [xeroxZoom, setXeroxZoom] = useState<number>(100);

  // --- 3. DIGITAL STAMP STATE ---
  const [stampDocImage, setStampDocImage] = useState<string | null>(null);
  const [stampType, setStampType] = useState<'verified' | 'true_copy' | 'attested'>('true_copy');
  const [stampColor, setStampColor] = useState<string>('#1d4ed8'); // Blue ink
  const [stampDate, setStampDate] = useState<string>(new Date().toLocaleDateString('en-GB'));
  const [stampPosition, setStampPosition] = useState<{ x: number; y: number }>({ x: 70, y: 75 });

  // Handle compressor image upload
  const handleCompressorUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setCompressorFile(file);
    setOriginalSizeKb(Math.round(file.size / 1024));

    const reader = new FileReader();
    reader.onload = () => {
      setCompressorPreview(reader.result as string);
      processCompression(reader.result as string, targetKb);
    };
    reader.readAsDataURL(file);
  };

  // Perform compression to target KB
  const processCompression = (imageSrc: string, targetSizeKb: number) => {
    setIsCompressing(true);
    const img = new Image();
    img.src = imageSrc;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;

      // Scale down if extremely large
      const maxDim = 1600;
      if (width > maxDim || height > maxDim) {
        if (width > height) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        } else {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        setIsCompressing(false);
        return;
      }

      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, width, height);
      ctx.drawImage(img, 0, 0, width, height);

      // Binary search for optimal JPEG quality to match target KB
      let minQuality = 0.05;
      let maxQuality = 0.95;
      let bestBlob: Blob | null = null;
      let bestSizeKb = 0;

      const attempt = (quality: number) => {
        return new Promise<Blob>((resolve) => {
          canvas.toBlob((b) => resolve(b!), 'image/jpeg', quality);
        });
      };

      (async () => {
        for (let i = 0; i < 7; i++) {
          const midQuality = (minQuality + maxQuality) / 2;
          const b = await attempt(midQuality);
          const currentKb = Math.round(b.size / 1024);
          bestBlob = b;
          bestSizeKb = currentKb;

          if (Math.abs(currentKb - targetSizeKb) <= 3) {
            break;
          }

          if (currentKb > targetSizeKb) {
            maxQuality = midQuality;
          } else {
            minQuality = midQuality;
          }
        }

        if (bestBlob) {
          setCompressedBlob(bestBlob);
          setCompressedSizeKb(bestSizeKb);
          setCompressedPreview(URL.createObjectURL(bestBlob));
        }
        setIsCompressing(false);
      })();
    };
  };

  const handleDownloadCompressed = () => {
    if (!compressedBlob) return;
    const url = URL.createObjectURL(compressedBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Sarkari-Document-${compressedSizeKb}KB.jpg`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Xerox 2-in-1 print
  const handlePrintXerox = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 p-6 rounded-2xl border border-indigo-500/20 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                CSC & Cyber Cafe Suite
              </span>
              <span className="text-xs text-slate-400 font-mono">v3.0 Ultra Tools</span>
            </div>
            <h1 className="text-2xl font-black text-white mt-1 flex items-center gap-2">
              <ShieldCheck className="w-7 h-7 text-indigo-400" />
              <span>Sarkari Form & Xerox Master Tools</span>
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Exact 20KB/50KB/100KB Document Compressor, 2-in-1 A4 Aadhaar Xerox, aur "True Copy" Official Digital Stamp.
            </p>
          </div>

          {/* Sub Tabs */}
          <div className="flex items-center gap-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800">
            <button
              onClick={() => setActiveTool('compressor')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTool === 'compressor'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Minimize2 className="w-3.5 h-3.5" />
              <span>KB Compressor</span>
            </button>

            <button
              onClick={() => setActiveTool('xerox_2in1')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTool === 'xerox_2in1'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Copy className="w-3.5 h-3.5" />
              <span>A4 2-in-1 Xerox</span>
            </button>

            <button
              onClick={() => setActiveTool('digital_stamp')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                activeTool === 'digital_stamp'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Stamp className="w-3.5 h-3.5" />
              <span>Verified Stamp</span>
            </button>
          </div>
        </div>
      </div>

      {/* ============================================================== */}
      {/* TOOL 1: SARKARI FORM KB COMPRESSOR */}
      {/* ============================================================== */}
      {activeTool === 'compressor' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Controls Left Column */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-lg">
              <h3 className="font-extrabold text-white text-sm flex items-center gap-2">
                <Minimize2 className="w-4 h-4 text-indigo-400" />
                <span>Upload & Target Size Selection</span>
              </h3>

              {/* Upload Box */}
              <label className="border-2 border-dashed border-indigo-500/30 hover:border-indigo-500/60 bg-slate-950/60 rounded-xl p-6 flex flex-col items-center justify-center cursor-pointer transition-all group">
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={handleCompressorUpload}
                  className="hidden"
                />
                <Upload className="w-8 h-8 text-indigo-400 group-hover:scale-110 transition-transform mb-2" />
                <span className="text-xs font-bold text-white">Upload Sarkari Document / Photo</span>
                <span className="text-[11px] text-slate-500 mt-0.5">JPG, PNG supported</span>
              </label>

              {/* Target Size Presets */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300 flex items-center justify-between">
                  <span>Target File Size:</span>
                  <span className="text-indigo-400 font-mono font-bold text-sm">{targetKb} KB</span>
                </label>

                <div className="grid grid-cols-3 gap-2">
                  {[
                    { label: 'Signature', kb: 20 },
                    { label: 'Passport Photo', kb: 50 },
                    { label: 'Caste/Income', kb: 100 },
                    { label: 'Domicile/EWS', kb: 200 },
                    { label: 'Ration/Aadhaar', kb: 300 },
                    { label: 'High Res', kb: 500 },
                  ].map((p) => (
                    <button
                      key={p.kb}
                      onClick={() => {
                        setTargetKb(p.kb);
                        if (compressorPreview) processCompression(compressorPreview, p.kb);
                      }}
                      className={`p-2 rounded-xl text-left border transition-all ${
                        targetKb === p.kb
                          ? 'bg-indigo-600/30 border-indigo-500 text-white font-bold'
                          : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      <div className="text-[10px] text-slate-400">{p.label}</div>
                      <div className="text-xs font-extrabold text-indigo-300">{p.kb} KB</div>
                    </button>
                  ))}
                </div>

                {/* Custom Slider */}
                <input
                  type="range"
                  min="10"
                  max="1000"
                  step="5"
                  value={targetKb}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setTargetKb(val);
                    if (compressorPreview) processCompression(compressorPreview, val);
                  }}
                  className="w-full accent-indigo-500 h-2 bg-slate-800 rounded-lg cursor-pointer mt-2"
                />
              </div>

              {/* Quick Info */}
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-[11px] text-slate-400 space-y-1">
                <div className="flex items-center gap-1.5 text-indigo-300 font-bold">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Sarkari Form Guidelines:</span>
                </div>
                <div>• SSC GD / MTS: Photo 20-50KB, Signature 10-20KB</div>
                <div>• Maharashtra Police Bharti: Photo 50KB, Sign 20KB</div>
                <div>• MahaDBT & Aaple Sarkar: Documents under 256KB</div>
              </div>
            </div>
          </div>

          {/* Preview Right Column */}
          <div className="lg:col-span-7">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-lg flex flex-col justify-between h-full min-h-[420px]">
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <h3 className="font-extrabold text-white text-sm">Real-Time Compression Preview</h3>
                  {originalSizeKb > 0 && (
                    <div className="flex items-center gap-3 text-xs font-mono">
                      <span className="text-slate-400">Original: <b className="text-amber-400">{originalSizeKb} KB</b></span>
                      <span>➡️</span>
                      <span className="text-slate-400">Target: <b className="text-emerald-400">{compressedSizeKb} KB</b></span>
                    </div>
                  )}
                </div>

                {compressorPreview ? (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <span className="text-[10px] text-slate-400 uppercase font-bold">Original Image</span>
                      <div className="h-64 bg-slate-950 rounded-xl border border-slate-800 overflow-hidden flex items-center justify-center p-2">
                        <img src={compressorPreview} alt="Original" className="max-h-full max-w-full object-contain" />
                      </div>
                    </div>

                    <div className="space-y-1">
                      <span className="text-[10px] text-emerald-400 uppercase font-bold flex items-center gap-1">
                        <span>Compressed Output</span>
                        {isCompressing && <RefreshCw className="w-3 h-3 animate-spin" />}
                      </span>
                      <div className="h-64 bg-slate-950 rounded-xl border border-emerald-500/30 overflow-hidden flex items-center justify-center p-2 relative">
                        {compressedPreview && (
                          <img src={compressedPreview} alt="Compressed" className="max-h-full max-w-full object-contain" />
                        )}
                        <span className="absolute bottom-2 right-2 bg-emerald-500/90 text-slate-950 font-black text-[10px] px-2 py-0.5 rounded shadow">
                          {compressedSizeKb} KB
                        </span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="h-64 flex flex-col items-center justify-center text-slate-500 text-xs border border-dashed border-slate-800 rounded-xl">
                    <Minimize2 className="w-8 h-8 text-slate-600 mb-2" />
                    <span>Upload a document or photo to compress</span>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-slate-800 flex items-center gap-3">
                <button
                  onClick={handleDownloadCompressed}
                  disabled={!compressedBlob || isCompressing}
                  className="flex-1 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs py-3 rounded-xl shadow transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Exact {compressedSizeKb} KB File</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* TOOL 2: A4 2-IN-1 AADHAAR XEROX GENERATOR */}
      {/* ============================================================== */}
      {activeTool === 'xerox_2in1' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Controls Left Column */}
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-lg">
              <h3 className="font-extrabold text-white text-sm flex items-center gap-2">
                <Copy className="w-4 h-4 text-indigo-400" />
                <span>Upload Front & Back Cards</span>
              </h3>

              {/* Front Upload */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">1. Front Side (Photo & Name):</label>
                <label className="border border-slate-700 hover:border-indigo-500 bg-slate-950 rounded-xl p-3 flex items-center justify-center cursor-pointer transition-all">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) {
                        const r = new FileReader();
                        r.onload = () => setFrontImage(r.result as string);
                        r.readAsDataURL(f);
                      }
                    }}
                    className="hidden"
                  />
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <Upload className="w-4 h-4 text-indigo-400" />
                    <span>{frontImage ? 'Front Loaded (Click to Change)' : 'Upload Front Image'}</span>
                  </div>
                </label>
              </div>

              {/* Back Upload */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">2. Back Side (Address & QR):</label>
                <label className="border border-slate-700 hover:border-indigo-500 bg-slate-950 rounded-xl p-3 flex items-center justify-center cursor-pointer transition-all">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) {
                        const r = new FileReader();
                        r.onload = () => setBackImage(r.result as string);
                        r.readAsDataURL(f);
                      }
                    }}
                    className="hidden"
                  />
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <Upload className="w-4 h-4 text-indigo-400" />
                    <span>{backImage ? 'Back Loaded (Click to Change)' : 'Upload Back Image'}</span>
                  </div>
                </label>
              </div>

              {/* Mode Toggle */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300">Print Color Mode:</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setXeroxMode('bw')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all ${
                      xeroxMode === 'bw'
                        ? 'bg-slate-100 text-slate-900 border-white'
                        : 'bg-slate-950 text-slate-400 border-slate-800'
                    }`}
                  >
                    B&W Xerox Mode
                  </button>
                  <button
                    onClick={() => setXeroxMode('color')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border transition-all ${
                      xeroxMode === 'color'
                        ? 'bg-indigo-600 text-white border-indigo-400'
                        : 'bg-slate-950 text-slate-400 border-slate-800'
                    }`}
                  >
                    Full Color Mode
                  </button>
                </div>
              </div>

              {/* Shop Header Checkbox */}
              <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={includeShopHeader}
                  onChange={(e) => setIncludeShopHeader(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-0"
                />
                <span>Include Cyber Cafe Header & Date</span>
              </label>

              {/* Print Button */}
              <button
                onClick={handlePrintXerox}
                className="w-full bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-extrabold text-xs py-3 rounded-xl shadow transition-all flex items-center justify-center gap-2"
              >
                <Printer className="w-4 h-4" />
                <span>1-Click Print A4 Xerox</span>
              </button>
            </div>
          </div>

          {/* A4 Sheet Live Preview */}
          <div className="lg:col-span-8 flex justify-center">
            <div 
              id="printable-xerox-a4" 
              className={`w-[480px] bg-white text-slate-900 rounded shadow-2xl p-8 border border-slate-300 min-h-[660px] flex flex-col justify-between ${
                xeroxMode === 'bw' ? 'filter grayscale contrast-125' : ''
              }`}
            >
              {/* Header */}
              {includeShopHeader && (
                <div className="border-b-2 border-slate-900 pb-2 flex items-center justify-between text-[11px]">
                  <div>
                    <h2 className="font-black text-sm tracking-wide uppercase">{settings.shopName || 'MUZAMMIL ONLINE SERVICE'}</h2>
                    <p className="text-[10px] text-slate-600">Aadhaar / Voter / PAN Official 2-in-1 Customer Xerox Copy</p>
                  </div>
                  <div className="text-right text-[10px] font-mono">
                    <div>Date: {new Date().toLocaleDateString('en-GB')}</div>
                    <div>Ph: {settings.phone || '9561460313'}</div>
                  </div>
                </div>
              )}

              {/* Front Card Container */}
              <div className="flex flex-col items-center my-4">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">FRONT SIDE</span>
                <div className="w-[340px] h-[215px] border-2 border-dashed border-slate-400 rounded-lg flex items-center justify-center overflow-hidden bg-slate-50 shadow-sm p-1">
                  {frontImage ? (
                    <img src={frontImage} alt="Front" className="max-w-full max-h-full object-contain" />
                  ) : (
                    <span className="text-xs text-slate-400 font-semibold">[ Upload Front Card ]</span>
                  )}
                </div>
              </div>

              {/* Center Fold / Cut Line */}
              <div className="w-full flex items-center gap-2 text-slate-400 text-[10px] font-mono my-2">
                <div className="flex-1 border-b border-dashed border-slate-400" />
                <span>✂️ FOLD OR CUT LINE</span>
                <div className="flex-1 border-b border-dashed border-slate-400" />
              </div>

              {/* Back Card Container */}
              <div className="flex flex-col items-center my-4">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">BACK SIDE</span>
                <div className="w-[340px] h-[215px] border-2 border-dashed border-slate-400 rounded-lg flex items-center justify-center overflow-hidden bg-slate-50 shadow-sm p-1">
                  {backImage ? (
                    <img src={backImage} alt="Back" className="max-w-full max-h-full object-contain" />
                  ) : (
                    <span className="text-xs text-slate-400 font-semibold">[ Upload Back Card ]</span>
                  )}
                </div>
              </div>

              {/* Footer */}
              <div className="text-center text-[9px] text-slate-500 border-t border-slate-200 pt-2 font-mono">
                Printed via Muzammil Online Service Workstation Suite • Verified Customer Document
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* TOOL 3: DIGITAL "TRUE COPY / VERIFIED" OFFICIAL STAMP */}
      {/* ============================================================== */}
      {activeTool === 'digital_stamp' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-lg">
              <h3 className="font-extrabold text-white text-sm flex items-center gap-2">
                <Stamp className="w-4 h-4 text-indigo-400" />
                <span>Cyber Cafe Official Seal & Stamp</span>
              </h3>

              {/* Stamp Type */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">Seal Stamp Type:</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'true_copy', label: 'TRUE COPY' },
                    { id: 'verified', label: 'VERIFIED' },
                    { id: 'attested', label: 'ATTESTED' },
                  ].map((s) => (
                    <button
                      key={s.id}
                      onClick={() => setStampType(s.id as any)}
                      className={`p-2 rounded-xl text-center text-xs font-bold border transition-all ${
                        stampType === s.id
                          ? 'bg-blue-600/30 border-blue-500 text-white'
                          : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Ink Color */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">Stamp Ink Color:</label>
                <div className="flex items-center gap-3">
                  {[
                    { color: '#1d4ed8', name: 'Official Blue Ink' },
                    { color: '#b91c1c', name: 'Official Red Ink' },
                    { color: '#047857', name: 'Official Green Ink' },
                  ].map((c) => (
                    <button
                      key={c.color}
                      onClick={() => setStampColor(c.color)}
                      className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-semibold ${
                        stampColor === c.color ? 'border-white text-white' : 'border-slate-800 text-slate-400'
                      }`}
                    >
                      <span className="w-3 h-3 rounded-full" style={{ backgroundColor: c.color }} />
                      <span>{c.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Date */}
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-300">Stamp Verification Date:</label>
                <input
                  type="text"
                  value={stampDate}
                  onChange={(e) => setStampDate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white"
                />
              </div>

              {/* Info */}
              <p className="text-[11px] text-slate-400 bg-slate-950 p-3 rounded-xl border border-slate-800">
                Ye stamp aapke kisi bhi Xerox document par professional "True Copy" ka official thappa lagane ke liye use hota hai.
              </p>
            </div>
          </div>

          {/* Stamp Preview Card */}
          <div className="lg:col-span-7 flex flex-col items-center justify-center p-8 bg-slate-900 border border-slate-800 rounded-2xl shadow-lg">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-6">Live Digital Seal Preview</h4>

            {/* Rendered Stamp Graphic */}
            <div 
              className="p-6 border-4 border-double rounded-2xl flex flex-col items-center justify-center text-center shadow-md bg-white select-none max-w-sm"
              style={{ borderColor: stampColor, color: stampColor }}
            >
              <div className="text-[11px] font-black uppercase tracking-widest border-b-2 pb-1 mb-2 w-full" style={{ borderColor: stampColor }}>
                ★ {stampType.toUpperCase().replace('_', ' ')} ★
              </div>
              <div className="text-sm font-extrabold uppercase tracking-wide">
                {settings.shopName || 'MUZAMMIL ONLINE SERVICE'}
              </div>
              <div className="text-[10px] font-bold mt-1">
                CSC & CYBER CAFE VERIFIED
              </div>
              <div className="text-[9px] font-mono mt-1">
                DATE: {stampDate} | MOB: {settings.phone || '9561460313'}
              </div>
              <div className="text-[8px] italic mt-2 text-slate-500">
                Authorised Signature & Verification Stamp
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
