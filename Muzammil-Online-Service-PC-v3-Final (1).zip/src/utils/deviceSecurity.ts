import { OperatorAccount, UserAccount } from '../types';

const STORAGE_KEYS = {
  DEVICE_ID: 'mos_hardware_device_id',
  DEVICE_NAME: 'mos_hardware_device_name',
  OPERATORS: 'mos_registered_operators',
  AUDIT_LOGS: 'mos_security_audit_logs'
};

export interface SecurityAuditLog {
  id: string;
  timestamp: string;
  username: string;
  action: 'LOGIN_SUCCESS' | 'LOGIN_FAILED' | 'DEVICE_BLOCKED' | 'DEVICE_BOUND' | 'DEVICE_RESET' | 'OPERATOR_LOCKED';
  deviceId: string;
  deviceName: string;
  deviceType: 'pc' | 'mobile';
  details: string;
}

// Detect if current runtime is a mobile phone / tablet
export function isMobileDevice(): boolean {
  if (typeof navigator === 'undefined') return false;
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

// Persistent hardware device ID (Generated once per machine/browser)
export function getHardwareDeviceId(): string {
  try {
    let deviceId = localStorage.getItem(STORAGE_KEYS.DEVICE_ID);
    if (!deviceId) {
      const randStr = Math.random().toString(36).substring(2, 6).toUpperCase() + '-' + Math.random().toString(36).substring(2, 6).toUpperCase();
      const mobile = isMobileDevice();
      deviceId = `DEV-MOS-${mobile ? 'MOB' : 'PC'}-${randStr}`;
      localStorage.setItem(STORAGE_KEYS.DEVICE_ID, deviceId);
    }
    return deviceId;
  } catch {
    return 'DEV-MOS-DEFAULT-001';
  }
}

// Friendly device name based on platform/browser
export function getHardwareDeviceName(): string {
  try {
    let name = localStorage.getItem(STORAGE_KEYS.DEVICE_NAME);
    if (!name) {
      const ua = navigator.userAgent;
      let os = 'Windows PC';
      if (/Android/i.test(ua)) os = 'Android Mobile';
      else if (/iPhone/i.test(ua)) os = 'iPhone';
      else if (/iPad/i.test(ua)) os = 'iPad';
      else if (/Mac/i.test(ua)) os = 'Mac Workstation';
      else if (/Linux/i.test(ua)) os = 'Linux Workstation';

      let browser = 'Chrome';
      if (/Firefox/i.test(ua)) browser = 'Firefox';
      else if (/Edg/i.test(ua)) browser = 'Edge';
      else if (/Safari/i.test(ua) && !/Chrome/i.test(ua)) browser = 'Safari';

      name = `${os} • ${browser}`;
      localStorage.setItem(STORAGE_KEYS.DEVICE_NAME, name);
    }
    return name;
  } catch {
    return isMobileDevice() ? 'Authorized Mobile' : 'Authorized Workstation';
  }
}

// Default pre-configured operators (Dual Device: 1 PC + 1 Mobile)
const DEFAULT_OPERATORS: OperatorAccount[] = [
  {
    id: 'op-admin',
    username: 'admin',
    password: 'muzammil786',
    displayName: 'Imran Khan (Master Admin)',
    role: 'admin',
    phone: '9561460313',
    boundPcDeviceId: null,
    boundPcDeviceName: null,
    boundPcAt: null,
    boundMobileDeviceId: null,
    boundMobileDeviceName: null,
    boundMobileAt: null,
    lastLogin: null,
    isLocked: false,
    validityExpiresAt: 'Lifetime (Never Expires)',
    validityDaysLeft: 999999
  },
  {
    id: 'op-1',
    username: 'operator1',
    password: 'sameer123',
    displayName: 'Shaikh Sameer',
    role: 'operator',
    phone: '9876543210',
    boundPcDeviceId: null,
    boundPcDeviceName: null,
    boundPcAt: null,
    boundMobileDeviceId: null,
    boundMobileDeviceName: null,
    boundMobileAt: null,
    lastLogin: null,
    isLocked: false
  },
  {
    id: 'op-2',
    username: 'operator2',
    password: 'adil123',
    displayName: 'Adil Khan',
    role: 'operator',
    phone: '9123456780',
    boundPcDeviceId: null,
    boundPcDeviceName: null,
    boundPcAt: null,
    boundMobileDeviceId: null,
    boundMobileDeviceName: null,
    boundMobileAt: null,
    lastLogin: null,
    isLocked: false
  }
];

// Load registered operators
export function getRegisteredOperators(): OperatorAccount[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.OPERATORS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.OPERATORS, JSON.stringify(DEFAULT_OPERATORS));
      return DEFAULT_OPERATORS;
    }
    const parsed = JSON.parse(raw);
    // Ensure dual device fields are present if loaded from legacy format
    return parsed.map((op: any) => ({
      ...op,
      boundPcDeviceId: op.boundPcDeviceId ?? (op.boundDeviceId?.includes('-PC-') ? op.boundDeviceId : null),
      boundPcDeviceName: op.boundPcDeviceName ?? (op.boundDeviceId?.includes('-PC-') ? op.boundDeviceName : null),
      boundPcAt: op.boundPcAt ?? (op.boundDeviceId?.includes('-PC-') ? op.boundAt : null),
      boundMobileDeviceId: op.boundMobileDeviceId ?? (op.boundDeviceId?.includes('-MOB-') ? op.boundDeviceId : null),
      boundMobileDeviceName: op.boundMobileDeviceName ?? (op.boundDeviceId?.includes('-MOB-') ? op.boundDeviceName : null),
      boundMobileAt: op.boundMobileAt ?? (op.boundDeviceId?.includes('-MOB-') ? op.boundAt : null),
    }));
  } catch {
    return DEFAULT_OPERATORS;
  }
}

// Save operators
export function saveRegisteredOperators(operators: OperatorAccount[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.OPERATORS, JSON.stringify(operators));
  } catch (e) {
    console.error('Failed to save operators', e);
  }
}

// Add security audit log
export function addSecurityAuditLog(
  action: SecurityAuditLog['action'],
  username: string,
  details: string
): void {
  try {
    const deviceId = getHardwareDeviceId();
    const deviceName = getHardwareDeviceName();
    const deviceType: 'pc' | 'mobile' = isMobileDevice() ? 'mobile' : 'pc';

    const raw = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
    const logs: SecurityAuditLog[] = raw ? JSON.parse(raw) : [];

    const newLog: SecurityAuditLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp: new Date().toLocaleString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      }),
      username,
      action,
      deviceId,
      deviceName,
      deviceType,
      details
    };

    logs.unshift(newLog);
    if (logs.length > 60) logs.pop();
    localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(logs));
  } catch (e) {
    console.error('Failed to record audit log', e);
  }
}

export function getSecurityAuditLogs(): SecurityAuditLog[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

// -------------------------------------------------------------
// DUAL-DEVICE AUTHENTICATION (1 ID = 1 Authorized PC + 1 Authorized Mobile)
// -------------------------------------------------------------
export interface AuthResult {
  success: boolean;
  user?: UserAccount;
  error?: string;
  deviceLockedToOther?: boolean;
  deviceType?: 'pc' | 'mobile';
  boundDeviceName?: string;
}

export function authenticateOperator(usernameInput: string, passwordInput: string): AuthResult {
  const username = usernameInput.trim().toLowerCase();
  const password = passwordInput.trim();
  const currentDeviceId = getHardwareDeviceId();
  const currentDeviceName = getHardwareDeviceName();
  const currentType: 'pc' | 'mobile' = isMobileDevice() ? 'mobile' : 'pc';

  const operators = getRegisteredOperators();
  const operator = operators.find(o => o.username.toLowerCase() === username);

  if (!operator) {
    addSecurityAuditLog('LOGIN_FAILED', username, 'Invalid operator username');
    return {
      success: false,
      error: 'Invalid Operator ID. Please verify your username.'
    };
  }

  // Check password
  if (operator.password && operator.password !== password) {
    addSecurityAuditLog('LOGIN_FAILED', username, 'Incorrect password entered');
    return {
      success: false,
      error: 'Incorrect Password. Please try again.'
    };
  }

  // Check if account is suspended / locked
  if (operator.isLocked) {
    addSecurityAuditLog('OPERATOR_LOCKED', username, 'Attempt to login to suspended account');
    return {
      success: false,
      error: '⛔ ACCOUNT SUSPENDED: This operator ID has been locked by Master Admin. Please contact shop owner.'
    };
  }

  // -------------------------------------------------------------
  // DUAL-DEVICE ENFORCEMENT: PC SLOT vs MOBILE SLOT
  // -------------------------------------------------------------
  const now = new Date().toLocaleString('en-IN');

  if (currentType === 'pc') {
    // Logging in from PC
    if (!operator.boundPcDeviceId) {
      // First PC login: Bind this PC!
      operator.boundPcDeviceId = currentDeviceId;
      operator.boundPcDeviceName = currentDeviceName;
      operator.boundPcAt = now;
      operator.lastLogin = now;
      saveRegisteredOperators(operators);
      addSecurityAuditLog('DEVICE_BOUND', username, `PC bound: ${currentDeviceName} (${currentDeviceId})`);
    } else if (operator.boundPcDeviceId !== currentDeviceId) {
      // Different PC tried to access!
      addSecurityAuditLog(
        'DEVICE_BLOCKED',
        username,
        `Unauthorized PC login attempt. ID is already bound to PC (${operator.boundPcDeviceName} / ${operator.boundPcDeviceId})`
      );

      return {
        success: false,
        deviceLockedToOther: true,
        deviceType: 'pc',
        boundDeviceName: operator.boundPcDeviceName || operator.boundPcDeviceId,
        error: `🚨 PC DEVICE MISMATCH:\nThis Operator ID is already paired with your shop PC (${operator.boundPcDeviceName || operator.boundPcDeviceId}).\n\n1 ID is permitted on 1 PC + 1 Mobile only. To use on this new computer, ask Master Admin to reset your PC binding.`
      };
    } else {
      // Authorized PC match!
      operator.lastLogin = now;
      saveRegisteredOperators(operators);
      addSecurityAuditLog('LOGIN_SUCCESS', username, `Successful login on authorized PC (${currentDeviceId})`);
    }
  } else {
    // Logging in from Mobile Phone / Tablet
    if (!operator.boundMobileDeviceId) {
      // First Mobile login: Bind this Mobile!
      operator.boundMobileDeviceId = currentDeviceId;
      operator.boundMobileDeviceName = currentDeviceName;
      operator.boundMobileAt = now;
      operator.lastLogin = now;
      saveRegisteredOperators(operators);
      addSecurityAuditLog('DEVICE_BOUND', username, `Mobile bound: ${currentDeviceName} (${currentDeviceId})`);
    } else if (operator.boundMobileDeviceId !== currentDeviceId) {
      // Different Mobile tried to access!
      addSecurityAuditLog(
        'DEVICE_BLOCKED',
        username,
        `Unauthorized Mobile login attempt. ID is already bound to Mobile (${operator.boundMobileDeviceName} / ${operator.boundMobileDeviceId})`
      );

      return {
        success: false,
        deviceLockedToOther: true,
        deviceType: 'mobile',
        boundDeviceName: operator.boundMobileDeviceName || operator.boundMobileDeviceId,
        error: `🚨 MOBILE DEVICE MISMATCH:\nThis Operator ID is already paired with your registered Mobile (${operator.boundMobileDeviceName || operator.boundMobileDeviceId}).\n\n1 ID is permitted on 1 PC + 1 Mobile only. To use on this new phone, ask Master Admin to reset your Mobile binding.`
      };
    } else {
      // Authorized Mobile match!
      operator.lastLogin = now;
      saveRegisteredOperators(operators);
      addSecurityAuditLog('LOGIN_SUCCESS', username, `Successful login on authorized Mobile (${currentDeviceId})`);
    }
  }

  const activeUser: UserAccount = {
    username: operator.username,
    displayName: operator.displayName,
    role: operator.role,
    phone: operator.phone,
    shopName: 'Muzammil Online Service',
    isLoggedIn: true,
    currentDeviceType: currentType,
    currentDeviceId,
    currentDeviceName,
    boundPcDeviceId: operator.boundPcDeviceId || undefined,
    boundMobileDeviceId: operator.boundMobileDeviceId || undefined
  };

  return {
    success: true,
    user: activeUser
  };
}

// Master Admin: Reset PC Device Binding
export function resetOperatorPcBinding(operatorId: string): boolean {
  const operators = getRegisteredOperators();
  const op = operators.find(o => o.id === operatorId || o.username === operatorId);
  if (!op) return false;

  const prev = op.boundPcDeviceName || op.boundPcDeviceId || 'PC';
  op.boundPcDeviceId = null;
  op.boundPcDeviceName = null;
  op.boundPcAt = null;

  saveRegisteredOperators(operators);
  addSecurityAuditLog('DEVICE_RESET', op.username, `Master Admin cleared PC device binding (was: ${prev})`);
  return true;
}

// Master Admin: Reset Mobile Device Binding
export function resetOperatorMobileBinding(operatorId: string): boolean {
  const operators = getRegisteredOperators();
  const op = operators.find(o => o.id === operatorId || o.username === operatorId);
  if (!op) return false;

  const prev = op.boundMobileDeviceName || op.boundMobileDeviceId || 'Mobile';
  op.boundMobileDeviceId = null;
  op.boundMobileDeviceName = null;
  op.boundMobileAt = null;

  saveRegisteredOperators(operators);
  addSecurityAuditLog('DEVICE_RESET', op.username, `Master Admin cleared Mobile device binding (was: ${prev})`);
  return true;
}

// Master Admin: Reset Both Device Bindings (Full Reset)
export function resetOperatorAllBindings(operatorId: string): boolean {
  const operators = getRegisteredOperators();
  const op = operators.find(o => o.id === operatorId || o.username === operatorId);
  if (!op) return false;

  op.boundPcDeviceId = null;
  op.boundPcDeviceName = null;
  op.boundPcAt = null;
  op.boundMobileDeviceId = null;
  op.boundMobileDeviceName = null;
  op.boundMobileAt = null;

  saveRegisteredOperators(operators);
  addSecurityAuditLog('DEVICE_RESET', op.username, `Master Admin cleared all device bindings (PC & Mobile)`);
  return true;
}

// Master Admin: Toggle Lock Account
export function toggleOperatorLock(operatorId: string): boolean {
  const operators = getRegisteredOperators();
  const op = operators.find(o => o.id === operatorId || o.username === operatorId);
  if (!op) return false;

  op.isLocked = !op.isLocked;
  saveRegisteredOperators(operators);
  addSecurityAuditLog('OPERATOR_LOCKED', op.username, `Master Admin set lock status to: ${op.isLocked ? 'LOCKED' : 'ACTIVE'}`);
  return true;
}

// Master Admin: Add Operator
export function addNewOperator(op: Omit<OperatorAccount, 'id' | 'boundPcDeviceId' | 'boundPcDeviceName' | 'boundPcAt' | 'boundMobileDeviceId' | 'boundMobileDeviceName' | 'boundMobileAt' | 'lastLogin' | 'isLocked'>): boolean {
  const operators = getRegisteredOperators();
  if (operators.some(o => o.username.toLowerCase() === op.username.toLowerCase())) {
    return false;
  }

  const newOp: OperatorAccount = {
    ...op,
    id: `op-${Date.now()}`,
    boundPcDeviceId: null,
    boundPcDeviceName: null,
    boundPcAt: null,
    boundMobileDeviceId: null,
    boundMobileDeviceName: null,
    boundMobileAt: null,
    lastLogin: null,
    isLocked: false
  };

  operators.push(newOp);
  saveRegisteredOperators(operators);
  addSecurityAuditLog('LOGIN_SUCCESS', 'admin', `Master Admin registered new operator: ${op.username}`);
  return true;
}

// Master Admin: Delete Operator
export function deleteOperator(operatorId: string): boolean {
  let operators = getRegisteredOperators();
  const op = operators.find(o => o.id === operatorId);
  if (!op || op.role === 'admin') return false;

  operators = operators.filter(o => o.id !== operatorId);
  saveRegisteredOperators(operators);
  addSecurityAuditLog('LOGIN_SUCCESS', 'admin', `Master Admin deleted operator: ${op.username}`);
  return true;
}

// Calculate Days Left until validity expiry (Admin is Lifetime / Never Expires)
export function calculateRemainingDays(dateStr?: string | null): number {
  if (!dateStr || dateStr.toLowerCase().includes('lifetime') || dateStr.toLowerCase().includes('never')) {
    return 999999; // Never expires
  }
  const expiry = new Date(dateStr).getTime();
  if (isNaN(expiry)) return 999999;
  const now = Date.now();
  const diff = expiry - now;
  return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
}

// Master Admin: Renew Operator License / Access
export function renewOperatorLicense(operatorId: string, daysToAdd: number): { success: boolean; newExpiry: string; daysLeft: number } {
  const operators = getRegisteredOperators();
  const op = operators.find(o => o.id === operatorId || o.username === operatorId);
  if (!op) return { success: false, newExpiry: '', daysLeft: 0 };

  if (op.role === 'admin' || op.username === 'admin') {
    op.validityExpiresAt = 'Lifetime (Never Expires)';
    op.validityDaysLeft = 999999;
    op.isLocked = false;
    saveRegisteredOperators(operators);
    return {
      success: true,
      newExpiry: 'Lifetime (Never Expires)',
      daysLeft: 999999
    };
  }

  let currentExpiry = op.validityExpiresAt ? new Date(op.validityExpiresAt).getTime() : Date.now();
  if (isNaN(currentExpiry) || currentExpiry < Date.now()) {
    currentExpiry = Date.now();
  }

  const newExpiryTime = currentExpiry + (daysToAdd * 24 * 60 * 60 * 1000);
  const newExpiryStr = new Date(newExpiryTime).toISOString().split('T')[0];
  const daysLeft = Math.ceil((newExpiryTime - Date.now()) / (1000 * 60 * 60 * 24));

  op.validityExpiresAt = newExpiryStr;
  op.validityDaysLeft = daysLeft;

  saveRegisteredOperators(operators);
  addSecurityAuditLog('LOGIN_SUCCESS', op.username, `License renewed for +${daysToAdd} days. Valid until ${newExpiryStr} (${daysLeft} days left)`);

  return {
    success: true,
    newExpiry: newExpiryStr,
    daysLeft
  };
}

// Client Live Heartbeat Reporter
export async function sendOperatorHeartbeat(data: {
  username: string;
  displayName: string;
  role: 'admin' | 'operator';
  phone?: string;
  currentTab: string;
  currentTask?: string;
}): Promise<{ success: boolean; activeCount: number; broadcastMessage?: string | null }> {
  const deviceId = getHardwareDeviceId();
  const deviceName = getHardwareDeviceName();
  const deviceType = isMobileDevice() ? 'mobile' : 'pc';

  try {
    const res = await fetch('/api/live/heartbeat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...data,
        deviceId,
        deviceName,
        deviceType
      })
    });
    if (res.ok) {
      return await res.json();
    }
  } catch {
    // Offline mode: store in local storage heartbeat registry
    try {
      const localKey = 'mos_local_live_pulse';
      const existing = JSON.parse(localStorage.getItem(localKey) || '{}');
      existing[data.username] = {
        ...data,
        deviceId,
        deviceName,
        deviceType,
        lastHeartbeat: new Date().toISOString()
      };
      localStorage.setItem(localKey, JSON.stringify(existing));
    } catch {}
  }
  return { success: true, activeCount: 1, broadcastMessage: null };
}

// Master Admin: Fetch Live Operator Sessions
export async function getLiveOperatorSessions(): Promise<any[]> {
  try {
    const res = await fetch('/api/live/sessions');
    if (res.ok) {
      const data = await res.json();
      return data.sessions || [];
    }
  } catch {}

  // Local fallback if server unreachable
  const operators = getRegisteredOperators();
  const currentDevId = getHardwareDeviceId();
  const currentDevName = getHardwareDeviceName();

  return operators.map(op => ({
    sessionId: `local-${op.id}`,
    username: op.username,
    displayName: op.displayName,
    role: op.role,
    phone: op.phone,
    deviceType: isMobileDevice() ? 'mobile' : 'pc',
    deviceId: currentDevId,
    deviceName: currentDevName,
    currentTab: 'Workstation Active',
    currentTask: 'Online Hub',
    loginTime: op.lastLogin || new Date().toISOString(),
    lastHeartbeat: new Date().toISOString(),
    validityExpiresAt: op.validityExpiresAt || '2026-12-31',
    isOnline: true,
    lastActiveSecondsAgo: 2,
    ipAddress: '127.0.0.1 (Local)'
  }));
}

// Master Admin: Force Disconnect an Operator
export async function forceDisconnectOperator(username: string, deviceId?: string): Promise<boolean> {
  try {
    const res = await fetch('/api/live/terminate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, deviceId })
    });
    return res.ok;
  } catch {
    return false;
  }
}

// Master Admin: Broadcast message to operator
export async function sendOperatorBroadcastMessage(username: string, message: string): Promise<boolean> {
  try {
    const res = await fetch('/api/live/broadcast', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, message })
    });
    return res.ok;
  } catch {
    return false;
  }
}

