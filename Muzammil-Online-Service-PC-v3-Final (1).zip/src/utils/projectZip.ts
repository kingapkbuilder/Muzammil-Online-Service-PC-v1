import JSZip from 'jszip';

export async function generateProjectZip(onProgress?: (percent: number, file: string) => void): Promise<Blob> {
  try {
    if (onProgress) onProgress(25, 'Fetching complete production ZIP archive from server...');
    const serverRes = await fetch('/api/download-zip');
    if (serverRes.ok) {
      if (onProgress) onProgress(100, 'Completed!');
      return await serverRes.blob();
    }
  } catch (err) {
    console.warn('Server ZIP fetch failed, falling back to in-browser bundle', err);
  }

  const zip = new JSZip();

  // Project information
  const readmeContent = `# Muzammil Online Service - CSC & Cyber Cafe Workstation Suite
## Version: v98.0 PC Suite (Standalone Standalone Edition)
**Owner:** Imran Khan | **Contact:** 9561460313
**Address:** Naya Munshi Shaban Nagar, Main Road, Maharashtra, India

---

### Features & Workstation Modules:
1. **Strict 1-Device Security Locking**: Each Operator ID is permanently bound to a single computer/phone.
2. **PVC Smart Card Studio**: CR-80 85.6x54mm instant dual card 300 DPI layout for 4x6 photo paper with center cut line.
3. **Passport Photo Studio Pro**:
   - 4x6 Landscape (8 Copies @ 300 DPI) & A4 Landscape sheet layout.
   - Connected Flood-Fill Magic Wand Background Cutout.
   - Vector Pen Tool with Anchor Points & Live Dual Preview.
   - AI Auto Beauty Face Effect with Skin Smoothing & Facial Radiance.
   - Official Exam Stamp (Candidate Name & Date for SSC/Police Bharti).
4. **PDF to HD JPG High-Resolution Rasterizer**: Convert PDF Aadhaar/PAN/Voter slips to 300 DPI images.
5. **Fast Thermal Billing Desk & POS**: 58mm & 80mm thermal receipt generator with QR code payment.
6. **Customer CRM & Delivery Tracker**: Token tracking, pending work alerts, WhatsApp notifications.
7. **BioData & CV Maker**: Hindi, English, and Islamic wedding biodata templates.
8. **50+ Government Portals Directory**: Direct links to all Central & Maharashtra State Citizen Portals.
9. **Cyber Cafe Daily SOP Workflow Engine**: Interactive checklist for day-to-day cyber operations.
10. **Master Admin Panel**: Device lock resets, operator management, and security audit logs.

---

### How to Run Locally:
\`\`\`bash
# 1. Install dependencies
npm install

# 2. Run development server (Port 3000)
npm run dev

# 3. Build for production
npm run build
\`\`\`
`;

  zip.file('README.md', readmeContent);

  // We can fetch files or bundle the source files that make up the client app
  const sourceFiles = [
    '/package.json',
    '/package-lock.json',
    '/server.ts',
    '/vite.config.ts',
    '/tsconfig.json',
    '/index.html',
    '/src/main.tsx',
    '/src/App.tsx',
    '/src/index.css',
    '/src/types.ts',
    '/src/data/portalData.ts',
    '/src/utils/storage.ts',
    '/src/utils/printer.ts',
    '/src/utils/deviceSecurity.ts',
    '/src/utils/projectZip.ts',
    '/src/components/Header.tsx',
    '/src/components/Sidebar.tsx',
    '/src/components/DashboardView.tsx',
    '/src/components/LoginScreen.tsx',
    '/src/components/PvcStudioView.tsx',
    '/src/components/PassportStudioView.tsx',
    '/src/components/VideoStudioView.tsx',
    '/src/components/BillingDeskView.tsx',
    '/src/components/CustomerCrmView.tsx',
    '/src/components/PdfToJpgView.tsx',
    '/src/components/BioDataMakerView.tsx',
    '/src/components/GovernmentPortalsView.tsx',
    '/src/components/AiAssistantView.tsx',
    '/src/components/DownloadsView.tsx',
    '/src/components/SettingsView.tsx',
    '/src/components/ShortcutsModal.tsx',
    '/src/components/AuthModal.tsx',
    '/src/components/MasterAdminView.tsx',
    '/src/components/WorkflowGuideView.tsx',
    '/src/components/SarkariDocToolsView.tsx',
    '/src/components/LegalDraftsView.tsx',
    '/src/components/YojanaFinderView.tsx',
    '/START-WORKSTATION.bat',
    '/run-pc.js',
    '/CREATE-EXE-SETUP.bat',
    '/HOW-TO-BUILD-EXE.md',
    '/GITHUB-EXE-GUIDE.md',
    '/.github/workflows/build-windows-exe.yml',
    '/installer/setup.iss',
    '/electron/main.cjs',
    '/electron/preload.cjs'
  ];

  let completed = 0;
  for (const filePath of sourceFiles) {
    try {
      const cleanPath = filePath.startsWith('/') ? filePath.slice(1) : filePath;
      if (onProgress) {
        onProgress(Math.round((completed / sourceFiles.length) * 100), cleanPath);
      }
      
      const res = await fetch(filePath);
      if (res.ok) {
        const text = await res.text();
        zip.file(cleanPath, text);
      }
    } catch {
      // Continue bundling
    }
    completed++;
  }

  if (onProgress) {
    onProgress(100, 'Compressing archive...');
  }

  const content = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 }
  });

  return content;
}

export function triggerDownloadZip(blob: Blob, filename = 'Muzammil-Online-Service-PC-v3-Final.zip') {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
