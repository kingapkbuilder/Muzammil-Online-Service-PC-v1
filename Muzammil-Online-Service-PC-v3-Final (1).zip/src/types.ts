export interface PortalItem {
  id: string;
  title: string;
  category: 'citizen_id' | 'central_scheme' | 'state_scheme' | 'transport' | 'banking' | 'revenue' | 'utility';
  url: string;
  icon: string;
  description: string;
  requiredDocs: string[];
  popular?: boolean;
  portalType: 'central' | 'state' | 'direct';
}

export interface BillItem {
  id: string;
  invoiceNo: string;
  customerName: string;
  customerMobile: string;
  serviceName: string;
  category: string;
  govtFee: number;
  serviceFee: number;
  total: number;
  paymentMode: 'Cash' | 'UPI / QR' | 'Card' | 'Pending';
  status: 'Paid' | 'Pending' | 'Due';
  createdAt: string;
  notes?: string;
}

export interface CustomerRecord {
  id: string;
  name: string;
  mobile: string;
  serviceType: string;
  ackToken: string;
  status: 'Pending' | 'Processing' | 'Ready' | 'Delivered';
  date: string;
  amount: number;
  notes?: string;
}

export interface ShopSettings {
  shopName: string;
  tagline: string;
  ownerName: string;
  phone: string;
  address: string;
  upiId: string;
  thermalWidth: '58mm' | '80mm';
  gstNo?: string;
}

export interface UserAccount {
  username: string;
  displayName: string;
  role: 'admin' | 'operator';
  phone: string;
  shopName: string;
  isLoggedIn: boolean;
  currentDeviceType?: 'pc' | 'mobile';
  currentDeviceId?: string;
  currentDeviceName?: string;
  boundPcDeviceId?: string;
  boundMobileDeviceId?: string;
}

export interface OperatorAccount {
  id: string;
  username: string;
  password?: string;
  displayName: string;
  role: 'admin' | 'operator';
  phone: string;
  // Dual-Device Binding: 1 Authorized PC + 1 Authorized Mobile
  boundPcDeviceId: string | null;
  boundPcDeviceName: string | null;
  boundPcAt: string | null;
  boundMobileDeviceId: string | null;
  boundMobileDeviceName: string | null;
  boundMobileAt: string | null;
  lastLogin: string | null;
  isLocked: boolean;
  // Workstation License & Access Validity
  validityExpiresAt?: string;
  validityDaysLeft?: number;
}

export interface LiveOperatorSession {
  sessionId: string;
  username: string;
  displayName: string;
  role: 'admin' | 'operator';
  phone: string;
  deviceType: 'pc' | 'mobile';
  deviceId: string;
  deviceName: string;
  currentTab: string;
  currentTask?: string;
  loginTime: string;
  lastHeartbeat: string;
  validityExpiresAt: string;
  isOnline: boolean;
  lastActiveSecondsAgo: number;
  ipAddress?: string;
}

export interface DownloadedDocument {
  id: string;
  fileName: string;
  portalSource: string;
  fileType: 'pdf' | 'jpg' | 'png' | 'html';
  fileSize: string;
  downloadedAt: string;
  dataUrl?: string;
  customerName?: string;
  ackToken?: string;
}

export interface PvcCardSettings {
  card1: { image: string | null; x: number; y: number; scale: number; rotate: number };
  card2: { image: string | null; x: number; y: number; scale: number; rotate: number };
  brightness: number;
  contrast: number;
  sharpness: boolean;
  showBorders: boolean;
  layout: '4x6_2up' | 'a4_10up';
  preset: 'standard_cr80' | 'aadhaar' | 'pan' | 'voter' | 'ayushman';
}

export interface PassportSettings {
  image: string | null;
  cropPreset: 'indian_passport' | 'stamp' | 'us_visa' | 'pan_photo';
  copies: 6 | 8 | 12 | 16 | 32;
  paper: '4x6' | 'a4';
  bgColor: string;
  brightness: number;
  contrast: number;
  skinSmooth: number;
  showNameDate: boolean;
  candidateName: string;
  photoDate: string;
}

export interface BioDataForm {
  template: 'cv_modern' | 'resume_classic' | 'biodata_hindi' | 'biodata_english' | 'biodata_islamic';
  fullName: string;
  dob: string;
  mobile: string;
  email: string;
  education: string;
  job: string;
  income: string;
  address: string;
  familyDetails: string;
  customDetails: string;
  photo: string | null;
}

export interface DownloadItem {
  id: string;
  title: string;
  type: 'PVC Card PDF' | 'PVC Card JPG' | 'Passport Sheet PDF' | 'Passport Sheet JPG' | 'BioData PDF' | 'Converted JPG' | 'Thermal Receipt' | 'A4 Invoice';
  size: string;
  timestamp: string;
  dataUrl?: string;
}
