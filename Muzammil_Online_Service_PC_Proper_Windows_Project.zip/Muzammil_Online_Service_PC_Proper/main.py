import os, sys, webbrowser, shutil, traceback
from pathlib import Path
from datetime import datetime

from PySide6.QtCore import Qt, QTimer, QSize
from PySide6.QtGui import QPixmap, QImage, QIcon, QAction
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QLineEdit, QComboBox, QListWidget, QListWidgetItem,
    QFileDialog, QMessageBox, QStackedWidget, QFrame, QScrollArea, QSpinBox,
    QCheckBox, QFormLayout, QGroupBox, QProgressBar, QTextEdit, QDoubleSpinBox
)
from PySide6.QtPrintSupport import QPrinter, QPrintDialog
from PIL import Image, ImageOps, ImageDraw, ImageFont
import fitz
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm, inch

APP_NAME = "Muzammil Online Service & Xerox"
BASE = Path.home() / "MuzammilOnlineService"
DOWNLOADS = BASE / "Downloads"
DOWNLOADS.mkdir(parents=True, exist_ok=True)

BLUE = "#071b31"
PANEL = "#0b2a47"
CARD = "#103b62"
CYAN = "#0799ff"
TEXT = "#f4f8ff"
MUTED = "#a9c0d8"
GREEN = "#16c784"
YELLOW = "#ffd31a"

SERVICES = [
    ("Dashboard", "dashboard"), ("Government Services", "gov"),
    ("State Schemes (Maharashtra)", "state"), ("Central Schemes (India)", "central"),
    ("Banking Services", "bank"), ("Aadhaar & PAN", "aadhaar"),
    ("Voter ID & Election", "voter"), ("MahaSarathi (DL/RC)", "maha"),
    ("Passport Size Photo", "passport"), ("PVC Card Print", "pvc"),
    ("PDF Tools", "pdf"), ("CV / Bio Data Maker", "cv"),
    ("Banner Maker", "banner"), ("Bill / Receipt", "bill"),
    ("Downloads", "downloads"), ("Utilities & Tools", "tools"), ("Settings", "settings")
]
LINKS = {
    "MahaSarathi": "https://transport.maharashtra.gov.in/",
    "Aadhaar Portal": "https://myaadhaar.uidai.gov.in/",
    "PAN Suvidha": "https://www.pan.utiitsl.com/",
    "Voter ID": "https://voters.eci.gov.in/",
    "e-Shram": "https://eshram.gov.in/",
    "CSC Registration": "https://register.csc.gov.in/",
    "Udyam Registration": "https://udyamregistration.gov.in/",
    "Aaple Sarkar": "https://aaplesarkar.mahaonline.gov.in/",
    "PM Kisan": "https://pmkisan.gov.in/",
    "PM Solar": "https://www.pmsuryaghar.gov.in/",
    "PM Mudra": "https://www.mudra.org.in/",
    "PM Awas": "https://pmaymis.gov.in/",
    "ABHA": "https://abha.abdm.gov.in/"
}

STYLE = f"""
QMainWindow, QWidget {{ background:{BLUE}; color:{TEXT}; font-family:'Segoe UI'; }}
QLabel {{ color:{TEXT}; }}
QLineEdit, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox {{ background:#09233d; color:{TEXT}; border:1px solid #2d587d; border-radius:8px; padding:8px; }}
QPushButton {{ background:#0d5f9e; color:white; border:1px solid #2e8bd0; border-radius:9px; padding:9px 14px; font-weight:600; }}
QPushButton:hover {{ background:#1187dc; }}
QPushButton#primary {{ background:{CYAN}; border:none; }}
QPushButton#success {{ background:{GREEN}; border:none; }}
QPushButton#danger {{ background:#b92c38; border:none; }}
QListWidget {{ background:#06182b; border:none; }}
QListWidget::item {{ padding:10px 12px; border-radius:8px; margin:2px 5px; }}
QListWidget::item:selected {{ background:{CYAN}; }}
QGroupBox {{ border:1px solid #244d70; border-radius:10px; margin-top:12px; padding:10px; font-weight:700; }}
QGroupBox::title {{ subcontrol-origin: margin; left:12px; padding:0 5px; }}
QProgressBar {{ background:#06182b; border:1px solid #284b68; border-radius:6px; height:10px; }}
QProgressBar::chunk {{ background:{CYAN}; border-radius:6px; }}
"""

def title_label(text, size=22):
    l=QLabel(text); l.setStyleSheet(f"font-size:{size}px;font-weight:800;"); return l

def card_widget():
    w=QFrame(); w.setStyleSheet(f"QFrame{{background:{CARD};border:1px solid #24567c;border-radius:12px;}}"); return w

def fit_image(img, size):
    return ImageOps.fit(img.convert("RGB"), size, method=Image.Resampling.LANCZOS, centering=(0.5,0.5))

def save_pil_pdf(img, path, dpi=300):
    img.save(path, "PDF", resolution=dpi)

def add_button(layout, text, key, callback):
    b=QPushButton(text); b.clicked.connect(callback); b.setProperty("page",key); layout.addWidget(b); return b

class App(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle(APP_NAME + " — PC Version"); self.resize(1500, 920); self.setStyleSheet(STYLE)
        self.dark=True; self.lang="English"; self.last_files=[]
        root=QWidget(); self.setCentralWidget(root); main=QVBoxLayout(root); main.setContentsMargins(8,8,8,8); main.setSpacing(7)
        main.addWidget(self.header())
        body=QHBoxLayout(); main.addLayout(body,1)
        self.nav=QListWidget(); self.nav.setFixedWidth(235); self.nav.currentRowChanged.connect(self.switch_page)
        for label,key in SERVICES:
            it=QListWidgetItem(label); it.setData(Qt.UserRole,key); self.nav.addItem(it)
        body.addWidget(self.nav)
        self.stack=QStackedWidget(); body.addWidget(self.stack,1)
        self.pages={}
        for label,key in SERVICES:
            page=self.make_page(key,label); self.pages[key]=page; self.stack.addWidget(page)
        self.nav.setCurrentRow(0)
        self.status=QLabel("Ready • Local files are stored in your MuzammilOnlineService folder")
        self.status.setStyleSheet(f"color:{MUTED};padding:4px 8px;"); main.addWidget(self.status)
        self.timer=QTimer(self); self.timer.timeout.connect(self.tick); self.timer.start(1000); self.tick()

    def header(self):
        w=QFrame(); w.setStyleSheet("QFrame{background:#06182b;border:1px solid #1e4a70;border-radius:12px;}"); h=QHBoxLayout(w)
        brand=QLabel("🖨️  Muzammil\nOnline Service & Xerox"); brand.setStyleSheet(f"font-size:20px;font-weight:900;color:white;"); h.addWidget(brand,0)
        self.search=QLineEdit(); self.search.setPlaceholderText("🔍  Search Service, Scheme or Website..."); self.search.returnPressed.connect(self.do_search); h.addWidget(self.search,1)
        self.clock=QLabel(); self.clock.setMinimumWidth(190); h.addWidget(self.clock)
        self.translate=QPushButton("🌐 Translate"); self.translate.clicked.connect(self.toggle_lang); h.addWidget(self.translate)
        theme=QPushButton("☀ / ☾"); theme.clicked.connect(self.toggle_theme); h.addWidget(theme)
        bell=QPushButton("🔔"); bell.clicked.connect(lambda: QMessageBox.information(self,"Notifications","No new notifications.")); h.addWidget(bell)
        return w

    def tick(self): self.clock.setText(datetime.now().strftime("%I:%M:%S %p\n%d %b %Y"))
    def toggle_lang(self):
        self.lang="Roman Hindi" if self.lang=="English" else "English"; self.translate.setText("🌐 "+self.lang); self.status.setText("Language: "+self.lang)
    def toggle_theme(self):
        self.dark=not self.dark
        if self.dark: self.setStyleSheet(STYLE)
        else: self.setStyleSheet(STYLE.replace(BLUE,"#eef4f9").replace("#06182b","#ffffff").replace("#09233d","#ffffff").replace("#0b2a47","#ffffff").replace("#103b62","#ffffff").replace("color:{TEXT}","color:#102238"))
    def do_search(self):
        q=self.search.text().lower().strip()
        if not q: return
        matches=[i for i,(label,key) in enumerate(SERVICES) if q in label.lower()]
        if matches: self.nav.setCurrentRow(matches[0])
        else: self.status.setText("No local service found. Use Quick Links on Dashboard.")
    def switch_page(self,row):
        if row>=0: self.stack.setCurrentIndex(row)

    def make_page(self,key,label):
        if key=="dashboard": return self.dashboard()
        if key=="passport": return self.passport_page()
        if key=="pvc": return self.pvc_page()
        if key=="pdf": return self.pdf_page()
        if key=="cv": return self.cv_page()
        if key=="bill": return self.bill_page()
        if key=="banner": return self.banner_page()
        if key=="downloads": return self.downloads_page()
        if key in ("gov","state","central","bank","aadhaar","voter","maha"): return self.links_page(key,label)
        if key=="settings": return self.settings_page()
        return self.tools_page()

    def dashboard(self):
        w=QWidget(); lay=QVBoxLayout(w); lay.addWidget(title_label("Muzammil Online Service & Xerox",28))
        sub=QLabel("Professional Windows desktop application • Online Services • Printing • Document Tools"); sub.setStyleSheet(f"color:{MUTED};font-size:14px"); lay.addWidget(sub)
        grid=QGridLayout(); lay.addLayout(grid)
        quick=[("🏛️ Government Services","gov"),("🏦 Banking Services","bank"),("🚗 MahaSarathi","maha"),("🪪 Aadhaar / PAN","aadhaar"),("📷 Passport Size Photo","passport"),("🪪 PVC Card Print","pvc"),("📄 PDF Tools","pdf"),("🧾 Bill / Receipt","bill")]
        for i,(t,k) in enumerate(quick):
            c=card_widget(); v=QVBoxLayout(c); b=QPushButton(t); b.setMinimumHeight(65); b.setObjectName("primary"); b.clicked.connect(lambda _,kk=k:self.open_key(kk)); v.addWidget(b); grid.addWidget(c,i//4,i%4)
        lower=QHBoxLayout(); lay.addLayout(lower,1)
        updates=card_widget(); uv=QVBoxLayout(updates); uv.addWidget(title_label("Recent Updates",16))
        for d,t in [("25-09-2026","MahaSarathi portal shortcut ready"),("25-09-2026","PDF to JPG 300 DPI"),("25-09-2026","PVC 4×6 two-card layout"),("25-09-2026","Passport photo A4 sheet")]: uv.addWidget(QLabel(f"{d}   {t}"))
        lower.addWidget(updates,1)
        ql=card_widget(); qv=QVBoxLayout(ql); qv.addWidget(title_label("Quick Links",16))
        for n in ["MahaSarathi","Aadhaar Portal","PAN Suvidha","Voter ID","e-Shram","CSC Registration","Udyam Registration"]:
            b=QPushButton("🔗 "+n); b.clicked.connect(lambda _,x=n:self.open_link(x)); qv.addWidget(b)
        lower.addWidget(ql,1)
        dm=card_widget(); dv=QVBoxLayout(dm); dv.addWidget(title_label("Download Manager",16)); self.dash_list=QListWidget(); dv.addWidget(self.dash_list); self.refresh_downloads(); lower.addWidget(dm,1)
        return w

    def open_key(self,key):
        for i,(_,k) in enumerate(SERVICES):
            if k==key: self.nav.setCurrentRow(i); break
    def open_link(self,name):
        webbrowser.open(LINKS.get(name,"https://www.google.com/search?q="+name.replace(" ","+"))); self.status.setText("Opened: "+name)

    def links_page(self,key,label):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(title_label(label,26)); l.addWidget(QLabel("Official portal shortcuts. Links open from the desktop application."))
        urls=[]
        if key=="gov": urls=list(LINKS.items())
        elif key=="state": urls=[("Aaple Sarkar",LINKS["Aaple Sarkar"]),("MahaSarathi",LINKS["MahaSarathi"])]
        elif key=="central": urls=[("PM Kisan",LINKS["PM Kisan"]),("PM Solar",LINKS["PM Solar"]),("PM Mudra",LINKS["PM Mudra"]),("PM Awas",LINKS["PM Awas"]),("ABHA",LINKS["ABHA"])]
        elif key=="bank": urls=[("SBI", "https://sbi.co.in/"),("Bank of Baroda","https://www.bankofbaroda.in/"),("HDFC Bank","https://www.hdfcbank.com/"),("ICICI Bank","https://www.icicibank.com/")]
        elif key=="aadhaar": urls=[("Aadhaar Portal",LINKS["Aadhaar Portal"]),("PAN Suvidha",LINKS["PAN Suvidha"]),("ABHA",LINKS["ABHA"]),("Udyam",LINKS["Udyam Registration"])]
        elif key=="voter": urls=[("Voter ID",LINKS["Voter ID"]),("e-Shram",LINKS["e-Shram"])]
        elif key=="maha": urls=[("MahaSarathi",LINKS["MahaSarathi"])]
        sc=QScrollArea(); sc.setWidgetResizable(True); inner=QWidget(); g=QGridLayout(inner)
        for i,(n,u) in enumerate(urls):
            c=card_widget(); v=QVBoxLayout(c); v.addWidget(title_label(n,16)); v.addWidget(QLabel(u)); b=QPushButton("Open Portal"); b.setObjectName("primary"); b.clicked.connect(lambda _,x=n:self.open_link(x)); v.addWidget(b); g.addWidget(c,i//3,i%3)
        sc.setWidget(inner); l.addWidget(sc,1); return w

    def passport_page(self):
        w=QWidget(); l=QHBoxLayout(w); left=QVBoxLayout(); right=QVBoxLayout(); l.addLayout(left,1); l.addLayout(right,1)
        left.addWidget(title_label("Passport Size Photo",26)); self.pass_img=QLabel("No photo selected"); self.pass_img.setAlignment(Qt.AlignCenter); self.pass_img.setMinimumSize(420,500); self.pass_img.setStyleSheet("border:1px dashed #3e7197;background:#06182b;border-radius:10px;"); left.addWidget(self.pass_img,1)
        b=QPushButton("Open Photo"); b.setObjectName("primary"); b.clicked.connect(self.choose_passport); left.addWidget(b)
        self.pass_info=QLabel("35 × 45 mm • White background • A4 multiple photos"); left.addWidget(self.pass_info)
        box=QGroupBox("Photo Sheet"); form=QFormLayout(box); self.pass_count=QSpinBox(); self.pass_count.setRange(1,30); self.pass_count.setValue(8); form.addRow("Photos:",self.pass_count); self.pass_bg=QComboBox(); self.pass_bg.addItems(["White","Original"]); form.addRow("Background:",self.pass_bg); right.addWidget(box)
        self.pass_preview=QLabel("A4 sheet preview will appear here"); self.pass_preview.setAlignment(Qt.AlignCenter); self.pass_preview.setMinimumHeight(450); self.pass_preview.setStyleSheet("border:1px solid #315a78;border-radius:10px;"); right.addWidget(self.pass_preview,1)
        row=QHBoxLayout(); forbtn=QPushButton("Generate A4 Sheet"); forbtn.setObjectName("success"); forbtn.clicked.connect(self.generate_passport_sheet); row.addWidget(forbtn); pdfb=QPushButton("Save JPG/PDF"); pdfb.clicked.connect(self.save_passport); row.addWidget(pdfb); right.addLayout(row)
        return w
    def choose_passport(self):
        p,_=QFileDialog.getOpenFileName(self,"Choose Photo","","Images (*.jpg *.jpeg *.png *.webp)");
        if not p:return
        self.pass_path=p; pix=QPixmap(p); self.pass_img.setPixmap(pix.scaled(self.pass_img.size(),Qt.KeepAspectRatio,Qt.SmoothTransformation)); self.status.setText("Photo loaded: "+p)
    def make_passport_sheet(self):
        img=Image.open(self.pass_path).convert("RGB"); one=fit_image(img,(413,531)); sheet=Image.new("RGB",(2480,3508),"white"); d=ImageDraw.Draw(sheet); count=self.pass_count.value(); cols=4; x0=90; y0=100; gapx=55; gapy=80
        for i in range(count):
            r=i//cols; c=i%cols; x=x0+c*(413+gapx); y=y0+r*(531+gapy)
            if x+413>2480: continue
            if y+531>3508: break
            sheet.paste(one,(x,y)); d.rectangle((x,y,x+412,y+530),outline="#aaaaaa",width=2)
        return sheet
    def generate_passport_sheet(self):
        if not hasattr(self,"pass_path"): QMessageBox.warning(self,"Photo","Pehle photo choose karo."); return
        sheet=self.make_passport_sheet(); p=DOWNLOADS/"passport_photo_A4.jpg"; sheet.save(p,"JPEG",quality=98,dpi=(300,300)); self.pass_preview.setPixmap(QPixmap(str(p)).scaled(self.pass_preview.size(),Qt.KeepAspectRatio,Qt.SmoothTransformation)); self.last_files.append(str(p)); self.refresh_downloads(); self.status.setText("Passport A4 sheet saved")
    def save_passport(self):
        if not hasattr(self,"pass_path"): QMessageBox.warning(self,"Photo","Pehle photo choose karo."); return
        sheet=self.make_passport_sheet(); p=DOWNLOADS/"passport_photo_A4.pdf"; save_pil_pdf(sheet,p,300); self.last_files.append(str(p)); self.refresh_downloads(); QMessageBox.information(self,"Saved",str(p))

    def pvc_page(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(title_label("PVC Card Print — 4×6 Portrait",26)); l.addWidget(QLabel("Card size: 8.5 × 5.5 cm • Cards per page: 2 (Top & Bottom) • 300 DPI")); row=QHBoxLayout(); l.addLayout(row)
        self.pvc_label=QLabel("No card image selected"); self.pvc_label.setMinimumSize(500,350); self.pvc_label.setAlignment(Qt.AlignCenter); self.pvc_label.setStyleSheet("border:1px dashed #3e7197;border-radius:10px;"); row.addWidget(self.pvc_label,1)
        controls=QGroupBox("Card Controls"); f=QFormLayout(controls); self.pvc_name=QLineEdit(); self.pvc_name.setPlaceholderText("Optional name"); f.addRow("Name:",self.pvc_name); self.pvc_count=QSpinBox(); self.pvc_count.setRange(1,2); self.pvc_count.setValue(2); f.addRow("Cards:",self.pvc_count); choose=QPushButton("Choose Card Image"); choose.clicked.connect(self.choose_pvc); f.addRow(choose); preview=QPushButton("Preview 4×6"); preview.setObjectName("primary"); preview.clicked.connect(self.preview_pvc); f.addRow(preview); save=QPushButton("Create JPG + PDF"); save.setObjectName("success"); save.clicked.connect(self.create_pvc); f.addRow(save); row.addWidget(controls,1)
        self.pvc_preview=QLabel("Preview"); self.pvc_preview.setAlignment(Qt.AlignCenter); self.pvc_preview.setMinimumHeight(500); self.pvc_preview.setStyleSheet("border:1px solid #315a78;border-radius:10px;"); l.addWidget(self.pvc_preview,1); return w
    def choose_pvc(self):
        p,_=QFileDialog.getOpenFileName(self,"Choose PVC/card image","","Images (*.jpg *.jpeg *.png *.webp)");
        if p:self.pvc_path=p; self.pvc_label.setPixmap(QPixmap(p).scaled(self.pvc_label.size(),Qt.KeepAspectRatio,Qt.SmoothTransformation))
    def make_pvc_sheet(self):
        if not hasattr(self,"pvc_path"): raise ValueError("Choose card image")
        card=fit_image(Image.open(self.pvc_path),(1004,650)); page=Image.new("RGB",(1800,2700),"white"); x=(1800-1004)//2
        for i in range(self.pvc_count.value()): page.paste(card,(x,180+i*1100)); ImageDraw.Draw(page).rectangle((x,180+i*1100,x+1003,829+i*1100),outline="#777",width=3)
        return page
    def preview_pvc(self):
        try:
            p=DOWNLOADS/"pvc_preview.jpg"; self.make_pvc_sheet().save(p,"JPEG",quality=98,dpi=(300,300)); self.pvc_preview.setPixmap(QPixmap(str(p)).scaled(self.pvc_preview.size(),Qt.KeepAspectRatio,Qt.SmoothTransformation))
        except Exception as e: QMessageBox.warning(self,"PVC",str(e))
    def create_pvc(self):
        try:
            page=self.make_pvc_sheet(); jpg=DOWNLOADS/"pvc_4x6_two_cards.jpg"; pdf=DOWNLOADS/"pvc_4x6_two_cards.pdf"; page.save(jpg,"JPEG",quality=98,dpi=(300,300)); save_pil_pdf(page,pdf,300); self.last_files += [str(jpg),str(pdf)]; self.refresh_downloads(); self.preview_pvc(); QMessageBox.information(self,"PVC Ready",f"Saved:\n{jpg}\n{pdf}")
        except Exception as e: QMessageBox.warning(self,"PVC",str(e))

    def pdf_page(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(title_label("PDF Tools",26)); top=QHBoxLayout(); l.addLayout(top); self.pdf_list=QListWidget(); l.addWidget(self.pdf_list,1)
        for text,fn in [("Add PDF",self.add_pdfs),("PDF → JPG 300 DPI",self.pdf_to_jpg),("Merge PDFs",self.merge_pdfs),("Split First PDF",self.split_pdf)]:
            b=QPushButton(text); b.clicked.connect(fn); top.addWidget(b)
        self.pdf_progress=QProgressBar(); l.addWidget(self.pdf_progress); return w
    def add_pdfs(self):
        ps,_=QFileDialog.getOpenFileNames(self,"Choose PDFs","","PDF (*.pdf)");
        for p in ps:self.pdf_list.addItem(p)
    def pdf_to_jpg(self):
        ps=[self.pdf_list.item(i).text() for i in range(self.pdf_list.count())]
        if not ps: QMessageBox.warning(self,"PDF","Add a PDF first."); return
        out=DOWNLOADS/"PDF_JPG"; out.mkdir(exist_ok=True); total=0
        for p in ps:
            doc=fitz.open(p); total+=len(doc)
        done=0
        for p in ps:
            doc=fitz.open(p); stem=Path(p).stem
            for i,page in enumerate(doc):
                pix=page.get_pixmap(dpi=300,alpha=False); op=out/f"{stem}_page_{i+1}.jpg"; pix.save(str(op),"jpeg"); done+=1; self.pdf_progress.setValue(int(done*100/max(total,1))); QApplication.processEvents(); self.last_files.append(str(op))
            doc.close()
        self.refresh_downloads(); QMessageBox.information(self,"Done",f"Converted {done} page(s) to JPG at 300 DPI.")
    def merge_pdfs(self):
        ps=[self.pdf_list.item(i).text() for i in range(self.pdf_list.count())]
        if len(ps)<2: QMessageBox.warning(self,"Merge","Select at least 2 PDFs."); return
        out=DOWNLOADS/"merged.pdf"; dst=fitz.open()
        for p in ps: src=fitz.open(p); dst.insert_pdf(src); src.close()
        dst.save(str(out)); dst.close(); self.last_files.append(str(out)); self.refresh_downloads(); QMessageBox.information(self,"Merged",str(out))
    def split_pdf(self):
        if self.pdf_list.count()==0: QMessageBox.warning(self,"Split","Add a PDF first."); return
        p=self.pdf_list.item(0).text(); doc=fitz.open(p); out=DOWNLOADS/(Path(p).stem+"_page_1.pdf"); one=fitz.open(); one.insert_pdf(doc,from_page=0,to_page=0); one.save(str(out)); one.close(); doc.close(); self.last_files.append(str(out)); self.refresh_downloads(); QMessageBox.information(self,"Split",str(out))

    def cv_page(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(title_label("CV / Bio Data Maker",26)); form=QFormLayout(); self.cv_name=QLineEdit(); self.cv_phone=QLineEdit(); self.cv_email=QLineEdit(); self.cv_address=QTextEdit(); self.cv_education=QTextEdit(); self.cv_experience=QTextEdit(); self.cv_skills=QTextEdit();
        for lab,wd in [("Full Name",self.cv_name),("Phone",self.cv_phone),("Email",self.cv_email),("Address",self.cv_address),("Education",self.cv_education),("Experience",self.cv_experience),("Skills",self.cv_skills)]: form.addRow(lab,wd)
        l.addLayout(form); b=QPushButton("Generate A4 CV PDF"); b.setObjectName("success"); b.clicked.connect(self.make_cv); l.addWidget(b); return w
    def make_cv(self):
        p=DOWNLOADS/"CV_Bio_Data.pdf"; c=canvas.Canvas(str(p),pagesize=A4); y=800; c.setFont("Helvetica-Bold",22); c.drawString(50,y,self.cv_name.text() or "Your Name"); y-=35; c.setFont("Helvetica",11); c.drawString(50,y,f"Phone: {self.cv_phone.text()}   Email: {self.cv_email.text()}"); y-=25
        for head,txt in [("Address",self.cv_address.toPlainText()),("Education",self.cv_education.toPlainText()),("Experience",self.cv_experience.toPlainText()),("Skills",self.cv_skills.toPlainText())]:
            c.setFont("Helvetica-Bold",14); c.drawString(50,y,head); y-=20; c.setFont("Helvetica",10)
            for line in (txt or "").splitlines() or [""]:
                c.drawString(60,y,line[:110]); y-=15
            y-=10
        c.save(); self.last_files.append(str(p)); self.refresh_downloads(); QMessageBox.information(self,"CV Saved",str(p))

    def bill_page(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(title_label("Bill / Receipt Maker",26)); form=QFormLayout(); self.bill_shop=QLineEdit(APP_NAME); self.bill_customer=QLineEdit(); self.bill_items=QTextEdit(); self.bill_total=QDoubleSpinBox(); self.bill_total.setMaximum(9999999); self.bill_total.setDecimals(2); self.bill_total.setPrefix("₹ ");
        for a,b in [("Shop",self.bill_shop),("Customer",self.bill_customer),("Items / Details",self.bill_items),("Total",self.bill_total)]: form.addRow(a,b)
        l.addLayout(form); b=QPushButton("Generate Receipt PDF"); b.setObjectName("success"); b.clicked.connect(self.make_bill); l.addWidget(b); return w
    def make_bill(self):
        p=DOWNLOADS/"receipt.pdf"; c=canvas.Canvas(str(p),pagesize=A4); y=800; c.setFont("Helvetica-Bold",20); c.drawString(50,y,self.bill_shop.text()); y-=30; c.setFont("Helvetica",11); c.drawString(50,y,"Customer: "+self.bill_customer.text()); y-=35; c.setFont("Helvetica-Bold",13); c.drawString(50,y,"Details"); y-=22; c.setFont("Helvetica",10)
        for line in self.bill_items.toPlainText().splitlines() or ["Service / Item"]: c.drawString(60,y,line[:110]); y-=16
        y-=20; c.setFont("Helvetica-Bold",16); c.drawString(50,y,f"Total: ₹ {self.bill_total.value():.2f}"); y-=35; c.setFont("Helvetica",9); c.drawString(50,y,"Generated by Muzammil Online Service & Xerox"); c.save(); self.last_files.append(str(p)); self.refresh_downloads(); QMessageBox.information(self,"Receipt Saved",str(p))

    def banner_page(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(title_label("Banner Maker",26)); self.banner_text=QLineEdit("Muzammil Online Service & Xerox"); l.addWidget(self.banner_text); self.banner_sub=QLineEdit("PAN • Aadhaar • PVC Card • Xerox • Online Services"); l.addWidget(self.banner_sub); choose=QPushButton("Choose Background Image"); choose.clicked.connect(self.choose_banner_bg); l.addWidget(choose); self.banner_prev=QLabel("Banner preview"); self.banner_prev.setAlignment(Qt.AlignCenter); self.banner_prev.setMinimumHeight(400); self.banner_prev.setStyleSheet("border:1px solid #315a78;border-radius:10px;"); l.addWidget(self.banner_prev,1); row=QHBoxLayout(); g=QPushButton("Generate 1920×1080 JPG"); g.setObjectName("success"); g.clicked.connect(self.generate_banner); row.addWidget(g); l.addLayout(row); return w
    def choose_banner_bg(self): self.banner_bg,_=QFileDialog.getOpenFileName(self,"Background","","Images (*.jpg *.jpeg *.png)");
    def generate_banner(self):
        bg=Image.new("RGB",(1920,1080),(7,45,80))
        if hasattr(self,"banner_bg") and self.banner_bg: bg=ImageOps.fit(Image.open(self.banner_bg).convert("RGB"),(1920,1080))
        d=ImageDraw.Draw(bg); d.rectangle((50,50,1870,1030),outline=(0,170,255),width=6); d.text((120,300),self.banner_text.text(),fill="white",stroke_width=2,stroke_fill=(0,0,0)); d.text((125,430),self.banner_sub.text(),fill=(255,220,0)); p=DOWNLOADS/"banner.jpg"; bg.save(p,"JPEG",quality=96); self.banner_prev.setPixmap(QPixmap(str(p)).scaled(self.banner_prev.size(),Qt.KeepAspectRatio,Qt.SmoothTransformation)); self.last_files.append(str(p)); self.refresh_downloads()

    def downloads_page(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(title_label("Download Manager",26)); self.download_list=QListWidget(); l.addWidget(self.download_list,1); row=QHBoxLayout(); o=QPushButton("Open Selected"); o.clicked.connect(self.open_selected); row.addWidget(o); rf=QPushButton("Refresh"); rf.clicked.connect(self.refresh_downloads); row.addWidget(rf); od=QPushButton("Open Downloads Folder"); od.clicked.connect(lambda:webbrowser.open(DOWNLOADS.as_uri())); row.addWidget(od); l.addLayout(row); self.refresh_downloads(); return w
    def refresh_downloads(self):
        lists=[]
        for p in DOWNLOADS.rglob("*"):
            if p.is_file(): lists.append(p)
        if hasattr(self,"download_list"):
            self.download_list.clear(); [self.download_list.addItem(str(p)) for p in lists]
        if hasattr(self,"dash_list"):
            self.dash_list.clear(); [self.dash_list.addItem(p.name) for p in lists[-8:]]
    def open_selected(self):
        w=self.download_list.currentItem() if hasattr(self,"download_list") else None
        if w: os.startfile(w.text())

    def tools_page(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(title_label("Utilities & Tools",26)); l.addWidget(QLabel("Local tools and common desktop actions.")); b=QPushButton("Open Downloads Folder"); b.clicked.connect(lambda:webbrowser.open(DOWNLOADS.as_uri())); l.addWidget(b); b2=QPushButton("Create Backup ZIP of Downloads"); b2.clicked.connect(self.backup_downloads); l.addWidget(b2); l.addStretch(); return w
    def backup_downloads(self):
        target=shutil.make_archive(str(BASE/"Downloads_Backup"),"zip",str(DOWNLOADS)); self.last_files.append(target); self.refresh_downloads(); QMessageBox.information(self,"Backup",target)
    def settings_page(self):
        w=QWidget(); l=QVBoxLayout(w); l.addWidget(title_label("Settings",26)); l.addWidget(QLabel("Application data folder:")); l.addWidget(QLabel(str(BASE))); l.addWidget(QLabel("Downloads folder:")); l.addWidget(QLabel(str(DOWNLOADS))); b=QPushButton("Open Data Folder"); b.clicked.connect(lambda:webbrowser.open(BASE.as_uri())); l.addWidget(b); l.addStretch(); return w

if __name__=="__main__":
    app=QApplication(sys.argv); app.setApplicationName(APP_NAME); win=App(); win.show(); sys.exit(app.exec())
