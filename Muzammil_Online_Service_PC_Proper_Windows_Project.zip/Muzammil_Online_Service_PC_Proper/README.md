# Muzammil Online Service & Xerox — PC Version

A functional Windows desktop application inspired by the supplied dashboard reference. It is a real PySide6 desktop application, not a browser wrapper.

## Working tools
- Dashboard with live clock, search, quick links and download manager
- Passport Size Photo: open image, crop to passport ratio, generate A4 photo sheet, save JPG/PDF
- PVC Card Print: import a card image, set 8.5×5.5 cm, generate 4×6 inch portrait sheet with two cards
- PDF → JPG: all pages, 300 DPI, high quality
- PDF Merge and Split
- CV / Bio Data Maker → PDF
- Bill / Receipt Maker → PDF
- Banner Maker → image
- Government / Maharashtra / Central / Banking portal shortcuts
- Downloads folder and open-file buttons
- Dark/light theme
- English / Roman Hindi UI toggle
- Search across services

## Run on Windows
1. Install Python 3.11+.
2. Run `run.bat`.

## Build EXE
GitHub Actions workflow `.github/workflows/build-windows.yml` builds a one-folder Windows package and a ZIP artifact.
