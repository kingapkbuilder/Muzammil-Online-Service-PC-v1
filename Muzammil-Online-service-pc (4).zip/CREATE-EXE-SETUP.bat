@echo off
title Muzammil Online service pc - Professional .EXE Setup Builder
color 0a

echo ========================================================
echo   MUZAMMIL ONLINE SERVICE PC - PROFESSIONAL .EXE BUILDER
echo   Building Desktop Application and Windows Installer...
echo ========================================================
echo.

:: 1. Check Node.js
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed!
    echo Please install Node.js from https://nodejs.org
    pause
    exit /b
)

:: 2. Install dependencies
echo [1/4] Installing necessary build packages...
call npm install
call npm install --save-dev electron electron-packager electron-builder

:: 3. Build Web Production Files
echo [2/4] Building high-performance production assets...
call npm run build

:: 4. Package Windows .EXE Executable
echo [3/4] Packaging standalone Windows Executable (.exe)...
call npx electron-packager . "Muzammil Online service pc" --platform=win32 --arch=x64 --out=dist-exe --overwrite --icon=public/favicon.ico

echo.
echo ========================================================
echo   SUCCESS! Windows Desktop Software is Ready!
echo   Folder: dist-exe\Muzammil Online service pc-win32-x64\
echo   Executable: "Muzammil Online service pc.exe"
echo ========================================================
echo.
echo Opening folder now...
explorer "dist-exe\Muzammil Online service pc-win32-x64"
pause
