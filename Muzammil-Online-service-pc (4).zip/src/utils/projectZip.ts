const JSZip = __vite__cjsImport0_jszip;import __vite__cjsImport0_jszip from "/node_modules/.vite/deps/jszip.js?v=090625a0";
export async function generateProjectZip(onProgress) {
	const zip = new JSZip();
	// Project information
	const readmeContent = `# Muzammil Online Service - CSC & Cyber Cafe Workstation Suite
## Version: v98.0 PC Suite (Standalone Standalone Edition)
**Owner:** Imran Khan | **Contact:** 9561460313
**Address:** Naya Munshi Shaban Nagar, Main Road, Maharashtra, India

---

### Features & Workstation Modules:
1. **Strict 1-Device Security Locking**: Each Operator ID is permanently bound to a single computer/phone.
2. **PVC Smart Card Studio**: CR-80 85.6x54mm instant dual card 300 DPI layout for 4x6 photo paper with center cut line.
3. **Passport Photo Studio Pro**:
   - 4x6 Landscape (8 Copies @ 300 DPI) & A4 Landscape sheet layout.
   - Connected Flood-Fill Magic Wand Background Cutout.
   - Vector Pen Tool with Anchor Points & Live Dual Preview.
   - AI Auto Beauty Face Effect with Skin Smoothing & Facial Radiance.
   - Official Exam Stamp (Candidate Name & Date for SSC/Police Bharti).
4. **PDF to HD JPG High-Resolution Rasterizer**: Convert PDF Aadhaar/PAN/Voter slips to 300 DPI images.
5. **Fast Thermal Billing Desk & POS**: 58mm & 80mm thermal receipt generator with QR code payment.
6. **Customer CRM & Delivery Tracker**: Token tracking, pending work alerts, WhatsApp notifications.
7. **BioData & CV Maker**: Hindi, English, and Islamic wedding biodata templates.
8. **50+ Government Portals Directory**: Direct links to all Central & Maharashtra State Citizen Portals.
9. **Cyber Cafe Daily SOP Workflow Engine**: Interactive checklist for day-to-day cyber operations.
10. **Master Admin Panel**: Device lock resets, operator management, and security audit logs.

---

### How to Run Locally:
\`\`\`bash
# 1. Install dependencies
npm install

# 2. Run development server (Port 3000)
npm run dev

# 3. Build for production
npm run build
\`\`\`
`;
	zip.file("README.md", readmeContent);
	// We can fetch files or bundle the source files that make up the client app
	const sourceFiles = [
		"/package.json",
		"/server.ts",
		"/vite.config.ts",
		"/tsconfig.json",
		"/index.html",
		"/src/main.tsx",
		"/src/App.tsx",
		"/src/index.css",
		"/src/types.ts",
		"/src/data/portalData.ts",
		"/src/utils/storage.ts",
		"/src/utils/printer.ts",
		"/src/utils/deviceSecurity.ts",
		"/src/utils/projectZip.ts",
		"/src/components/Header.tsx",
		"/src/components/Sidebar.tsx",
		"/src/components/DashboardView.tsx",
		"/src/components/LoginScreen.tsx",
		"/src/components/PvcStudioView.tsx",
		"/src/components/PassportStudioView.tsx",
		"/src/components/VideoStudioView.tsx",
		"/src/components/BillingDeskView.tsx",
		"/src/components/CustomerCrmView.tsx",
		"/src/components/PdfToJpgView.tsx",
		"/src/components/BioDataMakerView.tsx",
		"/src/components/GovernmentPortalsView.tsx",
		"/src/components/AiAssistantView.tsx",
		"/src/components/DownloadsView.tsx",
		"/src/components/SettingsView.tsx",
		"/src/components/ShortcutsModal.tsx",
		"/src/components/AuthModal.tsx",
		"/src/components/MasterAdminView.tsx",
		"/src/components/WorkflowGuideView.tsx",
		"/START-WORKSTATION.bat",
		"/CREATE-EXE-SETUP.bat",
		"/HOW-TO-BUILD-EXE.md",
		"/GITHUB-EXE-GUIDE.md",
		"/.github/workflows/build-windows-exe.yml",
		"/installer/setup.iss",
		"/electron/main.cjs",
		"/electron/preload.cjs"
	];
	let completed = 0;
	for (const filePath of sourceFiles) {
		try {
			const cleanPath = filePath.startsWith("/") ? filePath.slice(1) : filePath;
			if (onProgress) {
				onProgress(Math.round(completed / sourceFiles.length * 100), cleanPath);
			}
			const res = await fetch(filePath);
			if (res.ok) {
				const text = await res.text();
				zip.file(cleanPath, text);
			}
		} catch {}
		completed++;
	}
	if (onProgress) {
		onProgress(100, "Compressing archive...");
	}
	const content = await zip.generateAsync({
		type: "blob",
		compression: "DEFLATE",
		compressionOptions: { level: 9 }
	});
	return content;
}
export function triggerDownloadZip(blob, filename = "Muzammil-Online-Service-Complete-Source.zip") {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	document.body.appendChild(a);
	a.click();
	document.body.removeChild(a);
	setTimeout(() => URL.revokeObjectURL(url), 5e3);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBRWxCLE9BQU8sZUFBZSxtQkFBbUIsWUFBcUU7Q0FDNUcsTUFBTSxNQUFNLElBQUksTUFBTTs7Q0FHdEIsTUFBTSxnQkFBZ0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBdUN0QixJQUFJLEtBQUssYUFBYSxhQUFhOztDQUduQyxNQUFNLGNBQWM7RUFDbEI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGO0NBRUEsSUFBSSxZQUFZO0NBQ2hCLEtBQUssTUFBTSxZQUFZLGFBQWE7RUFDbEMsSUFBSTtHQUNGLE1BQU0sWUFBWSxTQUFTLFdBQVcsR0FBRyxJQUFJLFNBQVMsTUFBTSxDQUFDLElBQUk7R0FDakUsSUFBSSxZQUFZO0lBQ2QsV0FBVyxLQUFLLE1BQU8sWUFBWSxZQUFZLFNBQVUsR0FBRyxHQUFHLFNBQVM7R0FDMUU7R0FFQSxNQUFNLE1BQU0sTUFBTSxNQUFNLFFBQVE7R0FDaEMsSUFBSSxJQUFJLElBQUk7SUFDVixNQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7SUFDNUIsSUFBSSxLQUFLLFdBQVcsSUFBSTtHQUMxQjtFQUNGLFFBQVEsQ0FFUjtFQUNBO0NBQ0Y7Q0FFQSxJQUFJLFlBQVk7RUFDZCxXQUFXLEtBQUssd0JBQXdCO0NBQzFDO0NBRUEsTUFBTSxVQUFVLE1BQU0sSUFBSSxjQUFjO0VBQ3RDLE1BQU07RUFDTixhQUFhO0VBQ2Isb0JBQW9CLEVBQUUsT0FBTyxFQUFFO0NBQ2pDLENBQUM7Q0FFRCxPQUFPO0FBQ1Q7QUFFQSxPQUFPLFNBQVMsbUJBQW1CLE1BQVksV0FBVywrQ0FBK0M7Q0FDdkcsTUFBTSxNQUFNLElBQUksZ0JBQWdCLElBQUk7Q0FDcEMsTUFBTSxJQUFJLFNBQVMsY0FBYyxHQUFHO0NBQ3BDLEVBQUUsT0FBTztDQUNULEVBQUUsV0FBVztDQUNiLFNBQVMsS0FBSyxZQUFZLENBQUM7Q0FDM0IsRUFBRSxNQUFNO0NBQ1IsU0FBUyxLQUFLLFlBQVksQ0FBQztDQUMzQixpQkFBaUIsSUFBSSxnQkFBZ0IsR0FBRyxHQUFHLEdBQUk7QUFDakQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsicHJvamVjdFppcC50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSlNaaXAgZnJvbSAnanN6aXAnO1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2VuZXJhdGVQcm9qZWN0WmlwKG9uUHJvZ3Jlc3M/OiAocGVyY2VudDogbnVtYmVyLCBmaWxlOiBzdHJpbmcpID0+IHZvaWQpOiBQcm9taXNlPEJsb2I+IHtcbiAgY29uc3QgemlwID0gbmV3IEpTWmlwKCk7XG5cbiAgLy8gUHJvamVjdCBpbmZvcm1hdGlvblxuICBjb25zdCByZWFkbWVDb250ZW50ID0gYCMgTXV6YW1taWwgT25saW5lIFNlcnZpY2UgLSBDU0MgJiBDeWJlciBDYWZlIFdvcmtzdGF0aW9uIFN1aXRlXG4jIyBWZXJzaW9uOiB2OTguMCBQQyBTdWl0ZSAoU3RhbmRhbG9uZSBTdGFuZGFsb25lIEVkaXRpb24pXG4qKk93bmVyOioqIEltcmFuIEtoYW4gfCAqKkNvbnRhY3Q6KiogOTU2MTQ2MDMxM1xuKipBZGRyZXNzOioqIE5heWEgTXVuc2hpIFNoYWJhbiBOYWdhciwgTWFpbiBSb2FkLCBNYWhhcmFzaHRyYSwgSW5kaWFcblxuLS0tXG5cbiMjIyBGZWF0dXJlcyAmIFdvcmtzdGF0aW9uIE1vZHVsZXM6XG4xLiAqKlN0cmljdCAxLURldmljZSBTZWN1cml0eSBMb2NraW5nKio6IEVhY2ggT3BlcmF0b3IgSUQgaXMgcGVybWFuZW50bHkgYm91bmQgdG8gYSBzaW5nbGUgY29tcHV0ZXIvcGhvbmUuXG4yLiAqKlBWQyBTbWFydCBDYXJkIFN0dWRpbyoqOiBDUi04MCA4NS42eDU0bW0gaW5zdGFudCBkdWFsIGNhcmQgMzAwIERQSSBsYXlvdXQgZm9yIDR4NiBwaG90byBwYXBlciB3aXRoIGNlbnRlciBjdXQgbGluZS5cbjMuICoqUGFzc3BvcnQgUGhvdG8gU3R1ZGlvIFBybyoqOlxuICAgLSA0eDYgTGFuZHNjYXBlICg4IENvcGllcyBAIDMwMCBEUEkpICYgQTQgTGFuZHNjYXBlIHNoZWV0IGxheW91dC5cbiAgIC0gQ29ubmVjdGVkIEZsb29kLUZpbGwgTWFnaWMgV2FuZCBCYWNrZ3JvdW5kIEN1dG91dC5cbiAgIC0gVmVjdG9yIFBlbiBUb29sIHdpdGggQW5jaG9yIFBvaW50cyAmIExpdmUgRHVhbCBQcmV2aWV3LlxuICAgLSBBSSBBdXRvIEJlYXV0eSBGYWNlIEVmZmVjdCB3aXRoIFNraW4gU21vb3RoaW5nICYgRmFjaWFsIFJhZGlhbmNlLlxuICAgLSBPZmZpY2lhbCBFeGFtIFN0YW1wIChDYW5kaWRhdGUgTmFtZSAmIERhdGUgZm9yIFNTQy9Qb2xpY2UgQmhhcnRpKS5cbjQuICoqUERGIHRvIEhEIEpQRyBIaWdoLVJlc29sdXRpb24gUmFzdGVyaXplcioqOiBDb252ZXJ0IFBERiBBYWRoYWFyL1BBTi9Wb3RlciBzbGlwcyB0byAzMDAgRFBJIGltYWdlcy5cbjUuICoqRmFzdCBUaGVybWFsIEJpbGxpbmcgRGVzayAmIFBPUyoqOiA1OG1tICYgODBtbSB0aGVybWFsIHJlY2VpcHQgZ2VuZXJhdG9yIHdpdGggUVIgY29kZSBwYXltZW50LlxuNi4gKipDdXN0b21lciBDUk0gJiBEZWxpdmVyeSBUcmFja2VyKio6IFRva2VuIHRyYWNraW5nLCBwZW5kaW5nIHdvcmsgYWxlcnRzLCBXaGF0c0FwcCBub3RpZmljYXRpb25zLlxuNy4gKipCaW9EYXRhICYgQ1YgTWFrZXIqKjogSGluZGksIEVuZ2xpc2gsIGFuZCBJc2xhbWljIHdlZGRpbmcgYmlvZGF0YSB0ZW1wbGF0ZXMuXG44LiAqKjUwKyBHb3Zlcm5tZW50IFBvcnRhbHMgRGlyZWN0b3J5Kio6IERpcmVjdCBsaW5rcyB0byBhbGwgQ2VudHJhbCAmIE1haGFyYXNodHJhIFN0YXRlIENpdGl6ZW4gUG9ydGFscy5cbjkuICoqQ3liZXIgQ2FmZSBEYWlseSBTT1AgV29ya2Zsb3cgRW5naW5lKio6IEludGVyYWN0aXZlIGNoZWNrbGlzdCBmb3IgZGF5LXRvLWRheSBjeWJlciBvcGVyYXRpb25zLlxuMTAuICoqTWFzdGVyIEFkbWluIFBhbmVsKio6IERldmljZSBsb2NrIHJlc2V0cywgb3BlcmF0b3IgbWFuYWdlbWVudCwgYW5kIHNlY3VyaXR5IGF1ZGl0IGxvZ3MuXG5cbi0tLVxuXG4jIyMgSG93IHRvIFJ1biBMb2NhbGx5OlxuXFxgXFxgXFxgYmFzaFxuIyAxLiBJbnN0YWxsIGRlcGVuZGVuY2llc1xubnBtIGluc3RhbGxcblxuIyAyLiBSdW4gZGV2ZWxvcG1lbnQgc2VydmVyIChQb3J0IDMwMDApXG5ucG0gcnVuIGRldlxuXG4jIDMuIEJ1aWxkIGZvciBwcm9kdWN0aW9uXG5ucG0gcnVuIGJ1aWxkXG5cXGBcXGBcXGBcbmA7XG5cbiAgemlwLmZpbGUoJ1JFQURNRS5tZCcsIHJlYWRtZUNvbnRlbnQpO1xuXG4gIC8vIFdlIGNhbiBmZXRjaCBmaWxlcyBvciBidW5kbGUgdGhlIHNvdXJjZSBmaWxlcyB0aGF0IG1ha2UgdXAgdGhlIGNsaWVudCBhcHBcbiAgY29uc3Qgc291cmNlRmlsZXMgPSBbXG4gICAgJy9wYWNrYWdlLmpzb24nLFxuICAgICcvc2VydmVyLnRzJyxcbiAgICAnL3ZpdGUuY29uZmlnLnRzJyxcbiAgICAnL3RzY29uZmlnLmpzb24nLFxuICAgICcvaW5kZXguaHRtbCcsXG4gICAgJy9zcmMvbWFpbi50c3gnLFxuICAgICcvc3JjL0FwcC50c3gnLFxuICAgICcvc3JjL2luZGV4LmNzcycsXG4gICAgJy9zcmMvdHlwZXMudHMnLFxuICAgICcvc3JjL2RhdGEvcG9ydGFsRGF0YS50cycsXG4gICAgJy9zcmMvdXRpbHMvc3RvcmFnZS50cycsXG4gICAgJy9zcmMvdXRpbHMvcHJpbnRlci50cycsXG4gICAgJy9zcmMvdXRpbHMvZGV2aWNlU2VjdXJpdHkudHMnLFxuICAgICcvc3JjL3V0aWxzL3Byb2plY3RaaXAudHMnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvSGVhZGVyLnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9TaWRlYmFyLnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9EYXNoYm9hcmRWaWV3LnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9Mb2dpblNjcmVlbi50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvUHZjU3R1ZGlvVmlldy50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvUGFzc3BvcnRTdHVkaW9WaWV3LnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9WaWRlb1N0dWRpb1ZpZXcudHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL0JpbGxpbmdEZXNrVmlldy50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvQ3VzdG9tZXJDcm1WaWV3LnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9QZGZUb0pwZ1ZpZXcudHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL0Jpb0RhdGFNYWtlclZpZXcudHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL0dvdmVybm1lbnRQb3J0YWxzVmlldy50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvQWlBc3Npc3RhbnRWaWV3LnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9Eb3dubG9hZHNWaWV3LnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9TZXR0aW5nc1ZpZXcudHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL1Nob3J0Y3V0c01vZGFsLnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9BdXRoTW9kYWwudHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL01hc3RlckFkbWluVmlldy50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvV29ya2Zsb3dHdWlkZVZpZXcudHN4JyxcbiAgICAnL1NUQVJULVdPUktTVEFUSU9OLmJhdCcsXG4gICAgJy9DUkVBVEUtRVhFLVNFVFVQLmJhdCcsXG4gICAgJy9IT1ctVE8tQlVJTEQtRVhFLm1kJyxcbiAgICAnL0dJVEhVQi1FWEUtR1VJREUubWQnLFxuICAgICcvLmdpdGh1Yi93b3JrZmxvd3MvYnVpbGQtd2luZG93cy1leGUueW1sJyxcbiAgICAnL2luc3RhbGxlci9zZXR1cC5pc3MnLFxuICAgICcvZWxlY3Ryb24vbWFpbi5janMnLFxuICAgICcvZWxlY3Ryb24vcHJlbG9hZC5janMnXG4gIF07XG5cbiAgbGV0IGNvbXBsZXRlZCA9IDA7XG4gIGZvciAoY29uc3QgZmlsZVBhdGggb2Ygc291cmNlRmlsZXMpIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY2xlYW5QYXRoID0gZmlsZVBhdGguc3RhcnRzV2l0aCgnLycpID8gZmlsZVBhdGguc2xpY2UoMSkgOiBmaWxlUGF0aDtcbiAgICAgIGlmIChvblByb2dyZXNzKSB7XG4gICAgICAgIG9uUHJvZ3Jlc3MoTWF0aC5yb3VuZCgoY29tcGxldGVkIC8gc291cmNlRmlsZXMubGVuZ3RoKSAqIDEwMCksIGNsZWFuUGF0aCk7XG4gICAgICB9XG4gICAgICBcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGZpbGVQYXRoKTtcbiAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgICAgIHppcC5maWxlKGNsZWFuUGF0aCwgdGV4dCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBDb250aW51ZSBidW5kbGluZ1xuICAgIH1cbiAgICBjb21wbGV0ZWQrKztcbiAgfVxuXG4gIGlmIChvblByb2dyZXNzKSB7XG4gICAgb25Qcm9ncmVzcygxMDAsICdDb21wcmVzc2luZyBhcmNoaXZlLi4uJyk7XG4gIH1cblxuICBjb25zdCBjb250ZW50ID0gYXdhaXQgemlwLmdlbmVyYXRlQXN5bmMoe1xuICAgIHR5cGU6ICdibG9iJyxcbiAgICBjb21wcmVzc2lvbjogJ0RFRkxBVEUnLFxuICAgIGNvbXByZXNzaW9uT3B0aW9uczogeyBsZXZlbDogOSB9XG4gIH0pO1xuXG4gIHJldHVybiBjb250ZW50O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdHJpZ2dlckRvd25sb2FkWmlwKGJsb2I6IEJsb2IsIGZpbGVuYW1lID0gJ011emFtbWlsLU9ubGluZS1TZXJ2aWNlLUNvbXBsZXRlLVNvdXJjZS56aXAnKSB7XG4gIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XG4gIGNvbnN0IGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gIGEuaHJlZiA9IHVybDtcbiAgYS5kb3dubG9hZCA9IGZpbGVuYW1lO1xuICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGEpO1xuICBhLmNsaWNrKCk7XG4gIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoYSk7XG4gIHNldFRpbWVvdXQoKCkgPT4gVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpLCA1MDAwKTtcbn1cbiJdfQ==