export const printImageSheet = (dataUrl, options) => {
	let pageSizeStyle = "6in 4in landscape";
	let imgStyle = "width: 6in; height: 4in;";
	if (options.paperFormat === "a4_landscape") {
		pageSizeStyle = "A4 landscape";
		imgStyle = "width: 297mm; height: 210mm;";
	} else if (options.paperFormat === "a4_portrait") {
		pageSizeStyle = "A4 portrait";
		imgStyle = "width: 210mm; height: 297mm;";
	} else if (options.paperFormat === "4x6_portrait") {
		pageSizeStyle = "4in 6in portrait";
		imgStyle = "width: 4in; height: 6in;";
	} else {
		// 4x6 landscape
		pageSizeStyle = "6in 4in landscape";
		imgStyle = "width: 6in; height: 4in;";
	}
	const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8" />
        <title>${options.title}</title>
        <style>
          @page {
            size: ${pageSizeStyle};
            margin: 0mm;
          }
          * {
            box-sizing: border-box;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          html, body {
            margin: 0 !important;
            padding: 0 !important;
            background: #ffffff !important;
            width: 100%;
            height: 100%;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          img {
            ${imgStyle}
            display: block;
            margin: 0 auto;
            image-rendering: -webkit-optimize-contrast;
            image-rendering: crisp-edges;
          }
        </style>
      </head>
      <body>
        <img id="print-target" src="${dataUrl}" />
      </body>
    </html>
  `;
	executePrint(html);
};
export const printHtmlDocument = (htmlBody, title, pageStyle) => {
	const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8" />
        <title>${title}</title>
        <style>
          ${pageStyle}
          * {
            box-sizing: border-box;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          body {
            margin: 0;
            padding: 0;
            background: #fff;
            color: #0f172a;
          }
        </style>
      </head>
      <body>
        ${htmlBody}
      </body>
    </html>
  `;
	executePrint(html);
};
function executePrint(fullHtml) {
	// Use a dedicated print iframe in document body
	let iframe = document.getElementById("mos-universal-print-frame");
	if (!iframe) {
		iframe = document.createElement("iframe");
		iframe.id = "mos-universal-print-frame";
		iframe.style.position = "fixed";
		iframe.style.right = "0";
		iframe.style.bottom = "0";
		iframe.style.width = "0px";
		iframe.style.height = "0px";
		iframe.style.border = "0px none transparent";
		iframe.style.opacity = "0";
		iframe.style.pointerEvents = "none";
		iframe.style.zIndex = "-9999";
		document.body.appendChild(iframe);
	}
	const doc = iframe.contentWindow?.document || iframe.contentDocument;
	if (!doc) {
		window.print();
		return;
	}
	doc.open();
	doc.write(fullHtml);
	doc.close();
	// Wait for all assets in iframe to load
	setTimeout(() => {
		try {
			iframe.contentWindow?.focus();
			iframe.contentWindow?.print();
		} catch (e) {
			console.warn("Iframe print error, falling back to window.print", e);
			window.print();
		}
	}, 250);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBWUEsT0FBTyxNQUFNLG1CQUNYLFNBQ0EsWUFLRztDQUNILElBQUksZ0JBQWdCO0NBQ3BCLElBQUksV0FBVztDQUVmLElBQUksUUFBUSxnQkFBZ0IsZ0JBQWdCO0VBQzFDLGdCQUFnQjtFQUNoQixXQUFXO0NBQ2IsT0FBTyxJQUFJLFFBQVEsZ0JBQWdCLGVBQWU7RUFDaEQsZ0JBQWdCO0VBQ2hCLFdBQVc7Q0FDYixPQUFPLElBQUksUUFBUSxnQkFBZ0IsZ0JBQWdCO0VBQ2pELGdCQUFnQjtFQUNoQixXQUFXO0NBQ2IsT0FBTzs7RUFFTCxnQkFBZ0I7RUFDaEIsV0FBVztDQUNiO0NBRUEsTUFBTSxPQUFPOzs7OztpQkFLRSxRQUFRLE1BQU07OztvQkFHWCxjQUFjOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztjQW9CcEIsU0FBUzs7Ozs7Ozs7O3NDQVNlLFFBQVE7Ozs7Q0FLNUMsYUFBYSxJQUFJO0FBQ25CO0FBRUEsT0FBTyxNQUFNLHFCQUFxQixVQUFrQixPQUFlLGNBQXNCO0NBQ3ZGLE1BQU0sT0FBTzs7Ozs7aUJBS0UsTUFBTTs7WUFFWCxVQUFVOzs7Ozs7Ozs7Ozs7Ozs7VUFlWixTQUFTOzs7O0NBS2pCLGFBQWEsSUFBSTtBQUNuQjtBQUVBLFNBQVMsYUFBYSxVQUFrQjs7Q0FFdEMsSUFBSSxTQUFTLFNBQVMsZUFBZSwyQkFBMkI7Q0FDaEUsSUFBSSxDQUFDLFFBQVE7RUFDWCxTQUFTLFNBQVMsY0FBYyxRQUFRO0VBQ3hDLE9BQU8sS0FBSztFQUNaLE9BQU8sTUFBTSxXQUFXO0VBQ3hCLE9BQU8sTUFBTSxRQUFRO0VBQ3JCLE9BQU8sTUFBTSxTQUFTO0VBQ3RCLE9BQU8sTUFBTSxRQUFRO0VBQ3JCLE9BQU8sTUFBTSxTQUFTO0VBQ3RCLE9BQU8sTUFBTSxTQUFTO0VBQ3RCLE9BQU8sTUFBTSxVQUFVO0VBQ3ZCLE9BQU8sTUFBTSxnQkFBZ0I7RUFDN0IsT0FBTyxNQUFNLFNBQVM7RUFDdEIsU0FBUyxLQUFLLFlBQVksTUFBTTtDQUNsQztDQUVBLE1BQU0sTUFBTSxPQUFPLGVBQWUsWUFBWSxPQUFPO0NBQ3JELElBQUksQ0FBQyxLQUFLO0VBQ1IsT0FBTyxNQUFNO0VBQ2I7Q0FDRjtDQUVBLElBQUksS0FBSztDQUNULElBQUksTUFBTSxRQUFRO0NBQ2xCLElBQUksTUFBTTs7Q0FHVixpQkFBaUI7RUFDZixJQUFJO0dBQ0YsT0FBTyxlQUFlLE1BQU07R0FDNUIsT0FBTyxlQUFlLE1BQU07RUFDOUIsU0FBUyxHQUFHO0dBQ1YsUUFBUSxLQUFLLG9EQUFvRCxDQUFDO0dBQ2xFLE9BQU8sTUFBTTtFQUNmO0NBQ0YsR0FBRyxHQUFHO0FBQ1IiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsicHJpbnRlci50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIFVuaXZlcnNhbCBJbi1BcHAgUHJpbnQgRW5naW5lIGZvciBNdXphbW1pbCBPbmxpbmUgU2VydmljZSBQQyBTdWl0ZVxuICogV29ya3Mgd2l0aG91dCB3aW5kb3cub3BlbiAvIHBvcHVwIGJsb2NrZXIgaXNzdWVzIGluIGFsbCBkZXNrdG9wIGJyb3dzZXJzICYgaWZyYW1lc1xuICovXG5cbmV4cG9ydCBpbnRlcmZhY2UgUHJpbnRPcHRpb25zIHtcbiAgdGl0bGU/OiBzdHJpbmc7XG4gIHBhZ2VTaXplPzogJzRpbiA2aW4gbGFuZHNjYXBlJyB8ICc0aW4gNmluIHBvcnRyYWl0JyB8ICdBNCBsYW5kc2NhcGUnIHwgJ0E0IHBvcnRyYWl0JyB8ICc1OG1tJyB8ICc4MG1tJztcbiAgb3JpZW50YXRpb24/OiAnbGFuZHNjYXBlJyB8ICdwb3J0cmFpdCc7XG4gIG1hcmdpbnM/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBjb25zdCBwcmludEltYWdlU2hlZXQgPSAoXG4gIGRhdGFVcmw6IHN0cmluZyxcbiAgb3B0aW9uczoge1xuICAgIHBhcGVyRm9ybWF0OiAnNHg2X2xhbmRzY2FwZScgfCAnYTRfbGFuZHNjYXBlJyB8ICc0eDZfcG9ydHJhaXQnIHwgJ2E0X3BvcnRyYWl0JztcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIGNvcGllc0NvdW50PzogbnVtYmVyO1xuICB9XG4pID0+IHtcbiAgbGV0IHBhZ2VTaXplU3R5bGUgPSAnNmluIDRpbiBsYW5kc2NhcGUnO1xuICBsZXQgaW1nU3R5bGUgPSAnd2lkdGg6IDZpbjsgaGVpZ2h0OiA0aW47JztcblxuICBpZiAob3B0aW9ucy5wYXBlckZvcm1hdCA9PT0gJ2E0X2xhbmRzY2FwZScpIHtcbiAgICBwYWdlU2l6ZVN0eWxlID0gJ0E0IGxhbmRzY2FwZSc7XG4gICAgaW1nU3R5bGUgPSAnd2lkdGg6IDI5N21tOyBoZWlnaHQ6IDIxMG1tOyc7XG4gIH0gZWxzZSBpZiAob3B0aW9ucy5wYXBlckZvcm1hdCA9PT0gJ2E0X3BvcnRyYWl0Jykge1xuICAgIHBhZ2VTaXplU3R5bGUgPSAnQTQgcG9ydHJhaXQnO1xuICAgIGltZ1N0eWxlID0gJ3dpZHRoOiAyMTBtbTsgaGVpZ2h0OiAyOTdtbTsnO1xuICB9IGVsc2UgaWYgKG9wdGlvbnMucGFwZXJGb3JtYXQgPT09ICc0eDZfcG9ydHJhaXQnKSB7XG4gICAgcGFnZVNpemVTdHlsZSA9ICc0aW4gNmluIHBvcnRyYWl0JztcbiAgICBpbWdTdHlsZSA9ICd3aWR0aDogNGluOyBoZWlnaHQ6IDZpbjsnO1xuICB9IGVsc2Uge1xuICAgIC8vIDR4NiBsYW5kc2NhcGVcbiAgICBwYWdlU2l6ZVN0eWxlID0gJzZpbiA0aW4gbGFuZHNjYXBlJztcbiAgICBpbWdTdHlsZSA9ICd3aWR0aDogNmluOyBoZWlnaHQ6IDRpbjsnO1xuICB9XG5cbiAgY29uc3QgaHRtbCA9IGBcbiAgICA8IURPQ1RZUEUgaHRtbD5cbiAgICA8aHRtbD5cbiAgICAgIDxoZWFkPlxuICAgICAgICA8bWV0YSBjaGFyc2V0PVwidXRmLThcIiAvPlxuICAgICAgICA8dGl0bGU+JHtvcHRpb25zLnRpdGxlfTwvdGl0bGU+XG4gICAgICAgIDxzdHlsZT5cbiAgICAgICAgICBAcGFnZSB7XG4gICAgICAgICAgICBzaXplOiAke3BhZ2VTaXplU3R5bGV9O1xuICAgICAgICAgICAgbWFyZ2luOiAwbW07XG4gICAgICAgICAgfVxuICAgICAgICAgICoge1xuICAgICAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgICAgICAgICAgIC13ZWJraXQtcHJpbnQtY29sb3ItYWRqdXN0OiBleGFjdCAhaW1wb3J0YW50O1xuICAgICAgICAgICAgcHJpbnQtY29sb3ItYWRqdXN0OiBleGFjdCAhaW1wb3J0YW50O1xuICAgICAgICAgIH1cbiAgICAgICAgICBodG1sLCBib2R5IHtcbiAgICAgICAgICAgIG1hcmdpbjogMCAhaW1wb3J0YW50O1xuICAgICAgICAgICAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xuICAgICAgICAgICAgYmFja2dyb3VuZDogI2ZmZmZmZiAhaW1wb3J0YW50O1xuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XG4gICAgICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgICB9XG4gICAgICAgICAgaW1nIHtcbiAgICAgICAgICAgICR7aW1nU3R5bGV9XG4gICAgICAgICAgICBkaXNwbGF5OiBibG9jaztcbiAgICAgICAgICAgIG1hcmdpbjogMCBhdXRvO1xuICAgICAgICAgICAgaW1hZ2UtcmVuZGVyaW5nOiAtd2Via2l0LW9wdGltaXplLWNvbnRyYXN0O1xuICAgICAgICAgICAgaW1hZ2UtcmVuZGVyaW5nOiBjcmlzcC1lZGdlcztcbiAgICAgICAgICB9XG4gICAgICAgIDwvc3R5bGU+XG4gICAgICA8L2hlYWQ+XG4gICAgICA8Ym9keT5cbiAgICAgICAgPGltZyBpZD1cInByaW50LXRhcmdldFwiIHNyYz1cIiR7ZGF0YVVybH1cIiAvPlxuICAgICAgPC9ib2R5PlxuICAgIDwvaHRtbD5cbiAgYDtcblxuICBleGVjdXRlUHJpbnQoaHRtbCk7XG59O1xuXG5leHBvcnQgY29uc3QgcHJpbnRIdG1sRG9jdW1lbnQgPSAoaHRtbEJvZHk6IHN0cmluZywgdGl0bGU6IHN0cmluZywgcGFnZVN0eWxlOiBzdHJpbmcpID0+IHtcbiAgY29uc3QgaHRtbCA9IGBcbiAgICA8IURPQ1RZUEUgaHRtbD5cbiAgICA8aHRtbD5cbiAgICAgIDxoZWFkPlxuICAgICAgICA8bWV0YSBjaGFyc2V0PVwidXRmLThcIiAvPlxuICAgICAgICA8dGl0bGU+JHt0aXRsZX08L3RpdGxlPlxuICAgICAgICA8c3R5bGU+XG4gICAgICAgICAgJHtwYWdlU3R5bGV9XG4gICAgICAgICAgKiB7XG4gICAgICAgICAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICAgICAgICAgICAgLXdlYmtpdC1wcmludC1jb2xvci1hZGp1c3Q6IGV4YWN0ICFpbXBvcnRhbnQ7XG4gICAgICAgICAgICBwcmludC1jb2xvci1hZGp1c3Q6IGV4YWN0ICFpbXBvcnRhbnQ7XG4gICAgICAgICAgfVxuICAgICAgICAgIGJvZHkge1xuICAgICAgICAgICAgbWFyZ2luOiAwO1xuICAgICAgICAgICAgcGFkZGluZzogMDtcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICNmZmY7XG4gICAgICAgICAgICBjb2xvcjogIzBmMTcyYTtcbiAgICAgICAgICB9XG4gICAgICAgIDwvc3R5bGU+XG4gICAgICA8L2hlYWQ+XG4gICAgICA8Ym9keT5cbiAgICAgICAgJHtodG1sQm9keX1cbiAgICAgIDwvYm9keT5cbiAgICA8L2h0bWw+XG4gIGA7XG5cbiAgZXhlY3V0ZVByaW50KGh0bWwpO1xufTtcblxuZnVuY3Rpb24gZXhlY3V0ZVByaW50KGZ1bGxIdG1sOiBzdHJpbmcpIHtcbiAgLy8gVXNlIGEgZGVkaWNhdGVkIHByaW50IGlmcmFtZSBpbiBkb2N1bWVudCBib2R5XG4gIGxldCBpZnJhbWUgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbW9zLXVuaXZlcnNhbC1wcmludC1mcmFtZScpIGFzIEhUTUxJRnJhbWVFbGVtZW50O1xuICBpZiAoIWlmcmFtZSkge1xuICAgIGlmcmFtZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2lmcmFtZScpO1xuICAgIGlmcmFtZS5pZCA9ICdtb3MtdW5pdmVyc2FsLXByaW50LWZyYW1lJztcbiAgICBpZnJhbWUuc3R5bGUucG9zaXRpb24gPSAnZml4ZWQnO1xuICAgIGlmcmFtZS5zdHlsZS5yaWdodCA9ICcwJztcbiAgICBpZnJhbWUuc3R5bGUuYm90dG9tID0gJzAnO1xuICAgIGlmcmFtZS5zdHlsZS53aWR0aCA9ICcwcHgnO1xuICAgIGlmcmFtZS5zdHlsZS5oZWlnaHQgPSAnMHB4JztcbiAgICBpZnJhbWUuc3R5bGUuYm9yZGVyID0gJzBweCBub25lIHRyYW5zcGFyZW50JztcbiAgICBpZnJhbWUuc3R5bGUub3BhY2l0eSA9ICcwJztcbiAgICBpZnJhbWUuc3R5bGUucG9pbnRlckV2ZW50cyA9ICdub25lJztcbiAgICBpZnJhbWUuc3R5bGUuekluZGV4ID0gJy05OTk5JztcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGlmcmFtZSk7XG4gIH1cblxuICBjb25zdCBkb2MgPSBpZnJhbWUuY29udGVudFdpbmRvdz8uZG9jdW1lbnQgfHwgaWZyYW1lLmNvbnRlbnREb2N1bWVudDtcbiAgaWYgKCFkb2MpIHtcbiAgICB3aW5kb3cucHJpbnQoKTtcbiAgICByZXR1cm47XG4gIH1cblxuICBkb2Mub3BlbigpO1xuICBkb2Mud3JpdGUoZnVsbEh0bWwpO1xuICBkb2MuY2xvc2UoKTtcblxuICAvLyBXYWl0IGZvciBhbGwgYXNzZXRzIGluIGlmcmFtZSB0byBsb2FkXG4gIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBpZnJhbWUuY29udGVudFdpbmRvdz8uZm9jdXMoKTtcbiAgICAgIGlmcmFtZS5jb250ZW50V2luZG93Py5wcmludCgpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUud2FybignSWZyYW1lIHByaW50IGVycm9yLCBmYWxsaW5nIGJhY2sgdG8gd2luZG93LnByaW50JywgZSk7XG4gICAgICB3aW5kb3cucHJpbnQoKTtcbiAgICB9XG4gIH0sIDI1MCk7XG59XG4iXX0=