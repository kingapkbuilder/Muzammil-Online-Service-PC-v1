const STORAGE_KEYS = {
	DEVICE_ID: "mos_hardware_device_id",
	DEVICE_NAME: "mos_hardware_device_name",
	OPERATORS: "mos_registered_operators",
	AUDIT_LOGS: "mos_security_audit_logs"
};
// Detect if current runtime is a mobile phone / tablet
export function isMobileDevice() {
	if (typeof navigator === "undefined") return false;
	return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}
// Persistent hardware device ID (Generated once per machine/browser)
export function getHardwareDeviceId() {
	try {
		let deviceId = localStorage.getItem(STORAGE_KEYS.DEVICE_ID);
		if (!deviceId) {
			const randStr = Math.random().toString(36).substring(2, 6).toUpperCase() + "-" + Math.random().toString(36).substring(2, 6).toUpperCase();
			const mobile = isMobileDevice();
			deviceId = `DEV-MOS-${mobile ? "MOB" : "PC"}-${randStr}`;
			localStorage.setItem(STORAGE_KEYS.DEVICE_ID, deviceId);
		}
		return deviceId;
	} catch {
		return "DEV-MOS-DEFAULT-001";
	}
}
// Friendly device name based on platform/browser
export function getHardwareDeviceName() {
	try {
		let name = localStorage.getItem(STORAGE_KEYS.DEVICE_NAME);
		if (!name) {
			const ua = navigator.userAgent;
			let os = "Windows PC";
			if (/Android/i.test(ua)) os = "Android Mobile";
			else if (/iPhone/i.test(ua)) os = "iPhone";
			else if (/iPad/i.test(ua)) os = "iPad";
			else if (/Mac/i.test(ua)) os = "Mac Workstation";
			else if (/Linux/i.test(ua)) os = "Linux Workstation";
			let browser = "Chrome";
			if (/Firefox/i.test(ua)) browser = "Firefox";
			else if (/Edg/i.test(ua)) browser = "Edge";
			else if (/Safari/i.test(ua) && !/Chrome/i.test(ua)) browser = "Safari";
			name = `${os} • ${browser}`;
			localStorage.setItem(STORAGE_KEYS.DEVICE_NAME, name);
		}
		return name;
	} catch {
		return isMobileDevice() ? "Authorized Mobile" : "Authorized Workstation";
	}
}
// Default pre-configured operators (Dual Device: 1 PC + 1 Mobile)
const DEFAULT_OPERATORS = [
	{
		id: "op-admin",
		username: "admin",
		password: "muzammil786",
		displayName: "Imran Khan (Master Admin)",
		role: "admin",
		phone: "9561460313",
		boundPcDeviceId: null,
		boundPcDeviceName: null,
		boundPcAt: null,
		boundMobileDeviceId: null,
		boundMobileDeviceName: null,
		boundMobileAt: null,
		lastLogin: null,
		isLocked: false,
		validityExpiresAt: "Lifetime (Never Expires)",
		validityDaysLeft: 999999
	},
	{
		id: "op-1",
		username: "operator1",
		password: "sameer123",
		displayName: "Shaikh Sameer",
		role: "operator",
		phone: "9876543210",
		boundPcDeviceId: null,
		boundPcDeviceName: null,
		boundPcAt: null,
		boundMobileDeviceId: null,
		boundMobileDeviceName: null,
		boundMobileAt: null,
		lastLogin: null,
		isLocked: false
	},
	{
		id: "op-2",
		username: "operator2",
		password: "adil123",
		displayName: "Adil Khan",
		role: "operator",
		phone: "9123456780",
		boundPcDeviceId: null,
		boundPcDeviceName: null,
		boundPcAt: null,
		boundMobileDeviceId: null,
		boundMobileDeviceName: null,
		boundMobileAt: null,
		lastLogin: null,
		isLocked: false
	}
];
// Load registered operators
export function getRegisteredOperators() {
	try {
		const raw = localStorage.getItem(STORAGE_KEYS.OPERATORS);
		if (!raw) {
			localStorage.setItem(STORAGE_KEYS.OPERATORS, JSON.stringify(DEFAULT_OPERATORS));
			return DEFAULT_OPERATORS;
		}
		const parsed = JSON.parse(raw);
		// Ensure dual device fields are present if loaded from legacy format
		return parsed.map((op) => ({
			...op,
			boundPcDeviceId: op.boundPcDeviceId ?? (op.boundDeviceId?.includes("-PC-") ? op.boundDeviceId : null),
			boundPcDeviceName: op.boundPcDeviceName ?? (op.boundDeviceId?.includes("-PC-") ? op.boundDeviceName : null),
			boundPcAt: op.boundPcAt ?? (op.boundDeviceId?.includes("-PC-") ? op.boundAt : null),
			boundMobileDeviceId: op.boundMobileDeviceId ?? (op.boundDeviceId?.includes("-MOB-") ? op.boundDeviceId : null),
			boundMobileDeviceName: op.boundMobileDeviceName ?? (op.boundDeviceId?.includes("-MOB-") ? op.boundDeviceName : null),
			boundMobileAt: op.boundMobileAt ?? (op.boundDeviceId?.includes("-MOB-") ? op.boundAt : null)
		}));
	} catch {
		return DEFAULT_OPERATORS;
	}
}
// Save operators
export function saveRegisteredOperators(operators) {
	try {
		localStorage.setItem(STORAGE_KEYS.OPERATORS, JSON.stringify(operators));
	} catch (e) {
		console.error("Failed to save operators", e);
	}
}
// Add security audit log
export function addSecurityAuditLog(action, username, details) {
	try {
		const deviceId = getHardwareDeviceId();
		const deviceName = getHardwareDeviceName();
		const deviceType = isMobileDevice() ? "mobile" : "pc";
		const raw = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
		const logs = raw ? JSON.parse(raw) : [];
		const newLog = {
			id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
			timestamp: new Date().toLocaleString("en-IN", {
				day: "2-digit",
				month: "short",
				year: "numeric",
				hour: "2-digit",
				minute: "2-digit",
				second: "2-digit"
			}),
			username,
			action,
			deviceId,
			deviceName,
			deviceType,
			details
		};
		logs.unshift(newLog);
		if (logs.length > 60) logs.pop();
		localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(logs));
	} catch (e) {
		console.error("Failed to record audit log", e);
	}
}
export function getSecurityAuditLogs() {
	try {
		const raw = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
		return raw ? JSON.parse(raw) : [];
	} catch {
		return [];
	}
}
export function authenticateOperator(usernameInput, passwordInput) {
	const username = usernameInput.trim().toLowerCase();
	const password = passwordInput.trim();
	const currentDeviceId = getHardwareDeviceId();
	const currentDeviceName = getHardwareDeviceName();
	const currentType = isMobileDevice() ? "mobile" : "pc";
	const operators = getRegisteredOperators();
	const operator = operators.find((o) => o.username.toLowerCase() === username);
	if (!operator) {
		addSecurityAuditLog("LOGIN_FAILED", username, "Invalid operator username");
		return {
			success: false,
			error: "Invalid Operator ID. Please verify your username."
		};
	}
	// Check password
	if (operator.password && operator.password !== password) {
		addSecurityAuditLog("LOGIN_FAILED", username, "Incorrect password entered");
		return {
			success: false,
			error: "Incorrect Password. Please try again."
		};
	}
	// Check if account is suspended / locked
	if (operator.isLocked) {
		addSecurityAuditLog("OPERATOR_LOCKED", username, "Attempt to login to suspended account");
		return {
			success: false,
			error: "⛔ ACCOUNT SUSPENDED: This operator ID has been locked by Master Admin. Please contact shop owner."
		};
	}
	// -------------------------------------------------------------
	// DUAL-DEVICE ENFORCEMENT: PC SLOT vs MOBILE SLOT
	// -------------------------------------------------------------
	const now = new Date().toLocaleString("en-IN");
	if (currentType === "pc") {
		// Logging in from PC
		if (!operator.boundPcDeviceId) {
			// First PC login: Bind this PC!
			operator.boundPcDeviceId = currentDeviceId;
			operator.boundPcDeviceName = currentDeviceName;
			operator.boundPcAt = now;
			operator.lastLogin = now;
			saveRegisteredOperators(operators);
			addSecurityAuditLog("DEVICE_BOUND", username, `PC bound: ${currentDeviceName} (${currentDeviceId})`);
		} else if (operator.boundPcDeviceId !== currentDeviceId) {
			// Different PC tried to access!
			addSecurityAuditLog("DEVICE_BLOCKED", username, `Unauthorized PC login attempt. ID is already bound to PC (${operator.boundPcDeviceName} / ${operator.boundPcDeviceId})`);
			return {
				success: false,
				deviceLockedToOther: true,
				deviceType: "pc",
				boundDeviceName: operator.boundPcDeviceName || operator.boundPcDeviceId,
				error: `🚨 PC DEVICE MISMATCH:\nThis Operator ID is already paired with your shop PC (${operator.boundPcDeviceName || operator.boundPcDeviceId}).\n\n1 ID is permitted on 1 PC + 1 Mobile only. To use on this new computer, ask Master Admin to reset your PC binding.`
			};
		} else {
			// Authorized PC match!
			operator.lastLogin = now;
			saveRegisteredOperators(operators);
			addSecurityAuditLog("LOGIN_SUCCESS", username, `Successful login on authorized PC (${currentDeviceId})`);
		}
	} else {
		// Logging in from Mobile Phone / Tablet
		if (!operator.boundMobileDeviceId) {
			// First Mobile login: Bind this Mobile!
			operator.boundMobileDeviceId = currentDeviceId;
			operator.boundMobileDeviceName = currentDeviceName;
			operator.boundMobileAt = now;
			operator.lastLogin = now;
			saveRegisteredOperators(operators);
			addSecurityAuditLog("DEVICE_BOUND", username, `Mobile bound: ${currentDeviceName} (${currentDeviceId})`);
		} else if (operator.boundMobileDeviceId !== currentDeviceId) {
			// Different Mobile tried to access!
			addSecurityAuditLog("DEVICE_BLOCKED", username, `Unauthorized Mobile login attempt. ID is already bound to Mobile (${operator.boundMobileDeviceName} / ${operator.boundMobileDeviceId})`);
			return {
				success: false,
				deviceLockedToOther: true,
				deviceType: "mobile",
				boundDeviceName: operator.boundMobileDeviceName || operator.boundMobileDeviceId,
				error: `🚨 MOBILE DEVICE MISMATCH:\nThis Operator ID is already paired with your registered Mobile (${operator.boundMobileDeviceName || operator.boundMobileDeviceId}).\n\n1 ID is permitted on 1 PC + 1 Mobile only. To use on this new phone, ask Master Admin to reset your Mobile binding.`
			};
		} else {
			// Authorized Mobile match!
			operator.lastLogin = now;
			saveRegisteredOperators(operators);
			addSecurityAuditLog("LOGIN_SUCCESS", username, `Successful login on authorized Mobile (${currentDeviceId})`);
		}
	}
	const activeUser = {
		username: operator.username,
		displayName: operator.displayName,
		role: operator.role,
		phone: operator.phone,
		shopName: "Muzammil Online Service",
		isLoggedIn: true,
		currentDeviceType: currentType,
		currentDeviceId,
		currentDeviceName,
		boundPcDeviceId: operator.boundPcDeviceId || undefined,
		boundMobileDeviceId: operator.boundMobileDeviceId || undefined
	};
	return {
		success: true,
		user: activeUser
	};
}
// Master Admin: Reset PC Device Binding
export function resetOperatorPcBinding(operatorId) {
	const operators = getRegisteredOperators();
	const op = operators.find((o) => o.id === operatorId || o.username === operatorId);
	if (!op) return false;
	const prev = op.boundPcDeviceName || op.boundPcDeviceId || "PC";
	op.boundPcDeviceId = null;
	op.boundPcDeviceName = null;
	op.boundPcAt = null;
	saveRegisteredOperators(operators);
	addSecurityAuditLog("DEVICE_RESET", op.username, `Master Admin cleared PC device binding (was: ${prev})`);
	return true;
}
// Master Admin: Reset Mobile Device Binding
export function resetOperatorMobileBinding(operatorId) {
	const operators = getRegisteredOperators();
	const op = operators.find((o) => o.id === operatorId || o.username === operatorId);
	if (!op) return false;
	const prev = op.boundMobileDeviceName || op.boundMobileDeviceId || "Mobile";
	op.boundMobileDeviceId = null;
	op.boundMobileDeviceName = null;
	op.boundMobileAt = null;
	saveRegisteredOperators(operators);
	addSecurityAuditLog("DEVICE_RESET", op.username, `Master Admin cleared Mobile device binding (was: ${prev})`);
	return true;
}
// Master Admin: Reset Both Device Bindings (Full Reset)
export function resetOperatorAllBindings(operatorId) {
	const operators = getRegisteredOperators();
	const op = operators.find((o) => o.id === operatorId || o.username === operatorId);
	if (!op) return false;
	op.boundPcDeviceId = null;
	op.boundPcDeviceName = null;
	op.boundPcAt = null;
	op.boundMobileDeviceId = null;
	op.boundMobileDeviceName = null;
	op.boundMobileAt = null;
	saveRegisteredOperators(operators);
	addSecurityAuditLog("DEVICE_RESET", op.username, `Master Admin cleared all device bindings (PC & Mobile)`);
	return true;
}
// Master Admin: Toggle Lock Account
export function toggleOperatorLock(operatorId) {
	const operators = getRegisteredOperators();
	const op = operators.find((o) => o.id === operatorId || o.username === operatorId);
	if (!op) return false;
	op.isLocked = !op.isLocked;
	saveRegisteredOperators(operators);
	addSecurityAuditLog("OPERATOR_LOCKED", op.username, `Master Admin set lock status to: ${op.isLocked ? "LOCKED" : "ACTIVE"}`);
	return true;
}
// Master Admin: Add Operator
export function addNewOperator(op) {
	const operators = getRegisteredOperators();
	if (operators.some((o) => o.username.toLowerCase() === op.username.toLowerCase())) {
		return false;
	}
	const newOp = {
		...op,
		id: `op-${Date.now()}`,
		boundPcDeviceId: null,
		boundPcDeviceName: null,
		boundPcAt: null,
		boundMobileDeviceId: null,
		boundMobileDeviceName: null,
		boundMobileAt: null,
		lastLogin: null,
		isLocked: false
	};
	operators.push(newOp);
	saveRegisteredOperators(operators);
	addSecurityAuditLog("LOGIN_SUCCESS", "admin", `Master Admin registered new operator: ${op.username}`);
	return true;
}
// Master Admin: Delete Operator
export function deleteOperator(operatorId) {
	let operators = getRegisteredOperators();
	const op = operators.find((o) => o.id === operatorId);
	if (!op || op.role === "admin") return false;
	operators = operators.filter((o) => o.id !== operatorId);
	saveRegisteredOperators(operators);
	addSecurityAuditLog("LOGIN_SUCCESS", "admin", `Master Admin deleted operator: ${op.username}`);
	return true;
}
// Calculate Days Left until validity expiry (Admin is Lifetime / Never Expires)
export function calculateRemainingDays(dateStr) {
	if (!dateStr || dateStr.toLowerCase().includes("lifetime") || dateStr.toLowerCase().includes("never")) {
		return 999999;
	}
	const expiry = new Date(dateStr).getTime();
	if (isNaN(expiry)) return 999999;
	const now = Date.now();
	const diff = expiry - now;
	return Math.max(0, Math.ceil(diff / (1e3 * 60 * 60 * 24)));
}
// Master Admin: Renew Operator License / Access
export function renewOperatorLicense(operatorId, daysToAdd) {
	const operators = getRegisteredOperators();
	const op = operators.find((o) => o.id === operatorId || o.username === operatorId);
	if (!op) return {
		success: false,
		newExpiry: "",
		daysLeft: 0
	};
	if (op.role === "admin" || op.username === "admin") {
		op.validityExpiresAt = "Lifetime (Never Expires)";
		op.validityDaysLeft = 999999;
		op.isLocked = false;
		saveRegisteredOperators(operators);
		return {
			success: true,
			newExpiry: "Lifetime (Never Expires)",
			daysLeft: 999999
		};
	}
	let currentExpiry = op.validityExpiresAt ? new Date(op.validityExpiresAt).getTime() : Date.now();
	if (isNaN(currentExpiry) || currentExpiry < Date.now()) {
		currentExpiry = Date.now();
	}
	const newExpiryTime = currentExpiry + daysToAdd * 24 * 60 * 60 * 1e3;
	const newExpiryStr = new Date(newExpiryTime).toISOString().split("T")[0];
	const daysLeft = Math.ceil((newExpiryTime - Date.now()) / (1e3 * 60 * 60 * 24));
	op.validityExpiresAt = newExpiryStr;
	op.validityDaysLeft = daysLeft;
	saveRegisteredOperators(operators);
	addSecurityAuditLog("LOGIN_SUCCESS", op.username, `License renewed for +${daysToAdd} days. Valid until ${newExpiryStr} (${daysLeft} days left)`);
	return {
		success: true,
		newExpiry: newExpiryStr,
		daysLeft
	};
}
// Client Live Heartbeat Reporter
export async function sendOperatorHeartbeat(data) {
	const deviceId = getHardwareDeviceId();
	const deviceName = getHardwareDeviceName();
	const deviceType = isMobileDevice() ? "mobile" : "pc";
	try {
		const res = await fetch("/api/live/heartbeat", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				...data,
				deviceId,
				deviceName,
				deviceType
			})
		});
		if (res.ok) {
			return await res.json();
		}
	} catch {
		// Offline mode: store in local storage heartbeat registry
		try {
			const localKey = "mos_local_live_pulse";
			const existing = JSON.parse(localStorage.getItem(localKey) || "{}");
			existing[data.username] = {
				...data,
				deviceId,
				deviceName,
				deviceType,
				lastHeartbeat: new Date().toISOString()
			};
			localStorage.setItem(localKey, JSON.stringify(existing));
		} catch {}
	}
	return {
		success: true,
		activeCount: 1,
		broadcastMessage: null
	};
}
// Master Admin: Fetch Live Operator Sessions
export async function getLiveOperatorSessions() {
	try {
		const res = await fetch("/api/live/sessions");
		if (res.ok) {
			const data = await res.json();
			return data.sessions || [];
		}
	} catch {}
	// Local fallback if server unreachable
	const operators = getRegisteredOperators();
	const currentDevId = getHardwareDeviceId();
	const currentDevName = getHardwareDeviceName();
	return operators.map((op) => ({
		sessionId: `local-${op.id}`,
		username: op.username,
		displayName: op.displayName,
		role: op.role,
		phone: op.phone,
		deviceType: isMobileDevice() ? "mobile" : "pc",
		deviceId: currentDevId,
		deviceName: currentDevName,
		currentTab: "Workstation Active",
		currentTask: "Online Hub",
		loginTime: op.lastLogin || new Date().toISOString(),
		lastHeartbeat: new Date().toISOString(),
		validityExpiresAt: op.validityExpiresAt || "2026-12-31",
		isOnline: true,
		lastActiveSecondsAgo: 2,
		ipAddress: "127.0.0.1 (Local)"
	}));
}
// Master Admin: Force Disconnect an Operator
export async function forceDisconnectOperator(username, deviceId) {
	try {
		const res = await fetch("/api/live/terminate", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				username,
				deviceId
			})
		});
		return res.ok;
	} catch {
		return false;
	}
}
// Master Admin: Broadcast message to operator
export async function sendOperatorBroadcastMessage(username, message) {
	try {
		const res = await fetch("/api/live/broadcast", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				username,
				message
			})
		});
		return res.ok;
	} catch {
		return false;
	}
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBRUEsTUFBTSxlQUFlO0NBQ25CLFdBQVc7Q0FDWCxhQUFhO0NBQ2IsV0FBVztDQUNYLFlBQVk7QUFDZDs7QUFjQSxPQUFPLFNBQVMsaUJBQTBCO0NBQ3hDLElBQUksT0FBTyxjQUFjLGFBQWEsT0FBTztDQUM3QyxPQUFPLGlFQUFpRSxLQUFLLFVBQVUsU0FBUztBQUNsRzs7QUFHQSxPQUFPLFNBQVMsc0JBQThCO0NBQzVDLElBQUk7RUFDRixJQUFJLFdBQVcsYUFBYSxRQUFRLGFBQWEsU0FBUztFQUMxRCxJQUFJLENBQUMsVUFBVTtHQUNiLE1BQU0sVUFBVSxLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDLFlBQVksSUFBSSxNQUFNLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUMsWUFBWTtHQUN4SSxNQUFNLFNBQVMsZUFBZTtHQUM5QixXQUFXLFdBQVcsU0FBUyxRQUFRLEtBQUssR0FBRztHQUMvQyxhQUFhLFFBQVEsYUFBYSxXQUFXLFFBQVE7RUFDdkQ7RUFDQSxPQUFPO0NBQ1QsUUFBUTtFQUNOLE9BQU87Q0FDVDtBQUNGOztBQUdBLE9BQU8sU0FBUyx3QkFBZ0M7Q0FDOUMsSUFBSTtFQUNGLElBQUksT0FBTyxhQUFhLFFBQVEsYUFBYSxXQUFXO0VBQ3hELElBQUksQ0FBQyxNQUFNO0dBQ1QsTUFBTSxLQUFLLFVBQVU7R0FDckIsSUFBSSxLQUFLO0dBQ1QsSUFBSSxXQUFXLEtBQUssRUFBRSxHQUFHLEtBQUs7UUFDekIsSUFBSSxVQUFVLEtBQUssRUFBRSxHQUFHLEtBQUs7UUFDN0IsSUFBSSxRQUFRLEtBQUssRUFBRSxHQUFHLEtBQUs7UUFDM0IsSUFBSSxPQUFPLEtBQUssRUFBRSxHQUFHLEtBQUs7UUFDMUIsSUFBSSxTQUFTLEtBQUssRUFBRSxHQUFHLEtBQUs7R0FFakMsSUFBSSxVQUFVO0dBQ2QsSUFBSSxXQUFXLEtBQUssRUFBRSxHQUFHLFVBQVU7UUFDOUIsSUFBSSxPQUFPLEtBQUssRUFBRSxHQUFHLFVBQVU7UUFDL0IsSUFBSSxVQUFVLEtBQUssRUFBRSxLQUFLLENBQUMsVUFBVSxLQUFLLEVBQUUsR0FBRyxVQUFVO0dBRTlELE9BQU8sR0FBRyxHQUFHLEtBQUs7R0FDbEIsYUFBYSxRQUFRLGFBQWEsYUFBYSxJQUFJO0VBQ3JEO0VBQ0EsT0FBTztDQUNULFFBQVE7RUFDTixPQUFPLGVBQWUsSUFBSSxzQkFBc0I7Q0FDbEQ7QUFDRjs7QUFHQSxNQUFNLG9CQUF1QztDQUMzQztFQUNFLElBQUk7RUFDSixVQUFVO0VBQ1YsVUFBVTtFQUNWLGFBQWE7RUFDYixNQUFNO0VBQ04sT0FBTztFQUNQLGlCQUFpQjtFQUNqQixtQkFBbUI7RUFDbkIsV0FBVztFQUNYLHFCQUFxQjtFQUNyQix1QkFBdUI7RUFDdkIsZUFBZTtFQUNmLFdBQVc7RUFDWCxVQUFVO0VBQ1YsbUJBQW1CO0VBQ25CLGtCQUFrQjtDQUNwQjtDQUNBO0VBQ0UsSUFBSTtFQUNKLFVBQVU7RUFDVixVQUFVO0VBQ1YsYUFBYTtFQUNiLE1BQU07RUFDTixPQUFPO0VBQ1AsaUJBQWlCO0VBQ2pCLG1CQUFtQjtFQUNuQixXQUFXO0VBQ1gscUJBQXFCO0VBQ3JCLHVCQUF1QjtFQUN2QixlQUFlO0VBQ2YsV0FBVztFQUNYLFVBQVU7Q0FDWjtDQUNBO0VBQ0UsSUFBSTtFQUNKLFVBQVU7RUFDVixVQUFVO0VBQ1YsYUFBYTtFQUNiLE1BQU07RUFDTixPQUFPO0VBQ1AsaUJBQWlCO0VBQ2pCLG1CQUFtQjtFQUNuQixXQUFXO0VBQ1gscUJBQXFCO0VBQ3JCLHVCQUF1QjtFQUN2QixlQUFlO0VBQ2YsV0FBVztFQUNYLFVBQVU7Q0FDWjtBQUNGOztBQUdBLE9BQU8sU0FBUyx5QkFBNEM7Q0FDMUQsSUFBSTtFQUNGLE1BQU0sTUFBTSxhQUFhLFFBQVEsYUFBYSxTQUFTO0VBQ3ZELElBQUksQ0FBQyxLQUFLO0dBQ1IsYUFBYSxRQUFRLGFBQWEsV0FBVyxLQUFLLFVBQVUsaUJBQWlCLENBQUM7R0FDOUUsT0FBTztFQUNUO0VBQ0EsTUFBTSxTQUFTLEtBQUssTUFBTSxHQUFHOztFQUU3QixPQUFPLE9BQU8sS0FBSyxRQUFhO0dBQzlCLEdBQUc7R0FDSCxpQkFBaUIsR0FBRyxvQkFBb0IsR0FBRyxlQUFlLFNBQVMsTUFBTSxJQUFJLEdBQUcsZ0JBQWdCO0dBQ2hHLG1CQUFtQixHQUFHLHNCQUFzQixHQUFHLGVBQWUsU0FBUyxNQUFNLElBQUksR0FBRyxrQkFBa0I7R0FDdEcsV0FBVyxHQUFHLGNBQWMsR0FBRyxlQUFlLFNBQVMsTUFBTSxJQUFJLEdBQUcsVUFBVTtHQUM5RSxxQkFBcUIsR0FBRyx3QkFBd0IsR0FBRyxlQUFlLFNBQVMsT0FBTyxJQUFJLEdBQUcsZ0JBQWdCO0dBQ3pHLHVCQUF1QixHQUFHLDBCQUEwQixHQUFHLGVBQWUsU0FBUyxPQUFPLElBQUksR0FBRyxrQkFBa0I7R0FDL0csZUFBZSxHQUFHLGtCQUFrQixHQUFHLGVBQWUsU0FBUyxPQUFPLElBQUksR0FBRyxVQUFVO0VBQ3pGLEVBQUU7Q0FDSixRQUFRO0VBQ04sT0FBTztDQUNUO0FBQ0Y7O0FBR0EsT0FBTyxTQUFTLHdCQUF3QixXQUFvQztDQUMxRSxJQUFJO0VBQ0YsYUFBYSxRQUFRLGFBQWEsV0FBVyxLQUFLLFVBQVUsU0FBUyxDQUFDO0NBQ3hFLFNBQVMsR0FBRztFQUNWLFFBQVEsTUFBTSw0QkFBNEIsQ0FBQztDQUM3QztBQUNGOztBQUdBLE9BQU8sU0FBUyxvQkFDZCxRQUNBLFVBQ0EsU0FDTTtDQUNOLElBQUk7RUFDRixNQUFNLFdBQVcsb0JBQW9CO0VBQ3JDLE1BQU0sYUFBYSxzQkFBc0I7RUFDekMsTUFBTSxhQUE4QixlQUFlLElBQUksV0FBVztFQUVsRSxNQUFNLE1BQU0sYUFBYSxRQUFRLGFBQWEsVUFBVTtFQUN4RCxNQUFNLE9BQTJCLE1BQU0sS0FBSyxNQUFNLEdBQUcsSUFBSSxDQUFDO0VBRTFELE1BQU0sU0FBMkI7R0FDL0IsSUFBSSxPQUFPLEtBQUssSUFBSSxFQUFFLEdBQUcsS0FBSyxPQUFPLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLE9BQU8sR0FBRyxDQUFDO0dBQy9ELFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxlQUFlLFNBQVM7SUFDNUMsS0FBSztJQUNMLE9BQU87SUFDUCxNQUFNO0lBQ04sTUFBTTtJQUNOLFFBQVE7SUFDUixRQUFRO0dBQ1YsQ0FBQztHQUNEO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtFQUNGO0VBRUEsS0FBSyxRQUFRLE1BQU07RUFDbkIsSUFBSSxLQUFLLFNBQVMsSUFBSSxLQUFLLElBQUk7RUFDL0IsYUFBYSxRQUFRLGFBQWEsWUFBWSxLQUFLLFVBQVUsSUFBSSxDQUFDO0NBQ3BFLFNBQVMsR0FBRztFQUNWLFFBQVEsTUFBTSw4QkFBOEIsQ0FBQztDQUMvQztBQUNGO0FBRUEsT0FBTyxTQUFTLHVCQUEyQztDQUN6RCxJQUFJO0VBQ0YsTUFBTSxNQUFNLGFBQWEsUUFBUSxhQUFhLFVBQVU7RUFDeEQsT0FBTyxNQUFNLEtBQUssTUFBTSxHQUFHLElBQUksQ0FBQztDQUNsQyxRQUFRO0VBQ04sT0FBTyxDQUFDO0NBQ1Y7QUFDRjtBQWNBLE9BQU8sU0FBUyxxQkFBcUIsZUFBdUIsZUFBbUM7Q0FDN0YsTUFBTSxXQUFXLGNBQWMsS0FBSyxDQUFDLENBQUMsWUFBWTtDQUNsRCxNQUFNLFdBQVcsY0FBYyxLQUFLO0NBQ3BDLE1BQU0sa0JBQWtCLG9CQUFvQjtDQUM1QyxNQUFNLG9CQUFvQixzQkFBc0I7Q0FDaEQsTUFBTSxjQUErQixlQUFlLElBQUksV0FBVztDQUVuRSxNQUFNLFlBQVksdUJBQXVCO0NBQ3pDLE1BQU0sV0FBVyxVQUFVLE1BQUssTUFBSyxFQUFFLFNBQVMsWUFBWSxNQUFNLFFBQVE7Q0FFMUUsSUFBSSxDQUFDLFVBQVU7RUFDYixvQkFBb0IsZ0JBQWdCLFVBQVUsMkJBQTJCO0VBQ3pFLE9BQU87R0FDTCxTQUFTO0dBQ1QsT0FBTztFQUNUO0NBQ0Y7O0NBR0EsSUFBSSxTQUFTLFlBQVksU0FBUyxhQUFhLFVBQVU7RUFDdkQsb0JBQW9CLGdCQUFnQixVQUFVLDRCQUE0QjtFQUMxRSxPQUFPO0dBQ0wsU0FBUztHQUNULE9BQU87RUFDVDtDQUNGOztDQUdBLElBQUksU0FBUyxVQUFVO0VBQ3JCLG9CQUFvQixtQkFBbUIsVUFBVSx1Q0FBdUM7RUFDeEYsT0FBTztHQUNMLFNBQVM7R0FDVCxPQUFPO0VBQ1Q7Q0FDRjs7OztDQUtBLE1BQU0sTUFBTSxJQUFJLEtBQUssQ0FBQyxDQUFDLGVBQWUsT0FBTztDQUU3QyxJQUFJLGdCQUFnQixNQUFNOztFQUV4QixJQUFJLENBQUMsU0FBUyxpQkFBaUI7O0dBRTdCLFNBQVMsa0JBQWtCO0dBQzNCLFNBQVMsb0JBQW9CO0dBQzdCLFNBQVMsWUFBWTtHQUNyQixTQUFTLFlBQVk7R0FDckIsd0JBQXdCLFNBQVM7R0FDakMsb0JBQW9CLGdCQUFnQixVQUFVLGFBQWEsa0JBQWtCLElBQUksZ0JBQWdCLEVBQUU7RUFDckcsT0FBTyxJQUFJLFNBQVMsb0JBQW9CLGlCQUFpQjs7R0FFdkQsb0JBQ0Usa0JBQ0EsVUFDQSw2REFBNkQsU0FBUyxrQkFBa0IsS0FBSyxTQUFTLGdCQUFnQixFQUN4SDtHQUVBLE9BQU87SUFDTCxTQUFTO0lBQ1QscUJBQXFCO0lBQ3JCLFlBQVk7SUFDWixpQkFBaUIsU0FBUyxxQkFBcUIsU0FBUztJQUN4RCxPQUFPLGlGQUFpRixTQUFTLHFCQUFxQixTQUFTLGdCQUFnQjtHQUNqSjtFQUNGLE9BQU87O0dBRUwsU0FBUyxZQUFZO0dBQ3JCLHdCQUF3QixTQUFTO0dBQ2pDLG9CQUFvQixpQkFBaUIsVUFBVSxzQ0FBc0MsZ0JBQWdCLEVBQUU7RUFDekc7Q0FDRixPQUFPOztFQUVMLElBQUksQ0FBQyxTQUFTLHFCQUFxQjs7R0FFakMsU0FBUyxzQkFBc0I7R0FDL0IsU0FBUyx3QkFBd0I7R0FDakMsU0FBUyxnQkFBZ0I7R0FDekIsU0FBUyxZQUFZO0dBQ3JCLHdCQUF3QixTQUFTO0dBQ2pDLG9CQUFvQixnQkFBZ0IsVUFBVSxpQkFBaUIsa0JBQWtCLElBQUksZ0JBQWdCLEVBQUU7RUFDekcsT0FBTyxJQUFJLFNBQVMsd0JBQXdCLGlCQUFpQjs7R0FFM0Qsb0JBQ0Usa0JBQ0EsVUFDQSxxRUFBcUUsU0FBUyxzQkFBc0IsS0FBSyxTQUFTLG9CQUFvQixFQUN4STtHQUVBLE9BQU87SUFDTCxTQUFTO0lBQ1QscUJBQXFCO0lBQ3JCLFlBQVk7SUFDWixpQkFBaUIsU0FBUyx5QkFBeUIsU0FBUztJQUM1RCxPQUFPLCtGQUErRixTQUFTLHlCQUF5QixTQUFTLG9CQUFvQjtHQUN2SztFQUNGLE9BQU87O0dBRUwsU0FBUyxZQUFZO0dBQ3JCLHdCQUF3QixTQUFTO0dBQ2pDLG9CQUFvQixpQkFBaUIsVUFBVSwwQ0FBMEMsZ0JBQWdCLEVBQUU7RUFDN0c7Q0FDRjtDQUVBLE1BQU0sYUFBMEI7RUFDOUIsVUFBVSxTQUFTO0VBQ25CLGFBQWEsU0FBUztFQUN0QixNQUFNLFNBQVM7RUFDZixPQUFPLFNBQVM7RUFDaEIsVUFBVTtFQUNWLFlBQVk7RUFDWixtQkFBbUI7RUFDbkI7RUFDQTtFQUNBLGlCQUFpQixTQUFTLG1CQUFtQjtFQUM3QyxxQkFBcUIsU0FBUyx1QkFBdUI7Q0FDdkQ7Q0FFQSxPQUFPO0VBQ0wsU0FBUztFQUNULE1BQU07Q0FDUjtBQUNGOztBQUdBLE9BQU8sU0FBUyx1QkFBdUIsWUFBNkI7Q0FDbEUsTUFBTSxZQUFZLHVCQUF1QjtDQUN6QyxNQUFNLEtBQUssVUFBVSxNQUFLLE1BQUssRUFBRSxPQUFPLGNBQWMsRUFBRSxhQUFhLFVBQVU7Q0FDL0UsSUFBSSxDQUFDLElBQUksT0FBTztDQUVoQixNQUFNLE9BQU8sR0FBRyxxQkFBcUIsR0FBRyxtQkFBbUI7Q0FDM0QsR0FBRyxrQkFBa0I7Q0FDckIsR0FBRyxvQkFBb0I7Q0FDdkIsR0FBRyxZQUFZO0NBRWYsd0JBQXdCLFNBQVM7Q0FDakMsb0JBQW9CLGdCQUFnQixHQUFHLFVBQVUsZ0RBQWdELEtBQUssRUFBRTtDQUN4RyxPQUFPO0FBQ1Q7O0FBR0EsT0FBTyxTQUFTLDJCQUEyQixZQUE2QjtDQUN0RSxNQUFNLFlBQVksdUJBQXVCO0NBQ3pDLE1BQU0sS0FBSyxVQUFVLE1BQUssTUFBSyxFQUFFLE9BQU8sY0FBYyxFQUFFLGFBQWEsVUFBVTtDQUMvRSxJQUFJLENBQUMsSUFBSSxPQUFPO0NBRWhCLE1BQU0sT0FBTyxHQUFHLHlCQUF5QixHQUFHLHVCQUF1QjtDQUNuRSxHQUFHLHNCQUFzQjtDQUN6QixHQUFHLHdCQUF3QjtDQUMzQixHQUFHLGdCQUFnQjtDQUVuQix3QkFBd0IsU0FBUztDQUNqQyxvQkFBb0IsZ0JBQWdCLEdBQUcsVUFBVSxvREFBb0QsS0FBSyxFQUFFO0NBQzVHLE9BQU87QUFDVDs7QUFHQSxPQUFPLFNBQVMseUJBQXlCLFlBQTZCO0NBQ3BFLE1BQU0sWUFBWSx1QkFBdUI7Q0FDekMsTUFBTSxLQUFLLFVBQVUsTUFBSyxNQUFLLEVBQUUsT0FBTyxjQUFjLEVBQUUsYUFBYSxVQUFVO0NBQy9FLElBQUksQ0FBQyxJQUFJLE9BQU87Q0FFaEIsR0FBRyxrQkFBa0I7Q0FDckIsR0FBRyxvQkFBb0I7Q0FDdkIsR0FBRyxZQUFZO0NBQ2YsR0FBRyxzQkFBc0I7Q0FDekIsR0FBRyx3QkFBd0I7Q0FDM0IsR0FBRyxnQkFBZ0I7Q0FFbkIsd0JBQXdCLFNBQVM7Q0FDakMsb0JBQW9CLGdCQUFnQixHQUFHLFVBQVUsd0RBQXdEO0NBQ3pHLE9BQU87QUFDVDs7QUFHQSxPQUFPLFNBQVMsbUJBQW1CLFlBQTZCO0NBQzlELE1BQU0sWUFBWSx1QkFBdUI7Q0FDekMsTUFBTSxLQUFLLFVBQVUsTUFBSyxNQUFLLEVBQUUsT0FBTyxjQUFjLEVBQUUsYUFBYSxVQUFVO0NBQy9FLElBQUksQ0FBQyxJQUFJLE9BQU87Q0FFaEIsR0FBRyxXQUFXLENBQUMsR0FBRztDQUNsQix3QkFBd0IsU0FBUztDQUNqQyxvQkFBb0IsbUJBQW1CLEdBQUcsVUFBVSxvQ0FBb0MsR0FBRyxXQUFXLFdBQVcsVUFBVTtDQUMzSCxPQUFPO0FBQ1Q7O0FBR0EsT0FBTyxTQUFTLGVBQWUsSUFBaU07Q0FDOU4sTUFBTSxZQUFZLHVCQUF1QjtDQUN6QyxJQUFJLFVBQVUsTUFBSyxNQUFLLEVBQUUsU0FBUyxZQUFZLE1BQU0sR0FBRyxTQUFTLFlBQVksQ0FBQyxHQUFHO0VBQy9FLE9BQU87Q0FDVDtDQUVBLE1BQU0sUUFBeUI7RUFDN0IsR0FBRztFQUNILElBQUksTUFBTSxLQUFLLElBQUk7RUFDbkIsaUJBQWlCO0VBQ2pCLG1CQUFtQjtFQUNuQixXQUFXO0VBQ1gscUJBQXFCO0VBQ3JCLHVCQUF1QjtFQUN2QixlQUFlO0VBQ2YsV0FBVztFQUNYLFVBQVU7Q0FDWjtDQUVBLFVBQVUsS0FBSyxLQUFLO0NBQ3BCLHdCQUF3QixTQUFTO0NBQ2pDLG9CQUFvQixpQkFBaUIsU0FBUyx5Q0FBeUMsR0FBRyxVQUFVO0NBQ3BHLE9BQU87QUFDVDs7QUFHQSxPQUFPLFNBQVMsZUFBZSxZQUE2QjtDQUMxRCxJQUFJLFlBQVksdUJBQXVCO0NBQ3ZDLE1BQU0sS0FBSyxVQUFVLE1BQUssTUFBSyxFQUFFLE9BQU8sVUFBVTtDQUNsRCxJQUFJLENBQUMsTUFBTSxHQUFHLFNBQVMsU0FBUyxPQUFPO0NBRXZDLFlBQVksVUFBVSxRQUFPLE1BQUssRUFBRSxPQUFPLFVBQVU7Q0FDckQsd0JBQXdCLFNBQVM7Q0FDakMsb0JBQW9CLGlCQUFpQixTQUFTLGtDQUFrQyxHQUFHLFVBQVU7Q0FDN0YsT0FBTztBQUNUOztBQUdBLE9BQU8sU0FBUyx1QkFBdUIsU0FBaUM7Q0FDdEUsSUFBSSxDQUFDLFdBQVcsUUFBUSxZQUFZLENBQUMsQ0FBQyxTQUFTLFVBQVUsS0FBSyxRQUFRLFlBQVksQ0FBQyxDQUFDLFNBQVMsT0FBTyxHQUFHO0VBQ3JHLE9BQU87Q0FDVDtDQUNBLE1BQU0sU0FBUyxJQUFJLEtBQUssT0FBTyxDQUFDLENBQUMsUUFBUTtDQUN6QyxJQUFJLE1BQU0sTUFBTSxHQUFHLE9BQU87Q0FDMUIsTUFBTSxNQUFNLEtBQUssSUFBSTtDQUNyQixNQUFNLE9BQU8sU0FBUztDQUN0QixPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssS0FBSyxRQUFRLE1BQU8sS0FBSyxLQUFLLEdBQUcsQ0FBQztBQUM1RDs7QUFHQSxPQUFPLFNBQVMscUJBQXFCLFlBQW9CLFdBQThFO0NBQ3JJLE1BQU0sWUFBWSx1QkFBdUI7Q0FDekMsTUFBTSxLQUFLLFVBQVUsTUFBSyxNQUFLLEVBQUUsT0FBTyxjQUFjLEVBQUUsYUFBYSxVQUFVO0NBQy9FLElBQUksQ0FBQyxJQUFJLE9BQU87RUFBRSxTQUFTO0VBQU8sV0FBVztFQUFJLFVBQVU7Q0FBRTtDQUU3RCxJQUFJLEdBQUcsU0FBUyxXQUFXLEdBQUcsYUFBYSxTQUFTO0VBQ2xELEdBQUcsb0JBQW9CO0VBQ3ZCLEdBQUcsbUJBQW1CO0VBQ3RCLEdBQUcsV0FBVztFQUNkLHdCQUF3QixTQUFTO0VBQ2pDLE9BQU87R0FDTCxTQUFTO0dBQ1QsV0FBVztHQUNYLFVBQVU7RUFDWjtDQUNGO0NBRUEsSUFBSSxnQkFBZ0IsR0FBRyxvQkFBb0IsSUFBSSxLQUFLLEdBQUcsaUJBQWlCLENBQUMsQ0FBQyxRQUFRLElBQUksS0FBSyxJQUFJO0NBQy9GLElBQUksTUFBTSxhQUFhLEtBQUssZ0JBQWdCLEtBQUssSUFBSSxHQUFHO0VBQ3RELGdCQUFnQixLQUFLLElBQUk7Q0FDM0I7Q0FFQSxNQUFNLGdCQUFnQixnQkFBaUIsWUFBWSxLQUFLLEtBQUssS0FBSztDQUNsRSxNQUFNLGVBQWUsSUFBSSxLQUFLLGFBQWEsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7Q0FDdEUsTUFBTSxXQUFXLEtBQUssTUFBTSxnQkFBZ0IsS0FBSyxJQUFJLE1BQU0sTUFBTyxLQUFLLEtBQUssR0FBRztDQUUvRSxHQUFHLG9CQUFvQjtDQUN2QixHQUFHLG1CQUFtQjtDQUV0Qix3QkFBd0IsU0FBUztDQUNqQyxvQkFBb0IsaUJBQWlCLEdBQUcsVUFBVSx3QkFBd0IsVUFBVSxxQkFBcUIsYUFBYSxJQUFJLFNBQVMsWUFBWTtDQUUvSSxPQUFPO0VBQ0wsU0FBUztFQUNULFdBQVc7RUFDWDtDQUNGO0FBQ0Y7O0FBR0EsT0FBTyxlQUFlLHNCQUFzQixNQU82QztDQUN2RixNQUFNLFdBQVcsb0JBQW9CO0NBQ3JDLE1BQU0sYUFBYSxzQkFBc0I7Q0FDekMsTUFBTSxhQUFhLGVBQWUsSUFBSSxXQUFXO0NBRWpELElBQUk7RUFDRixNQUFNLE1BQU0sTUFBTSxNQUFNLHVCQUF1QjtHQUM3QyxRQUFRO0dBQ1IsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7R0FDOUMsTUFBTSxLQUFLLFVBQVU7SUFDbkIsR0FBRztJQUNIO0lBQ0E7SUFDQTtHQUNGLENBQUM7RUFDSCxDQUFDO0VBQ0QsSUFBSSxJQUFJLElBQUk7R0FDVixPQUFPLE1BQU0sSUFBSSxLQUFLO0VBQ3hCO0NBQ0YsUUFBUTs7RUFFTixJQUFJO0dBQ0YsTUFBTSxXQUFXO0dBQ2pCLE1BQU0sV0FBVyxLQUFLLE1BQU0sYUFBYSxRQUFRLFFBQVEsS0FBSyxJQUFJO0dBQ2xFLFNBQVMsS0FBSyxZQUFZO0lBQ3hCLEdBQUc7SUFDSDtJQUNBO0lBQ0E7SUFDQSxlQUFlLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtHQUN4QztHQUNBLGFBQWEsUUFBUSxVQUFVLEtBQUssVUFBVSxRQUFRLENBQUM7RUFDekQsUUFBUSxDQUFDO0NBQ1g7Q0FDQSxPQUFPO0VBQUUsU0FBUztFQUFNLGFBQWE7RUFBRyxrQkFBa0I7Q0FBSztBQUNqRTs7QUFHQSxPQUFPLGVBQWUsMEJBQTBDO0NBQzlELElBQUk7RUFDRixNQUFNLE1BQU0sTUFBTSxNQUFNLG9CQUFvQjtFQUM1QyxJQUFJLElBQUksSUFBSTtHQUNWLE1BQU0sT0FBTyxNQUFNLElBQUksS0FBSztHQUM1QixPQUFPLEtBQUssWUFBWSxDQUFDO0VBQzNCO0NBQ0YsUUFBUSxDQUFDOztDQUdULE1BQU0sWUFBWSx1QkFBdUI7Q0FDekMsTUFBTSxlQUFlLG9CQUFvQjtDQUN6QyxNQUFNLGlCQUFpQixzQkFBc0I7Q0FFN0MsT0FBTyxVQUFVLEtBQUksUUFBTztFQUMxQixXQUFXLFNBQVMsR0FBRztFQUN2QixVQUFVLEdBQUc7RUFDYixhQUFhLEdBQUc7RUFDaEIsTUFBTSxHQUFHO0VBQ1QsT0FBTyxHQUFHO0VBQ1YsWUFBWSxlQUFlLElBQUksV0FBVztFQUMxQyxVQUFVO0VBQ1YsWUFBWTtFQUNaLFlBQVk7RUFDWixhQUFhO0VBQ2IsV0FBVyxHQUFHLGFBQWEsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0VBQ2xELGVBQWUsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0VBQ3RDLG1CQUFtQixHQUFHLHFCQUFxQjtFQUMzQyxVQUFVO0VBQ1Ysc0JBQXNCO0VBQ3RCLFdBQVc7Q0FDYixFQUFFO0FBQ0o7O0FBR0EsT0FBTyxlQUFlLHdCQUF3QixVQUFrQixVQUFxQztDQUNuRyxJQUFJO0VBQ0YsTUFBTSxNQUFNLE1BQU0sTUFBTSx1QkFBdUI7R0FDN0MsUUFBUTtHQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0dBQzlDLE1BQU0sS0FBSyxVQUFVO0lBQUU7SUFBVTtHQUFTLENBQUM7RUFDN0MsQ0FBQztFQUNELE9BQU8sSUFBSTtDQUNiLFFBQVE7RUFDTixPQUFPO0NBQ1Q7QUFDRjs7QUFHQSxPQUFPLGVBQWUsNkJBQTZCLFVBQWtCLFNBQW1DO0NBQ3RHLElBQUk7RUFDRixNQUFNLE1BQU0sTUFBTSxNQUFNLHVCQUF1QjtHQUM3QyxRQUFRO0dBQ1IsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7R0FDOUMsTUFBTSxLQUFLLFVBQVU7SUFBRTtJQUFVO0dBQVEsQ0FBQztFQUM1QyxDQUFDO0VBQ0QsT0FBTyxJQUFJO0NBQ2IsUUFBUTtFQUNOLE9BQU87Q0FDVDtBQUNGIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImRldmljZVNlY3VyaXR5LnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE9wZXJhdG9yQWNjb3VudCwgVXNlckFjY291bnQgfSBmcm9tICcuLi90eXBlcyc7XG5cbmNvbnN0IFNUT1JBR0VfS0VZUyA9IHtcbiAgREVWSUNFX0lEOiAnbW9zX2hhcmR3YXJlX2RldmljZV9pZCcsXG4gIERFVklDRV9OQU1FOiAnbW9zX2hhcmR3YXJlX2RldmljZV9uYW1lJyxcbiAgT1BFUkFUT1JTOiAnbW9zX3JlZ2lzdGVyZWRfb3BlcmF0b3JzJyxcbiAgQVVESVRfTE9HUzogJ21vc19zZWN1cml0eV9hdWRpdF9sb2dzJ1xufTtcblxuZXhwb3J0IGludGVyZmFjZSBTZWN1cml0eUF1ZGl0TG9nIHtcbiAgaWQ6IHN0cmluZztcbiAgdGltZXN0YW1wOiBzdHJpbmc7XG4gIHVzZXJuYW1lOiBzdHJpbmc7XG4gIGFjdGlvbjogJ0xPR0lOX1NVQ0NFU1MnIHwgJ0xPR0lOX0ZBSUxFRCcgfCAnREVWSUNFX0JMT0NLRUQnIHwgJ0RFVklDRV9CT1VORCcgfCAnREVWSUNFX1JFU0VUJyB8ICdPUEVSQVRPUl9MT0NLRUQnO1xuICBkZXZpY2VJZDogc3RyaW5nO1xuICBkZXZpY2VOYW1lOiBzdHJpbmc7XG4gIGRldmljZVR5cGU6ICdwYycgfCAnbW9iaWxlJztcbiAgZGV0YWlsczogc3RyaW5nO1xufVxuXG4vLyBEZXRlY3QgaWYgY3VycmVudCBydW50aW1lIGlzIGEgbW9iaWxlIHBob25lIC8gdGFibGV0XG5leHBvcnQgZnVuY3Rpb24gaXNNb2JpbGVEZXZpY2UoKTogYm9vbGVhbiB7XG4gIGlmICh0eXBlb2YgbmF2aWdhdG9yID09PSAndW5kZWZpbmVkJykgcmV0dXJuIGZhbHNlO1xuICByZXR1cm4gL0FuZHJvaWR8d2ViT1N8aVBob25lfGlQYWR8aVBvZHxCbGFja0JlcnJ5fElFTW9iaWxlfE9wZXJhIE1pbmkvaS50ZXN0KG5hdmlnYXRvci51c2VyQWdlbnQpO1xufVxuXG4vLyBQZXJzaXN0ZW50IGhhcmR3YXJlIGRldmljZSBJRCAoR2VuZXJhdGVkIG9uY2UgcGVyIG1hY2hpbmUvYnJvd3NlcilcbmV4cG9ydCBmdW5jdGlvbiBnZXRIYXJkd2FyZURldmljZUlkKCk6IHN0cmluZyB7XG4gIHRyeSB7XG4gICAgbGV0IGRldmljZUlkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oU1RPUkFHRV9LRVlTLkRFVklDRV9JRCk7XG4gICAgaWYgKCFkZXZpY2VJZCkge1xuICAgICAgY29uc3QgcmFuZFN0ciA9IE1hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnN1YnN0cmluZygyLCA2KS50b1VwcGVyQ2FzZSgpICsgJy0nICsgTWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc3Vic3RyaW5nKDIsIDYpLnRvVXBwZXJDYXNlKCk7XG4gICAgICBjb25zdCBtb2JpbGUgPSBpc01vYmlsZURldmljZSgpO1xuICAgICAgZGV2aWNlSWQgPSBgREVWLU1PUy0ke21vYmlsZSA/ICdNT0InIDogJ1BDJ30tJHtyYW5kU3RyfWA7XG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShTVE9SQUdFX0tFWVMuREVWSUNFX0lELCBkZXZpY2VJZCk7XG4gICAgfVxuICAgIHJldHVybiBkZXZpY2VJZDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuICdERVYtTU9TLURFRkFVTFQtMDAxJztcbiAgfVxufVxuXG4vLyBGcmllbmRseSBkZXZpY2UgbmFtZSBiYXNlZCBvbiBwbGF0Zm9ybS9icm93c2VyXG5leHBvcnQgZnVuY3Rpb24gZ2V0SGFyZHdhcmVEZXZpY2VOYW1lKCk6IHN0cmluZyB7XG4gIHRyeSB7XG4gICAgbGV0IG5hbWUgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShTVE9SQUdFX0tFWVMuREVWSUNFX05BTUUpO1xuICAgIGlmICghbmFtZSkge1xuICAgICAgY29uc3QgdWEgPSBuYXZpZ2F0b3IudXNlckFnZW50O1xuICAgICAgbGV0IG9zID0gJ1dpbmRvd3MgUEMnO1xuICAgICAgaWYgKC9BbmRyb2lkL2kudGVzdCh1YSkpIG9zID0gJ0FuZHJvaWQgTW9iaWxlJztcbiAgICAgIGVsc2UgaWYgKC9pUGhvbmUvaS50ZXN0KHVhKSkgb3MgPSAnaVBob25lJztcbiAgICAgIGVsc2UgaWYgKC9pUGFkL2kudGVzdCh1YSkpIG9zID0gJ2lQYWQnO1xuICAgICAgZWxzZSBpZiAoL01hYy9pLnRlc3QodWEpKSBvcyA9ICdNYWMgV29ya3N0YXRpb24nO1xuICAgICAgZWxzZSBpZiAoL0xpbnV4L2kudGVzdCh1YSkpIG9zID0gJ0xpbnV4IFdvcmtzdGF0aW9uJztcblxuICAgICAgbGV0IGJyb3dzZXIgPSAnQ2hyb21lJztcbiAgICAgIGlmICgvRmlyZWZveC9pLnRlc3QodWEpKSBicm93c2VyID0gJ0ZpcmVmb3gnO1xuICAgICAgZWxzZSBpZiAoL0VkZy9pLnRlc3QodWEpKSBicm93c2VyID0gJ0VkZ2UnO1xuICAgICAgZWxzZSBpZiAoL1NhZmFyaS9pLnRlc3QodWEpICYmICEvQ2hyb21lL2kudGVzdCh1YSkpIGJyb3dzZXIgPSAnU2FmYXJpJztcblxuICAgICAgbmFtZSA9IGAke29zfSDigKIgJHticm93c2VyfWA7XG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShTVE9SQUdFX0tFWVMuREVWSUNFX05BTUUsIG5hbWUpO1xuICAgIH1cbiAgICByZXR1cm4gbmFtZTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIGlzTW9iaWxlRGV2aWNlKCkgPyAnQXV0aG9yaXplZCBNb2JpbGUnIDogJ0F1dGhvcml6ZWQgV29ya3N0YXRpb24nO1xuICB9XG59XG5cbi8vIERlZmF1bHQgcHJlLWNvbmZpZ3VyZWQgb3BlcmF0b3JzIChEdWFsIERldmljZTogMSBQQyArIDEgTW9iaWxlKVxuY29uc3QgREVGQVVMVF9PUEVSQVRPUlM6IE9wZXJhdG9yQWNjb3VudFtdID0gW1xuICB7XG4gICAgaWQ6ICdvcC1hZG1pbicsXG4gICAgdXNlcm5hbWU6ICdhZG1pbicsXG4gICAgcGFzc3dvcmQ6ICdtdXphbW1pbDc4NicsXG4gICAgZGlzcGxheU5hbWU6ICdJbXJhbiBLaGFuIChNYXN0ZXIgQWRtaW4pJyxcbiAgICByb2xlOiAnYWRtaW4nLFxuICAgIHBob25lOiAnOTU2MTQ2MDMxMycsXG4gICAgYm91bmRQY0RldmljZUlkOiBudWxsLFxuICAgIGJvdW5kUGNEZXZpY2VOYW1lOiBudWxsLFxuICAgIGJvdW5kUGNBdDogbnVsbCxcbiAgICBib3VuZE1vYmlsZURldmljZUlkOiBudWxsLFxuICAgIGJvdW5kTW9iaWxlRGV2aWNlTmFtZTogbnVsbCxcbiAgICBib3VuZE1vYmlsZUF0OiBudWxsLFxuICAgIGxhc3RMb2dpbjogbnVsbCxcbiAgICBpc0xvY2tlZDogZmFsc2UsXG4gICAgdmFsaWRpdHlFeHBpcmVzQXQ6ICdMaWZldGltZSAoTmV2ZXIgRXhwaXJlcyknLFxuICAgIHZhbGlkaXR5RGF5c0xlZnQ6IDk5OTk5OVxuICB9LFxuICB7XG4gICAgaWQ6ICdvcC0xJyxcbiAgICB1c2VybmFtZTogJ29wZXJhdG9yMScsXG4gICAgcGFzc3dvcmQ6ICdzYW1lZXIxMjMnLFxuICAgIGRpc3BsYXlOYW1lOiAnU2hhaWtoIFNhbWVlcicsXG4gICAgcm9sZTogJ29wZXJhdG9yJyxcbiAgICBwaG9uZTogJzk4NzY1NDMyMTAnLFxuICAgIGJvdW5kUGNEZXZpY2VJZDogbnVsbCxcbiAgICBib3VuZFBjRGV2aWNlTmFtZTogbnVsbCxcbiAgICBib3VuZFBjQXQ6IG51bGwsXG4gICAgYm91bmRNb2JpbGVEZXZpY2VJZDogbnVsbCxcbiAgICBib3VuZE1vYmlsZURldmljZU5hbWU6IG51bGwsXG4gICAgYm91bmRNb2JpbGVBdDogbnVsbCxcbiAgICBsYXN0TG9naW46IG51bGwsXG4gICAgaXNMb2NrZWQ6IGZhbHNlXG4gIH0sXG4gIHtcbiAgICBpZDogJ29wLTInLFxuICAgIHVzZXJuYW1lOiAnb3BlcmF0b3IyJyxcbiAgICBwYXNzd29yZDogJ2FkaWwxMjMnLFxuICAgIGRpc3BsYXlOYW1lOiAnQWRpbCBLaGFuJyxcbiAgICByb2xlOiAnb3BlcmF0b3InLFxuICAgIHBob25lOiAnOTEyMzQ1Njc4MCcsXG4gICAgYm91bmRQY0RldmljZUlkOiBudWxsLFxuICAgIGJvdW5kUGNEZXZpY2VOYW1lOiBudWxsLFxuICAgIGJvdW5kUGNBdDogbnVsbCxcbiAgICBib3VuZE1vYmlsZURldmljZUlkOiBudWxsLFxuICAgIGJvdW5kTW9iaWxlRGV2aWNlTmFtZTogbnVsbCxcbiAgICBib3VuZE1vYmlsZUF0OiBudWxsLFxuICAgIGxhc3RMb2dpbjogbnVsbCxcbiAgICBpc0xvY2tlZDogZmFsc2VcbiAgfVxuXTtcblxuLy8gTG9hZCByZWdpc3RlcmVkIG9wZXJhdG9yc1xuZXhwb3J0IGZ1bmN0aW9uIGdldFJlZ2lzdGVyZWRPcGVyYXRvcnMoKTogT3BlcmF0b3JBY2NvdW50W10ge1xuICB0cnkge1xuICAgIGNvbnN0IHJhdyA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFNUT1JBR0VfS0VZUy5PUEVSQVRPUlMpO1xuICAgIGlmICghcmF3KSB7XG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShTVE9SQUdFX0tFWVMuT1BFUkFUT1JTLCBKU09OLnN0cmluZ2lmeShERUZBVUxUX09QRVJBVE9SUykpO1xuICAgICAgcmV0dXJuIERFRkFVTFRfT1BFUkFUT1JTO1xuICAgIH1cbiAgICBjb25zdCBwYXJzZWQgPSBKU09OLnBhcnNlKHJhdyk7XG4gICAgLy8gRW5zdXJlIGR1YWwgZGV2aWNlIGZpZWxkcyBhcmUgcHJlc2VudCBpZiBsb2FkZWQgZnJvbSBsZWdhY3kgZm9ybWF0XG4gICAgcmV0dXJuIHBhcnNlZC5tYXAoKG9wOiBhbnkpID0+ICh7XG4gICAgICAuLi5vcCxcbiAgICAgIGJvdW5kUGNEZXZpY2VJZDogb3AuYm91bmRQY0RldmljZUlkID8/IChvcC5ib3VuZERldmljZUlkPy5pbmNsdWRlcygnLVBDLScpID8gb3AuYm91bmREZXZpY2VJZCA6IG51bGwpLFxuICAgICAgYm91bmRQY0RldmljZU5hbWU6IG9wLmJvdW5kUGNEZXZpY2VOYW1lID8/IChvcC5ib3VuZERldmljZUlkPy5pbmNsdWRlcygnLVBDLScpID8gb3AuYm91bmREZXZpY2VOYW1lIDogbnVsbCksXG4gICAgICBib3VuZFBjQXQ6IG9wLmJvdW5kUGNBdCA/PyAob3AuYm91bmREZXZpY2VJZD8uaW5jbHVkZXMoJy1QQy0nKSA/IG9wLmJvdW5kQXQgOiBudWxsKSxcbiAgICAgIGJvdW5kTW9iaWxlRGV2aWNlSWQ6IG9wLmJvdW5kTW9iaWxlRGV2aWNlSWQgPz8gKG9wLmJvdW5kRGV2aWNlSWQ/LmluY2x1ZGVzKCctTU9CLScpID8gb3AuYm91bmREZXZpY2VJZCA6IG51bGwpLFxuICAgICAgYm91bmRNb2JpbGVEZXZpY2VOYW1lOiBvcC5ib3VuZE1vYmlsZURldmljZU5hbWUgPz8gKG9wLmJvdW5kRGV2aWNlSWQ/LmluY2x1ZGVzKCctTU9CLScpID8gb3AuYm91bmREZXZpY2VOYW1lIDogbnVsbCksXG4gICAgICBib3VuZE1vYmlsZUF0OiBvcC5ib3VuZE1vYmlsZUF0ID8/IChvcC5ib3VuZERldmljZUlkPy5pbmNsdWRlcygnLU1PQi0nKSA/IG9wLmJvdW5kQXQgOiBudWxsKSxcbiAgICB9KSk7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBERUZBVUxUX09QRVJBVE9SUztcbiAgfVxufVxuXG4vLyBTYXZlIG9wZXJhdG9yc1xuZXhwb3J0IGZ1bmN0aW9uIHNhdmVSZWdpc3RlcmVkT3BlcmF0b3JzKG9wZXJhdG9yczogT3BlcmF0b3JBY2NvdW50W10pOiB2b2lkIHtcbiAgdHJ5IHtcbiAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShTVE9SQUdFX0tFWVMuT1BFUkFUT1JTLCBKU09OLnN0cmluZ2lmeShvcGVyYXRvcnMpKTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byBzYXZlIG9wZXJhdG9ycycsIGUpO1xuICB9XG59XG5cbi8vIEFkZCBzZWN1cml0eSBhdWRpdCBsb2dcbmV4cG9ydCBmdW5jdGlvbiBhZGRTZWN1cml0eUF1ZGl0TG9nKFxuICBhY3Rpb246IFNlY3VyaXR5QXVkaXRMb2dbJ2FjdGlvbiddLFxuICB1c2VybmFtZTogc3RyaW5nLFxuICBkZXRhaWxzOiBzdHJpbmdcbik6IHZvaWQge1xuICB0cnkge1xuICAgIGNvbnN0IGRldmljZUlkID0gZ2V0SGFyZHdhcmVEZXZpY2VJZCgpO1xuICAgIGNvbnN0IGRldmljZU5hbWUgPSBnZXRIYXJkd2FyZURldmljZU5hbWUoKTtcbiAgICBjb25zdCBkZXZpY2VUeXBlOiAncGMnIHwgJ21vYmlsZScgPSBpc01vYmlsZURldmljZSgpID8gJ21vYmlsZScgOiAncGMnO1xuXG4gICAgY29uc3QgcmF3ID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oU1RPUkFHRV9LRVlTLkFVRElUX0xPR1MpO1xuICAgIGNvbnN0IGxvZ3M6IFNlY3VyaXR5QXVkaXRMb2dbXSA9IHJhdyA/IEpTT04ucGFyc2UocmF3KSA6IFtdO1xuXG4gICAgY29uc3QgbmV3TG9nOiBTZWN1cml0eUF1ZGl0TG9nID0ge1xuICAgICAgaWQ6IGBsb2ctJHtEYXRlLm5vdygpfS0ke01hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnN1YnN0cigyLCA0KX1gLFxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvTG9jYWxlU3RyaW5nKCdlbi1JTicsIHtcbiAgICAgICAgZGF5OiAnMi1kaWdpdCcsXG4gICAgICAgIG1vbnRoOiAnc2hvcnQnLFxuICAgICAgICB5ZWFyOiAnbnVtZXJpYycsXG4gICAgICAgIGhvdXI6ICcyLWRpZ2l0JyxcbiAgICAgICAgbWludXRlOiAnMi1kaWdpdCcsXG4gICAgICAgIHNlY29uZDogJzItZGlnaXQnXG4gICAgICB9KSxcbiAgICAgIHVzZXJuYW1lLFxuICAgICAgYWN0aW9uLFxuICAgICAgZGV2aWNlSWQsXG4gICAgICBkZXZpY2VOYW1lLFxuICAgICAgZGV2aWNlVHlwZSxcbiAgICAgIGRldGFpbHNcbiAgICB9O1xuXG4gICAgbG9ncy51bnNoaWZ0KG5ld0xvZyk7XG4gICAgaWYgKGxvZ3MubGVuZ3RoID4gNjApIGxvZ3MucG9wKCk7XG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oU1RPUkFHRV9LRVlTLkFVRElUX0xPR1MsIEpTT04uc3RyaW5naWZ5KGxvZ3MpKTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIGNvbnNvbGUuZXJyb3IoJ0ZhaWxlZCB0byByZWNvcmQgYXVkaXQgbG9nJywgZSk7XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldFNlY3VyaXR5QXVkaXRMb2dzKCk6IFNlY3VyaXR5QXVkaXRMb2dbXSB7XG4gIHRyeSB7XG4gICAgY29uc3QgcmF3ID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oU1RPUkFHRV9LRVlTLkFVRElUX0xPR1MpO1xuICAgIHJldHVybiByYXcgPyBKU09OLnBhcnNlKHJhdykgOiBbXTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIFtdO1xuICB9XG59XG5cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIERVQUwtREVWSUNFIEFVVEhFTlRJQ0FUSU9OICgxIElEID0gMSBBdXRob3JpemVkIFBDICsgMSBBdXRob3JpemVkIE1vYmlsZSlcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbmV4cG9ydCBpbnRlcmZhY2UgQXV0aFJlc3VsdCB7XG4gIHN1Y2Nlc3M6IGJvb2xlYW47XG4gIHVzZXI/OiBVc2VyQWNjb3VudDtcbiAgZXJyb3I/OiBzdHJpbmc7XG4gIGRldmljZUxvY2tlZFRvT3RoZXI/OiBib29sZWFuO1xuICBkZXZpY2VUeXBlPzogJ3BjJyB8ICdtb2JpbGUnO1xuICBib3VuZERldmljZU5hbWU/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBhdXRoZW50aWNhdGVPcGVyYXRvcih1c2VybmFtZUlucHV0OiBzdHJpbmcsIHBhc3N3b3JkSW5wdXQ6IHN0cmluZyk6IEF1dGhSZXN1bHQge1xuICBjb25zdCB1c2VybmFtZSA9IHVzZXJuYW1lSW5wdXQudHJpbSgpLnRvTG93ZXJDYXNlKCk7XG4gIGNvbnN0IHBhc3N3b3JkID0gcGFzc3dvcmRJbnB1dC50cmltKCk7XG4gIGNvbnN0IGN1cnJlbnREZXZpY2VJZCA9IGdldEhhcmR3YXJlRGV2aWNlSWQoKTtcbiAgY29uc3QgY3VycmVudERldmljZU5hbWUgPSBnZXRIYXJkd2FyZURldmljZU5hbWUoKTtcbiAgY29uc3QgY3VycmVudFR5cGU6ICdwYycgfCAnbW9iaWxlJyA9IGlzTW9iaWxlRGV2aWNlKCkgPyAnbW9iaWxlJyA6ICdwYyc7XG5cbiAgY29uc3Qgb3BlcmF0b3JzID0gZ2V0UmVnaXN0ZXJlZE9wZXJhdG9ycygpO1xuICBjb25zdCBvcGVyYXRvciA9IG9wZXJhdG9ycy5maW5kKG8gPT4gby51c2VybmFtZS50b0xvd2VyQ2FzZSgpID09PSB1c2VybmFtZSk7XG5cbiAgaWYgKCFvcGVyYXRvcikge1xuICAgIGFkZFNlY3VyaXR5QXVkaXRMb2coJ0xPR0lOX0ZBSUxFRCcsIHVzZXJuYW1lLCAnSW52YWxpZCBvcGVyYXRvciB1c2VybmFtZScpO1xuICAgIHJldHVybiB7XG4gICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgIGVycm9yOiAnSW52YWxpZCBPcGVyYXRvciBJRC4gUGxlYXNlIHZlcmlmeSB5b3VyIHVzZXJuYW1lLidcbiAgICB9O1xuICB9XG5cbiAgLy8gQ2hlY2sgcGFzc3dvcmRcbiAgaWYgKG9wZXJhdG9yLnBhc3N3b3JkICYmIG9wZXJhdG9yLnBhc3N3b3JkICE9PSBwYXNzd29yZCkge1xuICAgIGFkZFNlY3VyaXR5QXVkaXRMb2coJ0xPR0lOX0ZBSUxFRCcsIHVzZXJuYW1lLCAnSW5jb3JyZWN0IHBhc3N3b3JkIGVudGVyZWQnKTtcbiAgICByZXR1cm4ge1xuICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICBlcnJvcjogJ0luY29ycmVjdCBQYXNzd29yZC4gUGxlYXNlIHRyeSBhZ2Fpbi4nXG4gICAgfTtcbiAgfVxuXG4gIC8vIENoZWNrIGlmIGFjY291bnQgaXMgc3VzcGVuZGVkIC8gbG9ja2VkXG4gIGlmIChvcGVyYXRvci5pc0xvY2tlZCkge1xuICAgIGFkZFNlY3VyaXR5QXVkaXRMb2coJ09QRVJBVE9SX0xPQ0tFRCcsIHVzZXJuYW1lLCAnQXR0ZW1wdCB0byBsb2dpbiB0byBzdXNwZW5kZWQgYWNjb3VudCcpO1xuICAgIHJldHVybiB7XG4gICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgIGVycm9yOiAn4puUIEFDQ09VTlQgU1VTUEVOREVEOiBUaGlzIG9wZXJhdG9yIElEIGhhcyBiZWVuIGxvY2tlZCBieSBNYXN0ZXIgQWRtaW4uIFBsZWFzZSBjb250YWN0IHNob3Agb3duZXIuJ1xuICAgIH07XG4gIH1cblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIERVQUwtREVWSUNFIEVORk9SQ0VNRU5UOiBQQyBTTE9UIHZzIE1PQklMRSBTTE9UXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS50b0xvY2FsZVN0cmluZygnZW4tSU4nKTtcblxuICBpZiAoY3VycmVudFR5cGUgPT09ICdwYycpIHtcbiAgICAvLyBMb2dnaW5nIGluIGZyb20gUENcbiAgICBpZiAoIW9wZXJhdG9yLmJvdW5kUGNEZXZpY2VJZCkge1xuICAgICAgLy8gRmlyc3QgUEMgbG9naW46IEJpbmQgdGhpcyBQQyFcbiAgICAgIG9wZXJhdG9yLmJvdW5kUGNEZXZpY2VJZCA9IGN1cnJlbnREZXZpY2VJZDtcbiAgICAgIG9wZXJhdG9yLmJvdW5kUGNEZXZpY2VOYW1lID0gY3VycmVudERldmljZU5hbWU7XG4gICAgICBvcGVyYXRvci5ib3VuZFBjQXQgPSBub3c7XG4gICAgICBvcGVyYXRvci5sYXN0TG9naW4gPSBub3c7XG4gICAgICBzYXZlUmVnaXN0ZXJlZE9wZXJhdG9ycyhvcGVyYXRvcnMpO1xuICAgICAgYWRkU2VjdXJpdHlBdWRpdExvZygnREVWSUNFX0JPVU5EJywgdXNlcm5hbWUsIGBQQyBib3VuZDogJHtjdXJyZW50RGV2aWNlTmFtZX0gKCR7Y3VycmVudERldmljZUlkfSlgKTtcbiAgICB9IGVsc2UgaWYgKG9wZXJhdG9yLmJvdW5kUGNEZXZpY2VJZCAhPT0gY3VycmVudERldmljZUlkKSB7XG4gICAgICAvLyBEaWZmZXJlbnQgUEMgdHJpZWQgdG8gYWNjZXNzIVxuICAgICAgYWRkU2VjdXJpdHlBdWRpdExvZyhcbiAgICAgICAgJ0RFVklDRV9CTE9DS0VEJyxcbiAgICAgICAgdXNlcm5hbWUsXG4gICAgICAgIGBVbmF1dGhvcml6ZWQgUEMgbG9naW4gYXR0ZW1wdC4gSUQgaXMgYWxyZWFkeSBib3VuZCB0byBQQyAoJHtvcGVyYXRvci5ib3VuZFBjRGV2aWNlTmFtZX0gLyAke29wZXJhdG9yLmJvdW5kUGNEZXZpY2VJZH0pYFxuICAgICAgKTtcblxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgIGRldmljZUxvY2tlZFRvT3RoZXI6IHRydWUsXG4gICAgICAgIGRldmljZVR5cGU6ICdwYycsXG4gICAgICAgIGJvdW5kRGV2aWNlTmFtZTogb3BlcmF0b3IuYm91bmRQY0RldmljZU5hbWUgfHwgb3BlcmF0b3IuYm91bmRQY0RldmljZUlkLFxuICAgICAgICBlcnJvcjogYPCfmqggUEMgREVWSUNFIE1JU01BVENIOlxcblRoaXMgT3BlcmF0b3IgSUQgaXMgYWxyZWFkeSBwYWlyZWQgd2l0aCB5b3VyIHNob3AgUEMgKCR7b3BlcmF0b3IuYm91bmRQY0RldmljZU5hbWUgfHwgb3BlcmF0b3IuYm91bmRQY0RldmljZUlkfSkuXFxuXFxuMSBJRCBpcyBwZXJtaXR0ZWQgb24gMSBQQyArIDEgTW9iaWxlIG9ubHkuIFRvIHVzZSBvbiB0aGlzIG5ldyBjb21wdXRlciwgYXNrIE1hc3RlciBBZG1pbiB0byByZXNldCB5b3VyIFBDIGJpbmRpbmcuYFxuICAgICAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gQXV0aG9yaXplZCBQQyBtYXRjaCFcbiAgICAgIG9wZXJhdG9yLmxhc3RMb2dpbiA9IG5vdztcbiAgICAgIHNhdmVSZWdpc3RlcmVkT3BlcmF0b3JzKG9wZXJhdG9ycyk7XG4gICAgICBhZGRTZWN1cml0eUF1ZGl0TG9nKCdMT0dJTl9TVUNDRVNTJywgdXNlcm5hbWUsIGBTdWNjZXNzZnVsIGxvZ2luIG9uIGF1dGhvcml6ZWQgUEMgKCR7Y3VycmVudERldmljZUlkfSlgKTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgLy8gTG9nZ2luZyBpbiBmcm9tIE1vYmlsZSBQaG9uZSAvIFRhYmxldFxuICAgIGlmICghb3BlcmF0b3IuYm91bmRNb2JpbGVEZXZpY2VJZCkge1xuICAgICAgLy8gRmlyc3QgTW9iaWxlIGxvZ2luOiBCaW5kIHRoaXMgTW9iaWxlIVxuICAgICAgb3BlcmF0b3IuYm91bmRNb2JpbGVEZXZpY2VJZCA9IGN1cnJlbnREZXZpY2VJZDtcbiAgICAgIG9wZXJhdG9yLmJvdW5kTW9iaWxlRGV2aWNlTmFtZSA9IGN1cnJlbnREZXZpY2VOYW1lO1xuICAgICAgb3BlcmF0b3IuYm91bmRNb2JpbGVBdCA9IG5vdztcbiAgICAgIG9wZXJhdG9yLmxhc3RMb2dpbiA9IG5vdztcbiAgICAgIHNhdmVSZWdpc3RlcmVkT3BlcmF0b3JzKG9wZXJhdG9ycyk7XG4gICAgICBhZGRTZWN1cml0eUF1ZGl0TG9nKCdERVZJQ0VfQk9VTkQnLCB1c2VybmFtZSwgYE1vYmlsZSBib3VuZDogJHtjdXJyZW50RGV2aWNlTmFtZX0gKCR7Y3VycmVudERldmljZUlkfSlgKTtcbiAgICB9IGVsc2UgaWYgKG9wZXJhdG9yLmJvdW5kTW9iaWxlRGV2aWNlSWQgIT09IGN1cnJlbnREZXZpY2VJZCkge1xuICAgICAgLy8gRGlmZmVyZW50IE1vYmlsZSB0cmllZCB0byBhY2Nlc3MhXG4gICAgICBhZGRTZWN1cml0eUF1ZGl0TG9nKFxuICAgICAgICAnREVWSUNFX0JMT0NLRUQnLFxuICAgICAgICB1c2VybmFtZSxcbiAgICAgICAgYFVuYXV0aG9yaXplZCBNb2JpbGUgbG9naW4gYXR0ZW1wdC4gSUQgaXMgYWxyZWFkeSBib3VuZCB0byBNb2JpbGUgKCR7b3BlcmF0b3IuYm91bmRNb2JpbGVEZXZpY2VOYW1lfSAvICR7b3BlcmF0b3IuYm91bmRNb2JpbGVEZXZpY2VJZH0pYFxuICAgICAgKTtcblxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgIGRldmljZUxvY2tlZFRvT3RoZXI6IHRydWUsXG4gICAgICAgIGRldmljZVR5cGU6ICdtb2JpbGUnLFxuICAgICAgICBib3VuZERldmljZU5hbWU6IG9wZXJhdG9yLmJvdW5kTW9iaWxlRGV2aWNlTmFtZSB8fCBvcGVyYXRvci5ib3VuZE1vYmlsZURldmljZUlkLFxuICAgICAgICBlcnJvcjogYPCfmqggTU9CSUxFIERFVklDRSBNSVNNQVRDSDpcXG5UaGlzIE9wZXJhdG9yIElEIGlzIGFscmVhZHkgcGFpcmVkIHdpdGggeW91ciByZWdpc3RlcmVkIE1vYmlsZSAoJHtvcGVyYXRvci5ib3VuZE1vYmlsZURldmljZU5hbWUgfHwgb3BlcmF0b3IuYm91bmRNb2JpbGVEZXZpY2VJZH0pLlxcblxcbjEgSUQgaXMgcGVybWl0dGVkIG9uIDEgUEMgKyAxIE1vYmlsZSBvbmx5LiBUbyB1c2Ugb24gdGhpcyBuZXcgcGhvbmUsIGFzayBNYXN0ZXIgQWRtaW4gdG8gcmVzZXQgeW91ciBNb2JpbGUgYmluZGluZy5gXG4gICAgICB9O1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBBdXRob3JpemVkIE1vYmlsZSBtYXRjaCFcbiAgICAgIG9wZXJhdG9yLmxhc3RMb2dpbiA9IG5vdztcbiAgICAgIHNhdmVSZWdpc3RlcmVkT3BlcmF0b3JzKG9wZXJhdG9ycyk7XG4gICAgICBhZGRTZWN1cml0eUF1ZGl0TG9nKCdMT0dJTl9TVUNDRVNTJywgdXNlcm5hbWUsIGBTdWNjZXNzZnVsIGxvZ2luIG9uIGF1dGhvcml6ZWQgTW9iaWxlICgke2N1cnJlbnREZXZpY2VJZH0pYCk7XG4gICAgfVxuICB9XG5cbiAgY29uc3QgYWN0aXZlVXNlcjogVXNlckFjY291bnQgPSB7XG4gICAgdXNlcm5hbWU6IG9wZXJhdG9yLnVzZXJuYW1lLFxuICAgIGRpc3BsYXlOYW1lOiBvcGVyYXRvci5kaXNwbGF5TmFtZSxcbiAgICByb2xlOiBvcGVyYXRvci5yb2xlLFxuICAgIHBob25lOiBvcGVyYXRvci5waG9uZSxcbiAgICBzaG9wTmFtZTogJ011emFtbWlsIE9ubGluZSBTZXJ2aWNlJyxcbiAgICBpc0xvZ2dlZEluOiB0cnVlLFxuICAgIGN1cnJlbnREZXZpY2VUeXBlOiBjdXJyZW50VHlwZSxcbiAgICBjdXJyZW50RGV2aWNlSWQsXG4gICAgY3VycmVudERldmljZU5hbWUsXG4gICAgYm91bmRQY0RldmljZUlkOiBvcGVyYXRvci5ib3VuZFBjRGV2aWNlSWQgfHwgdW5kZWZpbmVkLFxuICAgIGJvdW5kTW9iaWxlRGV2aWNlSWQ6IG9wZXJhdG9yLmJvdW5kTW9iaWxlRGV2aWNlSWQgfHwgdW5kZWZpbmVkXG4gIH07XG5cbiAgcmV0dXJuIHtcbiAgICBzdWNjZXNzOiB0cnVlLFxuICAgIHVzZXI6IGFjdGl2ZVVzZXJcbiAgfTtcbn1cblxuLy8gTWFzdGVyIEFkbWluOiBSZXNldCBQQyBEZXZpY2UgQmluZGluZ1xuZXhwb3J0IGZ1bmN0aW9uIHJlc2V0T3BlcmF0b3JQY0JpbmRpbmcob3BlcmF0b3JJZDogc3RyaW5nKTogYm9vbGVhbiB7XG4gIGNvbnN0IG9wZXJhdG9ycyA9IGdldFJlZ2lzdGVyZWRPcGVyYXRvcnMoKTtcbiAgY29uc3Qgb3AgPSBvcGVyYXRvcnMuZmluZChvID0+IG8uaWQgPT09IG9wZXJhdG9ySWQgfHwgby51c2VybmFtZSA9PT0gb3BlcmF0b3JJZCk7XG4gIGlmICghb3ApIHJldHVybiBmYWxzZTtcblxuICBjb25zdCBwcmV2ID0gb3AuYm91bmRQY0RldmljZU5hbWUgfHwgb3AuYm91bmRQY0RldmljZUlkIHx8ICdQQyc7XG4gIG9wLmJvdW5kUGNEZXZpY2VJZCA9IG51bGw7XG4gIG9wLmJvdW5kUGNEZXZpY2VOYW1lID0gbnVsbDtcbiAgb3AuYm91bmRQY0F0ID0gbnVsbDtcblxuICBzYXZlUmVnaXN0ZXJlZE9wZXJhdG9ycyhvcGVyYXRvcnMpO1xuICBhZGRTZWN1cml0eUF1ZGl0TG9nKCdERVZJQ0VfUkVTRVQnLCBvcC51c2VybmFtZSwgYE1hc3RlciBBZG1pbiBjbGVhcmVkIFBDIGRldmljZSBiaW5kaW5nICh3YXM6ICR7cHJldn0pYCk7XG4gIHJldHVybiB0cnVlO1xufVxuXG4vLyBNYXN0ZXIgQWRtaW46IFJlc2V0IE1vYmlsZSBEZXZpY2UgQmluZGluZ1xuZXhwb3J0IGZ1bmN0aW9uIHJlc2V0T3BlcmF0b3JNb2JpbGVCaW5kaW5nKG9wZXJhdG9ySWQ6IHN0cmluZyk6IGJvb2xlYW4ge1xuICBjb25zdCBvcGVyYXRvcnMgPSBnZXRSZWdpc3RlcmVkT3BlcmF0b3JzKCk7XG4gIGNvbnN0IG9wID0gb3BlcmF0b3JzLmZpbmQobyA9PiBvLmlkID09PSBvcGVyYXRvcklkIHx8IG8udXNlcm5hbWUgPT09IG9wZXJhdG9ySWQpO1xuICBpZiAoIW9wKSByZXR1cm4gZmFsc2U7XG5cbiAgY29uc3QgcHJldiA9IG9wLmJvdW5kTW9iaWxlRGV2aWNlTmFtZSB8fCBvcC5ib3VuZE1vYmlsZURldmljZUlkIHx8ICdNb2JpbGUnO1xuICBvcC5ib3VuZE1vYmlsZURldmljZUlkID0gbnVsbDtcbiAgb3AuYm91bmRNb2JpbGVEZXZpY2VOYW1lID0gbnVsbDtcbiAgb3AuYm91bmRNb2JpbGVBdCA9IG51bGw7XG5cbiAgc2F2ZVJlZ2lzdGVyZWRPcGVyYXRvcnMob3BlcmF0b3JzKTtcbiAgYWRkU2VjdXJpdHlBdWRpdExvZygnREVWSUNFX1JFU0VUJywgb3AudXNlcm5hbWUsIGBNYXN0ZXIgQWRtaW4gY2xlYXJlZCBNb2JpbGUgZGV2aWNlIGJpbmRpbmcgKHdhczogJHtwcmV2fSlgKTtcbiAgcmV0dXJuIHRydWU7XG59XG5cbi8vIE1hc3RlciBBZG1pbjogUmVzZXQgQm90aCBEZXZpY2UgQmluZGluZ3MgKEZ1bGwgUmVzZXQpXG5leHBvcnQgZnVuY3Rpb24gcmVzZXRPcGVyYXRvckFsbEJpbmRpbmdzKG9wZXJhdG9ySWQ6IHN0cmluZyk6IGJvb2xlYW4ge1xuICBjb25zdCBvcGVyYXRvcnMgPSBnZXRSZWdpc3RlcmVkT3BlcmF0b3JzKCk7XG4gIGNvbnN0IG9wID0gb3BlcmF0b3JzLmZpbmQobyA9PiBvLmlkID09PSBvcGVyYXRvcklkIHx8IG8udXNlcm5hbWUgPT09IG9wZXJhdG9ySWQpO1xuICBpZiAoIW9wKSByZXR1cm4gZmFsc2U7XG5cbiAgb3AuYm91bmRQY0RldmljZUlkID0gbnVsbDtcbiAgb3AuYm91bmRQY0RldmljZU5hbWUgPSBudWxsO1xuICBvcC5ib3VuZFBjQXQgPSBudWxsO1xuICBvcC5ib3VuZE1vYmlsZURldmljZUlkID0gbnVsbDtcbiAgb3AuYm91bmRNb2JpbGVEZXZpY2VOYW1lID0gbnVsbDtcbiAgb3AuYm91bmRNb2JpbGVBdCA9IG51bGw7XG5cbiAgc2F2ZVJlZ2lzdGVyZWRPcGVyYXRvcnMob3BlcmF0b3JzKTtcbiAgYWRkU2VjdXJpdHlBdWRpdExvZygnREVWSUNFX1JFU0VUJywgb3AudXNlcm5hbWUsIGBNYXN0ZXIgQWRtaW4gY2xlYXJlZCBhbGwgZGV2aWNlIGJpbmRpbmdzIChQQyAmIE1vYmlsZSlgKTtcbiAgcmV0dXJuIHRydWU7XG59XG5cbi8vIE1hc3RlciBBZG1pbjogVG9nZ2xlIExvY2sgQWNjb3VudFxuZXhwb3J0IGZ1bmN0aW9uIHRvZ2dsZU9wZXJhdG9yTG9jayhvcGVyYXRvcklkOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgY29uc3Qgb3BlcmF0b3JzID0gZ2V0UmVnaXN0ZXJlZE9wZXJhdG9ycygpO1xuICBjb25zdCBvcCA9IG9wZXJhdG9ycy5maW5kKG8gPT4gby5pZCA9PT0gb3BlcmF0b3JJZCB8fCBvLnVzZXJuYW1lID09PSBvcGVyYXRvcklkKTtcbiAgaWYgKCFvcCkgcmV0dXJuIGZhbHNlO1xuXG4gIG9wLmlzTG9ja2VkID0gIW9wLmlzTG9ja2VkO1xuICBzYXZlUmVnaXN0ZXJlZE9wZXJhdG9ycyhvcGVyYXRvcnMpO1xuICBhZGRTZWN1cml0eUF1ZGl0TG9nKCdPUEVSQVRPUl9MT0NLRUQnLCBvcC51c2VybmFtZSwgYE1hc3RlciBBZG1pbiBzZXQgbG9jayBzdGF0dXMgdG86ICR7b3AuaXNMb2NrZWQgPyAnTE9DS0VEJyA6ICdBQ1RJVkUnfWApO1xuICByZXR1cm4gdHJ1ZTtcbn1cblxuLy8gTWFzdGVyIEFkbWluOiBBZGQgT3BlcmF0b3JcbmV4cG9ydCBmdW5jdGlvbiBhZGROZXdPcGVyYXRvcihvcDogT21pdDxPcGVyYXRvckFjY291bnQsICdpZCcgfCAnYm91bmRQY0RldmljZUlkJyB8ICdib3VuZFBjRGV2aWNlTmFtZScgfCAnYm91bmRQY0F0JyB8ICdib3VuZE1vYmlsZURldmljZUlkJyB8ICdib3VuZE1vYmlsZURldmljZU5hbWUnIHwgJ2JvdW5kTW9iaWxlQXQnIHwgJ2xhc3RMb2dpbicgfCAnaXNMb2NrZWQnPik6IGJvb2xlYW4ge1xuICBjb25zdCBvcGVyYXRvcnMgPSBnZXRSZWdpc3RlcmVkT3BlcmF0b3JzKCk7XG4gIGlmIChvcGVyYXRvcnMuc29tZShvID0+IG8udXNlcm5hbWUudG9Mb3dlckNhc2UoKSA9PT0gb3AudXNlcm5hbWUudG9Mb3dlckNhc2UoKSkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICBjb25zdCBuZXdPcDogT3BlcmF0b3JBY2NvdW50ID0ge1xuICAgIC4uLm9wLFxuICAgIGlkOiBgb3AtJHtEYXRlLm5vdygpfWAsXG4gICAgYm91bmRQY0RldmljZUlkOiBudWxsLFxuICAgIGJvdW5kUGNEZXZpY2VOYW1lOiBudWxsLFxuICAgIGJvdW5kUGNBdDogbnVsbCxcbiAgICBib3VuZE1vYmlsZURldmljZUlkOiBudWxsLFxuICAgIGJvdW5kTW9iaWxlRGV2aWNlTmFtZTogbnVsbCxcbiAgICBib3VuZE1vYmlsZUF0OiBudWxsLFxuICAgIGxhc3RMb2dpbjogbnVsbCxcbiAgICBpc0xvY2tlZDogZmFsc2VcbiAgfTtcblxuICBvcGVyYXRvcnMucHVzaChuZXdPcCk7XG4gIHNhdmVSZWdpc3RlcmVkT3BlcmF0b3JzKG9wZXJhdG9ycyk7XG4gIGFkZFNlY3VyaXR5QXVkaXRMb2coJ0xPR0lOX1NVQ0NFU1MnLCAnYWRtaW4nLCBgTWFzdGVyIEFkbWluIHJlZ2lzdGVyZWQgbmV3IG9wZXJhdG9yOiAke29wLnVzZXJuYW1lfWApO1xuICByZXR1cm4gdHJ1ZTtcbn1cblxuLy8gTWFzdGVyIEFkbWluOiBEZWxldGUgT3BlcmF0b3JcbmV4cG9ydCBmdW5jdGlvbiBkZWxldGVPcGVyYXRvcihvcGVyYXRvcklkOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgbGV0IG9wZXJhdG9ycyA9IGdldFJlZ2lzdGVyZWRPcGVyYXRvcnMoKTtcbiAgY29uc3Qgb3AgPSBvcGVyYXRvcnMuZmluZChvID0+IG8uaWQgPT09IG9wZXJhdG9ySWQpO1xuICBpZiAoIW9wIHx8IG9wLnJvbGUgPT09ICdhZG1pbicpIHJldHVybiBmYWxzZTtcblxuICBvcGVyYXRvcnMgPSBvcGVyYXRvcnMuZmlsdGVyKG8gPT4gby5pZCAhPT0gb3BlcmF0b3JJZCk7XG4gIHNhdmVSZWdpc3RlcmVkT3BlcmF0b3JzKG9wZXJhdG9ycyk7XG4gIGFkZFNlY3VyaXR5QXVkaXRMb2coJ0xPR0lOX1NVQ0NFU1MnLCAnYWRtaW4nLCBgTWFzdGVyIEFkbWluIGRlbGV0ZWQgb3BlcmF0b3I6ICR7b3AudXNlcm5hbWV9YCk7XG4gIHJldHVybiB0cnVlO1xufVxuXG4vLyBDYWxjdWxhdGUgRGF5cyBMZWZ0IHVudGlsIHZhbGlkaXR5IGV4cGlyeSAoQWRtaW4gaXMgTGlmZXRpbWUgLyBOZXZlciBFeHBpcmVzKVxuZXhwb3J0IGZ1bmN0aW9uIGNhbGN1bGF0ZVJlbWFpbmluZ0RheXMoZGF0ZVN0cj86IHN0cmluZyB8IG51bGwpOiBudW1iZXIge1xuICBpZiAoIWRhdGVTdHIgfHwgZGF0ZVN0ci50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKCdsaWZldGltZScpIHx8IGRhdGVTdHIudG9Mb3dlckNhc2UoKS5pbmNsdWRlcygnbmV2ZXInKSkge1xuICAgIHJldHVybiA5OTk5OTk7IC8vIE5ldmVyIGV4cGlyZXNcbiAgfVxuICBjb25zdCBleHBpcnkgPSBuZXcgRGF0ZShkYXRlU3RyKS5nZXRUaW1lKCk7XG4gIGlmIChpc05hTihleHBpcnkpKSByZXR1cm4gOTk5OTk5O1xuICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICBjb25zdCBkaWZmID0gZXhwaXJ5IC0gbm93O1xuICByZXR1cm4gTWF0aC5tYXgoMCwgTWF0aC5jZWlsKGRpZmYgLyAoMTAwMCAqIDYwICogNjAgKiAyNCkpKTtcbn1cblxuLy8gTWFzdGVyIEFkbWluOiBSZW5ldyBPcGVyYXRvciBMaWNlbnNlIC8gQWNjZXNzXG5leHBvcnQgZnVuY3Rpb24gcmVuZXdPcGVyYXRvckxpY2Vuc2Uob3BlcmF0b3JJZDogc3RyaW5nLCBkYXlzVG9BZGQ6IG51bWJlcik6IHsgc3VjY2VzczogYm9vbGVhbjsgbmV3RXhwaXJ5OiBzdHJpbmc7IGRheXNMZWZ0OiBudW1iZXIgfSB7XG4gIGNvbnN0IG9wZXJhdG9ycyA9IGdldFJlZ2lzdGVyZWRPcGVyYXRvcnMoKTtcbiAgY29uc3Qgb3AgPSBvcGVyYXRvcnMuZmluZChvID0+IG8uaWQgPT09IG9wZXJhdG9ySWQgfHwgby51c2VybmFtZSA9PT0gb3BlcmF0b3JJZCk7XG4gIGlmICghb3ApIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBuZXdFeHBpcnk6ICcnLCBkYXlzTGVmdDogMCB9O1xuXG4gIGlmIChvcC5yb2xlID09PSAnYWRtaW4nIHx8IG9wLnVzZXJuYW1lID09PSAnYWRtaW4nKSB7XG4gICAgb3AudmFsaWRpdHlFeHBpcmVzQXQgPSAnTGlmZXRpbWUgKE5ldmVyIEV4cGlyZXMpJztcbiAgICBvcC52YWxpZGl0eURheXNMZWZ0ID0gOTk5OTk5O1xuICAgIG9wLmlzTG9ja2VkID0gZmFsc2U7XG4gICAgc2F2ZVJlZ2lzdGVyZWRPcGVyYXRvcnMob3BlcmF0b3JzKTtcbiAgICByZXR1cm4ge1xuICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgIG5ld0V4cGlyeTogJ0xpZmV0aW1lIChOZXZlciBFeHBpcmVzKScsXG4gICAgICBkYXlzTGVmdDogOTk5OTk5XG4gICAgfTtcbiAgfVxuXG4gIGxldCBjdXJyZW50RXhwaXJ5ID0gb3AudmFsaWRpdHlFeHBpcmVzQXQgPyBuZXcgRGF0ZShvcC52YWxpZGl0eUV4cGlyZXNBdCkuZ2V0VGltZSgpIDogRGF0ZS5ub3coKTtcbiAgaWYgKGlzTmFOKGN1cnJlbnRFeHBpcnkpIHx8IGN1cnJlbnRFeHBpcnkgPCBEYXRlLm5vdygpKSB7XG4gICAgY3VycmVudEV4cGlyeSA9IERhdGUubm93KCk7XG4gIH1cblxuICBjb25zdCBuZXdFeHBpcnlUaW1lID0gY3VycmVudEV4cGlyeSArIChkYXlzVG9BZGQgKiAyNCAqIDYwICogNjAgKiAxMDAwKTtcbiAgY29uc3QgbmV3RXhwaXJ5U3RyID0gbmV3IERhdGUobmV3RXhwaXJ5VGltZSkudG9JU09TdHJpbmcoKS5zcGxpdCgnVCcpWzBdO1xuICBjb25zdCBkYXlzTGVmdCA9IE1hdGguY2VpbCgobmV3RXhwaXJ5VGltZSAtIERhdGUubm93KCkpIC8gKDEwMDAgKiA2MCAqIDYwICogMjQpKTtcblxuICBvcC52YWxpZGl0eUV4cGlyZXNBdCA9IG5ld0V4cGlyeVN0cjtcbiAgb3AudmFsaWRpdHlEYXlzTGVmdCA9IGRheXNMZWZ0O1xuXG4gIHNhdmVSZWdpc3RlcmVkT3BlcmF0b3JzKG9wZXJhdG9ycyk7XG4gIGFkZFNlY3VyaXR5QXVkaXRMb2coJ0xPR0lOX1NVQ0NFU1MnLCBvcC51c2VybmFtZSwgYExpY2Vuc2UgcmVuZXdlZCBmb3IgKyR7ZGF5c1RvQWRkfSBkYXlzLiBWYWxpZCB1bnRpbCAke25ld0V4cGlyeVN0cn0gKCR7ZGF5c0xlZnR9IGRheXMgbGVmdClgKTtcblxuICByZXR1cm4ge1xuICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgbmV3RXhwaXJ5OiBuZXdFeHBpcnlTdHIsXG4gICAgZGF5c0xlZnRcbiAgfTtcbn1cblxuLy8gQ2xpZW50IExpdmUgSGVhcnRiZWF0IFJlcG9ydGVyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2VuZE9wZXJhdG9ySGVhcnRiZWF0KGRhdGE6IHtcbiAgdXNlcm5hbWU6IHN0cmluZztcbiAgZGlzcGxheU5hbWU6IHN0cmluZztcbiAgcm9sZTogJ2FkbWluJyB8ICdvcGVyYXRvcic7XG4gIHBob25lPzogc3RyaW5nO1xuICBjdXJyZW50VGFiOiBzdHJpbmc7XG4gIGN1cnJlbnRUYXNrPzogc3RyaW5nO1xufSk6IFByb21pc2U8eyBzdWNjZXNzOiBib29sZWFuOyBhY3RpdmVDb3VudDogbnVtYmVyOyBicm9hZGNhc3RNZXNzYWdlPzogc3RyaW5nIHwgbnVsbCB9PiB7XG4gIGNvbnN0IGRldmljZUlkID0gZ2V0SGFyZHdhcmVEZXZpY2VJZCgpO1xuICBjb25zdCBkZXZpY2VOYW1lID0gZ2V0SGFyZHdhcmVEZXZpY2VOYW1lKCk7XG4gIGNvbnN0IGRldmljZVR5cGUgPSBpc01vYmlsZURldmljZSgpID8gJ21vYmlsZScgOiAncGMnO1xuXG4gIHRyeSB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goJy9hcGkvbGl2ZS9oZWFydGJlYXQnLCB7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LFxuICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAuLi5kYXRhLFxuICAgICAgICBkZXZpY2VJZCxcbiAgICAgICAgZGV2aWNlTmFtZSxcbiAgICAgICAgZGV2aWNlVHlwZVxuICAgICAgfSlcbiAgICB9KTtcbiAgICBpZiAocmVzLm9rKSB7XG4gICAgICByZXR1cm4gYXdhaXQgcmVzLmpzb24oKTtcbiAgICB9XG4gIH0gY2F0Y2gge1xuICAgIC8vIE9mZmxpbmUgbW9kZTogc3RvcmUgaW4gbG9jYWwgc3RvcmFnZSBoZWFydGJlYXQgcmVnaXN0cnlcbiAgICB0cnkge1xuICAgICAgY29uc3QgbG9jYWxLZXkgPSAnbW9zX2xvY2FsX2xpdmVfcHVsc2UnO1xuICAgICAgY29uc3QgZXhpc3RpbmcgPSBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKGxvY2FsS2V5KSB8fCAne30nKTtcbiAgICAgIGV4aXN0aW5nW2RhdGEudXNlcm5hbWVdID0ge1xuICAgICAgICAuLi5kYXRhLFxuICAgICAgICBkZXZpY2VJZCxcbiAgICAgICAgZGV2aWNlTmFtZSxcbiAgICAgICAgZGV2aWNlVHlwZSxcbiAgICAgICAgbGFzdEhlYXJ0YmVhdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gICAgICB9O1xuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0obG9jYWxLZXksIEpTT04uc3RyaW5naWZ5KGV4aXN0aW5nKSk7XG4gICAgfSBjYXRjaCB7fVxuICB9XG4gIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGFjdGl2ZUNvdW50OiAxLCBicm9hZGNhc3RNZXNzYWdlOiBudWxsIH07XG59XG5cbi8vIE1hc3RlciBBZG1pbjogRmV0Y2ggTGl2ZSBPcGVyYXRvciBTZXNzaW9uc1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldExpdmVPcGVyYXRvclNlc3Npb25zKCk6IFByb21pc2U8YW55W10+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCgnL2FwaS9saXZlL3Nlc3Npb25zJyk7XG4gICAgaWYgKHJlcy5vaykge1xuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XG4gICAgICByZXR1cm4gZGF0YS5zZXNzaW9ucyB8fCBbXTtcbiAgICB9XG4gIH0gY2F0Y2gge31cblxuICAvLyBMb2NhbCBmYWxsYmFjayBpZiBzZXJ2ZXIgdW5yZWFjaGFibGVcbiAgY29uc3Qgb3BlcmF0b3JzID0gZ2V0UmVnaXN0ZXJlZE9wZXJhdG9ycygpO1xuICBjb25zdCBjdXJyZW50RGV2SWQgPSBnZXRIYXJkd2FyZURldmljZUlkKCk7XG4gIGNvbnN0IGN1cnJlbnREZXZOYW1lID0gZ2V0SGFyZHdhcmVEZXZpY2VOYW1lKCk7XG5cbiAgcmV0dXJuIG9wZXJhdG9ycy5tYXAob3AgPT4gKHtcbiAgICBzZXNzaW9uSWQ6IGBsb2NhbC0ke29wLmlkfWAsXG4gICAgdXNlcm5hbWU6IG9wLnVzZXJuYW1lLFxuICAgIGRpc3BsYXlOYW1lOiBvcC5kaXNwbGF5TmFtZSxcbiAgICByb2xlOiBvcC5yb2xlLFxuICAgIHBob25lOiBvcC5waG9uZSxcbiAgICBkZXZpY2VUeXBlOiBpc01vYmlsZURldmljZSgpID8gJ21vYmlsZScgOiAncGMnLFxuICAgIGRldmljZUlkOiBjdXJyZW50RGV2SWQsXG4gICAgZGV2aWNlTmFtZTogY3VycmVudERldk5hbWUsXG4gICAgY3VycmVudFRhYjogJ1dvcmtzdGF0aW9uIEFjdGl2ZScsXG4gICAgY3VycmVudFRhc2s6ICdPbmxpbmUgSHViJyxcbiAgICBsb2dpblRpbWU6IG9wLmxhc3RMb2dpbiB8fCBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgbGFzdEhlYXJ0YmVhdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIHZhbGlkaXR5RXhwaXJlc0F0OiBvcC52YWxpZGl0eUV4cGlyZXNBdCB8fCAnMjAyNi0xMi0zMScsXG4gICAgaXNPbmxpbmU6IHRydWUsXG4gICAgbGFzdEFjdGl2ZVNlY29uZHNBZ286IDIsXG4gICAgaXBBZGRyZXNzOiAnMTI3LjAuMC4xIChMb2NhbCknXG4gIH0pKTtcbn1cblxuLy8gTWFzdGVyIEFkbWluOiBGb3JjZSBEaXNjb25uZWN0IGFuIE9wZXJhdG9yXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZm9yY2VEaXNjb25uZWN0T3BlcmF0b3IodXNlcm5hbWU6IHN0cmluZywgZGV2aWNlSWQ/OiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCgnL2FwaS9saXZlL3Rlcm1pbmF0ZScsIHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHVzZXJuYW1lLCBkZXZpY2VJZCB9KVxuICAgIH0pO1xuICAgIHJldHVybiByZXMub2s7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufVxuXG4vLyBNYXN0ZXIgQWRtaW46IEJyb2FkY2FzdCBtZXNzYWdlIHRvIG9wZXJhdG9yXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2VuZE9wZXJhdG9yQnJvYWRjYXN0TWVzc2FnZSh1c2VybmFtZTogc3RyaW5nLCBtZXNzYWdlOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgdHJ5IHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaCgnL2FwaS9saXZlL2Jyb2FkY2FzdCcsIHtcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHVzZXJuYW1lLCBtZXNzYWdlIH0pXG4gICAgfSk7XG4gICAgcmV0dXJuIHJlcy5vaztcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG5cbiJdfQ==