const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport22_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { Header } from "/src/components/Header.tsx";
import { Sidebar } from "/src/components/Sidebar.tsx";
import { DashboardView } from "/src/components/DashboardView.tsx";
import { PvcStudioView } from "/src/components/PvcStudioView.tsx";
import { PassportStudioView } from "/src/components/PassportStudioView.tsx";
import { PdfToJpgView } from "/src/components/PdfToJpgView.tsx";
import { BillingDeskView } from "/src/components/BillingDeskView.tsx";
import { CustomerCrmView } from "/src/components/CustomerCrmView.tsx";
import { BioDataMakerView } from "/src/components/BioDataMakerView.tsx";
import { GovernmentPortalsView } from "/src/components/GovernmentPortalsView.tsx";
import { AiAssistantView } from "/src/components/AiAssistantView.tsx";
import { DownloadsView } from "/src/components/DownloadsView.tsx";
import { SettingsView } from "/src/components/SettingsView.tsx";
import { MasterAdminView } from "/src/components/MasterAdminView.tsx";
import { WorkflowGuideView } from "/src/components/WorkflowGuideView.tsx";
import { VideoStudioView } from "/src/components/VideoStudioView.tsx";
import { AuthModal } from "/src/components/AuthModal.tsx";
import { ShortcutsModal } from "/src/components/ShortcutsModal.tsx";
import { loadSettings, saveSettings, loadUser, saveUser, logoutUser, loadBills, saveBills, loadCustomers, saveCustomers, loadDownloads, deleteDownloadRecord, exportAllData, saveDownloads } from "/src/utils/storage.ts";
import { sendOperatorHeartbeat } from "/src/utils/deviceSecurity.ts";
import { LoginScreen } from "/src/components/LoginScreen.tsx";
var _jsxFileName = "/app/applet/src/App.tsx";
import __vite__cjsImport22_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
export default function App() {
	const [activeTab, setActiveTab] = useState("dashboard");
	const [settings, setSettings] = useState(loadSettings);
	const [user, setUser] = useState(loadUser);
	const [bills, setBills] = useState(loadBills);
	const [customers, setCustomers] = useState(loadCustomers);
	const [downloads, setDownloads] = useState(loadDownloads);
	const [adminBroadcastToast, setAdminBroadcastToast] = useState(null);
	const [searchQuery, setSearchQuery] = useState("");
	const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
	const [showAuthModal, setShowAuthModal] = useState(false);
	const [showShortcutsModal, setShowShortcutsModal] = useState(false);
	// Live Operator Heartbeat loop
	useEffect(() => {
		if (!user.isLoggedIn || !user.username) return;
		const reportHeartbeat = async () => {
			try {
				const res = await sendOperatorHeartbeat({
					username: user.username,
					displayName: user.displayName,
					role: user.role,
					phone: user.phone,
					currentTab: activeTab,
					currentTask: `Active on ${activeTab}`
				});
				if (res && res.broadcastMessage) {
					if (res.broadcastMessage === "FORCE_DISCONNECTED_BY_ADMIN") {
						alert("🚨 Your workstation session was disconnected by Master Admin.");
						handleLogout();
					} else {
						setAdminBroadcastToast(res.broadcastMessage);
						setTimeout(() => setAdminBroadcastToast(null), 8e3);
					}
				}
			} catch {}
		};
		reportHeartbeat();
		const interval = setInterval(reportHeartbeat, 5e3);
		return () => clearInterval(interval);
	}, [
		user.isLoggedIn,
		user.username,
		activeTab
	]);
	const handleAddDownload = (newDl) => {
		const updated = [newDl, ...downloads];
		setDownloads(updated);
		saveDownloads(updated);
	};
	// Sync to storage
	const handleSaveSettings = (newSettings) => {
		setSettings(newSettings);
		saveSettings(newSettings);
	};
	const handleSelectUser = (newUser) => {
		setUser(newUser);
		saveUser(newUser);
	};
	const handleLogout = () => {
		logoutUser();
		setUser({
			username: "",
			displayName: "",
			role: "operator",
			phone: "",
			shopName: settings.shopName,
			isLoggedIn: false
		});
	};
	const handleAddBill = (newBill) => {
		const updated = [newBill, ...bills];
		setBills(updated);
		saveBills(updated);
	};
	const handleDeleteBill = (id) => {
		const updated = bills.filter((b) => b.id !== id);
		setBills(updated);
		saveBills(updated);
	};
	const handleAddCustomer = (newCustomer) => {
		const updated = [newCustomer, ...customers];
		setCustomers(updated);
		saveCustomers(updated);
	};
	const handleUpdateCustomerStatus = (id, newStatus) => {
		const updated = customers.map((c) => c.id === id ? {
			...c,
			status: newStatus
		} : c);
		setCustomers(updated);
		saveCustomers(updated);
	};
	const handleDeleteCustomer = (id) => {
		const updated = customers.filter((c) => c.id !== id);
		setCustomers(updated);
		saveCustomers(updated);
	};
	const handleDeleteDownload = (id) => {
		deleteDownloadRecord(id);
		setDownloads(loadDownloads());
	};
	const handleClearDownloads = () => {
		localStorage.removeItem("mos_pc_downloads");
		setDownloads([]);
	};
	// Keyboard Shortcuts for PC
	useEffect(() => {
		const handleKeyDown = (e) => {
			// Focus search: Ctrl + K or '/'
			if (e.ctrlKey && e.key === "k" || e.key === "/" && e.target.tagName !== "INPUT" && e.target.tagName !== "TEXTAREA") {
				e.preventDefault();
				const searchInput = document.getElementById("pc-global-search");
				searchInput?.focus();
			}
			// Fast Bill: Ctrl + B
			if (e.ctrlKey && e.key === "b") {
				e.preventDefault();
				setActiveTab("billing");
			}
			// Direct In-App Studio Print: Ctrl + P
			if (e.ctrlKey && e.key === "p") {
				e.preventDefault();
				window.dispatchEvent(new CustomEvent("app-direct-print"));
			}
			// Direct In-App PDF Download: Ctrl + S
			if (e.ctrlKey && e.key === "s") {
				e.preventDefault();
				window.dispatchEvent(new CustomEvent("app-direct-pdf"));
			}
			// Direct In-App HD JPG Download: Ctrl + J
			if (e.ctrlKey && e.key === "j") {
				e.preventDefault();
				window.dispatchEvent(new CustomEvent("app-direct-jpg"));
			}
			// Tab switcher: Alt + 1 to 9
			if (e.altKey) {
				const tabMap = {
					"1": "dashboard",
					"2": "pvc_studio",
					"3": "passport_studio",
					"4": "pdf_to_jpg",
					"5": "billing",
					"6": "customers",
					"7": "biodata_maker",
					"8": "portals",
					"9": "ai_assistant"
				};
				if (tabMap[e.key]) {
					e.preventDefault();
					setActiveTab(tabMap[e.key]);
				}
			}
			// Shortcuts Modal: '?'
			if (e.key === "?" && e.target.tagName !== "INPUT" && e.target.tagName !== "TEXTAREA") {
				setShowShortcutsModal(true);
			}
			// Escape to close modals
			if (e.key === "Escape") {
				setShowAuthModal(false);
				setShowShortcutsModal(false);
			}
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, []);
	// When global search is typed, automatically switch to portals or show matches if not empty
	useEffect(() => {
		if (searchQuery.trim().length > 1 && activeTab !== "portals" && activeTab !== "dashboard") {
			setActiveTab("portals");
		}
	}, [searchQuery]);
	const pendingJobsCount = customers.filter((c) => c.status === "Pending" || c.status === "Processing").length;
	// STRICT LOGIN WALL: Nothing works or displays without authentication!
	if (!user.isLoggedIn) {
		return /* @__PURE__ */ _jsxDEV(LoginScreen, {
			settings,
			onLoginSuccess: handleSelectUser
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 242,
			columnNumber: 7
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col h-screen w-screen bg-slate-950 text-slate-100 overflow-hidden font-sans selection:bg-blue-600 selection:text-white",
		children: [
			/* @__PURE__ */ _jsxDEV(Header, {
				settings,
				user,
				activeTab,
				onNavigate: (tab) => {
					setActiveTab(tab);
					setSearchQuery("");
				},
				onOpenLogin: () => setShowAuthModal(true),
				onOpenShortcuts: () => setShowShortcutsModal(true),
				onLogout: handleLogout,
				searchQuery,
				onSearchChange: setSearchQuery,
				isSidebarCollapsed,
				onToggleSidebar: () => setIsSidebarCollapsed((prev) => !prev)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 252,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-1 overflow-hidden relative",
				children: [/* @__PURE__ */ _jsxDEV(Sidebar, {
					activeTab,
					onNavigate: (tab) => {
						setActiveTab(tab);
						setSearchQuery("");
					},
					isCollapsed: isSidebarCollapsed,
					onToggleCollapse: () => setIsSidebarCollapsed((prev) => !prev),
					user,
					pendingJobsCount,
					onLogout: handleLogout
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 272,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("main", {
					className: "flex-1 overflow-y-auto p-4 lg:p-6 bg-slate-950 relative",
					children: [
						adminBroadcastToast && /* @__PURE__ */ _jsxDEV("div", {
							className: "mb-4 p-4 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xl flex items-center justify-between gap-3 animate-in fade-in slide-in-from-top-4 z-30",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xl",
									children: "📢"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 291,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "font-extrabold text-xs block uppercase tracking-wider text-blue-200",
									children: "Broadcast from Master Admin:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 293,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs font-semibold",
									children: adminBroadcastToast
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 294,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 292,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 290,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setAdminBroadcastToast(null),
								className: "text-white/80 hover:text-white px-2 py-1 bg-white/10 rounded-lg text-xs font-bold",
								children: "Dismiss"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 297,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 289,
							columnNumber: 13
						}, this),
						activeTab === "dashboard" && /* @__PURE__ */ _jsxDEV(DashboardView, {
							bills,
							customers,
							settings,
							onNavigate: setActiveTab,
							onOpenQuickBill: () => setActiveTab("billing"),
							onPrintBill: () => setActiveTab("billing")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 307,
							columnNumber: 13
						}, this),
						activeTab === "pvc_studio" && /* @__PURE__ */ _jsxDEV(PvcStudioView, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 318,
							columnNumber: 13
						}, this),
						activeTab === "passport_studio" && /* @__PURE__ */ _jsxDEV(PassportStudioView, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 322,
							columnNumber: 13
						}, this),
						activeTab === "video_studio" && /* @__PURE__ */ _jsxDEV(VideoStudioView, {
							onAddDownload: handleAddDownload,
							onNavigate: setActiveTab
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 326,
							columnNumber: 13
						}, this),
						activeTab === "pdf_to_jpg" && /* @__PURE__ */ _jsxDEV(PdfToJpgView, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 333,
							columnNumber: 13
						}, this),
						activeTab === "billing" && /* @__PURE__ */ _jsxDEV(BillingDeskView, {
							bills,
							settings,
							onAddBill: handleAddBill,
							onDeleteBill: handleDeleteBill
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 337,
							columnNumber: 13
						}, this),
						activeTab === "customers" && /* @__PURE__ */ _jsxDEV(CustomerCrmView, {
							customers,
							settings,
							onAddCustomer: handleAddCustomer,
							onUpdateStatus: handleUpdateCustomerStatus,
							onDeleteCustomer: handleDeleteCustomer
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 346,
							columnNumber: 13
						}, this),
						activeTab === "biodata_maker" && /* @__PURE__ */ _jsxDEV(BioDataMakerView, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 356,
							columnNumber: 13
						}, this),
						activeTab === "workflow" && /* @__PURE__ */ _jsxDEV(WorkflowGuideView, { onNavigate: setActiveTab }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 360,
							columnNumber: 13
						}, this),
						activeTab === "master_admin" && (user.role === "admin" ? /* @__PURE__ */ _jsxDEV(MasterAdminView, {
							settings,
							onUpdateSettings: handleSaveSettings,
							onNavigateToWorkflow: () => setActiveTab("workflow")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 365,
							columnNumber: 15
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "max-w-md mx-auto text-center p-8 bg-slate-900 border border-slate-800 rounded-3xl mt-12 space-y-3 shadow-2xl",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "w-12 h-12 bg-rose-500/20 text-rose-400 rounded-2xl flex items-center justify-center mx-auto text-2xl font-bold border border-rose-500/30",
									children: "🔒"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 372,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-base font-extrabold text-white",
									children: "Master Admin Restricted Access"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 375,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400 leading-relaxed",
									children: "Access Denied. The project source .ZIP archive, executable setup builder, and central security controls are strictly reserved for Master Admin (Imran Khan). Staff operators or customers cannot view or download this data."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 376,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 371,
							columnNumber: 15
						}, this)),
						activeTab === "portals" && /* @__PURE__ */ _jsxDEV(GovernmentPortalsView, {
							onAddDownload: handleAddDownload,
							onNavigate: setActiveTab
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 384,
							columnNumber: 13
						}, this),
						activeTab === "ai_assistant" && /* @__PURE__ */ _jsxDEV(AiAssistantView, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 391,
							columnNumber: 13
						}, this),
						activeTab === "downloads" && /* @__PURE__ */ _jsxDEV(DownloadsView, {
							downloads,
							onDeleteDownload: handleDeleteDownload,
							onClearAll: handleClearDownloads
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 395,
							columnNumber: 13
						}, this),
						activeTab === "settings" && /* @__PURE__ */ _jsxDEV(SettingsView, {
							settings,
							onSaveSettings: handleSaveSettings
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 403,
							columnNumber: 13
						}, this),
						activeTab === "backup" && /* @__PURE__ */ _jsxDEV("div", {
							className: "max-w-2xl mx-auto space-y-4 pt-6",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-900 border border-slate-800 p-6 rounded-3xl shadow-xl text-center space-y-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "w-16 h-16 rounded-2xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-400 mx-auto",
										children: /* @__PURE__ */ _jsxDEV("span", {
											className: "text-3xl",
											children: "💾"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 413,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 412,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("h2", {
										className: "text-xl font-bold text-white",
										children: "Full Station Data Backup"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 415,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-300 leading-relaxed max-w-md mx-auto",
										children: [
											"Export all your bills (",
											bills.length,
											"), customer records (",
											customers.length,
											"), settings, and recent download logs into a single secure file."
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 416,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-center gap-3 pt-2",
										children: /* @__PURE__ */ _jsxDEV("button", {
											onClick: exportAllData,
											className: "bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs px-5 py-2.5 rounded-xl shadow-lg shadow-purple-600/30 transition-all hover:scale-105",
											children: "Download Complete Backup JSON"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 420,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 419,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 411,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 410,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 286,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 270,
				columnNumber: 7
			}, this),
			showAuthModal && /* @__PURE__ */ _jsxDEV(AuthModal, {
				currentUser: user,
				onSelectUser: handleSelectUser,
				onClose: () => setShowAuthModal(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 435,
				columnNumber: 9
			}, this),
			showShortcutsModal && /* @__PURE__ */ _jsxDEV(ShortcutsModal, { onClose: () => setShowShortcutsModal(false) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 444,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 250,
		columnNumber: 5
	}, this);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsY0FBYztBQUN2QixTQUFTLGVBQWU7QUFDeEIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUywwQkFBMEI7QUFDbkMsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyx3QkFBd0I7QUFDakMsU0FBUyw2QkFBNkI7QUFDdEMsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxzQkFBc0I7QUFTL0IsU0FDRSxjQUNBLGNBQ0EsVUFDQSxVQUNBLFlBQ0EsV0FDQSxXQUNBLGVBQ0EsZUFDQSxlQUNBLHNCQUNBLGVBQ0EscUJBQ0s7QUFDUCxTQUFTLDZCQUE2QjtBQUN0QyxTQUFTLG1CQUFtQjs7O0FBRTVCLGVBQWUsU0FBUyxNQUFNO0NBQzVCLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFpQixXQUFXO0NBQzlELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBdUIsWUFBWTtDQUNuRSxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQXNCLFFBQVE7Q0FDdEQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFxQixTQUFTO0NBQ3hELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUEyQixhQUFhO0NBQzFFLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUF5QixhQUFhO0NBQ3hFLE1BQU0sQ0FBQyxxQkFBcUIsMEJBQTBCLFNBQXdCLElBQUk7Q0FFbEYsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQWlCLEVBQUU7Q0FDekQsTUFBTSxDQUFDLG9CQUFvQix5QkFBeUIsU0FBa0IsS0FBSztDQUMzRSxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBa0IsS0FBSztDQUNqRSxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUFrQixLQUFLOztDQUczRSxnQkFBZ0I7RUFDZCxJQUFJLENBQUMsS0FBSyxjQUFjLENBQUMsS0FBSyxVQUFVO0VBRXhDLE1BQU0sa0JBQWtCLFlBQVk7R0FDbEMsSUFBSTtJQUNGLE1BQU0sTUFBTSxNQUFNLHNCQUFzQjtLQUN0QyxVQUFVLEtBQUs7S0FDZixhQUFhLEtBQUs7S0FDbEIsTUFBTSxLQUFLO0tBQ1gsT0FBTyxLQUFLO0tBQ1osWUFBWTtLQUNaLGFBQWEsYUFBYTtJQUM1QixDQUFDO0lBRUQsSUFBSSxPQUFPLElBQUksa0JBQWtCO0tBQy9CLElBQUksSUFBSSxxQkFBcUIsK0JBQStCO01BQzFELE1BQU0sK0RBQStEO01BQ3JFLGFBQWE7S0FDZixPQUFPO01BQ0wsdUJBQXVCLElBQUksZ0JBQWdCO01BQzNDLGlCQUFpQix1QkFBdUIsSUFBSSxHQUFHLEdBQUk7S0FDckQ7SUFDRjtHQUNGLFFBQVEsQ0FBQztFQUNYO0VBRUEsZ0JBQWdCO0VBQ2hCLE1BQU0sV0FBVyxZQUFZLGlCQUFpQixHQUFJO0VBQ2xELGFBQWEsY0FBYyxRQUFRO0NBQ3JDLEdBQUc7RUFBQyxLQUFLO0VBQVksS0FBSztFQUFVO0NBQVMsQ0FBQztDQUU5QyxNQUFNLHFCQUFxQixVQUF3QjtFQUNqRCxNQUFNLFVBQVUsQ0FBQyxPQUFPLEdBQUcsU0FBUztFQUNwQyxhQUFhLE9BQU87RUFDcEIsY0FBYyxPQUFPO0NBQ3ZCOztDQUdBLE1BQU0sc0JBQXNCLGdCQUE4QjtFQUN4RCxZQUFZLFdBQVc7RUFDdkIsYUFBYSxXQUFXO0NBQzFCO0NBRUEsTUFBTSxvQkFBb0IsWUFBeUI7RUFDakQsUUFBUSxPQUFPO0VBQ2YsU0FBUyxPQUFPO0NBQ2xCO0NBRUEsTUFBTSxxQkFBcUI7RUFDekIsV0FBVztFQUNYLFFBQVE7R0FDTixVQUFVO0dBQ1YsYUFBYTtHQUNiLE1BQU07R0FDTixPQUFPO0dBQ1AsVUFBVSxTQUFTO0dBQ25CLFlBQVk7RUFDZCxDQUFDO0NBQ0g7Q0FFQSxNQUFNLGlCQUFpQixZQUFzQjtFQUMzQyxNQUFNLFVBQVUsQ0FBQyxTQUFTLEdBQUcsS0FBSztFQUNsQyxTQUFTLE9BQU87RUFDaEIsVUFBVSxPQUFPO0NBQ25CO0NBRUEsTUFBTSxvQkFBb0IsT0FBZTtFQUN2QyxNQUFNLFVBQVUsTUFBTSxRQUFPLE1BQUssRUFBRSxPQUFPLEVBQUU7RUFDN0MsU0FBUyxPQUFPO0VBQ2hCLFVBQVUsT0FBTztDQUNuQjtDQUVBLE1BQU0scUJBQXFCLGdCQUFnQztFQUN6RCxNQUFNLFVBQVUsQ0FBQyxhQUFhLEdBQUcsU0FBUztFQUMxQyxhQUFhLE9BQU87RUFDcEIsY0FBYyxPQUFPO0NBQ3ZCO0NBRUEsTUFBTSw4QkFBOEIsSUFBWSxjQUF3QztFQUN0RixNQUFNLFVBQVUsVUFBVSxLQUFJLE1BQUssRUFBRSxPQUFPLEtBQUs7R0FBRSxHQUFHO0dBQUcsUUFBUTtFQUFVLElBQUksQ0FBQztFQUNoRixhQUFhLE9BQU87RUFDcEIsY0FBYyxPQUFPO0NBQ3ZCO0NBRUEsTUFBTSx3QkFBd0IsT0FBZTtFQUMzQyxNQUFNLFVBQVUsVUFBVSxRQUFPLE1BQUssRUFBRSxPQUFPLEVBQUU7RUFDakQsYUFBYSxPQUFPO0VBQ3BCLGNBQWMsT0FBTztDQUN2QjtDQUVBLE1BQU0sd0JBQXdCLE9BQWU7RUFDM0MscUJBQXFCLEVBQUU7RUFDdkIsYUFBYSxjQUFjLENBQUM7Q0FDOUI7Q0FFQSxNQUFNLDZCQUE2QjtFQUNqQyxhQUFhLFdBQVcsa0JBQWtCO0VBQzFDLGFBQWEsQ0FBQyxDQUFDO0NBQ2pCOztDQUdBLGdCQUFnQjtFQUNkLE1BQU0saUJBQWlCLE1BQXFCOztHQUUxQyxJQUFLLEVBQUUsV0FBVyxFQUFFLFFBQVEsT0FBUyxFQUFFLFFBQVEsT0FBUSxFQUFFLE9BQXVCLFlBQVksV0FBWSxFQUFFLE9BQXVCLFlBQVksWUFBYTtJQUN4SixFQUFFLGVBQWU7SUFDakIsTUFBTSxjQUFjLFNBQVMsZUFBZSxrQkFBa0I7SUFDOUQsYUFBYSxNQUFNO0dBQ3JCOztHQUdBLElBQUksRUFBRSxXQUFXLEVBQUUsUUFBUSxLQUFLO0lBQzlCLEVBQUUsZUFBZTtJQUNqQixhQUFhLFNBQVM7R0FDeEI7O0dBR0EsSUFBSSxFQUFFLFdBQVcsRUFBRSxRQUFRLEtBQUs7SUFDOUIsRUFBRSxlQUFlO0lBQ2pCLE9BQU8sY0FBYyxJQUFJLFlBQVksa0JBQWtCLENBQUM7R0FDMUQ7O0dBR0EsSUFBSSxFQUFFLFdBQVcsRUFBRSxRQUFRLEtBQUs7SUFDOUIsRUFBRSxlQUFlO0lBQ2pCLE9BQU8sY0FBYyxJQUFJLFlBQVksZ0JBQWdCLENBQUM7R0FDeEQ7O0dBR0EsSUFBSSxFQUFFLFdBQVcsRUFBRSxRQUFRLEtBQUs7SUFDOUIsRUFBRSxlQUFlO0lBQ2pCLE9BQU8sY0FBYyxJQUFJLFlBQVksZ0JBQWdCLENBQUM7R0FDeEQ7O0dBR0EsSUFBSSxFQUFFLFFBQVE7SUFDWixNQUFNLFNBQWlDO0tBQ3JDLEtBQUs7S0FDTCxLQUFLO0tBQ0wsS0FBSztLQUNMLEtBQUs7S0FDTCxLQUFLO0tBQ0wsS0FBSztLQUNMLEtBQUs7S0FDTCxLQUFLO0tBQ0wsS0FBSztJQUNQO0lBQ0EsSUFBSSxPQUFPLEVBQUUsTUFBTTtLQUNqQixFQUFFLGVBQWU7S0FDakIsYUFBYSxPQUFPLEVBQUUsSUFBSTtJQUM1QjtHQUNGOztHQUdBLElBQUksRUFBRSxRQUFRLE9BQVEsRUFBRSxPQUF1QixZQUFZLFdBQVksRUFBRSxPQUF1QixZQUFZLFlBQVk7SUFDdEgsc0JBQXNCLElBQUk7R0FDNUI7O0dBR0EsSUFBSSxFQUFFLFFBQVEsVUFBVTtJQUN0QixpQkFBaUIsS0FBSztJQUN0QixzQkFBc0IsS0FBSztHQUM3QjtFQUNGO0VBRUEsT0FBTyxpQkFBaUIsV0FBVyxhQUFhO0VBQ2hELGFBQWEsT0FBTyxvQkFBb0IsV0FBVyxhQUFhO0NBQ2xFLEdBQUcsQ0FBQyxDQUFDOztDQUdMLGdCQUFnQjtFQUNkLElBQUksWUFBWSxLQUFLLENBQUMsQ0FBQyxTQUFTLEtBQUssY0FBYyxhQUFhLGNBQWMsYUFBYTtHQUN6RixhQUFhLFNBQVM7RUFDeEI7Q0FDRixHQUFHLENBQUMsV0FBVyxDQUFDO0NBRWhCLE1BQU0sbUJBQW1CLFVBQVUsUUFBTyxNQUFLLEVBQUUsV0FBVyxhQUFhLEVBQUUsV0FBVyxZQUFZLENBQUMsQ0FBQzs7Q0FHcEcsSUFBSSxDQUFDLEtBQUssWUFBWTtFQUNwQixPQUNFLHdCQUFDLGFBQUQ7R0FDWTtHQUNWLGdCQUFnQjtFQUNqQjs7Ozs7Q0FFTDtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLFFBQUQ7SUFDWTtJQUNKO0lBQ0s7SUFDWCxhQUFhLFFBQVE7S0FDbkIsYUFBYSxHQUFHO0tBQ2hCLGVBQWUsRUFBRTtJQUNuQjtJQUNBLG1CQUFtQixpQkFBaUIsSUFBSTtJQUN4Qyx1QkFBdUIsc0JBQXNCLElBQUk7SUFDakQsVUFBVTtJQUNHO0lBQ2IsZ0JBQWdCO0lBQ0k7SUFDcEIsdUJBQXVCLHVCQUFzQixTQUFRLENBQUMsSUFBSTtHQUMzRDs7Ozs7R0FHRCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBRUUsd0JBQUMsU0FBRDtLQUNhO0tBQ1gsYUFBYSxRQUFRO01BQ25CLGFBQWEsR0FBRztNQUNoQixlQUFlLEVBQUU7S0FDbkI7S0FDQSxhQUFhO0tBQ2Isd0JBQXdCLHVCQUFzQixTQUFRLENBQUMsSUFBSTtLQUNyRDtLQUNZO0tBQ2xCLFVBQVU7SUFDWDs7OztjQUdELHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWhCO01BRUcsdUJBQ0Msd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFVO1FBQVE7Ozs7a0JBQ2xDLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBc0U7UUFBa0M7Ozs7a0JBQ3hILHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUF5QjtRQUF1Qjs7OztnQkFDMUQ7Ozs7Z0JBQ0Y7Ozs7O2lCQUNMLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLHVCQUF1QixJQUFJO1FBQzFDLFdBQVU7a0JBQ1g7T0FFTzs7OztlQUNMOzs7Ozs7TUFHTixjQUFjLGVBQ2Isd0JBQUMsZUFBRDtPQUNTO09BQ0k7T0FDRDtPQUNWLFlBQVk7T0FDWix1QkFBdUIsYUFBYSxTQUFTO09BQzdDLG1CQUFtQixhQUFhLFNBQVM7TUFDMUM7Ozs7O01BR0YsY0FBYyxnQkFDYix3QkFBQyxlQUFELENBQWdCOzs7OztNQUdqQixjQUFjLHFCQUNiLHdCQUFDLG9CQUFELENBQXFCOzs7OztNQUd0QixjQUFjLGtCQUNiLHdCQUFDLGlCQUFEO09BQ0UsZUFBZTtPQUNmLFlBQVk7TUFDYjs7Ozs7TUFHRixjQUFjLGdCQUNiLHdCQUFDLGNBQUQsQ0FBZTs7Ozs7TUFHaEIsY0FBYyxhQUNiLHdCQUFDLGlCQUFEO09BQ1M7T0FDRztPQUNWLFdBQVc7T0FDWCxjQUFjO01BQ2Y7Ozs7O01BR0YsY0FBYyxlQUNiLHdCQUFDLGlCQUFEO09BQ2E7T0FDRDtPQUNWLGVBQWU7T0FDZixnQkFBZ0I7T0FDaEIsa0JBQWtCO01BQ25COzs7OztNQUdGLGNBQWMsbUJBQ2Isd0JBQUMsa0JBQUQsQ0FBbUI7Ozs7O01BR3BCLGNBQWMsY0FDYix3QkFBQyxtQkFBRCxFQUFtQixZQUFZLGFBQWU7Ozs7O01BRy9DLGNBQWMsbUJBQ2IsS0FBSyxTQUFTLFVBQ1osd0JBQUMsaUJBQUQ7T0FDWTtPQUNWLGtCQUFrQjtPQUNsQiw0QkFBNEIsYUFBYSxVQUFVO01BQ3BEOzs7O2lCQUVELHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQTJJO1FBRXJKOzs7OztRQUNMLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFzQztRQUFrQzs7Ozs7UUFDdEYsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQXlDO1FBRW5EOzs7OztPQUNBOzs7Ozs7TUFJUixjQUFjLGFBQ2Isd0JBQUMsdUJBQUQ7T0FDRSxlQUFlO09BQ2YsWUFBWTtNQUNiOzs7OztNQUdGLGNBQWMsa0JBQ2Isd0JBQUMsaUJBQUQsQ0FBa0I7Ozs7O01BR25CLGNBQWMsZUFDYix3QkFBQyxlQUFEO09BQ2E7T0FDWCxrQkFBa0I7T0FDbEIsWUFBWTtNQUNiOzs7OztNQUdGLGNBQWMsY0FDYix3QkFBQyxjQUFEO09BQ1k7T0FDVixnQkFBZ0I7TUFDakI7Ozs7O01BR0YsY0FBYyxZQUNiLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ2Isd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQVc7VUFBUTs7Ozs7U0FDaEM7Ozs7O1NBQ0wsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQStCO1NBQTRCOzs7OztTQUN6RSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBYjtXQUF1RTtXQUM3QyxNQUFNO1dBQU87V0FBc0IsVUFBVTtXQUFPO1VBQzNFOzs7Ozs7U0FDSCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDYix3QkFBQyxVQUFEO1dBQ0UsU0FBUztXQUNULFdBQVU7cUJBQ1g7VUFFTzs7Ozs7U0FDTDs7Ozs7UUFDRjs7Ozs7O01BQ0Y7Ozs7O0tBRUg7Ozs7O1lBQ0g7Ozs7OztHQUdKLGlCQUNDLHdCQUFDLFdBQUQ7SUFDRSxhQUFhO0lBQ2IsY0FBYztJQUNkLGVBQWUsaUJBQWlCLEtBQUs7R0FDdEM7Ozs7O0dBSUYsc0JBQ0Msd0JBQUMsZ0JBQUQsRUFDRSxlQUFlLHNCQUFzQixLQUFLLEVBQzNDOzs7OztFQUVBOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgSGVhZGVyIH0gZnJvbSAnLi9jb21wb25lbnRzL0hlYWRlcic7XG5pbXBvcnQgeyBTaWRlYmFyIH0gZnJvbSAnLi9jb21wb25lbnRzL1NpZGViYXInO1xuaW1wb3J0IHsgRGFzaGJvYXJkVmlldyB9IGZyb20gJy4vY29tcG9uZW50cy9EYXNoYm9hcmRWaWV3JztcbmltcG9ydCB7IFB2Y1N0dWRpb1ZpZXcgfSBmcm9tICcuL2NvbXBvbmVudHMvUHZjU3R1ZGlvVmlldyc7XG5pbXBvcnQgeyBQYXNzcG9ydFN0dWRpb1ZpZXcgfSBmcm9tICcuL2NvbXBvbmVudHMvUGFzc3BvcnRTdHVkaW9WaWV3JztcbmltcG9ydCB7IFBkZlRvSnBnVmlldyB9IGZyb20gJy4vY29tcG9uZW50cy9QZGZUb0pwZ1ZpZXcnO1xuaW1wb3J0IHsgQmlsbGluZ0Rlc2tWaWV3IH0gZnJvbSAnLi9jb21wb25lbnRzL0JpbGxpbmdEZXNrVmlldyc7XG5pbXBvcnQgeyBDdXN0b21lckNybVZpZXcgfSBmcm9tICcuL2NvbXBvbmVudHMvQ3VzdG9tZXJDcm1WaWV3JztcbmltcG9ydCB7IEJpb0RhdGFNYWtlclZpZXcgfSBmcm9tICcuL2NvbXBvbmVudHMvQmlvRGF0YU1ha2VyVmlldyc7XG5pbXBvcnQgeyBHb3Zlcm5tZW50UG9ydGFsc1ZpZXcgfSBmcm9tICcuL2NvbXBvbmVudHMvR292ZXJubWVudFBvcnRhbHNWaWV3JztcbmltcG9ydCB7IEFpQXNzaXN0YW50VmlldyB9IGZyb20gJy4vY29tcG9uZW50cy9BaUFzc2lzdGFudFZpZXcnO1xuaW1wb3J0IHsgRG93bmxvYWRzVmlldyB9IGZyb20gJy4vY29tcG9uZW50cy9Eb3dubG9hZHNWaWV3JztcbmltcG9ydCB7IFNldHRpbmdzVmlldyB9IGZyb20gJy4vY29tcG9uZW50cy9TZXR0aW5nc1ZpZXcnO1xuaW1wb3J0IHsgTWFzdGVyQWRtaW5WaWV3IH0gZnJvbSAnLi9jb21wb25lbnRzL01hc3RlckFkbWluVmlldyc7XG5pbXBvcnQgeyBXb3JrZmxvd0d1aWRlVmlldyB9IGZyb20gJy4vY29tcG9uZW50cy9Xb3JrZmxvd0d1aWRlVmlldyc7XG5pbXBvcnQgeyBWaWRlb1N0dWRpb1ZpZXcgfSBmcm9tICcuL2NvbXBvbmVudHMvVmlkZW9TdHVkaW9WaWV3JztcbmltcG9ydCB7IEF1dGhNb2RhbCB9IGZyb20gJy4vY29tcG9uZW50cy9BdXRoTW9kYWwnO1xuaW1wb3J0IHsgU2hvcnRjdXRzTW9kYWwgfSBmcm9tICcuL2NvbXBvbmVudHMvU2hvcnRjdXRzTW9kYWwnO1xuXG5pbXBvcnQgeyBcbiAgQmlsbEl0ZW0sIFxuICBDdXN0b21lclJlY29yZCwgXG4gIERvd25sb2FkSXRlbSwgXG4gIFNob3BTZXR0aW5ncywgXG4gIFVzZXJBY2NvdW50IFxufSBmcm9tICcuL3R5cGVzJztcbmltcG9ydCB7IFxuICBsb2FkU2V0dGluZ3MsIFxuICBzYXZlU2V0dGluZ3MsIFxuICBsb2FkVXNlciwgXG4gIHNhdmVVc2VyLCBcbiAgbG9nb3V0VXNlcixcbiAgbG9hZEJpbGxzLCBcbiAgc2F2ZUJpbGxzLCBcbiAgbG9hZEN1c3RvbWVycywgXG4gIHNhdmVDdXN0b21lcnMsIFxuICBsb2FkRG93bmxvYWRzLCBcbiAgZGVsZXRlRG93bmxvYWRSZWNvcmQsIFxuICBleHBvcnRBbGxEYXRhLFxuICBzYXZlRG93bmxvYWRzIFxufSBmcm9tICcuL3V0aWxzL3N0b3JhZ2UnO1xuaW1wb3J0IHsgc2VuZE9wZXJhdG9ySGVhcnRiZWF0IH0gZnJvbSAnLi91dGlscy9kZXZpY2VTZWN1cml0eSc7XG5pbXBvcnQgeyBMb2dpblNjcmVlbiB9IGZyb20gJy4vY29tcG9uZW50cy9Mb2dpblNjcmVlbic7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCgpIHtcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlPHN0cmluZz4oJ2Rhc2hib2FyZCcpO1xuICBjb25zdCBbc2V0dGluZ3MsIHNldFNldHRpbmdzXSA9IHVzZVN0YXRlPFNob3BTZXR0aW5ncz4obG9hZFNldHRpbmdzKTtcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGU8VXNlckFjY291bnQ+KGxvYWRVc2VyKTtcbiAgY29uc3QgW2JpbGxzLCBzZXRCaWxsc10gPSB1c2VTdGF0ZTxCaWxsSXRlbVtdPihsb2FkQmlsbHMpO1xuICBjb25zdCBbY3VzdG9tZXJzLCBzZXRDdXN0b21lcnNdID0gdXNlU3RhdGU8Q3VzdG9tZXJSZWNvcmRbXT4obG9hZEN1c3RvbWVycyk7XG4gIGNvbnN0IFtkb3dubG9hZHMsIHNldERvd25sb2Fkc10gPSB1c2VTdGF0ZTxEb3dubG9hZEl0ZW1bXT4obG9hZERvd25sb2Fkcyk7XG4gIGNvbnN0IFthZG1pbkJyb2FkY2FzdFRvYXN0LCBzZXRBZG1pbkJyb2FkY2FzdFRvYXN0XSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IFtzZWFyY2hRdWVyeSwgc2V0U2VhcmNoUXVlcnldID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG4gIGNvbnN0IFtpc1NpZGViYXJDb2xsYXBzZWQsIHNldElzU2lkZWJhckNvbGxhcHNlZF0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG4gIGNvbnN0IFtzaG93QXV0aE1vZGFsLCBzZXRTaG93QXV0aE1vZGFsXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW3Nob3dTaG9ydGN1dHNNb2RhbCwgc2V0U2hvd1Nob3J0Y3V0c01vZGFsXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcblxuICAvLyBMaXZlIE9wZXJhdG9yIEhlYXJ0YmVhdCBsb29wXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCF1c2VyLmlzTG9nZ2VkSW4gfHwgIXVzZXIudXNlcm5hbWUpIHJldHVybjtcblxuICAgIGNvbnN0IHJlcG9ydEhlYXJ0YmVhdCA9IGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHNlbmRPcGVyYXRvckhlYXJ0YmVhdCh7XG4gICAgICAgICAgdXNlcm5hbWU6IHVzZXIudXNlcm5hbWUsXG4gICAgICAgICAgZGlzcGxheU5hbWU6IHVzZXIuZGlzcGxheU5hbWUsXG4gICAgICAgICAgcm9sZTogdXNlci5yb2xlLFxuICAgICAgICAgIHBob25lOiB1c2VyLnBob25lLFxuICAgICAgICAgIGN1cnJlbnRUYWI6IGFjdGl2ZVRhYixcbiAgICAgICAgICBjdXJyZW50VGFzazogYEFjdGl2ZSBvbiAke2FjdGl2ZVRhYn1gXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGlmIChyZXMgJiYgcmVzLmJyb2FkY2FzdE1lc3NhZ2UpIHtcbiAgICAgICAgICBpZiAocmVzLmJyb2FkY2FzdE1lc3NhZ2UgPT09ICdGT1JDRV9ESVNDT05ORUNURURfQllfQURNSU4nKSB7XG4gICAgICAgICAgICBhbGVydCgn8J+aqCBZb3VyIHdvcmtzdGF0aW9uIHNlc3Npb24gd2FzIGRpc2Nvbm5lY3RlZCBieSBNYXN0ZXIgQWRtaW4uJyk7XG4gICAgICAgICAgICBoYW5kbGVMb2dvdXQoKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2V0QWRtaW5Ccm9hZGNhc3RUb2FzdChyZXMuYnJvYWRjYXN0TWVzc2FnZSk7XG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHNldEFkbWluQnJvYWRjYXN0VG9hc3QobnVsbCksIDgwMDApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCB7fVxuICAgIH07XG5cbiAgICByZXBvcnRIZWFydGJlYXQoKTtcbiAgICBjb25zdCBpbnRlcnZhbCA9IHNldEludGVydmFsKHJlcG9ydEhlYXJ0YmVhdCwgNTAwMCk7XG4gICAgcmV0dXJuICgpID0+IGNsZWFySW50ZXJ2YWwoaW50ZXJ2YWwpO1xuICB9LCBbdXNlci5pc0xvZ2dlZEluLCB1c2VyLnVzZXJuYW1lLCBhY3RpdmVUYWJdKTtcblxuICBjb25zdCBoYW5kbGVBZGREb3dubG9hZCA9IChuZXdEbDogRG93bmxvYWRJdGVtKSA9PiB7XG4gICAgY29uc3QgdXBkYXRlZCA9IFtuZXdEbCwgLi4uZG93bmxvYWRzXTtcbiAgICBzZXREb3dubG9hZHModXBkYXRlZCk7XG4gICAgc2F2ZURvd25sb2Fkcyh1cGRhdGVkKTtcbiAgfTtcblxuICAvLyBTeW5jIHRvIHN0b3JhZ2VcbiAgY29uc3QgaGFuZGxlU2F2ZVNldHRpbmdzID0gKG5ld1NldHRpbmdzOiBTaG9wU2V0dGluZ3MpID0+IHtcbiAgICBzZXRTZXR0aW5ncyhuZXdTZXR0aW5ncyk7XG4gICAgc2F2ZVNldHRpbmdzKG5ld1NldHRpbmdzKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVTZWxlY3RVc2VyID0gKG5ld1VzZXI6IFVzZXJBY2NvdW50KSA9PiB7XG4gICAgc2V0VXNlcihuZXdVc2VyKTtcbiAgICBzYXZlVXNlcihuZXdVc2VyKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVMb2dvdXQgPSAoKSA9PiB7XG4gICAgbG9nb3V0VXNlcigpO1xuICAgIHNldFVzZXIoe1xuICAgICAgdXNlcm5hbWU6ICcnLFxuICAgICAgZGlzcGxheU5hbWU6ICcnLFxuICAgICAgcm9sZTogJ29wZXJhdG9yJyxcbiAgICAgIHBob25lOiAnJyxcbiAgICAgIHNob3BOYW1lOiBzZXR0aW5ncy5zaG9wTmFtZSxcbiAgICAgIGlzTG9nZ2VkSW46IGZhbHNlXG4gICAgfSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQWRkQmlsbCA9IChuZXdCaWxsOiBCaWxsSXRlbSkgPT4ge1xuICAgIGNvbnN0IHVwZGF0ZWQgPSBbbmV3QmlsbCwgLi4uYmlsbHNdO1xuICAgIHNldEJpbGxzKHVwZGF0ZWQpO1xuICAgIHNhdmVCaWxscyh1cGRhdGVkKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVEZWxldGVCaWxsID0gKGlkOiBzdHJpbmcpID0+IHtcbiAgICBjb25zdCB1cGRhdGVkID0gYmlsbHMuZmlsdGVyKGIgPT4gYi5pZCAhPT0gaWQpO1xuICAgIHNldEJpbGxzKHVwZGF0ZWQpO1xuICAgIHNhdmVCaWxscyh1cGRhdGVkKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVBZGRDdXN0b21lciA9IChuZXdDdXN0b21lcjogQ3VzdG9tZXJSZWNvcmQpID0+IHtcbiAgICBjb25zdCB1cGRhdGVkID0gW25ld0N1c3RvbWVyLCAuLi5jdXN0b21lcnNdO1xuICAgIHNldEN1c3RvbWVycyh1cGRhdGVkKTtcbiAgICBzYXZlQ3VzdG9tZXJzKHVwZGF0ZWQpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVVwZGF0ZUN1c3RvbWVyU3RhdHVzID0gKGlkOiBzdHJpbmcsIG5ld1N0YXR1czogQ3VzdG9tZXJSZWNvcmRbJ3N0YXR1cyddKSA9PiB7XG4gICAgY29uc3QgdXBkYXRlZCA9IGN1c3RvbWVycy5tYXAoYyA9PiBjLmlkID09PSBpZCA/IHsgLi4uYywgc3RhdHVzOiBuZXdTdGF0dXMgfSA6IGMpO1xuICAgIHNldEN1c3RvbWVycyh1cGRhdGVkKTtcbiAgICBzYXZlQ3VzdG9tZXJzKHVwZGF0ZWQpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZURlbGV0ZUN1c3RvbWVyID0gKGlkOiBzdHJpbmcpID0+IHtcbiAgICBjb25zdCB1cGRhdGVkID0gY3VzdG9tZXJzLmZpbHRlcihjID0+IGMuaWQgIT09IGlkKTtcbiAgICBzZXRDdXN0b21lcnModXBkYXRlZCk7XG4gICAgc2F2ZUN1c3RvbWVycyh1cGRhdGVkKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVEZWxldGVEb3dubG9hZCA9IChpZDogc3RyaW5nKSA9PiB7XG4gICAgZGVsZXRlRG93bmxvYWRSZWNvcmQoaWQpO1xuICAgIHNldERvd25sb2Fkcyhsb2FkRG93bmxvYWRzKCkpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNsZWFyRG93bmxvYWRzID0gKCkgPT4ge1xuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdtb3NfcGNfZG93bmxvYWRzJyk7XG4gICAgc2V0RG93bmxvYWRzKFtdKTtcbiAgfTtcblxuICAvLyBLZXlib2FyZCBTaG9ydGN1dHMgZm9yIFBDXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgaGFuZGxlS2V5RG93biA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICAvLyBGb2N1cyBzZWFyY2g6IEN0cmwgKyBLIG9yICcvJ1xuICAgICAgaWYgKChlLmN0cmxLZXkgJiYgZS5rZXkgPT09ICdrJykgfHwgKGUua2V5ID09PSAnLycgJiYgKGUudGFyZ2V0IGFzIEhUTUxFbGVtZW50KS50YWdOYW1lICE9PSAnSU5QVVQnICYmIChlLnRhcmdldCBhcyBIVE1MRWxlbWVudCkudGFnTmFtZSAhPT0gJ1RFWFRBUkVBJykpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBjb25zdCBzZWFyY2hJbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdwYy1nbG9iYWwtc2VhcmNoJyk7XG4gICAgICAgIHNlYXJjaElucHV0Py5mb2N1cygpO1xuICAgICAgfVxuXG4gICAgICAvLyBGYXN0IEJpbGw6IEN0cmwgKyBCXG4gICAgICBpZiAoZS5jdHJsS2V5ICYmIGUua2V5ID09PSAnYicpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBzZXRBY3RpdmVUYWIoJ2JpbGxpbmcnKTtcbiAgICAgIH1cblxuICAgICAgLy8gRGlyZWN0IEluLUFwcCBTdHVkaW8gUHJpbnQ6IEN0cmwgKyBQXG4gICAgICBpZiAoZS5jdHJsS2V5ICYmIGUua2V5ID09PSAncCcpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICB3aW5kb3cuZGlzcGF0Y2hFdmVudChuZXcgQ3VzdG9tRXZlbnQoJ2FwcC1kaXJlY3QtcHJpbnQnKSk7XG4gICAgICB9XG5cbiAgICAgIC8vIERpcmVjdCBJbi1BcHAgUERGIERvd25sb2FkOiBDdHJsICsgU1xuICAgICAgaWYgKGUuY3RybEtleSAmJiBlLmtleSA9PT0gJ3MnKSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgd2luZG93LmRpc3BhdGNoRXZlbnQobmV3IEN1c3RvbUV2ZW50KCdhcHAtZGlyZWN0LXBkZicpKTtcbiAgICAgIH1cblxuICAgICAgLy8gRGlyZWN0IEluLUFwcCBIRCBKUEcgRG93bmxvYWQ6IEN0cmwgKyBKXG4gICAgICBpZiAoZS5jdHJsS2V5ICYmIGUua2V5ID09PSAnaicpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICB3aW5kb3cuZGlzcGF0Y2hFdmVudChuZXcgQ3VzdG9tRXZlbnQoJ2FwcC1kaXJlY3QtanBnJykpO1xuICAgICAgfVxuXG4gICAgICAvLyBUYWIgc3dpdGNoZXI6IEFsdCArIDEgdG8gOVxuICAgICAgaWYgKGUuYWx0S2V5KSB7XG4gICAgICAgIGNvbnN0IHRhYk1hcDogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcbiAgICAgICAgICAnMSc6ICdkYXNoYm9hcmQnLFxuICAgICAgICAgICcyJzogJ3B2Y19zdHVkaW8nLFxuICAgICAgICAgICczJzogJ3Bhc3Nwb3J0X3N0dWRpbycsXG4gICAgICAgICAgJzQnOiAncGRmX3RvX2pwZycsXG4gICAgICAgICAgJzUnOiAnYmlsbGluZycsXG4gICAgICAgICAgJzYnOiAnY3VzdG9tZXJzJyxcbiAgICAgICAgICAnNyc6ICdiaW9kYXRhX21ha2VyJyxcbiAgICAgICAgICAnOCc6ICdwb3J0YWxzJyxcbiAgICAgICAgICAnOSc6ICdhaV9hc3Npc3RhbnQnXG4gICAgICAgIH07XG4gICAgICAgIGlmICh0YWJNYXBbZS5rZXldKSB7XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIHNldEFjdGl2ZVRhYih0YWJNYXBbZS5rZXldKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBTaG9ydGN1dHMgTW9kYWw6ICc/J1xuICAgICAgaWYgKGUua2V5ID09PSAnPycgJiYgKGUudGFyZ2V0IGFzIEhUTUxFbGVtZW50KS50YWdOYW1lICE9PSAnSU5QVVQnICYmIChlLnRhcmdldCBhcyBIVE1MRWxlbWVudCkudGFnTmFtZSAhPT0gJ1RFWFRBUkVBJykge1xuICAgICAgICBzZXRTaG93U2hvcnRjdXRzTW9kYWwodHJ1ZSk7XG4gICAgICB9XG5cbiAgICAgIC8vIEVzY2FwZSB0byBjbG9zZSBtb2RhbHNcbiAgICAgIGlmIChlLmtleSA9PT0gJ0VzY2FwZScpIHtcbiAgICAgICAgc2V0U2hvd0F1dGhNb2RhbChmYWxzZSk7XG4gICAgICAgIHNldFNob3dTaG9ydGN1dHNNb2RhbChmYWxzZSk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93bik7XG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93bik7XG4gIH0sIFtdKTtcblxuICAvLyBXaGVuIGdsb2JhbCBzZWFyY2ggaXMgdHlwZWQsIGF1dG9tYXRpY2FsbHkgc3dpdGNoIHRvIHBvcnRhbHMgb3Igc2hvdyBtYXRjaGVzIGlmIG5vdCBlbXB0eVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChzZWFyY2hRdWVyeS50cmltKCkubGVuZ3RoID4gMSAmJiBhY3RpdmVUYWIgIT09ICdwb3J0YWxzJyAmJiBhY3RpdmVUYWIgIT09ICdkYXNoYm9hcmQnKSB7XG4gICAgICBzZXRBY3RpdmVUYWIoJ3BvcnRhbHMnKTtcbiAgICB9XG4gIH0sIFtzZWFyY2hRdWVyeV0pO1xuXG4gIGNvbnN0IHBlbmRpbmdKb2JzQ291bnQgPSBjdXN0b21lcnMuZmlsdGVyKGMgPT4gYy5zdGF0dXMgPT09ICdQZW5kaW5nJyB8fCBjLnN0YXR1cyA9PT0gJ1Byb2Nlc3NpbmcnKS5sZW5ndGg7XG5cbiAgLy8gU1RSSUNUIExPR0lOIFdBTEw6IE5vdGhpbmcgd29ya3Mgb3IgZGlzcGxheXMgd2l0aG91dCBhdXRoZW50aWNhdGlvbiFcbiAgaWYgKCF1c2VyLmlzTG9nZ2VkSW4pIHtcbiAgICByZXR1cm4gKFxuICAgICAgPExvZ2luU2NyZWVuXG4gICAgICAgIHNldHRpbmdzPXtzZXR0aW5nc31cbiAgICAgICAgb25Mb2dpblN1Y2Nlc3M9e2hhbmRsZVNlbGVjdFVzZXJ9XG4gICAgICAvPlxuICAgICk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBoLXNjcmVlbiB3LXNjcmVlbiBiZy1zbGF0ZS05NTAgdGV4dC1zbGF0ZS0xMDAgb3ZlcmZsb3ctaGlkZGVuIGZvbnQtc2FucyBzZWxlY3Rpb246YmctYmx1ZS02MDAgc2VsZWN0aW9uOnRleHQtd2hpdGVcIj5cbiAgICAgIHsvKiBQQyBUb3AgTmF2aWdhdGlvbiBIZWFkZXIgKi99XG4gICAgICA8SGVhZGVyXG4gICAgICAgIHNldHRpbmdzPXtzZXR0aW5nc31cbiAgICAgICAgdXNlcj17dXNlcn1cbiAgICAgICAgYWN0aXZlVGFiPXthY3RpdmVUYWJ9XG4gICAgICAgIG9uTmF2aWdhdGU9eyh0YWIpID0+IHtcbiAgICAgICAgICBzZXRBY3RpdmVUYWIodGFiKTtcbiAgICAgICAgICBzZXRTZWFyY2hRdWVyeSgnJyk7XG4gICAgICAgIH19XG4gICAgICAgIG9uT3BlbkxvZ2luPXsoKSA9PiBzZXRTaG93QXV0aE1vZGFsKHRydWUpfVxuICAgICAgICBvbk9wZW5TaG9ydGN1dHM9eygpID0+IHNldFNob3dTaG9ydGN1dHNNb2RhbCh0cnVlKX1cbiAgICAgICAgb25Mb2dvdXQ9e2hhbmRsZUxvZ291dH1cbiAgICAgICAgc2VhcmNoUXVlcnk9e3NlYXJjaFF1ZXJ5fVxuICAgICAgICBvblNlYXJjaENoYW5nZT17c2V0U2VhcmNoUXVlcnl9XG4gICAgICAgIGlzU2lkZWJhckNvbGxhcHNlZD17aXNTaWRlYmFyQ29sbGFwc2VkfVxuICAgICAgICBvblRvZ2dsZVNpZGViYXI9eygpID0+IHNldElzU2lkZWJhckNvbGxhcHNlZChwcmV2ID0+ICFwcmV2KX1cbiAgICAgIC8+XG5cbiAgICAgIHsvKiBNYWluIENvbnRhaW5lcjogU2lkZWJhciArIFdvcmtzcGFjZSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LTEgb3ZlcmZsb3ctaGlkZGVuIHJlbGF0aXZlXCI+XG4gICAgICAgIHsvKiBQQyBTaWRlYmFyIE5hdmlnYXRpb24gKi99XG4gICAgICAgIDxTaWRlYmFyXG4gICAgICAgICAgYWN0aXZlVGFiPXthY3RpdmVUYWJ9XG4gICAgICAgICAgb25OYXZpZ2F0ZT17KHRhYikgPT4ge1xuICAgICAgICAgICAgc2V0QWN0aXZlVGFiKHRhYik7XG4gICAgICAgICAgICBzZXRTZWFyY2hRdWVyeSgnJyk7XG4gICAgICAgICAgfX1cbiAgICAgICAgICBpc0NvbGxhcHNlZD17aXNTaWRlYmFyQ29sbGFwc2VkfVxuICAgICAgICAgIG9uVG9nZ2xlQ29sbGFwc2U9eygpID0+IHNldElzU2lkZWJhckNvbGxhcHNlZChwcmV2ID0+ICFwcmV2KX1cbiAgICAgICAgICB1c2VyPXt1c2VyfVxuICAgICAgICAgIHBlbmRpbmdKb2JzQ291bnQ9e3BlbmRpbmdKb2JzQ291bnR9XG4gICAgICAgICAgb25Mb2dvdXQ9e2hhbmRsZUxvZ291dH1cbiAgICAgICAgLz5cblxuICAgICAgICB7LyogTWFpbiBXb3Jrc3RhdGlvbiBWaWV3IEFyZWEgKi99XG4gICAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG8gcC00IGxnOnAtNiBiZy1zbGF0ZS05NTAgcmVsYXRpdmVcIj5cbiAgICAgICAgICB7LyogQWRtaW4gTGl2ZSBCcm9hZGNhc3QgVG9hc3QgKi99XG4gICAgICAgICAge2FkbWluQnJvYWRjYXN0VG9hc3QgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi00IHAtNCByb3VuZGVkLTJ4bCBiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS02MDAgdG8taW5kaWdvLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgYW5pbWF0ZS1pbiBmYWRlLWluIHNsaWRlLWluLWZyb20tdG9wLTQgei0zMFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bFwiPvCfk6I8L3NwYW4+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQteHMgYmxvY2sgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtYmx1ZS0yMDBcIj5Ccm9hZGNhc3QgZnJvbSBNYXN0ZXIgQWRtaW46PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkXCI+e2FkbWluQnJvYWRjYXN0VG9hc3R9PC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBZG1pbkJyb2FkY2FzdFRvYXN0KG51bGwpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtd2hpdGUvODAgaG92ZXI6dGV4dC13aGl0ZSBweC0yIHB5LTEgYmctd2hpdGUvMTAgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBEaXNtaXNzXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdkYXNoYm9hcmQnICYmIChcbiAgICAgICAgICAgIDxEYXNoYm9hcmRWaWV3XG4gICAgICAgICAgICAgIGJpbGxzPXtiaWxsc31cbiAgICAgICAgICAgICAgY3VzdG9tZXJzPXtjdXN0b21lcnN9XG4gICAgICAgICAgICAgIHNldHRpbmdzPXtzZXR0aW5nc31cbiAgICAgICAgICAgICAgb25OYXZpZ2F0ZT17c2V0QWN0aXZlVGFifVxuICAgICAgICAgICAgICBvbk9wZW5RdWlja0JpbGw9eygpID0+IHNldEFjdGl2ZVRhYignYmlsbGluZycpfVxuICAgICAgICAgICAgICBvblByaW50QmlsbD17KCkgPT4gc2V0QWN0aXZlVGFiKCdiaWxsaW5nJyl9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7YWN0aXZlVGFiID09PSAncHZjX3N0dWRpbycgJiYgKFxuICAgICAgICAgICAgPFB2Y1N0dWRpb1ZpZXcgLz5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ3Bhc3Nwb3J0X3N0dWRpbycgJiYgKFxuICAgICAgICAgICAgPFBhc3Nwb3J0U3R1ZGlvVmlldyAvPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7YWN0aXZlVGFiID09PSAndmlkZW9fc3R1ZGlvJyAmJiAoXG4gICAgICAgICAgICA8VmlkZW9TdHVkaW9WaWV3IFxuICAgICAgICAgICAgICBvbkFkZERvd25sb2FkPXtoYW5kbGVBZGREb3dubG9hZH1cbiAgICAgICAgICAgICAgb25OYXZpZ2F0ZT17c2V0QWN0aXZlVGFifVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ3BkZl90b19qcGcnICYmIChcbiAgICAgICAgICAgIDxQZGZUb0pwZ1ZpZXcgLz5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ2JpbGxpbmcnICYmIChcbiAgICAgICAgICAgIDxCaWxsaW5nRGVza1ZpZXdcbiAgICAgICAgICAgICAgYmlsbHM9e2JpbGxzfVxuICAgICAgICAgICAgICBzZXR0aW5ncz17c2V0dGluZ3N9XG4gICAgICAgICAgICAgIG9uQWRkQmlsbD17aGFuZGxlQWRkQmlsbH1cbiAgICAgICAgICAgICAgb25EZWxldGVCaWxsPXtoYW5kbGVEZWxldGVCaWxsfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ2N1c3RvbWVycycgJiYgKFxuICAgICAgICAgICAgPEN1c3RvbWVyQ3JtVmlld1xuICAgICAgICAgICAgICBjdXN0b21lcnM9e2N1c3RvbWVyc31cbiAgICAgICAgICAgICAgc2V0dGluZ3M9e3NldHRpbmdzfVxuICAgICAgICAgICAgICBvbkFkZEN1c3RvbWVyPXtoYW5kbGVBZGRDdXN0b21lcn1cbiAgICAgICAgICAgICAgb25VcGRhdGVTdGF0dXM9e2hhbmRsZVVwZGF0ZUN1c3RvbWVyU3RhdHVzfVxuICAgICAgICAgICAgICBvbkRlbGV0ZUN1c3RvbWVyPXtoYW5kbGVEZWxldGVDdXN0b21lcn1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdiaW9kYXRhX21ha2VyJyAmJiAoXG4gICAgICAgICAgICA8QmlvRGF0YU1ha2VyVmlldyAvPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7YWN0aXZlVGFiID09PSAnd29ya2Zsb3cnICYmIChcbiAgICAgICAgICAgIDxXb3JrZmxvd0d1aWRlVmlldyBvbk5hdmlnYXRlPXtzZXRBY3RpdmVUYWJ9IC8+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdtYXN0ZXJfYWRtaW4nICYmIChcbiAgICAgICAgICAgIHVzZXIucm9sZSA9PT0gJ2FkbWluJyA/IChcbiAgICAgICAgICAgICAgPE1hc3RlckFkbWluVmlld1xuICAgICAgICAgICAgICAgIHNldHRpbmdzPXtzZXR0aW5nc31cbiAgICAgICAgICAgICAgICBvblVwZGF0ZVNldHRpbmdzPXtoYW5kbGVTYXZlU2V0dGluZ3N9XG4gICAgICAgICAgICAgICAgb25OYXZpZ2F0ZVRvV29ya2Zsb3c9eygpID0+IHNldEFjdGl2ZVRhYignd29ya2Zsb3cnKX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctbWQgbXgtYXV0byB0ZXh0LWNlbnRlciBwLTggYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtM3hsIG10LTEyIHNwYWNlLXktMyBzaGFkb3ctMnhsXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgYmctcm9zZS01MDAvMjAgdGV4dC1yb3NlLTQwMCByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvIHRleHQtMnhsIGZvbnQtYm9sZCBib3JkZXIgYm9yZGVyLXJvc2UtNTAwLzMwXCI+XG4gICAgICAgICAgICAgICAgICDwn5SSXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlXCI+TWFzdGVyIEFkbWluIFJlc3RyaWN0ZWQgQWNjZXNzPC9oMz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgQWNjZXNzIERlbmllZC4gVGhlIHByb2plY3Qgc291cmNlIC5aSVAgYXJjaGl2ZSwgZXhlY3V0YWJsZSBzZXR1cCBidWlsZGVyLCBhbmQgY2VudHJhbCBzZWN1cml0eSBjb250cm9scyBhcmUgc3RyaWN0bHkgcmVzZXJ2ZWQgZm9yIE1hc3RlciBBZG1pbiAoSW1yYW4gS2hhbikuIFN0YWZmIG9wZXJhdG9ycyBvciBjdXN0b21lcnMgY2Fubm90IHZpZXcgb3IgZG93bmxvYWQgdGhpcyBkYXRhLlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApXG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdwb3J0YWxzJyAmJiAoXG4gICAgICAgICAgICA8R292ZXJubWVudFBvcnRhbHNWaWV3IFxuICAgICAgICAgICAgICBvbkFkZERvd25sb2FkPXtoYW5kbGVBZGREb3dubG9hZH1cbiAgICAgICAgICAgICAgb25OYXZpZ2F0ZT17c2V0QWN0aXZlVGFifVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ2FpX2Fzc2lzdGFudCcgJiYgKFxuICAgICAgICAgICAgPEFpQXNzaXN0YW50VmlldyAvPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7YWN0aXZlVGFiID09PSAnZG93bmxvYWRzJyAmJiAoXG4gICAgICAgICAgICA8RG93bmxvYWRzVmlld1xuICAgICAgICAgICAgICBkb3dubG9hZHM9e2Rvd25sb2Fkc31cbiAgICAgICAgICAgICAgb25EZWxldGVEb3dubG9hZD17aGFuZGxlRGVsZXRlRG93bmxvYWR9XG4gICAgICAgICAgICAgIG9uQ2xlYXJBbGw9e2hhbmRsZUNsZWFyRG93bmxvYWRzfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ3NldHRpbmdzJyAmJiAoXG4gICAgICAgICAgICA8U2V0dGluZ3NWaWV3XG4gICAgICAgICAgICAgIHNldHRpbmdzPXtzZXR0aW5nc31cbiAgICAgICAgICAgICAgb25TYXZlU2V0dGluZ3M9e2hhbmRsZVNhdmVTZXR0aW5nc31cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdiYWNrdXAnICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctMnhsIG14LWF1dG8gc3BhY2UteS00IHB0LTZcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcC02IHJvdW5kZWQtM3hsIHNoYWRvdy14bCB0ZXh0LWNlbnRlciBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiByb3VuZGVkLTJ4bCBiZy1wdXJwbGUtNjAwLzIwIGJvcmRlciBib3JkZXItcHVycGxlLTUwMC8zMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXB1cnBsZS00MDAgbXgtYXV0b1wiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0zeGxcIj7wn5K+PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+RnVsbCBTdGF0aW9uIERhdGEgQmFja3VwPC9oMj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIGxlYWRpbmctcmVsYXhlZCBtYXgtdy1tZCBteC1hdXRvXCI+XG4gICAgICAgICAgICAgICAgICBFeHBvcnQgYWxsIHlvdXIgYmlsbHMgKHtiaWxscy5sZW5ndGh9KSwgY3VzdG9tZXIgcmVjb3JkcyAoe2N1c3RvbWVycy5sZW5ndGh9KSwgc2V0dGluZ3MsIGFuZCByZWNlbnQgZG93bmxvYWQgbG9ncyBpbnRvIGEgc2luZ2xlIHNlY3VyZSBmaWxlLlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTMgcHQtMlwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtleHBvcnRBbGxEYXRhfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1wdXJwbGUtNjAwIGhvdmVyOmJnLXB1cnBsZS01MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14cyBweC01IHB5LTIuNSByb3VuZGVkLXhsIHNoYWRvdy1sZyBzaGFkb3ctcHVycGxlLTYwMC8zMCB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzY2FsZS0xMDVcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBEb3dubG9hZCBDb21wbGV0ZSBCYWNrdXAgSlNPTlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9tYWluPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBBdXRoIE1vZGFsICovfVxuICAgICAge3Nob3dBdXRoTW9kYWwgJiYgKFxuICAgICAgICA8QXV0aE1vZGFsXG4gICAgICAgICAgY3VycmVudFVzZXI9e3VzZXJ9XG4gICAgICAgICAgb25TZWxlY3RVc2VyPXtoYW5kbGVTZWxlY3RVc2VyfVxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dBdXRoTW9kYWwoZmFsc2UpfVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAgey8qIFNob3J0Y3V0cyBNb2RhbCAqL31cbiAgICAgIHtzaG93U2hvcnRjdXRzTW9kYWwgJiYgKFxuICAgICAgICA8U2hvcnRjdXRzTW9kYWxcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaG93U2hvcnRjdXRzTW9kYWwoZmFsc2UpfVxuICAgICAgICAvPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdfQ==