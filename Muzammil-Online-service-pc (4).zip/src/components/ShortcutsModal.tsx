const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { X, Keyboard, Mouse, Zap } from "/node_modules/.vite/deps/lucide-react.js?v=090625a0";
var _jsxFileName = "/app/applet/src/components/ShortcutsModal.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
export const ShortcutsModal = ({ onClose }) => {
	const keyboardShortcuts = [
		{
			key: "Ctrl + P",
			desc: "Direct print active sheet / PVC card / invoice (zero popup blocker)"
		},
		{
			key: "Ctrl + B",
			desc: "Fast Billing Desk & POS"
		},
		{
			key: "Ctrl + K or /",
			desc: "Focus global search bar (all 50+ portals)"
		},
		{
			key: "Ctrl + Z",
			desc: "Undo last point in Passport Pen Tool"
		},
		{
			key: "Ctrl + S",
			desc: "Download printable 300 DPI PDF"
		},
		{
			key: "Ctrl + J",
			desc: "Download HD JPG"
		},
		{
			key: "Alt + 1",
			desc: "Go to Dashboard & Daily Summary"
		},
		{
			key: "Alt + 2",
			desc: "Go to PVC Smart Card Studio (CR-80)"
		},
		{
			key: "Alt + 3",
			desc: "Go to Passport Photo Studio"
		},
		{
			key: "Alt + 4",
			desc: "Go to PDF to JPG Converter"
		},
		{
			key: "Alt + 5",
			desc: "Go to Fast Billing Desk"
		},
		{
			key: "Alt + 6",
			desc: "Go to Customer CRM & Job Tracker"
		},
		{
			key: "Alt + 7",
			desc: "Go to CV & BioData Maker"
		},
		{
			key: "Alt + 8",
			desc: "Go to Govt Portals Hub"
		},
		{
			key: "Alt + 9",
			desc: "Go to AI Scheme Assistant"
		},
		{
			key: "F11",
			desc: "Toggle Fullscreen PC Station Mode"
		},
		{
			key: "Esc",
			desc: "Close dialogs / Cancel Pen tool path"
		}
	];
	const mouseControls = [
		{
			action: "Left Click (Pen Tool)",
			desc: "Place anchor points around person to trace cutout"
		},
		{
			action: "Click First Point (Pen Tool)",
			desc: "Close polygon loop and preview studio background"
		},
		{
			action: "Mouse Drag (Canvas)",
			desc: "Pan image or reposition cards on sheet"
		},
		{
			action: "Mouse Wheel / Pinch",
			desc: "Zoom in / out on photo for precision tracing"
		},
		{
			action: "Right Click (Pen Tool)",
			desc: "Delete nearest anchor point"
		}
	];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between border-b border-slate-800 pb-3",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400",
							children: /* @__PURE__ */ _jsxDEV(Keyboard, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 43,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 42,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "font-extrabold text-white text-base",
							children: "PC Keyboard & Mouse Shortcuts"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: "High-speed operator hotkeys for Muzammil Online Service"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 47,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 45,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800",
						children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 40,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[65vh] overflow-y-auto pr-1",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1.5 text-xs font-bold text-blue-400 uppercase tracking-wider pb-1",
							children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 59,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Keyboard Hotkeys" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 60,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 58,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1.5",
							children: keyboardShortcuts.map((sc, i) => /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between p-2 rounded-xl bg-slate-950 border border-slate-800/80 text-xs",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-300 font-medium truncate pr-2",
									children: sc.desc
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 68,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("kbd", {
									className: "px-2 py-0.5 bg-slate-800 text-blue-300 font-mono font-bold rounded-lg border border-slate-700 shadow-sm text-[11px] whitespace-nowrap flex-shrink-0",
									children: sc.key
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 69,
									columnNumber: 19
								}, this)]
							}, i, true, {
								fileName: _jsxFileName,
								lineNumber: 64,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 62,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1.5 text-xs font-bold text-purple-400 uppercase tracking-wider pb-1",
								children: [/* @__PURE__ */ _jsxDEV(Mouse, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 80,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Mouse & Pen Tool Controls" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 81,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 79,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-1.5",
								children: mouseControls.map((mc, i) => /* @__PURE__ */ _jsxDEV("div", {
									className: "p-2 rounded-xl bg-slate-950 border border-slate-800/80 text-xs space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "font-bold text-purple-300 font-mono text-[11px]",
										children: mc.action
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 89,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-slate-400 text-[11px] leading-snug",
										children: mc.desc
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 90,
										columnNumber: 19
									}, this)]
								}, i, true, {
									fileName: _jsxFileName,
									lineNumber: 85,
									columnNumber: 17
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 rounded-2xl bg-blue-600/10 border border-blue-500/20 text-xs text-slate-300 space-y-1 mt-3",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "font-bold text-white block",
									children: "💡 Studio Tip:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 96,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-400",
									children: [
										"Passport Photo Studio mein ",
										/* @__PURE__ */ _jsxDEV("b", { children: "Pen Tool" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 98,
											columnNumber: 44
										}, this),
										" se points lagakar kisi bhi photo ka background direct change karein. Live Dual Preview se cut ki hui photo ka preview saath-saath dekhein!"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 97,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "pt-2 border-t border-slate-800 flex items-center justify-between",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs text-slate-500 font-mono",
						children: "Press ? anytime to open this guide"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-105",
						children: "Got It (Esc)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 106,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 104,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 38,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsR0FBRyxVQUFVLE9BQTBCLFdBQVc7OztBQU0zRCxPQUFPLE1BQU0sa0JBQWlELEVBQUUsY0FBYztDQUM1RSxNQUFNLG9CQUFvQjtFQUN4QjtHQUFFLEtBQUs7R0FBWSxNQUFNO0VBQXNFO0VBQy9GO0dBQUUsS0FBSztHQUFZLE1BQU07RUFBMEI7RUFDbkQ7R0FBRSxLQUFLO0dBQWlCLE1BQU07RUFBNEM7RUFDMUU7R0FBRSxLQUFLO0dBQVksTUFBTTtFQUF1QztFQUNoRTtHQUFFLEtBQUs7R0FBWSxNQUFNO0VBQWlDO0VBQzFEO0dBQUUsS0FBSztHQUFZLE1BQU07RUFBa0I7RUFDM0M7R0FBRSxLQUFLO0dBQVcsTUFBTTtFQUFrQztFQUMxRDtHQUFFLEtBQUs7R0FBVyxNQUFNO0VBQXNDO0VBQzlEO0dBQUUsS0FBSztHQUFXLE1BQU07RUFBOEI7RUFDdEQ7R0FBRSxLQUFLO0dBQVcsTUFBTTtFQUE2QjtFQUNyRDtHQUFFLEtBQUs7R0FBVyxNQUFNO0VBQTBCO0VBQ2xEO0dBQUUsS0FBSztHQUFXLE1BQU07RUFBbUM7RUFDM0Q7R0FBRSxLQUFLO0dBQVcsTUFBTTtFQUEyQjtFQUNuRDtHQUFFLEtBQUs7R0FBVyxNQUFNO0VBQXlCO0VBQ2pEO0dBQUUsS0FBSztHQUFXLE1BQU07RUFBNEI7RUFDcEQ7R0FBRSxLQUFLO0dBQU8sTUFBTTtFQUFvQztFQUN4RDtHQUFFLEtBQUs7R0FBTyxNQUFNO0VBQXVDO0NBQzdEO0NBRUEsTUFBTSxnQkFBZ0I7RUFDcEI7R0FBRSxRQUFRO0dBQXlCLE1BQU07RUFBb0Q7RUFDN0Y7R0FBRSxRQUFRO0dBQWdDLE1BQU07RUFBbUQ7RUFDbkc7R0FBRSxRQUFRO0dBQXVCLE1BQU07RUFBeUM7RUFDaEY7R0FBRSxRQUFRO0dBQXVCLE1BQU07RUFBK0M7RUFDdEY7R0FBRSxRQUFRO0dBQTBCLE1BQU07RUFBOEI7Q0FDMUU7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFVBQVc7Ozs7O01BQzVCOzs7O2dCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBc0M7TUFBaUM7Ozs7Z0JBQ3JGLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUF5QjtNQUEwRDs7OztjQUM3Rjs7OztjQUNGOzs7OztlQUNMLHdCQUFDLFVBQUQ7TUFBUSxTQUFTO01BQVMsV0FBVTtnQkFDbEMsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7S0FDbEI7Ozs7YUFDTDs7Ozs7O0lBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUVFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxLQUFELEVBQUssV0FBVSxjQUFlOzs7O2lCQUM5Qix3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7O2VBQ3pCOzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWixrQkFBa0IsS0FBSyxJQUFJLE1BQzFCLHdCQUFDLE9BQUQ7UUFFRSxXQUFVO2tCQUZaLENBSUUsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQTRDLEdBQUc7UUFBVzs7OztrQkFDMUUsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ1osR0FBRztRQUNEOzs7O2dCQUNGO1VBUEU7Ozs7Y0FPRixDQUNOO01BQ0U7Ozs7Y0FDRjs7Ozs7ZUFHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsY0FBZTs7OztrQkFDaEMsd0JBQUMsUUFBRCxZQUFNLDRCQUErQjs7OztnQkFDbEM7Ozs7OztPQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaLGNBQWMsS0FBSyxJQUFJLE1BQ3RCLHdCQUFDLE9BQUQ7U0FFRSxXQUFVO21CQUZaLENBSUUsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQW1ELEdBQUc7U0FBWTs7OzttQkFDakYsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQTJDLEdBQUc7U0FBVTs7OztpQkFDcEU7V0FMRTs7OztlQUtGLENBQ047T0FDRTs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUE2QjtRQUFvQjs7OztrQkFDakUsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWI7VUFBMEM7VUFDYix3QkFBQyxLQUFELFlBQUcsV0FBVzs7Ozs7VUFBQztTQUN6Qzs7Ozs7Z0JBQ0E7Ozs7OztNQUNGOzs7OzthQUNGOzs7Ozs7SUFFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQW1DO0tBQXdDOzs7O2VBQzNGLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFDWDtLQUVPOzs7O2FBQ0w7Ozs7OztHQUNGOzs7Ozs7Q0FDRjs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTaG9ydGN1dHNNb2RhbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFgsIEtleWJvYXJkLCBNb3VzZSwgU3BhcmtsZXMsIFByaW50ZXIsIFphcCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5cbmludGVyZmFjZSBTaG9ydGN1dHNNb2RhbFByb3BzIHtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IFNob3J0Y3V0c01vZGFsOiBSZWFjdC5GQzxTaG9ydGN1dHNNb2RhbFByb3BzPiA9ICh7IG9uQ2xvc2UgfSkgPT4ge1xuICBjb25zdCBrZXlib2FyZFNob3J0Y3V0cyA9IFtcbiAgICB7IGtleTogJ0N0cmwgKyBQJywgZGVzYzogJ0RpcmVjdCBwcmludCBhY3RpdmUgc2hlZXQgLyBQVkMgY2FyZCAvIGludm9pY2UgKHplcm8gcG9wdXAgYmxvY2tlciknIH0sXG4gICAgeyBrZXk6ICdDdHJsICsgQicsIGRlc2M6ICdGYXN0IEJpbGxpbmcgRGVzayAmIFBPUycgfSxcbiAgICB7IGtleTogJ0N0cmwgKyBLIG9yIC8nLCBkZXNjOiAnRm9jdXMgZ2xvYmFsIHNlYXJjaCBiYXIgKGFsbCA1MCsgcG9ydGFscyknIH0sXG4gICAgeyBrZXk6ICdDdHJsICsgWicsIGRlc2M6ICdVbmRvIGxhc3QgcG9pbnQgaW4gUGFzc3BvcnQgUGVuIFRvb2wnIH0sXG4gICAgeyBrZXk6ICdDdHJsICsgUycsIGRlc2M6ICdEb3dubG9hZCBwcmludGFibGUgMzAwIERQSSBQREYnIH0sXG4gICAgeyBrZXk6ICdDdHJsICsgSicsIGRlc2M6ICdEb3dubG9hZCBIRCBKUEcnIH0sXG4gICAgeyBrZXk6ICdBbHQgKyAxJywgZGVzYzogJ0dvIHRvIERhc2hib2FyZCAmIERhaWx5IFN1bW1hcnknIH0sXG4gICAgeyBrZXk6ICdBbHQgKyAyJywgZGVzYzogJ0dvIHRvIFBWQyBTbWFydCBDYXJkIFN0dWRpbyAoQ1ItODApJyB9LFxuICAgIHsga2V5OiAnQWx0ICsgMycsIGRlc2M6ICdHbyB0byBQYXNzcG9ydCBQaG90byBTdHVkaW8nIH0sXG4gICAgeyBrZXk6ICdBbHQgKyA0JywgZGVzYzogJ0dvIHRvIFBERiB0byBKUEcgQ29udmVydGVyJyB9LFxuICAgIHsga2V5OiAnQWx0ICsgNScsIGRlc2M6ICdHbyB0byBGYXN0IEJpbGxpbmcgRGVzaycgfSxcbiAgICB7IGtleTogJ0FsdCArIDYnLCBkZXNjOiAnR28gdG8gQ3VzdG9tZXIgQ1JNICYgSm9iIFRyYWNrZXInIH0sXG4gICAgeyBrZXk6ICdBbHQgKyA3JywgZGVzYzogJ0dvIHRvIENWICYgQmlvRGF0YSBNYWtlcicgfSxcbiAgICB7IGtleTogJ0FsdCArIDgnLCBkZXNjOiAnR28gdG8gR292dCBQb3J0YWxzIEh1YicgfSxcbiAgICB7IGtleTogJ0FsdCArIDknLCBkZXNjOiAnR28gdG8gQUkgU2NoZW1lIEFzc2lzdGFudCcgfSxcbiAgICB7IGtleTogJ0YxMScsIGRlc2M6ICdUb2dnbGUgRnVsbHNjcmVlbiBQQyBTdGF0aW9uIE1vZGUnIH0sXG4gICAgeyBrZXk6ICdFc2MnLCBkZXNjOiAnQ2xvc2UgZGlhbG9ncyAvIENhbmNlbCBQZW4gdG9vbCBwYXRoJyB9XG4gIF07XG5cbiAgY29uc3QgbW91c2VDb250cm9scyA9IFtcbiAgICB7IGFjdGlvbjogJ0xlZnQgQ2xpY2sgKFBlbiBUb29sKScsIGRlc2M6ICdQbGFjZSBhbmNob3IgcG9pbnRzIGFyb3VuZCBwZXJzb24gdG8gdHJhY2UgY3V0b3V0JyB9LFxuICAgIHsgYWN0aW9uOiAnQ2xpY2sgRmlyc3QgUG9pbnQgKFBlbiBUb29sKScsIGRlc2M6ICdDbG9zZSBwb2x5Z29uIGxvb3AgYW5kIHByZXZpZXcgc3R1ZGlvIGJhY2tncm91bmQnIH0sXG4gICAgeyBhY3Rpb246ICdNb3VzZSBEcmFnIChDYW52YXMpJywgZGVzYzogJ1BhbiBpbWFnZSBvciByZXBvc2l0aW9uIGNhcmRzIG9uIHNoZWV0JyB9LFxuICAgIHsgYWN0aW9uOiAnTW91c2UgV2hlZWwgLyBQaW5jaCcsIGRlc2M6ICdab29tIGluIC8gb3V0IG9uIHBob3RvIGZvciBwcmVjaXNpb24gdHJhY2luZycgfSxcbiAgICB7IGFjdGlvbjogJ1JpZ2h0IENsaWNrIChQZW4gVG9vbCknLCBkZXNjOiAnRGVsZXRlIG5lYXJlc3QgYW5jaG9yIHBvaW50JyB9XG4gIF07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svODUgYmFja2Ryb3AtYmx1ci1zbSB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgbWF4LXctMnhsIHctZnVsbCBwLTYgc2hhZG93LTJ4bCBzcGFjZS15LTUgYW5pbWF0ZS1pbiBmYWRlLWluIHpvb20taW4tOTVcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwYi0zXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLXhsIGJnLWJsdWUtNjAwLzIwIGJvcmRlciBib3JkZXItYmx1ZS01MDAvMzAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1ibHVlLTQwMFwiPlxuICAgICAgICAgICAgICA8S2V5Ym9hcmQgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIHRleHQtYmFzZVwiPlBDIEtleWJvYXJkICYgTW91c2UgU2hvcnRjdXRzPC9oMz5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPkhpZ2gtc3BlZWQgb3BlcmF0b3IgaG90a2V5cyBmb3IgTXV6YW1taWwgT25saW5lIFNlcnZpY2U8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQ2xvc2V9IGNsYXNzTmFtZT1cInAtMS41IHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUgcm91bmRlZC1sZyBob3ZlcjpiZy1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTQgbWF4LWgtWzY1dmhdIG92ZXJmbG93LXktYXV0byBwci0xXCI+XG4gICAgICAgICAgey8qIEtleWJvYXJkIFNob3J0Y3V0cyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQteHMgZm9udC1ib2xkIHRleHQtYmx1ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHBiLTFcIj5cbiAgICAgICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPktleWJvYXJkIEhvdGtleXM8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAge2tleWJvYXJkU2hvcnRjdXRzLm1hcCgoc2MsIGkpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICBrZXk9e2l9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcC0yIHJvdW5kZWQteGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwLzgwIHRleHQteHNcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwIGZvbnQtbWVkaXVtIHRydW5jYXRlIHByLTJcIj57c2MuZGVzY308L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8a2JkIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IGJnLXNsYXRlLTgwMCB0ZXh0LWJsdWUtMzAwIGZvbnQtbW9ubyBmb250LWJvbGQgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBzaGFkb3ctc20gdGV4dC1bMTFweF0gd2hpdGVzcGFjZS1ub3dyYXAgZmxleC1zaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICB7c2Mua2V5fVxuICAgICAgICAgICAgICAgICAgPC9rYmQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogTW91c2UgQ29udHJvbHMgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXB1cnBsZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHBiLTFcIj5cbiAgICAgICAgICAgICAgPE1vdXNlIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+TW91c2UgJiBQZW4gVG9vbCBDb250cm9sczwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICB7bW91c2VDb250cm9scy5tYXAoKG1jLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAga2V5PXtpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQteGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwLzgwIHRleHQteHMgc3BhY2UteS0xXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXB1cnBsZS0zMDAgZm9udC1tb25vIHRleHQtWzExcHhdXCI+e21jLmFjdGlvbn08L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgdGV4dC1bMTFweF0gbGVhZGluZy1zbnVnXCI+e21jLmRlc2N9PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQtMnhsIGJnLWJsdWUtNjAwLzEwIGJvcmRlciBib3JkZXItYmx1ZS01MDAvMjAgdGV4dC14cyB0ZXh0LXNsYXRlLTMwMCBzcGFjZS15LTEgbXQtM1wiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC13aGl0ZSBibG9ja1wiPvCfkqEgU3R1ZGlvIFRpcDo8L3NwYW4+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgUGFzc3BvcnQgUGhvdG8gU3R1ZGlvIG1laW4gPGI+UGVuIFRvb2w8L2I+IHNlIHBvaW50cyBsYWdha2FyIGtpc2kgYmhpIHBob3RvIGthIGJhY2tncm91bmQgZGlyZWN0IGNoYW5nZSBrYXJlaW4uIExpdmUgRHVhbCBQcmV2aWV3IHNlIGN1dCBraSBodWkgcGhvdG8ga2EgcHJldmlldyBzYWF0aC1zYWF0aCBkZWtoZWluIVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBmb250LW1vbm9cIj5QcmVzcyA/IGFueXRpbWUgdG8gb3BlbiB0aGlzIGd1aWRlPC9zcGFuPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC01IHB5LTIgYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS01MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14cyByb3VuZGVkLXhsIHNoYWRvdy1sZyBzaGFkb3ctYmx1ZS02MDAvMzAgdHJhbnNpdGlvbi1hbGwgaG92ZXI6c2NhbGUtMTA1XCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBHb3QgSXQgKEVzYylcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=