const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { CreditCard, Camera, Receipt, FileImage, FileText, Landmark, Sparkles, Printer, ExternalLink, TrendingUp, AlertCircle, Clock, ArrowRight, Send } from "/node_modules/.vite/deps/lucide-react.js?v=090625a0";
import { ALL_GOV_PORTALS } from "/src/data/portalData.ts";
var _jsxFileName = "/app/applet/src/components/DashboardView.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
export const DashboardView = ({ bills, customers, settings, onNavigate, onOpenQuickBill, onPrintBill }) => {
	// Calculations
	const todayStr = new Date().toISOString().slice(0, 10);
	const todayBills = bills.filter((b) => b.createdAt.includes(todayStr) || b.createdAt.includes("2026-09-30"));
	const todayIncome = todayBills.reduce((acc, curr) => acc + (curr.total || 0), 0);
	const pendingJobs = customers.filter((c) => c.status === "Pending" || c.status === "Processing");
	const popularPortals = ALL_GOV_PORTALS.filter((p) => p.popular).slice(0, 8);
	const quickTools = [
		{
			id: "pvc_studio",
			title: "PVC Card Maker 4×6",
			sub: "Standard CR-80 85.6×54mm • 300 DPI Live Zoom/Pan & Print",
			icon: CreditCard,
			color: "from-blue-600 to-cyan-600",
			badge: "Popular",
			badgeColor: "bg-blue-500/20 text-blue-300 border-blue-400/30"
		},
		{
			id: "passport_studio",
			title: "Passport Photo Studio",
			sub: "6, 8, 12, 16 Copies • Studio Background • Retouch • Name Stamp",
			icon: Camera,
			color: "from-purple-600 to-pink-600",
			badge: "300 DPI",
			badgeColor: "bg-purple-500/20 text-purple-300 border-purple-400/30"
		},
		{
			id: "billing",
			title: "Billing & Thermal POS",
			sub: "58mm / 80mm POS Slip, A4 Invoice, WhatsApp Share & UPI QR",
			icon: Receipt,
			color: "from-emerald-600 to-teal-600",
			badge: "Fast POS",
			badgeColor: "bg-emerald-500/20 text-emerald-300 border-emerald-400/30"
		},
		{
			id: "pdf_to_jpg",
			title: "PDF to High-Res JPG",
			sub: "Password Unlock (e-Aadhaar/PAN), Multi-page 300 DPI & ZIP",
			icon: FileImage,
			color: "from-amber-600 to-orange-600",
			badge: "Unlocked",
			badgeColor: "bg-amber-500/20 text-amber-300 border-amber-400/30"
		},
		{
			id: "biodata_maker",
			title: "CV & BioData Maker",
			sub: "Professional A4 Resume, Marriage BioData in Hindi & English",
			icon: FileText,
			color: "from-indigo-600 to-violet-600",
			badge: "18+ Layouts",
			badgeColor: "bg-indigo-500/20 text-indigo-300 border-indigo-400/30"
		},
		{
			id: "ai_assistant",
			title: "AI Scheme Assistant",
			sub: "Instant Document Checklists, Eligibility Rules & Portal Steps",
			icon: Sparkles,
			color: "from-amber-500 to-yellow-600",
			badge: "Gemini AI",
			badgeColor: "bg-amber-500/20 text-amber-200 border-amber-400/30"
		}
	];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "relative overflow-hidden rounded-2xl bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 border border-blue-500/20 p-6 shadow-xl",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-semibold",
								children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-emerald-400 animate-pulse" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 112,
									columnNumber: 15
								}, this), "PC Operator Station Online • High Performance Workstation"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 111,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("h1", {
								className: "text-2xl lg:text-3xl font-black text-white tracking-tight",
								children: settings.shopName
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 115,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-sm text-slate-300 max-w-2xl leading-relaxed",
								children: "Complete digital citizen services suite: 300 DPI PVC card generation, instant passport photo sheets, official government scheme applications, and fast thermal POS billing."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 118,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 110,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-wrap items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: onOpenQuickBill,
							className: "flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm px-4 py-2.5 rounded-xl shadow-lg shadow-emerald-600/30 transition-all hover:scale-105 active:scale-95",
							children: [/* @__PURE__ */ _jsxDEV(Receipt, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 128,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "+ New Customer Bill" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 129,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => onNavigate("pvc_studio"),
							className: "flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm px-4 py-2.5 rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-105 active:scale-95",
							children: [/* @__PURE__ */ _jsxDEV(CreditCard, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 135,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Open PVC Studio" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 136,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 131,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 109,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0 opacity-10 bg-[radial-gradient(#3b82f6_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 142,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 108,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-medium text-slate-400 uppercase tracking-wider",
								children: "Today's Revenue"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-2xl font-black text-emerald-400 mt-1",
								children: ["₹", todayIncome.toLocaleString("en-IN")]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 150,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-slate-500 mt-0.5 block",
								children: [todayBills.length, " service transactions"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 151,
								columnNumber: 13
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400",
							children: /* @__PURE__ */ _jsxDEV(TrendingUp, { className: "w-6 h-6" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 154,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 153,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 147,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-medium text-slate-400 uppercase tracking-wider",
								children: "Total Bills Today"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 160,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-2xl font-black text-blue-400 mt-1",
								children: todayBills.length
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 161,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-slate-500 mt-0.5 block",
								children: "Recorded in POS ledger"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 162,
								columnNumber: 13
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 159,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400",
							children: /* @__PURE__ */ _jsxDEV(Receipt, { className: "w-6 h-6" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 165,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 164,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 158,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-medium text-slate-400 uppercase tracking-wider",
								children: "Pending Customer Jobs"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 171,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-2xl font-black text-amber-400 mt-1",
								children: pendingJobs.length
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 172,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-slate-500 mt-0.5 block",
								children: "Awaiting biometric / print"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 173,
								columnNumber: 13
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 170,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400",
							children: /* @__PURE__ */ _jsxDEV(Clock, { className: "w-6 h-6" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 176,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 175,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 169,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-medium text-slate-400 uppercase tracking-wider",
								children: "Govt Portals Connected"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 182,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-2xl font-black text-purple-400 mt-1",
								children: ALL_GOV_PORTALS.length
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 183,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] text-slate-500 mt-0.5 block",
								children: "Central & Maharashtra Portals"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 184,
								columnNumber: 13
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 181,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400",
							children: /* @__PURE__ */ _jsxDEV(Landmark, { className: "w-6 h-6" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 186,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 180,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 146,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-lg font-bold text-white tracking-tight",
							children: "Core PC Workstation Tools"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full font-mono",
							children: "300 DPI"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 197,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 195,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs text-slate-400",
						children: "Optimized for keyboard, mouse & printer presets"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 199,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 194,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
					children: quickTools.map((tool) => {
						const Icon = tool.icon;
						return /* @__PURE__ */ _jsxDEV("div", {
							onClick: () => onNavigate(tool.id),
							className: "group relative bg-slate-900/90 hover:bg-slate-800/90 border border-slate-800 hover:border-slate-700 rounded-2xl p-5 cursor-pointer transition-all duration-200 shadow-md hover:shadow-xl hover:-translate-y-1 flex flex-col justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between mb-3",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: `w-12 h-12 rounded-xl bg-gradient-to-tr ${tool.color} flex items-center justify-center text-white shadow-lg shadow-black/20 group-hover:scale-110 transition-transform`,
										children: /* @__PURE__ */ _jsxDEV(Icon, { className: "w-6 h-6" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 214,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 213,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: `text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md border ${tool.badgeColor}`,
										children: tool.badge
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 216,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 212,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-extrabold text-base text-white group-hover:text-blue-400 transition-colors",
									children: tool.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 220,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400 mt-1 leading-relaxed",
									children: tool.sub
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 223,
									columnNumber: 19
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 211,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-xs font-semibold text-blue-400 group-hover:text-blue-300",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Launch Workspace" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 229,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "w-4 h-4 transform group-hover:translate-x-1 transition-transform" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 230,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 228,
								columnNumber: 17
							}, this)]
						}, tool.id, true, {
							fileName: _jsxFileName,
							lineNumber: 206,
							columnNumber: 15
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 202,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 193,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-lg font-bold text-white tracking-tight",
							children: "Popular Government Portals & Schemes"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 242,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/30 font-medium",
							children: "Direct Access"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 243,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 241,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => onNavigate("portals"),
						className: "text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: "View All 50+ Portals" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 249,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 250,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 245,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 240,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3",
					children: popularPortals.map((portal) => /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/80 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 p-3.5 rounded-xl transition-all shadow-sm flex flex-col justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between gap-2 mb-1.5",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 min-w-0",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xl",
									children: portal.icon
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 263,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("h4", {
									className: "text-xs font-bold text-slate-200 truncate",
									children: portal.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 264,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 262,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 261,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-[11px] text-slate-400 line-clamp-2 leading-relaxed",
							children: portal.description
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 267,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 260,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "mt-3 pt-2.5 border-t border-slate-800/60 flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("a", {
								href: portal.url,
								target: "_blank",
								rel: "noopener noreferrer",
								className: "text-[11px] font-bold text-blue-400 hover:text-blue-300 inline-flex items-center gap-1",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Open Official" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 279,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-3 h-3" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 280,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 273,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => onNavigate("portals"),
								className: "text-[10px] text-slate-500 hover:text-slate-300",
								children: "Docs Info"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 282,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 272,
							columnNumber: 15
						}, this)]
					}, portal.id, true, {
						fileName: _jsxFileName,
						lineNumber: 256,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 254,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 239,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-3 gap-6",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-md space-y-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "font-bold text-base text-white",
							children: "Recent Customer Billing Receipts"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 300,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: "Quick print thermal slip or share via WhatsApp"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 301,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 299,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => onNavigate("billing"),
							className: "text-xs font-semibold text-blue-400 hover:text-blue-300",
							children: "Full Ledger →"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 303,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 298,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ _jsxDEV("table", {
							className: "w-full text-left text-xs",
							children: [/* @__PURE__ */ _jsxDEV("thead", {
								className: "bg-slate-950 text-slate-400 border-b border-slate-800 font-mono",
								children: /* @__PURE__ */ _jsxDEV("tr", { children: [
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-2.5 px-3",
										children: "Invoice"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 315,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-2.5 px-3",
										children: "Customer"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 316,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-2.5 px-3",
										children: "Service"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 317,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-2.5 px-3 text-right",
										children: "Amount"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 318,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-2.5 px-3 text-center",
										children: "Status"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 319,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-2.5 px-3 text-right",
										children: "Actions"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 320,
										columnNumber: 19
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 314,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 313,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("tbody", {
								className: "divide-y divide-slate-800/60",
								children: bills.slice(0, 5).map((bill) => /* @__PURE__ */ _jsxDEV("tr", {
									className: "hover:bg-slate-800/40 transition-colors",
									children: [
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-3 font-mono font-bold text-slate-300",
											children: bill.invoiceNo
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 326,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-3",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "font-semibold text-white",
												children: bill.customerName
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 328,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "text-[10px] text-slate-500 font-mono",
												children: bill.customerMobile
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 329,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 327,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-3 text-slate-300 max-w-[160px] truncate",
											children: bill.serviceName
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 331,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-3 text-right font-bold text-emerald-400 font-mono",
											children: ["₹", bill.total]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 332,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-3 text-center",
											children: /* @__PURE__ */ _jsxDEV("span", {
												className: `px-2 py-0.5 rounded text-[10px] font-bold ${bill.status === "Paid" ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30" : "bg-amber-500/20 text-amber-300 border border-amber-500/30"}`,
												children: bill.status
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 334,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 333,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("td", {
											className: "py-3 px-3 text-right space-x-1.5 whitespace-nowrap",
											children: [/* @__PURE__ */ _jsxDEV("button", {
												onClick: () => onPrintBill(bill),
												title: "Print Thermal Slip",
												className: "p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white transition-colors",
												children: /* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 348,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 343,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("a", {
												href: `https://wa.me/91${bill.customerMobile}?text=Hello%20${encodeURIComponent(bill.customerName)},%20your%20bill%20at%20${encodeURIComponent(settings.shopName)}%20for%20${encodeURIComponent(bill.serviceName)}%20is%20Rs.${bill.total}.%20Thank%20you!`,
												target: "_blank",
												rel: "noopener noreferrer",
												title: "Share on WhatsApp",
												className: "p-1.5 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/40 text-emerald-400 inline-block transition-colors",
												children: /* @__PURE__ */ _jsxDEV(Send, { className: "w-3.5 h-3.5" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 357,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 350,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 342,
											columnNumber: 21
										}, this)
									]
								}, bill.id, true, {
									fileName: _jsxFileName,
									lineNumber: 325,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 323,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 312,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 311,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 297,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-md space-y-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-4 h-4 text-amber-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 370,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("h3", {
							className: "font-bold text-base text-white",
							children: "Govt Scheme Notices"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 371,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 369,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-3 text-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-200 leading-relaxed",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "font-bold block text-amber-300 mb-1",
									children: "📢 Majhi Ladki Bahin Yojana Alert:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 376,
									columnNumber: 15
								}, this), "Ensure the beneficiary's bank account has DBT / NPCI seeding active. If NPCI mapping is not done, monthly ₹1,500 instalment will fail."]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 375,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-200 leading-relaxed",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "font-bold block text-blue-300 mb-1",
									children: "🪪 PVC Card Printing Preset:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 381,
									columnNumber: 15
								}, this), "Use Standard 4×6 inch Photo Paper with 300 DPI mode on Epson L805 / Canon G3010 for crisp Aadhaar / PAN card prints."]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 380,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-200 leading-relaxed",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "font-bold block text-purple-300 mb-1",
									children: "📸 SSC / Police Bharti Photos:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 386,
									columnNumber: 15
								}, this), "Exam notification requires Candidate Name & Date printed at the bottom of the passport photo. Use our Passport Studio preset!"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 385,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 374,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 368,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 295,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 106,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQ0UsWUFDQSxRQUNBLFNBQ0EsV0FDQSxVQUVBLFVBQ0EsVUFDQSxTQUNBLGNBRUEsWUFDQSxhQUNBLE9BQ0EsWUFFQSxZQUNLO0FBRVAsU0FBUyx1QkFBdUI7OztBQVdoQyxPQUFPLE1BQU0saUJBQStDLEVBQzFELE9BQ0EsV0FDQSxVQUNBLFlBQ0EsaUJBQ0Esa0JBQ0k7O0NBRUosTUFBTSxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUU7Q0FDckQsTUFBTSxhQUFhLE1BQU0sUUFBTyxNQUFLLEVBQUUsVUFBVSxTQUFTLFFBQVEsS0FBSyxFQUFFLFVBQVUsU0FBUyxZQUFZLENBQUM7Q0FDekcsTUFBTSxjQUFjLFdBQVcsUUFBUSxLQUFLLFNBQVMsT0FBTyxLQUFLLFNBQVMsSUFBSSxDQUFDO0NBQy9FLE1BQU0sY0FBYyxVQUFVLFFBQU8sTUFBSyxFQUFFLFdBQVcsYUFBYSxFQUFFLFdBQVcsWUFBWTtDQUM3RixNQUFNLGlCQUFpQixnQkFBZ0IsUUFBTyxNQUFLLEVBQUUsT0FBTyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUM7Q0FFeEUsTUFBTSxhQUFhO0VBQ2pCO0dBQ0UsSUFBSTtHQUNKLE9BQU87R0FDUCxLQUFLO0dBQ0wsTUFBTTtHQUNOLE9BQU87R0FDUCxPQUFPO0dBQ1AsWUFBWTtFQUNkO0VBQ0E7R0FDRSxJQUFJO0dBQ0osT0FBTztHQUNQLEtBQUs7R0FDTCxNQUFNO0dBQ04sT0FBTztHQUNQLE9BQU87R0FDUCxZQUFZO0VBQ2Q7RUFDQTtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsS0FBSztHQUNMLE1BQU07R0FDTixPQUFPO0dBQ1AsT0FBTztHQUNQLFlBQVk7RUFDZDtFQUNBO0dBQ0UsSUFBSTtHQUNKLE9BQU87R0FDUCxLQUFLO0dBQ0wsTUFBTTtHQUNOLE9BQU87R0FDUCxPQUFPO0dBQ1AsWUFBWTtFQUNkO0VBQ0E7R0FDRSxJQUFJO0dBQ0osT0FBTztHQUNQLEtBQUs7R0FDTCxNQUFNO0dBQ04sT0FBTztHQUNQLE9BQU87R0FDUCxZQUFZO0VBQ2Q7RUFDQTtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsS0FBSztHQUNMLE1BQU07R0FDTixPQUFPO0dBQ1AsT0FBTztHQUNQLFlBQVk7RUFDZDtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsb0RBQTBEOzs7O2tCQUFDLDJEQUV4RTs7Ozs7O09BQ0wsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQ1gsU0FBUztPQUNSOzs7OztPQUNKLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFtRDtPQUU3RDs7Ozs7TUFDQTs7Ozs7ZUFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQ7T0FDRSxTQUFTO09BQ1QsV0FBVTtpQkFGWixDQUlFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7aUJBQzlCLHdCQUFDLFFBQUQsWUFBTSxzQkFBeUI7Ozs7ZUFDekI7Ozs7O2dCQUNSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLFdBQVcsWUFBWTtPQUN0QyxXQUFVO2lCQUZaLENBSUUsd0JBQUMsWUFBRCxFQUFZLFdBQVUsVUFBVzs7OztpQkFDakMsd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7OztlQUNyQjs7Ozs7Y0FDTDs7Ozs7YUFDRjs7Ozs7Y0FHTCx3QkFBQyxPQUFELEVBQUssV0FBVSxnSUFBaUk7Ozs7WUFDN0k7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBOEQ7T0FBcUI7Ozs7O09BQ25HLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQTJELEtBQUUsWUFBWSxlQUFlLE9BQU8sQ0FBTzs7Ozs7O09BQ3RHLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUEyRCxXQUFXLFFBQU8sdUJBQTJCOzs7Ozs7TUFDckc7Ozs7Z0JBQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsWUFBRCxFQUFZLFdBQVUsVUFBVzs7Ozs7TUFDOUI7Ozs7Y0FDRjs7Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQThEO09BQXVCOzs7OztPQUNyRyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBMEMsV0FBVztPQUFZOzs7OztPQUNoRix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBMEM7T0FBNEI7Ozs7O01BQ25GOzs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7O01BQzNCOzs7O2NBQ0Y7Ozs7OztLQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUE4RDtPQUEyQjs7Ozs7T0FDekcsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQTJDLFlBQVk7T0FBWTs7Ozs7T0FDbEYsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTBDO09BQWdDOzs7OztNQUN2Rjs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxPQUFELEVBQU8sV0FBVSxVQUFXOzs7OztNQUN6Qjs7OztjQUNGOzs7Ozs7S0FFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBOEQ7T0FBNEI7Ozs7O09BQzFHLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUE0QyxnQkFBZ0I7T0FBWTs7Ozs7T0FDdkYsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTBDO09BQW1DOzs7OztNQUMxRjs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7OztNQUM1Qjs7OztjQUNGOzs7Ozs7SUFDRjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUE4QztNQUE2Qjs7OztnQkFDekYsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQXlFO01BQWE7Ozs7Y0FDbkc7Ozs7O2VBQ0wsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQXlCO0tBQXFEOzs7O2FBQzNGOzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osV0FBVyxLQUFLLFNBQVM7TUFDeEIsTUFBTSxPQUFPLEtBQUs7TUFDbEIsT0FDRSx3QkFBQyxPQUFEO09BRUUsZUFBZSxXQUFXLEtBQUssRUFBRTtPQUNqQyxXQUFVO2lCQUhaLENBS0Usd0JBQUMsT0FBRDtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVcsMENBQTBDLEtBQUssTUFBTTtvQkFDbkUsd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7Ozs7U0FDeEI7Ozs7bUJBQ0wsd0JBQUMsUUFBRDtVQUFNLFdBQVcsZ0ZBQWdGLEtBQUs7b0JBQ25HLEtBQUs7U0FDRjs7OztpQkFDSDs7Ozs7O1FBQ0wsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1gsS0FBSztRQUNKOzs7OztRQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUNWLEtBQUs7UUFDTDs7Ozs7T0FDQTs7OztpQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxtQkFBc0I7Ozs7a0JBQzVCLHdCQUFDLFlBQUQsRUFBWSxXQUFVLG1FQUFvRTs7OztnQkFDdkY7Ozs7O2VBQ0Y7U0F6QkUsS0FBSzs7OzthQXlCUDtLQUVULENBQUM7SUFDRTs7OztZQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQThDO01BQXdDOzs7O2dCQUNwRyx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBMEc7TUFBbUI7Ozs7Y0FDMUk7Ozs7O2VBQ0wsd0JBQUMsVUFBRDtNQUNFLGVBQWUsV0FBVyxTQUFTO01BQ25DLFdBQVU7Z0JBRlosQ0FJRSx3QkFBQyxRQUFELFlBQU0sdUJBQTBCOzs7O2dCQUNoQyx3QkFBQyxZQUFELEVBQVksV0FBVSxjQUFlOzs7O2NBQy9COzs7OzthQUNMOzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osZUFBZSxLQUFLLFdBQ25CLHdCQUFDLE9BQUQ7TUFFRSxXQUFVO2dCQUZaLENBSUUsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQVcsT0FBTztRQUFXOzs7O2tCQUM3Qyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBNkMsT0FBTztRQUFVOzs7O2dCQUN6RTs7Ozs7O01BQ0Y7Ozs7Z0JBQ0wsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQ1YsT0FBTztNQUNQOzs7O2NBQ0E7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxLQUFEO1FBQ0UsTUFBTSxPQUFPO1FBQ2IsUUFBTztRQUNQLEtBQUk7UUFDSixXQUFVO2tCQUpaLENBTUUsd0JBQUMsUUFBRCxZQUFNLGdCQUFtQjs7OztrQkFDekIsd0JBQUMsY0FBRCxFQUFjLFdBQVUsVUFBVzs7OztnQkFDbEM7Ozs7O2lCQUNILHdCQUFDLFVBQUQ7UUFDRSxlQUFlLFdBQVcsU0FBUztRQUNuQyxXQUFVO2tCQUNYO09BRU87Ozs7ZUFDTDs7Ozs7Y0FDRjtRQWhDRSxPQUFPOzs7O1lBZ0NULENBQ047SUFDRTs7OztZQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBRUUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFpQztNQUFvQzs7OztnQkFDbkYsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXlCO01BQWlEOzs7O2NBQ3BGOzs7O2dCQUNMLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLFdBQVcsU0FBUztPQUNuQyxXQUFVO2lCQUNYO01BRU87Ozs7Y0FDTDs7Ozs7ZUFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBakIsQ0FDRSx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFDZix3QkFBQyxNQUFEO1NBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWM7U0FBVzs7Ozs7U0FDdkMsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWM7U0FBWTs7Ozs7U0FDeEMsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWM7U0FBVzs7Ozs7U0FDdkMsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQXlCO1NBQVU7Ozs7O1NBQ2pELHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUEwQjtTQUFVOzs7OztTQUNsRCx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBeUI7U0FBVzs7Ozs7UUFDaEQ7Ozs7O09BQ0M7Ozs7aUJBQ1Asd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQ2QsTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUN0Qix3QkFBQyxNQUFEO1NBQWtCLFdBQVU7bUJBQTVCO1VBQ0Usd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQWdELEtBQUs7VUFBYzs7Ozs7VUFDakYsd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQWQsQ0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBNEIsS0FBSztXQUFrQjs7OztxQkFDbEUsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQXdDLEtBQUs7V0FBb0I7Ozs7bUJBQzlFOzs7Ozs7VUFDSix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBbUQsS0FBSztVQUFnQjs7Ozs7VUFDdEYsd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQWQsQ0FBMEUsS0FBRSxLQUFLLEtBQVU7Ozs7OztVQUMzRix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFDWix3QkFBQyxRQUFEO1lBQU0sV0FBVyw2Q0FDZixLQUFLLFdBQVcsU0FDWixvRUFDQTtzQkFFSCxLQUFLO1dBQ0Y7Ozs7O1VBQ0o7Ozs7O1VBQ0osd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQWQsQ0FDRSx3QkFBQyxVQUFEO1lBQ0UsZUFBZSxZQUFZLElBQUk7WUFDL0IsT0FBTTtZQUNOLFdBQVU7c0JBRVYsd0JBQUMsU0FBRCxFQUFTLFdBQVUsY0FBZTs7Ozs7V0FDNUI7Ozs7cUJBQ1Isd0JBQUMsS0FBRDtZQUNFLE1BQU0sbUJBQW1CLEtBQUssZUFBZSxnQkFBZ0IsbUJBQW1CLEtBQUssWUFBWSxFQUFFLHlCQUF5QixtQkFBbUIsU0FBUyxRQUFRLEVBQUUsV0FBVyxtQkFBbUIsS0FBSyxXQUFXLEVBQUUsYUFBYSxLQUFLLE1BQU07WUFDMU8sUUFBTztZQUNQLEtBQUk7WUFDSixPQUFNO1lBQ04sV0FBVTtzQkFFVix3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7OztXQUM5Qjs7OzttQkFDRDs7Ozs7O1NBQ0Y7V0FuQ0ssS0FBSzs7OztlQW1DVixDQUNMO09BQ0k7Ozs7ZUFDRjs7Ozs7O0tBQ0o7Ozs7YUFDRjs7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSx5QkFBMEI7Ozs7Z0JBQ2pELHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFpQztNQUF1Qjs7OztjQUNuRTs7Ozs7ZUFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQXNDO1FBQXdDOzs7O2tCQUFDLHdJQUU1Rjs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBcUM7UUFBa0M7Ozs7a0JBQUMsc0hBRXJGOzs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUF1QztRQUFvQzs7OztrQkFBQywrSEFFekY7Ozs7OztNQUNGOzs7OzthQUNGOzs7OztZQUNGOzs7Ozs7RUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRGFzaGJvYXJkVmlldy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICBDcmVkaXRDYXJkLCBcbiAgQ2FtZXJhLCBcbiAgUmVjZWlwdCwgXG4gIEZpbGVJbWFnZSwgXG4gIEZpbGVUZXh0LCBcbiAgVXNlcnMsIFxuICBMYW5kbWFyaywgXG4gIFNwYXJrbGVzLCBcbiAgUHJpbnRlciwgXG4gIEV4dGVybmFsTGluayxcbiAgQ2hlY2tDaXJjbGUyLFxuICBUcmVuZGluZ1VwLFxuICBBbGVydENpcmNsZSxcbiAgQ2xvY2ssXG4gIEFycm93UmlnaHQsXG4gIFNoaWVsZENoZWNrLFxuICBTZW5kXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBCaWxsSXRlbSwgQ3VzdG9tZXJSZWNvcmQsIFNob3BTZXR0aW5ncyB9IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7IEFMTF9HT1ZfUE9SVEFMUyB9IGZyb20gJy4uL2RhdGEvcG9ydGFsRGF0YSc7XG5cbmludGVyZmFjZSBEYXNoYm9hcmRWaWV3UHJvcHMge1xuICBiaWxsczogQmlsbEl0ZW1bXTtcbiAgY3VzdG9tZXJzOiBDdXN0b21lclJlY29yZFtdO1xuICBzZXR0aW5nczogU2hvcFNldHRpbmdzO1xuICBvbk5hdmlnYXRlOiAodGFiOiBzdHJpbmcpID0+IHZvaWQ7XG4gIG9uT3BlblF1aWNrQmlsbDogKCkgPT4gdm9pZDtcbiAgb25QcmludEJpbGw6IChiaWxsOiBCaWxsSXRlbSkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IERhc2hib2FyZFZpZXc6IFJlYWN0LkZDPERhc2hib2FyZFZpZXdQcm9wcz4gPSAoe1xuICBiaWxscyxcbiAgY3VzdG9tZXJzLFxuICBzZXR0aW5ncyxcbiAgb25OYXZpZ2F0ZSxcbiAgb25PcGVuUXVpY2tCaWxsLFxuICBvblByaW50QmlsbFxufSkgPT4ge1xuICAvLyBDYWxjdWxhdGlvbnNcbiAgY29uc3QgdG9kYXlTdHIgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xuICBjb25zdCB0b2RheUJpbGxzID0gYmlsbHMuZmlsdGVyKGIgPT4gYi5jcmVhdGVkQXQuaW5jbHVkZXModG9kYXlTdHIpIHx8IGIuY3JlYXRlZEF0LmluY2x1ZGVzKCcyMDI2LTA5LTMwJykpO1xuICBjb25zdCB0b2RheUluY29tZSA9IHRvZGF5QmlsbHMucmVkdWNlKChhY2MsIGN1cnIpID0+IGFjYyArIChjdXJyLnRvdGFsIHx8IDApLCAwKTtcbiAgY29uc3QgcGVuZGluZ0pvYnMgPSBjdXN0b21lcnMuZmlsdGVyKGMgPT4gYy5zdGF0dXMgPT09ICdQZW5kaW5nJyB8fCBjLnN0YXR1cyA9PT0gJ1Byb2Nlc3NpbmcnKTtcbiAgY29uc3QgcG9wdWxhclBvcnRhbHMgPSBBTExfR09WX1BPUlRBTFMuZmlsdGVyKHAgPT4gcC5wb3B1bGFyKS5zbGljZSgwLCA4KTtcblxuICBjb25zdCBxdWlja1Rvb2xzID0gW1xuICAgIHtcbiAgICAgIGlkOiAncHZjX3N0dWRpbycsXG4gICAgICB0aXRsZTogJ1BWQyBDYXJkIE1ha2VyIDTDlzYnLFxuICAgICAgc3ViOiAnU3RhbmRhcmQgQ1ItODAgODUuNsOXNTRtbSDigKIgMzAwIERQSSBMaXZlIFpvb20vUGFuICYgUHJpbnQnLFxuICAgICAgaWNvbjogQ3JlZGl0Q2FyZCxcbiAgICAgIGNvbG9yOiAnZnJvbS1ibHVlLTYwMCB0by1jeWFuLTYwMCcsXG4gICAgICBiYWRnZTogJ1BvcHVsYXInLFxuICAgICAgYmFkZ2VDb2xvcjogJ2JnLWJsdWUtNTAwLzIwIHRleHQtYmx1ZS0zMDAgYm9yZGVyLWJsdWUtNDAwLzMwJ1xuICAgIH0sXG4gICAge1xuICAgICAgaWQ6ICdwYXNzcG9ydF9zdHVkaW8nLFxuICAgICAgdGl0bGU6ICdQYXNzcG9ydCBQaG90byBTdHVkaW8nLFxuICAgICAgc3ViOiAnNiwgOCwgMTIsIDE2IENvcGllcyDigKIgU3R1ZGlvIEJhY2tncm91bmQg4oCiIFJldG91Y2gg4oCiIE5hbWUgU3RhbXAnLFxuICAgICAgaWNvbjogQ2FtZXJhLFxuICAgICAgY29sb3I6ICdmcm9tLXB1cnBsZS02MDAgdG8tcGluay02MDAnLFxuICAgICAgYmFkZ2U6ICczMDAgRFBJJyxcbiAgICAgIGJhZGdlQ29sb3I6ICdiZy1wdXJwbGUtNTAwLzIwIHRleHQtcHVycGxlLTMwMCBib3JkZXItcHVycGxlLTQwMC8zMCdcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiAnYmlsbGluZycsXG4gICAgICB0aXRsZTogJ0JpbGxpbmcgJiBUaGVybWFsIFBPUycsXG4gICAgICBzdWI6ICc1OG1tIC8gODBtbSBQT1MgU2xpcCwgQTQgSW52b2ljZSwgV2hhdHNBcHAgU2hhcmUgJiBVUEkgUVInLFxuICAgICAgaWNvbjogUmVjZWlwdCxcbiAgICAgIGNvbG9yOiAnZnJvbS1lbWVyYWxkLTYwMCB0by10ZWFsLTYwMCcsXG4gICAgICBiYWRnZTogJ0Zhc3QgUE9TJyxcbiAgICAgIGJhZGdlQ29sb3I6ICdiZy1lbWVyYWxkLTUwMC8yMCB0ZXh0LWVtZXJhbGQtMzAwIGJvcmRlci1lbWVyYWxkLTQwMC8zMCdcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiAncGRmX3RvX2pwZycsXG4gICAgICB0aXRsZTogJ1BERiB0byBIaWdoLVJlcyBKUEcnLFxuICAgICAgc3ViOiAnUGFzc3dvcmQgVW5sb2NrIChlLUFhZGhhYXIvUEFOKSwgTXVsdGktcGFnZSAzMDAgRFBJICYgWklQJyxcbiAgICAgIGljb246IEZpbGVJbWFnZSxcbiAgICAgIGNvbG9yOiAnZnJvbS1hbWJlci02MDAgdG8tb3JhbmdlLTYwMCcsXG4gICAgICBiYWRnZTogJ1VubG9ja2VkJyxcbiAgICAgIGJhZGdlQ29sb3I6ICdiZy1hbWJlci01MDAvMjAgdGV4dC1hbWJlci0zMDAgYm9yZGVyLWFtYmVyLTQwMC8zMCdcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiAnYmlvZGF0YV9tYWtlcicsXG4gICAgICB0aXRsZTogJ0NWICYgQmlvRGF0YSBNYWtlcicsXG4gICAgICBzdWI6ICdQcm9mZXNzaW9uYWwgQTQgUmVzdW1lLCBNYXJyaWFnZSBCaW9EYXRhIGluIEhpbmRpICYgRW5nbGlzaCcsXG4gICAgICBpY29uOiBGaWxlVGV4dCxcbiAgICAgIGNvbG9yOiAnZnJvbS1pbmRpZ28tNjAwIHRvLXZpb2xldC02MDAnLFxuICAgICAgYmFkZ2U6ICcxOCsgTGF5b3V0cycsXG4gICAgICBiYWRnZUNvbG9yOiAnYmctaW5kaWdvLTUwMC8yMCB0ZXh0LWluZGlnby0zMDAgYm9yZGVyLWluZGlnby00MDAvMzAnXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogJ2FpX2Fzc2lzdGFudCcsXG4gICAgICB0aXRsZTogJ0FJIFNjaGVtZSBBc3Npc3RhbnQnLFxuICAgICAgc3ViOiAnSW5zdGFudCBEb2N1bWVudCBDaGVja2xpc3RzLCBFbGlnaWJpbGl0eSBSdWxlcyAmIFBvcnRhbCBTdGVwcycsXG4gICAgICBpY29uOiBTcGFya2xlcyxcbiAgICAgIGNvbG9yOiAnZnJvbS1hbWJlci01MDAgdG8teWVsbG93LTYwMCcsXG4gICAgICBiYWRnZTogJ0dlbWluaSBBSScsXG4gICAgICBiYWRnZUNvbG9yOiAnYmctYW1iZXItNTAwLzIwIHRleHQtYW1iZXItMjAwIGJvcmRlci1hbWJlci00MDAvMzAnXG4gICAgfVxuICBdO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgIHsvKiBUb3AgQmFubmVyIHdpdGggQ3liZXIgQ2FmZSBEZXRhaWxzICYgUXVpY2sgQWN0aW9uICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC0yeGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtOTUwIHZpYS1zbGF0ZS05MDAgdG8taW5kaWdvLTk1MCBib3JkZXIgYm9yZGVyLWJsdWUtNTAwLzIwIHAtNiBzaGFkb3cteGxcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB6LTEwIGZsZXggZmxleC1jb2wgbGc6ZmxleC1yb3cgbGc6aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC0zIHB5LTEgcm91bmRlZC1mdWxsIGJnLWJsdWUtNTAwLzEwIGJvcmRlciBib3JkZXItYmx1ZS01MDAvMzAgdGV4dC1ibHVlLTQwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC00MDAgYW5pbWF0ZS1wdWxzZVwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgUEMgT3BlcmF0b3IgU3RhdGlvbiBPbmxpbmUg4oCiIEhpZ2ggUGVyZm9ybWFuY2UgV29ya3N0YXRpb25cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGxnOnRleHQtM3hsIGZvbnQtYmxhY2sgdGV4dC13aGl0ZSB0cmFja2luZy10aWdodFwiPlxuICAgICAgICAgICAgICB7c2V0dGluZ3Muc2hvcE5hbWV9XG4gICAgICAgICAgICA8L2gxPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXNsYXRlLTMwMCBtYXgtdy0yeGwgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgIENvbXBsZXRlIGRpZ2l0YWwgY2l0aXplbiBzZXJ2aWNlcyBzdWl0ZTogMzAwIERQSSBQVkMgY2FyZCBnZW5lcmF0aW9uLCBpbnN0YW50IHBhc3Nwb3J0IHBob3RvIHNoZWV0cywgb2ZmaWNpYWwgZ292ZXJubWVudCBzY2hlbWUgYXBwbGljYXRpb25zLCBhbmQgZmFzdCB0aGVybWFsIFBPUyBiaWxsaW5nLlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17b25PcGVuUXVpY2tCaWxsfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTUwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXNtIHB4LTQgcHktMi41IHJvdW5kZWQteGwgc2hhZG93LWxnIHNoYWRvdy1lbWVyYWxkLTYwMC8zMCB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzY2FsZS0xMDUgYWN0aXZlOnNjYWxlLTk1XCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFJlY2VpcHQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPisgTmV3IEN1c3RvbWVyIEJpbGw8L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25OYXZpZ2F0ZSgncHZjX3N0dWRpbycpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTUwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXNtIHB4LTQgcHktMi41IHJvdW5kZWQteGwgc2hhZG93LWxnIHNoYWRvdy1ibHVlLTYwMC8zMCB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzY2FsZS0xMDUgYWN0aXZlOnNjYWxlLTk1XCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPENyZWRpdENhcmQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPk9wZW4gUFZDIFN0dWRpbzwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogRGVjb3JhdGl2ZSBiYWNrZ3JvdW5kIGdyaWQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCBvcGFjaXR5LTEwIGJnLVtyYWRpYWwtZ3JhZGllbnQoIzNiODJmNl8xcHgsdHJhbnNwYXJlbnRfMXB4KV0gW2JhY2tncm91bmQtc2l6ZToxNnB4XzE2cHhdIHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBDeWJlciBDYWZlIEtleSBNZXRyaWNzICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy00IGdhcC00XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzkwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNCBzaGFkb3ctbWQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+VG9kYXkncyBSZXZlbnVlPC9zcGFuPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtZW1lcmFsZC00MDAgbXQtMVwiPuKCuXt0b2RheUluY29tZS50b0xvY2FsZVN0cmluZygnZW4tSU4nKX08L2Rpdj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwIG10LTAuNSBibG9ja1wiPnt0b2RheUJpbGxzLmxlbmd0aH0gc2VydmljZSB0cmFuc2FjdGlvbnM8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgcm91bmRlZC14bCBiZy1lbWVyYWxkLTUwMC8xMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzIwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtZW1lcmFsZC00MDBcIj5cbiAgICAgICAgICAgIDxUcmVuZGluZ1VwIGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMC85MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTQgc2hhZG93LW1kIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlRvdGFsIEJpbGxzIFRvZGF5PC9zcGFuPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtYmx1ZS00MDAgbXQtMVwiPnt0b2RheUJpbGxzLmxlbmd0aH08L2Rpdj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwIG10LTAuNSBibG9ja1wiPlJlY29yZGVkIGluIFBPUyBsZWRnZXI8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgcm91bmRlZC14bCBiZy1ibHVlLTUwMC8xMCBib3JkZXIgYm9yZGVyLWJsdWUtNTAwLzIwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtYmx1ZS00MDBcIj5cbiAgICAgICAgICAgIDxSZWNlaXB0IGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMC85MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTQgc2hhZG93LW1kIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlBlbmRpbmcgQ3VzdG9tZXIgSm9iczwvc3Bhbj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ibGFjayB0ZXh0LWFtYmVyLTQwMCBtdC0xXCI+e3BlbmRpbmdKb2JzLmxlbmd0aH08L2Rpdj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwIG10LTAuNSBibG9ja1wiPkF3YWl0aW5nIGJpb21ldHJpYyAvIHByaW50PC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHJvdW5kZWQteGwgYmctYW1iZXItNTAwLzEwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzIwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtYW1iZXItNDAwXCI+XG4gICAgICAgICAgICA8Q2xvY2sgY2xhc3NOYW1lPVwidy02IGgtNlwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzkwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNCBzaGFkb3ctbWQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+R292dCBQb3J0YWxzIENvbm5lY3RlZDwvc3Bhbj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ibGFjayB0ZXh0LXB1cnBsZS00MDAgbXQtMVwiPntBTExfR09WX1BPUlRBTFMubGVuZ3RofTwvZGl2PlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgbXQtMC41IGJsb2NrXCI+Q2VudHJhbCAmIE1haGFyYXNodHJhIFBvcnRhbHM8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgcm91bmRlZC14bCBiZy1wdXJwbGUtNTAwLzEwIGJvcmRlciBib3JkZXItcHVycGxlLTUwMC8yMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXB1cnBsZS00MDBcIj5cbiAgICAgICAgICAgIDxMYW5kbWFyayBjbGFzc05hbWU9XCJ3LTYgaC02XCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEN5YmVyIENhZmUgUXVpY2sgVG9vbHMgV29ya3N0YXRpb24gR3JpZCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj5Db3JlIFBDIFdvcmtzdGF0aW9uIFRvb2xzPC9oMj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgYmctc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCBmb250LW1vbm9cIj4zMDAgRFBJPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5PcHRpbWl6ZWQgZm9yIGtleWJvYXJkLCBtb3VzZSAmIHByaW50ZXIgcHJlc2V0czwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIGdhcC00XCI+XG4gICAgICAgICAge3F1aWNrVG9vbHMubWFwKCh0b29sKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBJY29uID0gdG9vbC5pY29uO1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGtleT17dG9vbC5pZH1cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKHRvb2wuaWQpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyb3VwIHJlbGF0aXZlIGJnLXNsYXRlLTkwMC85MCBob3ZlcjpiZy1zbGF0ZS04MDAvOTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLTJ4bCBwLTUgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIHNoYWRvdy1tZCBob3ZlcjpzaGFkb3cteGwgaG92ZXI6LXRyYW5zbGF0ZS15LTEgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW5cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B3LTEyIGgtMTIgcm91bmRlZC14bCBiZy1ncmFkaWVudC10by10ciAke3Rvb2wuY29sb3J9IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtd2hpdGUgc2hhZG93LWxnIHNoYWRvdy1ibGFjay8yMCBncm91cC1ob3ZlcjpzY2FsZS0xMTAgdHJhbnNpdGlvbi10cmFuc2Zvcm1gfT5cbiAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTYgaC02XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgcHgtMiBweS0wLjUgcm91bmRlZC1tZCBib3JkZXIgJHt0b29sLmJhZGdlQ29sb3J9YH0+XG4gICAgICAgICAgICAgICAgICAgICAge3Rvb2wuYmFkZ2V9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtYmFzZSB0ZXh0LXdoaXRlIGdyb3VwLWhvdmVyOnRleHQtYmx1ZS00MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgICAge3Rvb2wudGl0bGV9XG4gICAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0xIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgICB7dG9vbC5zdWJ9XG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTQgcHQtMyBib3JkZXItdCBib3JkZXItc2xhdGUtODAwLzYwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1ibHVlLTQwMCBncm91cC1ob3Zlcjp0ZXh0LWJsdWUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5MYXVuY2ggV29ya3NwYWNlPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPEFycm93UmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNCB0cmFuc2Zvcm0gZ3JvdXAtaG92ZXI6dHJhbnNsYXRlLXgtMSB0cmFuc2l0aW9uLXRyYW5zZm9ybVwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9KX1cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFBvcHVsYXIgQ2l0aXplbiBTZXJ2aWNlcyAmIFBvcnRhbHMgUm93ICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC13aGl0ZSB0cmFja2luZy10aWdodFwiPlBvcHVsYXIgR292ZXJubWVudCBQb3J0YWxzICYgU2NoZW1lczwvaDI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGJnLWVtZXJhbGQtNTAwLzIwIHRleHQtZW1lcmFsZC00MDAgcHgtMiBweS0wLjUgcm91bmRlZCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIGZvbnQtbWVkaXVtXCI+RGlyZWN0IEFjY2Vzczwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25OYXZpZ2F0ZSgncG9ydGFscycpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtYmx1ZS00MDAgaG92ZXI6dGV4dC1ibHVlLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHNwYW4+VmlldyBBbGwgNTArIFBvcnRhbHM8L3NwYW4+XG4gICAgICAgICAgICA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtM1wiPlxuICAgICAgICAgIHtwb3B1bGFyUG9ydGFscy5tYXAoKHBvcnRhbCkgPT4gKFxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBrZXk9e3BvcnRhbC5pZH1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzgwIGhvdmVyOmJnLXNsYXRlLTg1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItc2xhdGUtNzAwIHAtMy41IHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgc2hhZG93LXNtIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMiBtYi0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgbWluLXctMFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsXCI+e3BvcnRhbC5pY29ufTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMjAwIHRydW5jYXRlXCI+e3BvcnRhbC50aXRsZX08L2g0PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgbGluZS1jbGFtcC0yIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAge3BvcnRhbC5kZXNjcmlwdGlvbn1cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBwdC0yLjUgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMC82MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgaHJlZj17cG9ydGFsLnVybH1cbiAgICAgICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LWJsdWUtNDAwIGhvdmVyOnRleHQtYmx1ZS0zMDAgaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5PcGVuIE9mZmljaWFsPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPEV4dGVybmFsTGluayBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cbiAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25OYXZpZ2F0ZSgncG9ydGFscycpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC1zbGF0ZS0zMDBcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIERvY3MgSW5mb1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogU3BsaXQgU2VjdGlvbjogUmVjZW50IEJpbGxzICYgQW5ub3VuY2VtZW50cyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMyBnYXAtNlwiPlxuICAgICAgICB7LyogUmVjZW50IEJpbGxzICgyIGNvbHVtbnMpICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTIgYmctc2xhdGUtOTAwLzkwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNSBzaGFkb3ctbWQgc3BhY2UteS00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1iYXNlIHRleHQtd2hpdGVcIj5SZWNlbnQgQ3VzdG9tZXIgQmlsbGluZyBSZWNlaXB0czwvaDM+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5RdWljayBwcmludCB0aGVybWFsIHNsaXAgb3Igc2hhcmUgdmlhIFdoYXRzQXBwPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGUoJ2JpbGxpbmcnKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtYmx1ZS00MDAgaG92ZXI6dGV4dC1ibHVlLTMwMFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIEZ1bGwgTGVkZ2VyIOKGklxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxuICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgdGV4dC14c1wiPlxuICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHRleHQtc2xhdGUtNDAwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zXCI+SW52b2ljZTwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5DdXN0b21lcjwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5TZXJ2aWNlPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMyB0ZXh0LXJpZ2h0XCI+QW1vdW50PC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMyB0ZXh0LWNlbnRlclwiPlN0YXR1czwvdGg+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTMgdGV4dC1yaWdodFwiPkFjdGlvbnM8L3RoPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtODAwLzYwXCI+XG4gICAgICAgICAgICAgICAge2JpbGxzLnNsaWNlKDAsIDUpLm1hcCgoYmlsbCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPHRyIGtleT17YmlsbC5pZH0gY2xhc3NOYW1lPVwiaG92ZXI6Ymctc2xhdGUtODAwLzQwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTMgZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMFwiPntiaWxsLmludm9pY2VOb308L3RkPlxuICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtd2hpdGVcIj57YmlsbC5jdXN0b21lck5hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LW1vbm9cIj57YmlsbC5jdXN0b21lck1vYmlsZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtMyB0ZXh0LXNsYXRlLTMwMCBtYXgtdy1bMTYwcHhdIHRydW5jYXRlXCI+e2JpbGwuc2VydmljZU5hbWV9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtMyB0ZXh0LXJpZ2h0IGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtbW9ub1wiPuKCuXtiaWxsLnRvdGFsfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIHB5LTAuNSByb3VuZGVkIHRleHQtWzEwcHhdIGZvbnQtYm9sZCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgYmlsbC5zdGF0dXMgPT09ICdQYWlkJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTMwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwJyBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctYW1iZXItNTAwLzIwIHRleHQtYW1iZXItMzAwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzMwJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtiaWxsLnN0YXR1c31cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1yaWdodCBzcGFjZS14LTEuNSB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uUHJpbnRCaWxsKGJpbGwpfVxuICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJQcmludCBUaGVybWFsIFNsaXBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC1sZyBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMjAwIGhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxQcmludGVyIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj17YGh0dHBzOi8vd2EubWUvOTEke2JpbGwuY3VzdG9tZXJNb2JpbGV9P3RleHQ9SGVsbG8lMjAke2VuY29kZVVSSUNvbXBvbmVudChiaWxsLmN1c3RvbWVyTmFtZSl9LCUyMHlvdXIlMjBiaWxsJTIwYXQlMjAke2VuY29kZVVSSUNvbXBvbmVudChzZXR0aW5ncy5zaG9wTmFtZSl9JTIwZm9yJTIwJHtlbmNvZGVVUklDb21wb25lbnQoYmlsbC5zZXJ2aWNlTmFtZSl9JTIwaXMlMjBScy4ke2JpbGwudG90YWx9LiUyMFRoYW5rJTIweW91IWB9XG4gICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgICAgICAgICAgICAgICAgICAgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiXG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIlNoYXJlIG9uIFdoYXRzQXBwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHJvdW5kZWQtbGcgYmctZW1lcmFsZC02MDAvMjAgaG92ZXI6YmctZW1lcmFsZC02MDAvNDAgdGV4dC1lbWVyYWxkLTQwMCBpbmxpbmUtYmxvY2sgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxTZW5kIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3Rib2R5PlxuICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIE5vdGljZXMgJiBDU0MgT3BlcmF0b3IgVGlwcyAoMSBjb2x1bW4pICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMC85MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTUgc2hhZG93LW1kIHNwYWNlLXktNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxBbGVydENpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1iYXNlIHRleHQtd2hpdGVcIj5Hb3Z0IFNjaGVtZSBOb3RpY2VzPC9oMz5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zIHRleHQteHNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQteGwgYmctYW1iZXItNTAwLzEwIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzIwIHRleHQtYW1iZXItMjAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgYmxvY2sgdGV4dC1hbWJlci0zMDAgbWItMVwiPvCfk6IgTWFqaGkgTGFka2kgQmFoaW4gWW9qYW5hIEFsZXJ0Ojwvc3Bhbj5cbiAgICAgICAgICAgICAgRW5zdXJlIHRoZSBiZW5lZmljaWFyeSdzIGJhbmsgYWNjb3VudCBoYXMgREJUIC8gTlBDSSBzZWVkaW5nIGFjdGl2ZS4gSWYgTlBDSSBtYXBwaW5nIGlzIG5vdCBkb25lLCBtb250aGx5IOKCuTEsNTAwIGluc3RhbG1lbnQgd2lsbCBmYWlsLlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQteGwgYmctYmx1ZS01MDAvMTAgYm9yZGVyIGJvcmRlci1ibHVlLTUwMC8yMCB0ZXh0LWJsdWUtMjAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgYmxvY2sgdGV4dC1ibHVlLTMwMCBtYi0xXCI+8J+qqiBQVkMgQ2FyZCBQcmludGluZyBQcmVzZXQ6PC9zcGFuPlxuICAgICAgICAgICAgICBVc2UgU3RhbmRhcmQgNMOXNiBpbmNoIFBob3RvIFBhcGVyIHdpdGggMzAwIERQSSBtb2RlIG9uIEVwc29uIEw4MDUgLyBDYW5vbiBHMzAxMCBmb3IgY3Jpc3AgQWFkaGFhciAvIFBBTiBjYXJkIHByaW50cy5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLXhsIGJnLXB1cnBsZS01MDAvMTAgYm9yZGVyIGJvcmRlci1wdXJwbGUtNTAwLzIwIHRleHQtcHVycGxlLTIwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIGJsb2NrIHRleHQtcHVycGxlLTMwMCBtYi0xXCI+8J+TuCBTU0MgLyBQb2xpY2UgQmhhcnRpIFBob3Rvczo8L3NwYW4+XG4gICAgICAgICAgICAgIEV4YW0gbm90aWZpY2F0aW9uIHJlcXVpcmVzIENhbmRpZGF0ZSBOYW1lICYgRGF0ZSBwcmludGVkIGF0IHRoZSBib3R0b20gb2YgdGhlIHBhc3Nwb3J0IHBob3RvLiBVc2Ugb3VyIFBhc3Nwb3J0IFN0dWRpbyBwcmVzZXQhXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=