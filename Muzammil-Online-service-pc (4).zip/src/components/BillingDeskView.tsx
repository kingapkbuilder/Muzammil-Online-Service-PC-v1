const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const QRCode = __vite__cjsImport2_qrcode;const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { Receipt, Printer, Send, Search, Trash2, FileSpreadsheet } from "/node_modules/.vite/deps/lucide-react.js?v=090625a0";
import __vite__cjsImport2_qrcode from "/node_modules/.vite/deps/qrcode.js?v=090625a0";
import { COMMON_SHOP_SERVICES } from "/src/data/portalData.ts";
import { printHtmlDocument } from "/src/utils/printer.ts";
var _jsxFileName = "/app/applet/src/components/BillingDeskView.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
export const BillingDeskView = ({ bills, settings, onAddBill, onDeleteBill }) => {
	// New Bill Form State
	const [customerName, setCustomerName] = useState("");
	const [customerMobile, setCustomerMobile] = useState("");
	const [selectedService, setSelectedService] = useState(COMMON_SHOP_SERVICES[0].name);
	const [category, setCategory] = useState(COMMON_SHOP_SERVICES[0].category);
	const [govtFee, setGovtFee] = useState(0);
	const [serviceFee, setServiceFee] = useState(0);
	const [paymentMode, setPaymentMode] = useState("Cash");
	const [paymentStatus, setPaymentStatus] = useState("Paid");
	const [notes, setNotes] = useState("");
	// Generated QR Code Data URL
	const [qrDataUrl, setQrDataUrl] = useState("");
	// Filter & Search
	const [searchTerm, setSearchTerm] = useState("");
	const [dateFilter, setDateFilter] = useState("");
	// Active bill for preview
	const [activePreviewBill, setActivePreviewBill] = useState(null);
	const totalAmount = (Number(govtFee) || 0) + (Number(serviceFee) || 0);
	// Auto-generate invoice number
	const nextInvoiceNo = `MOS-${new Date().getFullYear()}-${String(bills.length + 101).padStart(4, "0")}`;
	// When selected service changes, populate defaults
	const handleServiceSelect = (serviceName) => {
		setSelectedService(serviceName);
		const found = COMMON_SHOP_SERVICES.find((s) => s.name === serviceName);
		if (found) {
			setCategory(found.category);
			setGovtFee(found.govtFee);
			setServiceFee(found.serviceFee);
		}
	};
	// Generate UPI QR Code whenever total or UPI ID changes
	useEffect(() => {
		const upiString = `upi://pay?pa=${settings.upiId}&pn=${encodeURIComponent(settings.shopName)}&am=${totalAmount}&cu=INR&tn=${encodeURIComponent(nextInvoiceNo)}`;
		QRCode.toDataURL(upiString, {
			width: 180,
			margin: 1
		}).then((url) => setQrDataUrl(url)).catch(() => setQrDataUrl(""));
	}, [
		totalAmount,
		settings.upiId,
		settings.shopName,
		nextInvoiceNo
	]);
	// Handle Form Submission
	const handleCreateBill = (e) => {
		e.preventDefault();
		if (!customerName.trim()) {
			alert("Please enter Customer Name");
			return;
		}
		const newBill = {
			id: `bill-${Date.now()}`,
			invoiceNo: nextInvoiceNo,
			customerName: customerName.trim(),
			customerMobile: customerMobile.trim() || "N/A",
			serviceName: selectedService,
			category,
			govtFee: Number(govtFee) || 0,
			serviceFee: Number(serviceFee) || 0,
			total: totalAmount,
			paymentMode,
			status: paymentStatus,
			createdAt: new Date().toLocaleString("en-IN", {
				dateStyle: "medium",
				timeStyle: "short"
			}),
			notes: notes.trim()
		};
		onAddBill(newBill);
		setActivePreviewBill(newBill);
		// Reset customer name & mobile for next transaction
		setCustomerName("");
		setCustomerMobile("");
		setNotes("");
	};
	// Direct Thermal POS Print (58mm or 80mm format)
	const handlePrintThermal = (billToPrint) => {
		const is80 = settings.thermalWidth === "80mm";
		const paperWidth = is80 ? "76mm" : "56mm";
		const pageStyle = `
      @page {
        size: ${paperWidth} auto;
        margin: 0;
      }
      body {
        font-family: 'Courier New', Courier, monospace;
        width: ${paperWidth};
        margin: 0 auto;
        padding: 6px;
        font-size: 12px;
        color: #000;
        line-height: 1.3;
      }
      .center { text-align: center; }
      .right { text-align: right; }
      .bold { font-weight: bold; }
      .divider { border-top: 1px dashed #000; margin: 6px 0; }
      .header { font-size: 15px; font-weight: bold; }
      .qr { text-align: center; margin: 8px 0; }
      .qr img { width: 120px; height: 120px; }
      table { width: 100%; border-collapse: collapse; font-size: 12px; }
      td { padding: 2px 0; }
    `;
		const htmlBody = `
      <div class="center">
        <div class="header">${settings.shopName}</div>
        <div>${settings.tagline}</div>
        <div>${settings.address}</div>
        <div>Mob: ${settings.phone}</div>
      </div>
      <div class="divider"></div>
      <div><b>Invoice:</b> ${billToPrint.invoiceNo}</div>
      <div><b>Date:</b> ${billToPrint.createdAt}</div>
      <div><b>Customer:</b> ${billToPrint.customerName}</div>
      <div><b>Phone:</b> ${billToPrint.customerMobile}</div>
      <div class="divider"></div>
      <table>
        <tr><td class="bold">Service:</td><td class="right">${billToPrint.serviceName}</td></tr>
        ${billToPrint.govtFee > 0 ? `<tr><td>Govt Fee:</td><td class="right">₹${billToPrint.govtFee}</td></tr>` : ""}
        <tr><td>Service Charge:</td><td class="right">₹${billToPrint.serviceFee}</td></tr>
        <tr style="border-top:1px solid #000; font-weight:bold;">
          <td style="font-size:14px;">TOTAL:</td>
          <td class="right" style="font-size:14px;">₹${billToPrint.total}</td>
        </tr>
      </table>
      <div class="divider"></div>
      <div><b>Payment:</b> ${billToPrint.paymentMode} (${billToPrint.status})</div>
      ${settings.upiId ? `
        <div class="qr">
          <div>Scan UPI to Pay:</div>
          <img src="${qrDataUrl}" />
          <div style="font-size:10px;">${settings.upiId}</div>
        </div>
      ` : ""}
      <div class="center" style="font-size:11px; margin-top:8px;">
        <div>*** Thank You Visit Again ***</div>
        <div>Computerized Online Service Receipt</div>
      </div>
    `;
		printHtmlDocument(htmlBody, `Receipt_${billToPrint.invoiceNo}`, pageStyle);
	};
	// Direct A4 Official Invoice Print
	const handlePrintA4 = (billToPrint) => {
		const pageStyle = `
      @page { size: A4; margin: 15mm; }
      body { font-family: sans-serif; margin: 0; padding: 20px; color: #1e293b; font-size: 14px; }
      .header-table { width: 100%; border-bottom: 2px solid #2563eb; padding-bottom: 15px; margin-bottom: 20px; }
      .shop-title { font-size: 24px; font-weight: 800; color: #1e40af; }
      .info-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; margin-bottom: 20px; }
      table.items { width: 100%; border-collapse: collapse; margin-top: 15px; }
      table.items th { background: #2563eb; color: #fff; text-align: left; padding: 10px; font-size: 13px; }
      table.items td { padding: 10px; border-bottom: 1px solid #e2e8f0; }
      .total-row { font-size: 16px; font-weight: bold; background: #eff6ff; }
      .footer { margin-top: 40px; display: flex; justify-content: space-between; align-items: flex-end; }
      .sign { border-top: 1px solid #94a3b8; width: 180px; text-align: center; padding-top: 5px; font-size: 12px; }
    `;
		const htmlBody = `
          <table class="header-table">
            <tr>
              <td>
                <div class="shop-title">${settings.shopName}</div>
                <div>${settings.tagline}</div>
                <div>${settings.address}</div>
                <div>Phone / WhatsApp: ${settings.phone}</div>
                ${settings.gstNo ? `<div>GSTIN: ${settings.gstNo}</div>` : ""}
              </td>
              <td style="text-align:right;">
                <h2 style="margin:0; color:#1e40af;">SERVICE INVOICE</h2>
                <div style="font-family:monospace; font-size:16px; font-weight:bold;">${billToPrint.invoiceNo}</div>
                <div style="margin-top:4px;">Date: ${billToPrint.createdAt}</div>
              </td>
            </tr>
          </table>

          <div class="info-box">
            <table style="width:100%;">
              <tr>
                <td><b>Billed To:</b> ${billToPrint.customerName}</td>
                <td style="text-align:right;"><b>Mobile:</b> ${billToPrint.customerMobile}</td>
              </tr>
            </table>
          </div>

          <table class="items">
            <thead>
              <tr>
                <th>Sr.</th>
                <th>Service Description</th>
                <th>Category</th>
                <th style="text-align:right;">Govt Fee</th>
                <th style="text-align:right;">Service Charge</th>
                <th style="text-align:right;">Total (₹)</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td><b>${billToPrint.serviceName}</b></td>
                <td>${billToPrint.category}</td>
                <td style="text-align:right;">₹${billToPrint.govtFee}</td>
                <td style="text-align:right;">₹${billToPrint.serviceFee}</td>
                <td style="text-align:right; font-weight:bold;">₹${billToPrint.total}</td>
              </tr>
              <tr class="total-row">
                <td colspan="5" style="text-align:right;">GRAND TOTAL:</td>
                <td style="text-align:right; color:#1e40af;">₹${billToPrint.total}.00</td>
              </tr>
            </tbody>
          </table>

          <div style="margin-top:15px; font-size:12px; color:#64748b;">
            Payment Mode: <b>${billToPrint.paymentMode}</b> | Status: <b>${billToPrint.status}</b>
          </div>

          <div class="footer">
            <div style="font-size:11px; color:#64748b;">
              This is a computer generated invoice.<br>Terms: Fees once paid for government portal submissions are non-refundable.
            </div>
            <div class="sign">
              Authorized Signatory<br><b>${settings.shopName}</b>
            </div>
          </div>
        </body>
      </html>
    `;
		printHtmlDocument(htmlBody, `Invoice_${billToPrint.invoiceNo}`, pageStyle);
	};
	// Export ledger to CSV
	const handleExportCSV = () => {
		let csv = "Invoice No,Customer Name,Mobile,Service,Govt Fee,Service Fee,Total,Payment Mode,Status,Date\n";
		bills.forEach((b) => {
			csv += `"${b.invoiceNo}","${b.customerName}","${b.customerMobile}","${b.serviceName}",${b.govtFee},${b.serviceFee},${b.total},"${b.paymentMode}","${b.status}","${b.createdAt}"\n`;
		});
		const blob = new Blob([csv], { type: "text/csv" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `Muzammil_Bills_Ledger_${new Date().toISOString().slice(0, 10)}.csv`;
		a.click();
		URL.revokeObjectURL(url);
	};
	// Filter bills
	const filteredBills = bills.filter((b) => {
		const matchesSearch = b.customerName.toLowerCase().includes(searchTerm.toLowerCase()) || b.customerMobile.includes(searchTerm) || b.invoiceNo.toLowerCase().includes(searchTerm.toLowerCase()) || b.serviceName.toLowerCase().includes(searchTerm.toLowerCase());
		const matchesDate = !dateFilter || b.createdAt.includes(dateFilter);
		return matchesSearch && matchesDate;
	});
	const activeDisplayBill = activePreviewBill || (bills.length > 0 ? bills[0] : null);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl font-extrabold text-white",
						children: "Billing Desk & POS Station"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 310,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs px-2 py-0.5 rounded-full font-mono font-bold",
						children: [settings.thermalWidth, " POS / A4"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 311,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 309,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400 mt-0.5",
					children: "Quick customer billing, dynamic UPI QR payments, 58mm/80mm thermal receipt printing & WhatsApp notification"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 315,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 308,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: /* @__PURE__ */ _jsxDEV("button", {
						onClick: handleExportCSV,
						className: "flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs px-3 py-2 rounded-xl border border-slate-700 transition-all",
						title: "Export Bills Ledger to Excel CSV",
						children: [/* @__PURE__ */ _jsxDEV(FileSpreadsheet, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 326,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Export CSV" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 327,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 321,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 320,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 307,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-5 items-start",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-7 space-y-4",
					children: /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleCreateBill,
						className: "bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-md space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between border-b border-slate-800 pb-3",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV(Receipt, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 339,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Create New Customer Receipt" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 340,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 338,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-mono font-bold text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20",
									children: ["Next: ", nextInvoiceNo]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 342,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 337,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "font-semibold text-slate-300 block mb-1",
									children: "Customer Full Name *"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 350,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									required: true,
									placeholder: "e.g. Shaikh Sameer",
									value: customerName,
									onChange: (e) => setCustomerName(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 text-sm font-medium"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 351,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 349,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "font-semibold text-slate-300 block mb-1",
									children: "Customer Mobile (WhatsApp) *"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 362,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "tel",
									placeholder: "10 digit mobile (e.g. 9561460313)",
									value: customerMobile,
									onChange: (e) => setCustomerMobile(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 text-sm font-mono"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 363,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 361,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 348,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-xs space-y-1",
								children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "font-semibold text-slate-300 block",
									children: "Select Service / Application *"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 375,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("select", {
									value: selectedService,
									onChange: (e) => handleServiceSelect(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 text-sm font-medium",
									children: COMMON_SHOP_SERVICES.map((s) => /* @__PURE__ */ _jsxDEV("option", {
										value: s.name,
										children: [
											s.name,
											" (Govt: ₹",
											s.govtFee,
											" + Fee: ₹",
											s.serviceFee,
											" = ₹",
											s.govtFee + s.serviceFee,
											")"
										]
									}, s.name, true, {
										fileName: _jsxFileName,
										lineNumber: 382,
										columnNumber: 19
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 376,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 374,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-2 bg-slate-950/60 p-3 rounded-xl border border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-3 gap-3 text-xs",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-slate-400 block mb-1",
											children: "Govt Portal Fee (₹)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 393,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "number",
											min: "0",
											placeholder: "0",
											value: govtFee || "",
											onChange: (e) => setGovtFee(Number(e.target.value) || 0),
											className: "w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono text-sm"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 394,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 392,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-slate-400 block mb-1",
											children: "Shop Service Fee (₹)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 405,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "number",
											min: "0",
											placeholder: "0",
											value: serviceFee || "",
											onChange: (e) => setServiceFee(Number(e.target.value) || 0),
											className: "w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono text-sm"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 406,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 404,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-emerald-400 font-bold block mb-1",
											children: "Total Bill Amount"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 417,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "h-8 rounded-lg bg-emerald-950/40 border border-emerald-500/40 flex items-center px-3 font-mono font-black text-emerald-400 text-base",
											children: ["₹", totalAmount]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 418,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 416,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 391,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1.5 pt-1 flex-wrap text-[11px]",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-500 text-[10px]",
											children: "Quick Add:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 426,
											columnNumber: 17
										}, this),
										[
											10,
											20,
											30,
											50,
											70,
											100,
											150
										].map((amt) => /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => setServiceFee((prev) => (Number(prev) || 0) + amt),
											className: "px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 font-mono",
											children: ["+₹", amt]
										}, amt, true, {
											fileName: _jsxFileName,
											lineNumber: 428,
											columnNumber: 19
										}, this)),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => {
												setGovtFee(0);
												setServiceFee(0);
											},
											className: "px-2 py-0.5 rounded bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 font-bold ml-auto",
											children: "Reset ₹0"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 437,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 425,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 390,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "font-semibold text-slate-300 block mb-1",
									children: "Payment Method"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 450,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-3 gap-1.5",
									children: [
										"Cash",
										"UPI / QR",
										"Pending"
									].map((mode) => /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setPaymentMode(mode),
										className: `py-1.5 px-2 rounded-lg font-bold border transition-all ${paymentMode === mode ? "bg-blue-600 text-white border-blue-500 shadow-sm" : "bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800"}`,
										children: mode
									}, mode, false, {
										fileName: _jsxFileName,
										lineNumber: 453,
										columnNumber: 21
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 451,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 449,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "font-semibold text-slate-300 block mb-1",
									children: "Payment Status"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 470,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-1.5",
									children: ["Paid", "Due"].map((st) => /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setPaymentStatus(st === "Due" ? "Due" : "Paid"),
										className: `py-1.5 px-2 rounded-lg font-bold border transition-all ${paymentStatus === st ? st === "Paid" ? "bg-emerald-600 text-white border-emerald-500" : "bg-rose-600 text-white border-rose-500" : "bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800"}`,
										children: st
									}, st, false, {
										fileName: _jsxFileName,
										lineNumber: 473,
										columnNumber: 21
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 471,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 469,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 448,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-xs",
								children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-400 block mb-1",
									children: "Service Remarks / Ack Token (Optional)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 494,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									placeholder: "e.g. Ack token 88124, 2 copies printed",
									value: notes,
									onChange: (e) => setNotes(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-1.5 text-white placeholder-slate-500 text-xs"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 495,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 493,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								className: "w-full flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-sm py-3 rounded-xl shadow-lg shadow-emerald-600/30 transition-all hover:scale-[1.01] active:scale-[0.99]",
								children: [/* @__PURE__ */ _jsxDEV(Receipt, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 509,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
									"Generate Receipt & Save (₹",
									totalAmount,
									")"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 510,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 505,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 336,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 335,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-5 space-y-3",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between mb-3 text-xs",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "font-bold text-white flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 520,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Live POS Thermal Slip Preview" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 521,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 519,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[11px] font-mono text-slate-400 bg-slate-800 px-2 py-0.5 rounded",
									children: [settings.thermalWidth, " Monospace"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 523,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 518,
								columnNumber: 13
							}, this),
							activeDisplayBill ? /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-white text-slate-950 p-5 rounded-xl shadow-2xl font-mono text-xs select-text border border-slate-300 mx-auto max-w-[340px] leading-relaxed",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-center space-y-0.5 border-b border-dashed border-slate-400 pb-3",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "font-black text-sm uppercase tracking-tight",
												children: settings.shopName
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 533,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-[11px] text-slate-600",
												children: settings.tagline
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 534,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-[10px] text-slate-600",
												children: settings.address
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 535,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-[11px] font-bold",
												children: ["Mob: ", settings.phone]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 536,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 532,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "py-2.5 border-b border-dashed border-slate-400 space-y-0.5 text-[11px]",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Invoice:" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 542,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "font-bold",
													children: activeDisplayBill.invoiceNo
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 543,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 541,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Date:" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 546,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: activeDisplayBill.createdAt }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 547,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 545,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Customer:" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 550,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "font-bold",
													children: activeDisplayBill.customerName
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 551,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 549,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Phone:" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 554,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: activeDisplayBill.customerMobile }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 555,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 553,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 540,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "py-2.5 border-b border-dashed border-slate-400 space-y-1 text-xs",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "font-bold",
												children: activeDisplayBill.serviceName
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 561,
												columnNumber: 19
											}, this),
											activeDisplayBill.govtFee > 0 && /* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between text-[11px] text-slate-700",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Govt Portal Fee:" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 564,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["₹", activeDisplayBill.govtFee] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 565,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 563,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between text-[11px] text-slate-700",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Service Charge:" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 569,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["₹", activeDisplayBill.serviceFee] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 570,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 568,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between font-black text-sm pt-1 border-t border-slate-900 mt-1",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "NET TOTAL:" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 573,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
													"₹",
													activeDisplayBill.total,
													".00"
												] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 574,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 572,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 560,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "pt-2 text-center space-y-2",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-[11px] font-semibold",
												children: [
													"Payment Mode: ",
													/* @__PURE__ */ _jsxDEV("b", { children: activeDisplayBill.paymentMode }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 581,
														columnNumber: 35
													}, this),
													" (",
													activeDisplayBill.status,
													")"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 580,
												columnNumber: 19
											}, this),
											settings.upiId && /* @__PURE__ */ _jsxDEV("div", {
												className: "flex flex-col items-center justify-center p-2 bg-slate-50 rounded-lg border border-slate-200",
												children: [
													/* @__PURE__ */ _jsxDEV("span", {
														className: "text-[10px] text-slate-500 mb-1",
														children: "Scan QR via GPay / PhonePe / Paytm:"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 586,
														columnNumber: 23
													}, this),
													qrDataUrl && /* @__PURE__ */ _jsxDEV("img", {
														src: qrDataUrl,
														alt: "UPI QR",
														className: "w-28 h-28"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 587,
														columnNumber: 37
													}, this),
													/* @__PURE__ */ _jsxDEV("span", {
														className: "text-[10px] font-bold font-mono text-slate-700 mt-1",
														children: settings.upiId
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 588,
														columnNumber: 23
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 585,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-[10px] text-slate-500 pt-1",
												children: [
													"*** Thank You Visit Again ***",
													/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 593,
														columnNumber: 50
													}, this),
													"Muzammil Online Service Digital Hub"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 592,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 579,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 530,
								columnNumber: 15
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "p-8 text-center text-slate-500 text-xs",
								children: "No bill selected. Create a bill on the left to see live preview."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 599,
								columnNumber: 15
							}, this),
							activeDisplayBill && /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-slate-800",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => handlePrintThermal(activeDisplayBill),
										className: "flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs py-2 rounded-xl shadow-md transition-colors",
										title: "Print on 58mm/80mm Thermal Printer",
										children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 612,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Thermal" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 613,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 607,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => handlePrintA4(activeDisplayBill),
										className: "flex items-center justify-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs py-2 rounded-xl border border-slate-700 transition-colors",
										title: "Print Official A4 Tax Invoice",
										children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5 text-purple-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 621,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "A4 Invoice" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 622,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 616,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("a", {
										href: `https://wa.me/91${activeDisplayBill.customerMobile}?text=Hello%20${encodeURIComponent(activeDisplayBill.customerName)},%20your%20receipt%20for%20${encodeURIComponent(activeDisplayBill.serviceName)}%20at%20${encodeURIComponent(settings.shopName)}%20is%20ready.%20Total:%20Rs.${activeDisplayBill.total}.%20Invoice:%20${activeDisplayBill.invoiceNo}`,
										target: "_blank",
										rel: "noopener noreferrer",
										className: "flex items-center justify-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs py-2 rounded-xl shadow-md transition-colors",
										title: "Send Receipt via WhatsApp",
										children: [/* @__PURE__ */ _jsxDEV(Send, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 632,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "WhatsApp" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 633,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 625,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 606,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 517,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 516,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 333,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md space-y-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
						className: "font-bold text-base text-white",
						children: "Billing History & Sales Ledger"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 645,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400",
						children: [
							"Total ",
							bills.length,
							" bills recorded in local database"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 646,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 644,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "relative",
							children: [/* @__PURE__ */ _jsxDEV(Search, { className: "w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 651,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								placeholder: "Filter by customer, phone, invoice...",
								value: searchTerm,
								onChange: (e) => setSearchTerm(e.target.value),
								className: "bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 w-56"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 652,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 650,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 649,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 643,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "overflow-x-auto",
					children: /* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-left text-xs",
						children: [/* @__PURE__ */ _jsxDEV("thead", {
							className: "bg-slate-950 text-slate-400 border-b border-slate-800 font-mono",
							children: /* @__PURE__ */ _jsxDEV("tr", { children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Invoice"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 667,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Date & Time"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 668,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Customer"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 669,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Mobile"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 670,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Service"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 671,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3 text-right",
									children: "Govt"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 672,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3 text-right",
									children: "Fee"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 673,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3 text-right",
									children: "Total"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 674,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3 text-center",
									children: "Status"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 675,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3 text-right",
									children: "Actions"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 676,
									columnNumber: 17
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 666,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 665,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("tbody", {
							className: "divide-y divide-slate-800/60",
							children: filteredBills.map((b) => /* @__PURE__ */ _jsxDEV("tr", {
								onClick: () => setActivePreviewBill(b),
								className: `cursor-pointer transition-colors ${activePreviewBill?.id === b.id ? "bg-blue-950/30" : "hover:bg-slate-800/40"}`,
								children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 font-mono font-bold text-blue-400",
										children: b.invoiceNo
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 688,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 text-slate-400 font-mono text-[11px]",
										children: b.createdAt
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 689,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 font-semibold text-white",
										children: b.customerName
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 690,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 font-mono text-slate-400",
										children: b.customerMobile
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 691,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 text-slate-300 max-w-[200px] truncate",
										children: b.serviceName
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 692,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 text-right font-mono text-slate-400",
										children: ["₹", b.govtFee]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 693,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 text-right font-mono text-slate-400",
										children: ["₹", b.serviceFee]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 694,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 text-right font-mono font-bold text-emerald-400",
										children: ["₹", b.total]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 695,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 text-center",
										children: /* @__PURE__ */ _jsxDEV("span", {
											className: `px-2 py-0.5 rounded text-[10px] font-bold ${b.status === "Paid" ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30" : "bg-amber-500/20 text-amber-300 border border-amber-500/30"}`,
											children: b.status
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 697,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 696,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-3 px-3 text-right space-x-1 whitespace-nowrap",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											onClick: (e) => {
												e.stopPropagation();
												handlePrintThermal(b);
											},
											title: "Print Thermal Slip",
											className: "p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors",
											children: /* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 711,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 706,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: (e) => {
												e.stopPropagation();
												onDeleteBill(b.id);
											},
											title: "Delete Bill",
											className: "p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 transition-colors",
											children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 718,
												columnNumber: 23
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 713,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 705,
										columnNumber: 19
									}, this)
								]
							}, b.id, true, {
								fileName: _jsxFileName,
								lineNumber: 681,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 679,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 664,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 663,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 642,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 305,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQXlCO0FBQ25ELFNBQ0UsU0FDQSxTQUNBLE1BRUEsUUFDQSxRQUtBLHVCQUlLO0FBQ1AsT0FBTyxZQUFZO0FBRW5CLFNBQVMsNEJBQTRCO0FBQ3JDLFNBQVMseUJBQXlCOzs7QUFTbEMsT0FBTyxNQUFNLG1CQUFtRCxFQUM5RCxPQUNBLFVBQ0EsV0FDQSxtQkFDSTs7Q0FFSixNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxFQUFFO0NBQ25ELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVMsRUFBRTtDQUN2RCxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFTLHFCQUFxQixFQUFFLENBQUMsSUFBSTtDQUNuRixNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVMscUJBQXFCLEVBQUUsQ0FBQyxRQUFRO0NBQ3pFLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBaUIsQ0FBQztDQUNoRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBaUIsQ0FBQztDQUN0RCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBbUQsTUFBTTtDQUMvRixNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBcUMsTUFBTTtDQUNyRixNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTs7Q0FHckMsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQWlCLEVBQUU7O0NBR3JELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEVBQUU7Q0FDL0MsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsRUFBRTs7Q0FHL0MsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBMEIsSUFBSTtDQUVoRixNQUFNLGVBQWUsT0FBTyxPQUFPLEtBQUssTUFBTSxPQUFPLFVBQVUsS0FBSzs7Q0FHcEUsTUFBTSxnQkFBZ0IsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVksRUFBRSxHQUFHLE9BQU8sTUFBTSxTQUFTLEdBQUcsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHOztDQUduRyxNQUFNLHVCQUF1QixnQkFBd0I7RUFDbkQsbUJBQW1CLFdBQVc7RUFDOUIsTUFBTSxRQUFRLHFCQUFxQixNQUFLLE1BQUssRUFBRSxTQUFTLFdBQVc7RUFDbkUsSUFBSSxPQUFPO0dBQ1QsWUFBWSxNQUFNLFFBQVE7R0FDMUIsV0FBVyxNQUFNLE9BQU87R0FDeEIsY0FBYyxNQUFNLFVBQVU7RUFDaEM7Q0FDRjs7Q0FHQSxnQkFBZ0I7RUFDZCxNQUFNLFlBQVksZ0JBQWdCLFNBQVMsTUFBTSxNQUFNLG1CQUFtQixTQUFTLFFBQVEsRUFBRSxNQUFNLFlBQVksYUFBYSxtQkFBbUIsYUFBYTtFQUM1SixPQUFPLFVBQVUsV0FBVztHQUFFLE9BQU87R0FBSyxRQUFRO0VBQUUsQ0FBQyxDQUFDLENBQ25ELE1BQUssUUFBTyxhQUFhLEdBQUcsQ0FBQyxDQUFDLENBQzlCLFlBQVksYUFBYSxFQUFFLENBQUM7Q0FDakMsR0FBRztFQUFDO0VBQWEsU0FBUztFQUFPLFNBQVM7RUFBVTtDQUFhLENBQUM7O0NBR2xFLE1BQU0sb0JBQW9CLE1BQXVCO0VBQy9DLEVBQUUsZUFBZTtFQUNqQixJQUFJLENBQUMsYUFBYSxLQUFLLEdBQUc7R0FDeEIsTUFBTSw0QkFBNEI7R0FDbEM7RUFDRjtFQUVBLE1BQU0sVUFBb0I7R0FDeEIsSUFBSSxRQUFRLEtBQUssSUFBSTtHQUNyQixXQUFXO0dBQ1gsY0FBYyxhQUFhLEtBQUs7R0FDaEMsZ0JBQWdCLGVBQWUsS0FBSyxLQUFLO0dBQ3pDLGFBQWE7R0FDSDtHQUNWLFNBQVMsT0FBTyxPQUFPLEtBQUs7R0FDNUIsWUFBWSxPQUFPLFVBQVUsS0FBSztHQUNsQyxPQUFPO0dBQ007R0FDYixRQUFRO0dBQ1IsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLGVBQWUsU0FBUztJQUM1QyxXQUFXO0lBQ1gsV0FBVztHQUNiLENBQUM7R0FDRCxPQUFPLE1BQU0sS0FBSztFQUNwQjtFQUVBLFVBQVUsT0FBTztFQUNqQixxQkFBcUIsT0FBTzs7RUFHNUIsZ0JBQWdCLEVBQUU7RUFDbEIsa0JBQWtCLEVBQUU7RUFDcEIsU0FBUyxFQUFFO0NBQ2I7O0NBR0EsTUFBTSxzQkFBc0IsZ0JBQTBCO0VBQ3BELE1BQU0sT0FBTyxTQUFTLGlCQUFpQjtFQUN2QyxNQUFNLGFBQWEsT0FBTyxTQUFTO0VBRW5DLE1BQU0sWUFBWTs7Z0JBRU4sV0FBVzs7Ozs7aUJBS1YsV0FBVzs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFrQnhCLE1BQU0sV0FBVzs7OEJBRVMsU0FBUyxTQUFTO2VBQ2pDLFNBQVMsUUFBUTtlQUNqQixTQUFTLFFBQVE7b0JBQ1osU0FBUyxNQUFNOzs7NkJBR04sWUFBWSxVQUFVOzBCQUN6QixZQUFZLFVBQVU7OEJBQ2xCLFlBQVksYUFBYTsyQkFDNUIsWUFBWSxlQUFlOzs7OERBR1EsWUFBWSxZQUFZO1VBQzVFLFlBQVksVUFBVSxJQUFJLDRDQUE0QyxZQUFZLFFBQVEsY0FBYyxHQUFHO3lEQUM1RCxZQUFZLFdBQVc7Ozt1REFHekIsWUFBWSxNQUFNOzs7OzZCQUk1QyxZQUFZLFlBQVksSUFBSSxZQUFZLE9BQU87UUFDcEUsU0FBUyxRQUFROzs7c0JBR0gsVUFBVTt5Q0FDUyxTQUFTLE1BQU07O1VBRTlDLEdBQUc7Ozs7OztFQU9ULGtCQUFrQixVQUFVLFdBQVcsWUFBWSxhQUFhLFNBQVM7Q0FDM0U7O0NBR0EsTUFBTSxpQkFBaUIsZ0JBQTBCO0VBQy9DLE1BQU0sWUFBWTs7Ozs7Ozs7Ozs7OztFQWNsQixNQUFNLFdBQVc7Ozs7MENBSXFCLFNBQVMsU0FBUzt1QkFDckMsU0FBUyxRQUFRO3VCQUNqQixTQUFTLFFBQVE7eUNBQ0MsU0FBUyxNQUFNO2tCQUN0QyxTQUFTLFFBQVEsZUFBZSxTQUFTLE1BQU0sVUFBVSxHQUFHOzs7O3dGQUlVLFlBQVksVUFBVTtxREFDekQsWUFBWSxVQUFVOzs7Ozs7Ozt3Q0FRbkMsWUFBWSxhQUFhOytEQUNGLFlBQVksZUFBZTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt5QkFtQmpFLFlBQVksWUFBWTtzQkFDM0IsWUFBWSxTQUFTO2lEQUNNLFlBQVksUUFBUTtpREFDcEIsWUFBWSxXQUFXO21FQUNMLFlBQVksTUFBTTs7OztnRUFJckIsWUFBWSxNQUFNOzs7Ozs7K0JBTW5ELFlBQVksWUFBWSxvQkFBb0IsWUFBWSxPQUFPOzs7Ozs7OzsyQ0FRbkQsU0FBUyxTQUFTOzs7Ozs7RUFPekQsa0JBQWtCLFVBQVUsV0FBVyxZQUFZLGFBQWEsU0FBUztDQUMzRTs7Q0FHQSxNQUFNLHdCQUF3QjtFQUM1QixJQUFJLE1BQU07RUFDVixNQUFNLFNBQVEsTUFBSztHQUNqQixPQUFPLElBQUksRUFBRSxVQUFVLEtBQUssRUFBRSxhQUFhLEtBQUssRUFBRSxlQUFlLEtBQUssRUFBRSxZQUFZLElBQUksRUFBRSxRQUFRLEdBQUcsRUFBRSxXQUFXLEdBQUcsRUFBRSxNQUFNLElBQUksRUFBRSxZQUFZLEtBQUssRUFBRSxPQUFPLEtBQUssRUFBRSxVQUFVO0VBQ2hMLENBQUM7RUFDRCxNQUFNLE9BQU8sSUFBSSxLQUFLLENBQUMsR0FBRyxHQUFHLEVBQUUsTUFBTSxXQUFXLENBQUM7RUFDakQsTUFBTSxNQUFNLElBQUksZ0JBQWdCLElBQUk7RUFDcEMsTUFBTSxJQUFJLFNBQVMsY0FBYyxHQUFHO0VBQ3BDLEVBQUUsT0FBTztFQUNULEVBQUUsV0FBVyx5QkFBeUIsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxNQUFNLEdBQUcsRUFBRSxFQUFFO0VBQzVFLEVBQUUsTUFBTTtFQUNSLElBQUksZ0JBQWdCLEdBQUc7Q0FDekI7O0NBR0EsTUFBTSxnQkFBZ0IsTUFBTSxRQUFPLE1BQUs7RUFDdEMsTUFBTSxnQkFDSixFQUFFLGFBQWEsWUFBWSxDQUFDLENBQUMsU0FBUyxXQUFXLFlBQVksQ0FBQyxLQUM5RCxFQUFFLGVBQWUsU0FBUyxVQUFVLEtBQ3BDLEVBQUUsVUFBVSxZQUFZLENBQUMsQ0FBQyxTQUFTLFdBQVcsWUFBWSxDQUFDLEtBQzNELEVBQUUsWUFBWSxZQUFZLENBQUMsQ0FBQyxTQUFTLFdBQVcsWUFBWSxDQUFDO0VBQy9ELE1BQU0sY0FBYyxDQUFDLGNBQWMsRUFBRSxVQUFVLFNBQVMsVUFBVTtFQUNsRSxPQUFPLGlCQUFpQjtDQUMxQixDQUFDO0NBRUQsTUFBTSxvQkFBb0Isc0JBQXNCLE1BQU0sU0FBUyxJQUFJLE1BQU0sS0FBSztDQUU5RSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBb0M7S0FBOEI7Ozs7ZUFDaEYsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCLENBQ0csU0FBUyxjQUFhLFdBQ25COzs7OzthQUNIOzs7OztjQUNMLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWdDO0lBRTFDOzs7O1lBQ0E7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtNQUNWLE9BQU07Z0JBSFIsQ0FLRSx3QkFBQyxpQkFBRCxFQUFpQixXQUFVLDJCQUE0Qjs7OztnQkFDdkQsd0JBQUMsUUFBRCxZQUFNLGFBQWdCOzs7O2NBQ2hCOzs7Ozs7SUFDTDs7OztZQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBRUUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxRQUFEO01BQU0sVUFBVTtNQUFrQixXQUFVO2dCQUE1QztPQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCLENBQ0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsMkJBQTRCOzs7O21CQUMvQyx3QkFBQyxRQUFELFlBQU0sOEJBQWlDOzs7O2lCQUNuQzs7Ozs7a0JBQ04sd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCLENBQXlILFVBQ2hILGFBQ0g7Ozs7O2dCQUNIOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBMEM7UUFBMkI7Ozs7a0JBQ3RGLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0w7U0FDQSxhQUFZO1NBQ1osT0FBTztTQUNQLFdBQVcsTUFBTSxnQkFBZ0IsRUFBRSxPQUFPLEtBQUs7U0FDL0MsV0FBVTtRQUNYOzs7O2dCQUNFOzs7O2tCQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBMEM7UUFBbUM7Ozs7a0JBQzlGLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsYUFBWTtTQUNaLE9BQU87U0FDUCxXQUFXLE1BQU0sa0JBQWtCLEVBQUUsT0FBTyxLQUFLO1NBQ2pELFdBQVU7UUFDWDs7OztnQkFDRTs7OztnQkFDRjs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBcUM7UUFBcUM7Ozs7a0JBQzNGLHdCQUFDLFVBQUQ7U0FDRSxPQUFPO1NBQ1AsV0FBVyxNQUFNLG9CQUFvQixFQUFFLE9BQU8sS0FBSztTQUNuRCxXQUFVO21CQUVULHFCQUFxQixLQUFLLE1BQ3pCLHdCQUFDLFVBQUQ7VUFBcUIsT0FBTyxFQUFFO29CQUE5QjtXQUNHLEVBQUU7V0FBSztXQUFVLEVBQUU7V0FBUTtXQUFVLEVBQUU7V0FBVztXQUFLLEVBQUUsVUFBVSxFQUFFO1dBQVc7VUFDM0U7WUFGSyxFQUFFOzs7O2dCQUVQLENBQ1Q7UUFDSzs7OztnQkFDTDs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBNEI7VUFBMEI7Ozs7b0JBQ3ZFLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsS0FBSTtXQUNKLGFBQVk7V0FDWixPQUFPLFdBQVc7V0FDbEIsV0FBVyxNQUFNLFdBQVcsT0FBTyxFQUFFLE9BQU8sS0FBSyxLQUFLLENBQUM7V0FDdkQsV0FBVTtVQUNYOzs7O2tCQUNFOzs7OztVQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBNEI7VUFBMkI7Ozs7b0JBQ3hFLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsS0FBSTtXQUNKLGFBQVk7V0FDWixPQUFPLGNBQWM7V0FDckIsV0FBVyxNQUFNLGNBQWMsT0FBTyxFQUFFLE9BQU8sS0FBSyxLQUFLLENBQUM7V0FDMUQsV0FBVTtVQUNYOzs7O2tCQUNFOzs7OztVQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBd0M7VUFBd0I7Ozs7b0JBQ2pGLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQXNKLEtBQ2xKLFdBQ0M7Ozs7O2tCQUNGOzs7OztTQUNGOzs7OztrQkFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUE2QjtVQUFnQjs7Ozs7VUFDNUQ7V0FBQztXQUFJO1dBQUk7V0FBSTtXQUFJO1dBQUk7V0FBSztVQUFHLENBQUMsQ0FBQyxLQUFLLFFBQ25DLHdCQUFDLFVBQUQ7V0FDRSxNQUFLO1dBRUwsZUFBZSxlQUFlLFVBQVUsT0FBTyxJQUFJLEtBQUssS0FBSyxHQUFHO1dBQ2hFLFdBQVU7cUJBSlosQ0FLQyxNQUNJLEdBQ0c7YUFMRDs7OztpQkFLQyxDQUNUO1VBQ0Qsd0JBQUMsVUFBRDtXQUNFLE1BQUs7V0FDTCxlQUFlO1lBQUUsV0FBVyxDQUFDO1lBQUcsY0FBYyxDQUFDO1dBQUc7V0FDbEQsV0FBVTtxQkFDWDtVQUVPOzs7OztTQUNMOzs7OztnQkFDRjs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTBDO1FBQXFCOzs7O2tCQUNoRix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWDtVQUFDO1VBQVE7VUFBWTtTQUFTLENBQUMsQ0FBVyxLQUFLLFNBQy9DLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBRUwsZUFBZSxlQUFlLElBQUk7VUFDbEMsV0FBVywwREFDVCxnQkFBZ0IsT0FDWixxREFDQTtvQkFHTDtTQUNLLEdBVEQ7Ozs7Z0JBU0MsQ0FDVDtRQUNFOzs7O2dCQUNGOzs7O2tCQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBMEM7UUFBcUI7Ozs7a0JBQ2hGLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNYLENBQUMsUUFBUSxLQUFLLENBQUMsQ0FBVyxLQUFLLE9BQy9CLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBRUwsZUFBZSxpQkFBaUIsT0FBTyxRQUFRLFFBQVEsTUFBTTtVQUM3RCxXQUFXLDBEQUNULGtCQUFrQixLQUNkLE9BQU8sU0FDTCxpREFDQSwyQ0FDRjtvQkFHTDtTQUNLLEdBWEQ7Ozs7Z0JBV0MsQ0FDVDtRQUNFOzs7O2dCQUNGOzs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUE0QjtRQUE2Qzs7OztrQkFDMUYsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxhQUFZO1NBQ1osT0FBTztTQUNQLFdBQVcsTUFBTSxTQUFTLEVBQUUsT0FBTyxLQUFLO1NBQ3hDLFdBQVU7UUFDWDs7OztnQkFDRTs7Ozs7O09BR0wsd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxXQUFVO2tCQUZaLENBSUUsd0JBQUMsU0FBRCxFQUFTLFdBQVUsVUFBVzs7OztrQkFDOUIsd0JBQUMsUUFBRDtTQUFNO1NBQTJCO1NBQVk7UUFBTzs7OztnQkFDOUM7Ozs7OztNQUNKOzs7Ozs7SUFDSDs7OztjQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUNFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLDRCQUE2Qjs7OzttQkFDaEQsd0JBQUMsUUFBRCxZQUFNLGdDQUFtQzs7OztpQkFDckM7Ozs7O2tCQUNOLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUNHLFNBQVMsY0FBYSxZQUNuQjs7Ozs7Z0JBQ0g7Ozs7OztPQUdKLG9CQUNDLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBRUUsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBK0MsU0FBUztXQUFjOzs7OztXQUNyRix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBOEIsU0FBUztXQUFhOzs7OztXQUNuRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBOEIsU0FBUztXQUFhOzs7OztXQUNuRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUF1QyxTQUFNLFNBQVMsS0FBVzs7Ozs7O1VBQzlEOzs7Ozs7U0FHTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLFdBQWM7Ozs7c0JBQ3BCLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFhLGtCQUFrQjtZQUFnQjs7OztvQkFDNUQ7Ozs7OztXQUNMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLFFBQVc7Ozs7c0JBQ2pCLHdCQUFDLFFBQUQsWUFBTyxrQkFBa0IsVUFBZ0I7Ozs7b0JBQ3RDOzs7Ozs7V0FDTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxZQUFlOzs7O3NCQUNyQix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBYSxrQkFBa0I7WUFBbUI7Ozs7b0JBQy9EOzs7Ozs7V0FDTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxTQUFZOzs7O3NCQUNsQix3QkFBQyxRQUFELFlBQU8sa0JBQWtCLGVBQXFCOzs7O29CQUMzQzs7Ozs7O1VBQ0Y7Ozs7OztTQUdMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWEsa0JBQWtCO1dBQWlCOzs7OztXQUM5RCxrQkFBa0IsVUFBVSxLQUMzQix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxtQkFBc0I7Ozs7c0JBQzVCLHdCQUFDLFFBQUQsYUFBTSxLQUFFLGtCQUFrQixPQUFjOzs7O29CQUNyQzs7Ozs7O1dBRVAsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sa0JBQXFCOzs7O3NCQUMzQix3QkFBQyxRQUFELGFBQU0sS0FBRSxrQkFBa0IsVUFBaUI7Ozs7b0JBQ3hDOzs7Ozs7V0FDTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztzQkFDdEIsd0JBQUMsUUFBRDthQUFNO2FBQUUsa0JBQWtCO2FBQU07WUFBUzs7OztvQkFDdEM7Ozs7OztVQUNGOzs7Ozs7U0FHTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmO2FBQTJDO2FBQzNCLHdCQUFDLEtBQUQsWUFBSSxrQkFBa0IsWUFBZTs7Ozs7YUFBQzthQUFHLGtCQUFrQjthQUFPO1lBQzdFOzs7Ozs7V0FFSixTQUFTLFNBQ1Isd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWY7YUFDRSx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBa0M7YUFBeUM7Ozs7O2FBQzFGLGFBQWEsd0JBQUMsT0FBRDtjQUFLLEtBQUs7Y0FBVyxLQUFJO2NBQVMsV0FBVTthQUFhOzs7OzthQUN2RSx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBdUQsU0FBUzthQUFZOzs7OztZQUN6Rjs7Ozs7O1dBR1Asd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWY7YUFBaUQ7YUFDbEIsd0JBQUMsTUFBRCxDQUFLOzs7OzthQUFDO1lBRWhDOzs7Ozs7VUFDRjs7Ozs7O1FBQ0Y7Ozs7O2tCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUF5QztPQUVuRDs7Ozs7T0FJTixxQkFDQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFVBQUQ7VUFDRSxlQUFlLG1CQUFtQixpQkFBaUI7VUFDbkQsV0FBVTtVQUNWLE9BQU07b0JBSFIsQ0FLRSx3QkFBQyxTQUFELEVBQVMsV0FBVSxjQUFlOzs7O29CQUNsQyx3QkFBQyxRQUFELFlBQU0sVUFBYTs7OztrQkFDYjs7Ozs7O1NBRVIsd0JBQUMsVUFBRDtVQUNFLGVBQWUsY0FBYyxpQkFBaUI7VUFDOUMsV0FBVTtVQUNWLE9BQU07b0JBSFIsQ0FLRSx3QkFBQyxTQUFELEVBQVMsV0FBVSw4QkFBK0I7Ozs7b0JBQ2xELHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztrQkFDaEI7Ozs7OztTQUVSLHdCQUFDLEtBQUQ7VUFDRSxNQUFNLG1CQUFtQixrQkFBa0IsZUFBZSxnQkFBZ0IsbUJBQW1CLGtCQUFrQixZQUFZLEVBQUUsNkJBQTZCLG1CQUFtQixrQkFBa0IsV0FBVyxFQUFFLFVBQVUsbUJBQW1CLFNBQVMsUUFBUSxFQUFFLCtCQUErQixrQkFBa0IsTUFBTSxpQkFBaUIsa0JBQWtCO1VBQ3RWLFFBQU87VUFDUCxLQUFJO1VBQ0osV0FBVTtVQUNWLE9BQU07b0JBTFIsQ0FPRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O29CQUMvQix3QkFBQyxRQUFELFlBQU0sV0FBYzs7OztrQkFDbkI7Ozs7OztRQUNBOzs7Ozs7TUFFSjs7Ozs7O0lBQ0Y7Ozs7WUFDRjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWlDO0tBQWtDOzs7O2VBQ2pGLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFiO09BQXNDO09BQU8sTUFBTTtPQUFPO01BQW9DOzs7OzthQUMzRjs7OztlQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsd0VBQXlFOzs7O2lCQUMzRix3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLGFBQVk7UUFDWixPQUFPO1FBQ1AsV0FBVyxNQUFNLGNBQWMsRUFBRSxPQUFPLEtBQUs7UUFDN0MsV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7OztLQUNGOzs7O2FBQ0Y7Ozs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBakIsQ0FDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFDZix3QkFBQyxNQUFEO1FBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWM7UUFBVzs7Ozs7UUFDdkMsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWM7UUFBZTs7Ozs7UUFDM0Msd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWM7UUFBWTs7Ozs7UUFDeEMsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWM7UUFBVTs7Ozs7UUFDdEMsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWM7UUFBVzs7Ozs7UUFDdkMsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQXlCO1FBQVE7Ozs7O1FBQy9DLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF5QjtRQUFPOzs7OztRQUM5Qyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBeUI7UUFBUzs7Ozs7UUFDaEQsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQTBCO1FBQVU7Ozs7O1FBQ2xELHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF5QjtRQUFXOzs7OztPQUNoRDs7Ozs7TUFDQzs7OztnQkFDUCx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFDZCxjQUFjLEtBQUssTUFDbEIsd0JBQUMsTUFBRDtRQUVFLGVBQWUscUJBQXFCLENBQUM7UUFDckMsV0FBVyxvQ0FDVCxtQkFBbUIsT0FBTyxFQUFFLEtBQUssbUJBQW1CO2tCQUp4RDtTQU9FLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUErQyxFQUFFO1NBQWM7Ozs7O1NBQzdFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFrRCxFQUFFO1NBQWM7Ozs7O1NBQ2hGLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFzQyxFQUFFO1NBQWlCOzs7OztTQUN2RSx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBc0MsRUFBRTtTQUFtQjs7Ozs7U0FDekUsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQW1ELEVBQUU7U0FBZ0I7Ozs7O1NBQ25GLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFkLENBQThELEtBQUUsRUFBRSxPQUFZOzs7Ozs7U0FDOUUsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWQsQ0FBOEQsS0FBRSxFQUFFLFVBQWU7Ozs7OztTQUNqRix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBZCxDQUEwRSxLQUFFLEVBQUUsS0FBVTs7Ozs7O1NBQ3hGLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNaLHdCQUFDLFFBQUQ7V0FBTSxXQUFXLDZDQUNmLEVBQUUsV0FBVyxTQUNULG9FQUNBO3FCQUVILEVBQUU7VUFDQzs7Ozs7U0FDSjs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBZCxDQUNFLHdCQUFDLFVBQUQ7V0FDRSxVQUFVLE1BQU07WUFBRSxFQUFFLGdCQUFnQjtZQUFHLG1CQUFtQixDQUFDO1dBQUc7V0FDOUQsT0FBTTtXQUNOLFdBQVU7cUJBRVYsd0JBQUMsU0FBRCxFQUFTLFdBQVUsY0FBZTs7Ozs7VUFDNUI7Ozs7b0JBQ1Isd0JBQUMsVUFBRDtXQUNFLFVBQVUsTUFBTTtZQUFFLEVBQUUsZ0JBQWdCO1lBQUcsYUFBYSxFQUFFLEVBQUU7V0FBRztXQUMzRCxPQUFNO1dBQ04sV0FBVTtxQkFFVix3QkFBQyxRQUFELEVBQVEsV0FBVSxjQUFlOzs7OztVQUMzQjs7OztrQkFDTjs7Ozs7O1FBQ0Y7VUF2Q0csRUFBRTs7OztjQXVDTCxDQUNMO01BQ0k7Ozs7Y0FDRjs7Ozs7O0lBQ0o7Ozs7WUFDRjs7Ozs7O0VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkJpbGxpbmdEZXNrVmlldy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICBSZWNlaXB0LCBcbiAgUHJpbnRlciwgXG4gIFNlbmQsIFxuICBQbHVzLCBcbiAgU2VhcmNoLCBcbiAgVHJhc2gyLCBcbiAgUXJDb2RlLCBcbiAgSW5kaWFuUnVwZWUsIFxuICBDaGVja0NpcmNsZSwgXG4gIENsb2NrLCBcbiAgRmlsZVNwcmVhZHNoZWV0LCBcbiAgSGVscENpcmNsZSxcbiAgQ3JlZGl0Q2FyZCxcbiAgU21hcnRwaG9uZVxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IFFSQ29kZSBmcm9tICdxcmNvZGUnO1xuaW1wb3J0IHsgQmlsbEl0ZW0sIFNob3BTZXR0aW5ncyB9IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7IENPTU1PTl9TSE9QX1NFUlZJQ0VTIH0gZnJvbSAnLi4vZGF0YS9wb3J0YWxEYXRhJztcbmltcG9ydCB7IHByaW50SHRtbERvY3VtZW50IH0gZnJvbSAnLi4vdXRpbHMvcHJpbnRlcic7XG5cbmludGVyZmFjZSBCaWxsaW5nRGVza1ZpZXdQcm9wcyB7XG4gIGJpbGxzOiBCaWxsSXRlbVtdO1xuICBzZXR0aW5nczogU2hvcFNldHRpbmdzO1xuICBvbkFkZEJpbGw6IChiaWxsOiBCaWxsSXRlbSkgPT4gdm9pZDtcbiAgb25EZWxldGVCaWxsOiAoaWQ6IHN0cmluZykgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IEJpbGxpbmdEZXNrVmlldzogUmVhY3QuRkM8QmlsbGluZ0Rlc2tWaWV3UHJvcHM+ID0gKHtcbiAgYmlsbHMsXG4gIHNldHRpbmdzLFxuICBvbkFkZEJpbGwsXG4gIG9uRGVsZXRlQmlsbFxufSkgPT4ge1xuICAvLyBOZXcgQmlsbCBGb3JtIFN0YXRlXG4gIGNvbnN0IFtjdXN0b21lck5hbWUsIHNldEN1c3RvbWVyTmFtZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtjdXN0b21lck1vYmlsZSwgc2V0Q3VzdG9tZXJNb2JpbGVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbc2VsZWN0ZWRTZXJ2aWNlLCBzZXRTZWxlY3RlZFNlcnZpY2VdID0gdXNlU3RhdGUoQ09NTU9OX1NIT1BfU0VSVklDRVNbMF0ubmFtZSk7XG4gIGNvbnN0IFtjYXRlZ29yeSwgc2V0Q2F0ZWdvcnldID0gdXNlU3RhdGUoQ09NTU9OX1NIT1BfU0VSVklDRVNbMF0uY2F0ZWdvcnkpO1xuICBjb25zdCBbZ292dEZlZSwgc2V0R292dEZlZV0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCBbc2VydmljZUZlZSwgc2V0U2VydmljZUZlZV0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCBbcGF5bWVudE1vZGUsIHNldFBheW1lbnRNb2RlXSA9IHVzZVN0YXRlPCdDYXNoJyB8ICdVUEkgLyBRUicgfCAnQ2FyZCcgfCAnUGVuZGluZyc+KCdDYXNoJyk7XG4gIGNvbnN0IFtwYXltZW50U3RhdHVzLCBzZXRQYXltZW50U3RhdHVzXSA9IHVzZVN0YXRlPCdQYWlkJyB8ICdQZW5kaW5nJyB8ICdEdWUnPignUGFpZCcpO1xuICBjb25zdCBbbm90ZXMsIHNldE5vdGVzXSA9IHVzZVN0YXRlKCcnKTtcblxuICAvLyBHZW5lcmF0ZWQgUVIgQ29kZSBEYXRhIFVSTFxuICBjb25zdCBbcXJEYXRhVXJsLCBzZXRRckRhdGFVcmxdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG5cbiAgLy8gRmlsdGVyICYgU2VhcmNoXG4gIGNvbnN0IFtzZWFyY2hUZXJtLCBzZXRTZWFyY2hUZXJtXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2RhdGVGaWx0ZXIsIHNldERhdGVGaWx0ZXJdID0gdXNlU3RhdGUoJycpO1xuXG4gIC8vIEFjdGl2ZSBiaWxsIGZvciBwcmV2aWV3XG4gIGNvbnN0IFthY3RpdmVQcmV2aWV3QmlsbCwgc2V0QWN0aXZlUHJldmlld0JpbGxdID0gdXNlU3RhdGU8QmlsbEl0ZW0gfCBudWxsPihudWxsKTtcblxuICBjb25zdCB0b3RhbEFtb3VudCA9IChOdW1iZXIoZ292dEZlZSkgfHwgMCkgKyAoTnVtYmVyKHNlcnZpY2VGZWUpIHx8IDApO1xuXG4gIC8vIEF1dG8tZ2VuZXJhdGUgaW52b2ljZSBudW1iZXJcbiAgY29uc3QgbmV4dEludm9pY2VObyA9IGBNT1MtJHtuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCl9LSR7U3RyaW5nKGJpbGxzLmxlbmd0aCArIDEwMSkucGFkU3RhcnQoNCwgJzAnKX1gO1xuXG4gIC8vIFdoZW4gc2VsZWN0ZWQgc2VydmljZSBjaGFuZ2VzLCBwb3B1bGF0ZSBkZWZhdWx0c1xuICBjb25zdCBoYW5kbGVTZXJ2aWNlU2VsZWN0ID0gKHNlcnZpY2VOYW1lOiBzdHJpbmcpID0+IHtcbiAgICBzZXRTZWxlY3RlZFNlcnZpY2Uoc2VydmljZU5hbWUpO1xuICAgIGNvbnN0IGZvdW5kID0gQ09NTU9OX1NIT1BfU0VSVklDRVMuZmluZChzID0+IHMubmFtZSA9PT0gc2VydmljZU5hbWUpO1xuICAgIGlmIChmb3VuZCkge1xuICAgICAgc2V0Q2F0ZWdvcnkoZm91bmQuY2F0ZWdvcnkpO1xuICAgICAgc2V0R292dEZlZShmb3VuZC5nb3Z0RmVlKTtcbiAgICAgIHNldFNlcnZpY2VGZWUoZm91bmQuc2VydmljZUZlZSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIEdlbmVyYXRlIFVQSSBRUiBDb2RlIHdoZW5ldmVyIHRvdGFsIG9yIFVQSSBJRCBjaGFuZ2VzXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgdXBpU3RyaW5nID0gYHVwaTovL3BheT9wYT0ke3NldHRpbmdzLnVwaUlkfSZwbj0ke2VuY29kZVVSSUNvbXBvbmVudChzZXR0aW5ncy5zaG9wTmFtZSl9JmFtPSR7dG90YWxBbW91bnR9JmN1PUlOUiZ0bj0ke2VuY29kZVVSSUNvbXBvbmVudChuZXh0SW52b2ljZU5vKX1gO1xuICAgIFFSQ29kZS50b0RhdGFVUkwodXBpU3RyaW5nLCB7IHdpZHRoOiAxODAsIG1hcmdpbjogMSB9KVxuICAgICAgLnRoZW4odXJsID0+IHNldFFyRGF0YVVybCh1cmwpKVxuICAgICAgLmNhdGNoKCgpID0+IHNldFFyRGF0YVVybCgnJykpO1xuICB9LCBbdG90YWxBbW91bnQsIHNldHRpbmdzLnVwaUlkLCBzZXR0aW5ncy5zaG9wTmFtZSwgbmV4dEludm9pY2VOb10pO1xuXG4gIC8vIEhhbmRsZSBGb3JtIFN1Ym1pc3Npb25cbiAgY29uc3QgaGFuZGxlQ3JlYXRlQmlsbCA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKCFjdXN0b21lck5hbWUudHJpbSgpKSB7XG4gICAgICBhbGVydCgnUGxlYXNlIGVudGVyIEN1c3RvbWVyIE5hbWUnKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBuZXdCaWxsOiBCaWxsSXRlbSA9IHtcbiAgICAgIGlkOiBgYmlsbC0ke0RhdGUubm93KCl9YCxcbiAgICAgIGludm9pY2VObzogbmV4dEludm9pY2VObyxcbiAgICAgIGN1c3RvbWVyTmFtZTogY3VzdG9tZXJOYW1lLnRyaW0oKSxcbiAgICAgIGN1c3RvbWVyTW9iaWxlOiBjdXN0b21lck1vYmlsZS50cmltKCkgfHwgJ04vQScsXG4gICAgICBzZXJ2aWNlTmFtZTogc2VsZWN0ZWRTZXJ2aWNlLFxuICAgICAgY2F0ZWdvcnk6IGNhdGVnb3J5LFxuICAgICAgZ292dEZlZTogTnVtYmVyKGdvdnRGZWUpIHx8IDAsXG4gICAgICBzZXJ2aWNlRmVlOiBOdW1iZXIoc2VydmljZUZlZSkgfHwgMCxcbiAgICAgIHRvdGFsOiB0b3RhbEFtb3VudCxcbiAgICAgIHBheW1lbnRNb2RlOiBwYXltZW50TW9kZSxcbiAgICAgIHN0YXR1czogcGF5bWVudFN0YXR1cyxcbiAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKS50b0xvY2FsZVN0cmluZygnZW4tSU4nLCB7XG4gICAgICAgIGRhdGVTdHlsZTogJ21lZGl1bScsXG4gICAgICAgIHRpbWVTdHlsZTogJ3Nob3J0J1xuICAgICAgfSksXG4gICAgICBub3Rlczogbm90ZXMudHJpbSgpXG4gICAgfTtcblxuICAgIG9uQWRkQmlsbChuZXdCaWxsKTtcbiAgICBzZXRBY3RpdmVQcmV2aWV3QmlsbChuZXdCaWxsKTtcblxuICAgIC8vIFJlc2V0IGN1c3RvbWVyIG5hbWUgJiBtb2JpbGUgZm9yIG5leHQgdHJhbnNhY3Rpb25cbiAgICBzZXRDdXN0b21lck5hbWUoJycpO1xuICAgIHNldEN1c3RvbWVyTW9iaWxlKCcnKTtcbiAgICBzZXROb3RlcygnJyk7XG4gIH07XG5cbiAgLy8gRGlyZWN0IFRoZXJtYWwgUE9TIFByaW50ICg1OG1tIG9yIDgwbW0gZm9ybWF0KVxuICBjb25zdCBoYW5kbGVQcmludFRoZXJtYWwgPSAoYmlsbFRvUHJpbnQ6IEJpbGxJdGVtKSA9PiB7XG4gICAgY29uc3QgaXM4MCA9IHNldHRpbmdzLnRoZXJtYWxXaWR0aCA9PT0gJzgwbW0nO1xuICAgIGNvbnN0IHBhcGVyV2lkdGggPSBpczgwID8gJzc2bW0nIDogJzU2bW0nO1xuXG4gICAgY29uc3QgcGFnZVN0eWxlID0gYFxuICAgICAgQHBhZ2Uge1xuICAgICAgICBzaXplOiAke3BhcGVyV2lkdGh9IGF1dG87XG4gICAgICAgIG1hcmdpbjogMDtcbiAgICAgIH1cbiAgICAgIGJvZHkge1xuICAgICAgICBmb250LWZhbWlseTogJ0NvdXJpZXIgTmV3JywgQ291cmllciwgbW9ub3NwYWNlO1xuICAgICAgICB3aWR0aDogJHtwYXBlcldpZHRofTtcbiAgICAgICAgbWFyZ2luOiAwIGF1dG87XG4gICAgICAgIHBhZGRpbmc6IDZweDtcbiAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgICBjb2xvcjogIzAwMDtcbiAgICAgICAgbGluZS1oZWlnaHQ6IDEuMztcbiAgICAgIH1cbiAgICAgIC5jZW50ZXIgeyB0ZXh0LWFsaWduOiBjZW50ZXI7IH1cbiAgICAgIC5yaWdodCB7IHRleHQtYWxpZ246IHJpZ2h0OyB9XG4gICAgICAuYm9sZCB7IGZvbnQtd2VpZ2h0OiBib2xkOyB9XG4gICAgICAuZGl2aWRlciB7IGJvcmRlci10b3A6IDFweCBkYXNoZWQgIzAwMDsgbWFyZ2luOiA2cHggMDsgfVxuICAgICAgLmhlYWRlciB7IGZvbnQtc2l6ZTogMTVweDsgZm9udC13ZWlnaHQ6IGJvbGQ7IH1cbiAgICAgIC5xciB7IHRleHQtYWxpZ246IGNlbnRlcjsgbWFyZ2luOiA4cHggMDsgfVxuICAgICAgLnFyIGltZyB7IHdpZHRoOiAxMjBweDsgaGVpZ2h0OiAxMjBweDsgfVxuICAgICAgdGFibGUgeyB3aWR0aDogMTAwJTsgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTsgZm9udC1zaXplOiAxMnB4OyB9XG4gICAgICB0ZCB7IHBhZGRpbmc6IDJweCAwOyB9XG4gICAgYDtcblxuICAgIGNvbnN0IGh0bWxCb2R5ID0gYFxuICAgICAgPGRpdiBjbGFzcz1cImNlbnRlclwiPlxuICAgICAgICA8ZGl2IGNsYXNzPVwiaGVhZGVyXCI+JHtzZXR0aW5ncy5zaG9wTmFtZX08L2Rpdj5cbiAgICAgICAgPGRpdj4ke3NldHRpbmdzLnRhZ2xpbmV9PC9kaXY+XG4gICAgICAgIDxkaXY+JHtzZXR0aW5ncy5hZGRyZXNzfTwvZGl2PlxuICAgICAgICA8ZGl2Pk1vYjogJHtzZXR0aW5ncy5waG9uZX08L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzcz1cImRpdmlkZXJcIj48L2Rpdj5cbiAgICAgIDxkaXY+PGI+SW52b2ljZTo8L2I+ICR7YmlsbFRvUHJpbnQuaW52b2ljZU5vfTwvZGl2PlxuICAgICAgPGRpdj48Yj5EYXRlOjwvYj4gJHtiaWxsVG9QcmludC5jcmVhdGVkQXR9PC9kaXY+XG4gICAgICA8ZGl2PjxiPkN1c3RvbWVyOjwvYj4gJHtiaWxsVG9QcmludC5jdXN0b21lck5hbWV9PC9kaXY+XG4gICAgICA8ZGl2PjxiPlBob25lOjwvYj4gJHtiaWxsVG9QcmludC5jdXN0b21lck1vYmlsZX08L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJkaXZpZGVyXCI+PC9kaXY+XG4gICAgICA8dGFibGU+XG4gICAgICAgIDx0cj48dGQgY2xhc3M9XCJib2xkXCI+U2VydmljZTo8L3RkPjx0ZCBjbGFzcz1cInJpZ2h0XCI+JHtiaWxsVG9QcmludC5zZXJ2aWNlTmFtZX08L3RkPjwvdHI+XG4gICAgICAgICR7YmlsbFRvUHJpbnQuZ292dEZlZSA+IDAgPyBgPHRyPjx0ZD5Hb3Z0IEZlZTo8L3RkPjx0ZCBjbGFzcz1cInJpZ2h0XCI+4oK5JHtiaWxsVG9QcmludC5nb3Z0RmVlfTwvdGQ+PC90cj5gIDogJyd9XG4gICAgICAgIDx0cj48dGQ+U2VydmljZSBDaGFyZ2U6PC90ZD48dGQgY2xhc3M9XCJyaWdodFwiPuKCuSR7YmlsbFRvUHJpbnQuc2VydmljZUZlZX08L3RkPjwvdHI+XG4gICAgICAgIDx0ciBzdHlsZT1cImJvcmRlci10b3A6MXB4IHNvbGlkICMwMDA7IGZvbnQtd2VpZ2h0OmJvbGQ7XCI+XG4gICAgICAgICAgPHRkIHN0eWxlPVwiZm9udC1zaXplOjE0cHg7XCI+VE9UQUw6PC90ZD5cbiAgICAgICAgICA8dGQgY2xhc3M9XCJyaWdodFwiIHN0eWxlPVwiZm9udC1zaXplOjE0cHg7XCI+4oK5JHtiaWxsVG9QcmludC50b3RhbH08L3RkPlxuICAgICAgICA8L3RyPlxuICAgICAgPC90YWJsZT5cbiAgICAgIDxkaXYgY2xhc3M9XCJkaXZpZGVyXCI+PC9kaXY+XG4gICAgICA8ZGl2PjxiPlBheW1lbnQ6PC9iPiAke2JpbGxUb1ByaW50LnBheW1lbnRNb2RlfSAoJHtiaWxsVG9QcmludC5zdGF0dXN9KTwvZGl2PlxuICAgICAgJHtzZXR0aW5ncy51cGlJZCA/IGBcbiAgICAgICAgPGRpdiBjbGFzcz1cInFyXCI+XG4gICAgICAgICAgPGRpdj5TY2FuIFVQSSB0byBQYXk6PC9kaXY+XG4gICAgICAgICAgPGltZyBzcmM9XCIke3FyRGF0YVVybH1cIiAvPlxuICAgICAgICAgIDxkaXYgc3R5bGU9XCJmb250LXNpemU6MTBweDtcIj4ke3NldHRpbmdzLnVwaUlkfTwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIGAgOiAnJ31cbiAgICAgIDxkaXYgY2xhc3M9XCJjZW50ZXJcIiBzdHlsZT1cImZvbnQtc2l6ZToxMXB4OyBtYXJnaW4tdG9wOjhweDtcIj5cbiAgICAgICAgPGRpdj4qKiogVGhhbmsgWW91IFZpc2l0IEFnYWluICoqKjwvZGl2PlxuICAgICAgICA8ZGl2PkNvbXB1dGVyaXplZCBPbmxpbmUgU2VydmljZSBSZWNlaXB0PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICBgO1xuXG4gICAgcHJpbnRIdG1sRG9jdW1lbnQoaHRtbEJvZHksIGBSZWNlaXB0XyR7YmlsbFRvUHJpbnQuaW52b2ljZU5vfWAsIHBhZ2VTdHlsZSk7XG4gIH07XG5cbiAgLy8gRGlyZWN0IEE0IE9mZmljaWFsIEludm9pY2UgUHJpbnRcbiAgY29uc3QgaGFuZGxlUHJpbnRBNCA9IChiaWxsVG9QcmludDogQmlsbEl0ZW0pID0+IHtcbiAgICBjb25zdCBwYWdlU3R5bGUgPSBgXG4gICAgICBAcGFnZSB7IHNpemU6IEE0OyBtYXJnaW46IDE1bW07IH1cbiAgICAgIGJvZHkgeyBmb250LWZhbWlseTogc2Fucy1zZXJpZjsgbWFyZ2luOiAwOyBwYWRkaW5nOiAyMHB4OyBjb2xvcjogIzFlMjkzYjsgZm9udC1zaXplOiAxNHB4OyB9XG4gICAgICAuaGVhZGVyLXRhYmxlIHsgd2lkdGg6IDEwMCU7IGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjMjU2M2ViOyBwYWRkaW5nLWJvdHRvbTogMTVweDsgbWFyZ2luLWJvdHRvbTogMjBweDsgfVxuICAgICAgLnNob3AtdGl0bGUgeyBmb250LXNpemU6IDI0cHg7IGZvbnQtd2VpZ2h0OiA4MDA7IGNvbG9yOiAjMWU0MGFmOyB9XG4gICAgICAuaW5mby1ib3ggeyBiYWNrZ3JvdW5kOiAjZjhmYWZjOyBib3JkZXI6IDFweCBzb2xpZCAjZTJlOGYwOyBib3JkZXItcmFkaXVzOiA4cHg7IHBhZGRpbmc6IDEycHg7IG1hcmdpbi1ib3R0b206IDIwcHg7IH1cbiAgICAgIHRhYmxlLml0ZW1zIHsgd2lkdGg6IDEwMCU7IGJvcmRlci1jb2xsYXBzZTogY29sbGFwc2U7IG1hcmdpbi10b3A6IDE1cHg7IH1cbiAgICAgIHRhYmxlLml0ZW1zIHRoIHsgYmFja2dyb3VuZDogIzI1NjNlYjsgY29sb3I6ICNmZmY7IHRleHQtYWxpZ246IGxlZnQ7IHBhZGRpbmc6IDEwcHg7IGZvbnQtc2l6ZTogMTNweDsgfVxuICAgICAgdGFibGUuaXRlbXMgdGQgeyBwYWRkaW5nOiAxMHB4OyBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2UyZThmMDsgfVxuICAgICAgLnRvdGFsLXJvdyB7IGZvbnQtc2l6ZTogMTZweDsgZm9udC13ZWlnaHQ6IGJvbGQ7IGJhY2tncm91bmQ6ICNlZmY2ZmY7IH1cbiAgICAgIC5mb290ZXIgeyBtYXJnaW4tdG9wOiA0MHB4OyBkaXNwbGF5OiBmbGV4OyBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47IGFsaWduLWl0ZW1zOiBmbGV4LWVuZDsgfVxuICAgICAgLnNpZ24geyBib3JkZXItdG9wOiAxcHggc29saWQgIzk0YTNiODsgd2lkdGg6IDE4MHB4OyB0ZXh0LWFsaWduOiBjZW50ZXI7IHBhZGRpbmctdG9wOiA1cHg7IGZvbnQtc2l6ZTogMTJweDsgfVxuICAgIGA7XG5cbiAgICBjb25zdCBodG1sQm9keSA9IGBcbiAgICAgICAgICA8dGFibGUgY2xhc3M9XCJoZWFkZXItdGFibGVcIj5cbiAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzaG9wLXRpdGxlXCI+JHtzZXR0aW5ncy5zaG9wTmFtZX08L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PiR7c2V0dGluZ3MudGFnbGluZX08L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PiR7c2V0dGluZ3MuYWRkcmVzc308L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlBob25lIC8gV2hhdHNBcHA6ICR7c2V0dGluZ3MucGhvbmV9PC9kaXY+XG4gICAgICAgICAgICAgICAgJHtzZXR0aW5ncy5nc3RObyA/IGA8ZGl2PkdTVElOOiAke3NldHRpbmdzLmdzdE5vfTwvZGl2PmAgOiAnJ31cbiAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgPHRkIHN0eWxlPVwidGV4dC1hbGlnbjpyaWdodDtcIj5cbiAgICAgICAgICAgICAgICA8aDIgc3R5bGU9XCJtYXJnaW46MDsgY29sb3I6IzFlNDBhZjtcIj5TRVJWSUNFIElOVk9JQ0U8L2gyPlxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9XCJmb250LWZhbWlseTptb25vc3BhY2U7IGZvbnQtc2l6ZToxNnB4OyBmb250LXdlaWdodDpib2xkO1wiPiR7YmlsbFRvUHJpbnQuaW52b2ljZU5vfTwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9XCJtYXJnaW4tdG9wOjRweDtcIj5EYXRlOiAke2JpbGxUb1ByaW50LmNyZWF0ZWRBdH08L2Rpdj5cbiAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgPC90YWJsZT5cblxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJpbmZvLWJveFwiPlxuICAgICAgICAgICAgPHRhYmxlIHN0eWxlPVwid2lkdGg6MTAwJTtcIj5cbiAgICAgICAgICAgICAgPHRyPlxuICAgICAgICAgICAgICAgIDx0ZD48Yj5CaWxsZWQgVG86PC9iPiAke2JpbGxUb1ByaW50LmN1c3RvbWVyTmFtZX08L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBzdHlsZT1cInRleHQtYWxpZ246cmlnaHQ7XCI+PGI+TW9iaWxlOjwvYj4gJHtiaWxsVG9QcmludC5jdXN0b21lck1vYmlsZX08L3RkPlxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDx0YWJsZSBjbGFzcz1cIml0ZW1zXCI+XG4gICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICA8dGg+U3IuPC90aD5cbiAgICAgICAgICAgICAgICA8dGg+U2VydmljZSBEZXNjcmlwdGlvbjwvdGg+XG4gICAgICAgICAgICAgICAgPHRoPkNhdGVnb3J5PC90aD5cbiAgICAgICAgICAgICAgICA8dGggc3R5bGU9XCJ0ZXh0LWFsaWduOnJpZ2h0O1wiPkdvdnQgRmVlPC90aD5cbiAgICAgICAgICAgICAgICA8dGggc3R5bGU9XCJ0ZXh0LWFsaWduOnJpZ2h0O1wiPlNlcnZpY2UgQ2hhcmdlPC90aD5cbiAgICAgICAgICAgICAgICA8dGggc3R5bGU9XCJ0ZXh0LWFsaWduOnJpZ2h0O1wiPlRvdGFsICjigrkpPC90aD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICA8dGJvZHk+XG4gICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICA8dGQ+MTwvdGQ+XG4gICAgICAgICAgICAgICAgPHRkPjxiPiR7YmlsbFRvUHJpbnQuc2VydmljZU5hbWV9PC9iPjwvdGQ+XG4gICAgICAgICAgICAgICAgPHRkPiR7YmlsbFRvUHJpbnQuY2F0ZWdvcnl9PC90ZD5cbiAgICAgICAgICAgICAgICA8dGQgc3R5bGU9XCJ0ZXh0LWFsaWduOnJpZ2h0O1wiPuKCuSR7YmlsbFRvUHJpbnQuZ292dEZlZX08L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBzdHlsZT1cInRleHQtYWxpZ246cmlnaHQ7XCI+4oK5JHtiaWxsVG9QcmludC5zZXJ2aWNlRmVlfTwvdGQ+XG4gICAgICAgICAgICAgICAgPHRkIHN0eWxlPVwidGV4dC1hbGlnbjpyaWdodDsgZm9udC13ZWlnaHQ6Ym9sZDtcIj7igrkke2JpbGxUb1ByaW50LnRvdGFsfTwvdGQ+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDx0ciBjbGFzcz1cInRvdGFsLXJvd1wiPlxuICAgICAgICAgICAgICAgIDx0ZCBjb2xzcGFuPVwiNVwiIHN0eWxlPVwidGV4dC1hbGlnbjpyaWdodDtcIj5HUkFORCBUT1RBTDo8L3RkPlxuICAgICAgICAgICAgICAgIDx0ZCBzdHlsZT1cInRleHQtYWxpZ246cmlnaHQ7IGNvbG9yOiMxZTQwYWY7XCI+4oK5JHtiaWxsVG9QcmludC50b3RhbH0uMDA8L3RkPlxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICA8L3RhYmxlPlxuXG4gICAgICAgICAgPGRpdiBzdHlsZT1cIm1hcmdpbi10b3A6MTVweDsgZm9udC1zaXplOjEycHg7IGNvbG9yOiM2NDc0OGI7XCI+XG4gICAgICAgICAgICBQYXltZW50IE1vZGU6IDxiPiR7YmlsbFRvUHJpbnQucGF5bWVudE1vZGV9PC9iPiB8IFN0YXR1czogPGI+JHtiaWxsVG9QcmludC5zdGF0dXN9PC9iPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZvb3RlclwiPlxuICAgICAgICAgICAgPGRpdiBzdHlsZT1cImZvbnQtc2l6ZToxMXB4OyBjb2xvcjojNjQ3NDhiO1wiPlxuICAgICAgICAgICAgICBUaGlzIGlzIGEgY29tcHV0ZXIgZ2VuZXJhdGVkIGludm9pY2UuPGJyPlRlcm1zOiBGZWVzIG9uY2UgcGFpZCBmb3IgZ292ZXJubWVudCBwb3J0YWwgc3VibWlzc2lvbnMgYXJlIG5vbi1yZWZ1bmRhYmxlLlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwic2lnblwiPlxuICAgICAgICAgICAgICBBdXRob3JpemVkIFNpZ25hdG9yeTxicj48Yj4ke3NldHRpbmdzLnNob3BOYW1lfTwvYj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2JvZHk+XG4gICAgICA8L2h0bWw+XG4gICAgYDtcblxuICAgIHByaW50SHRtbERvY3VtZW50KGh0bWxCb2R5LCBgSW52b2ljZV8ke2JpbGxUb1ByaW50Lmludm9pY2VOb31gLCBwYWdlU3R5bGUpO1xuICB9O1xuXG4gIC8vIEV4cG9ydCBsZWRnZXIgdG8gQ1NWXG4gIGNvbnN0IGhhbmRsZUV4cG9ydENTViA9ICgpID0+IHtcbiAgICBsZXQgY3N2ID0gJ0ludm9pY2UgTm8sQ3VzdG9tZXIgTmFtZSxNb2JpbGUsU2VydmljZSxHb3Z0IEZlZSxTZXJ2aWNlIEZlZSxUb3RhbCxQYXltZW50IE1vZGUsU3RhdHVzLERhdGVcXG4nO1xuICAgIGJpbGxzLmZvckVhY2goYiA9PiB7XG4gICAgICBjc3YgKz0gYFwiJHtiLmludm9pY2VOb31cIixcIiR7Yi5jdXN0b21lck5hbWV9XCIsXCIke2IuY3VzdG9tZXJNb2JpbGV9XCIsXCIke2Iuc2VydmljZU5hbWV9XCIsJHtiLmdvdnRGZWV9LCR7Yi5zZXJ2aWNlRmVlfSwke2IudG90YWx9LFwiJHtiLnBheW1lbnRNb2RlfVwiLFwiJHtiLnN0YXR1c31cIixcIiR7Yi5jcmVhdGVkQXR9XCJcXG5gO1xuICAgIH0pO1xuICAgIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbY3N2XSwgeyB0eXBlOiAndGV4dC9jc3YnIH0pO1xuICAgIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XG4gICAgY29uc3QgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcbiAgICBhLmhyZWYgPSB1cmw7XG4gICAgYS5kb3dubG9hZCA9IGBNdXphbW1pbF9CaWxsc19MZWRnZXJfJHtuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApfS5jc3ZgO1xuICAgIGEuY2xpY2soKTtcbiAgICBVUkwucmV2b2tlT2JqZWN0VVJMKHVybCk7XG4gIH07XG5cbiAgLy8gRmlsdGVyIGJpbGxzXG4gIGNvbnN0IGZpbHRlcmVkQmlsbHMgPSBiaWxscy5maWx0ZXIoYiA9PiB7XG4gICAgY29uc3QgbWF0Y2hlc1NlYXJjaCA9IFxuICAgICAgYi5jdXN0b21lck5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hUZXJtLnRvTG93ZXJDYXNlKCkpIHx8XG4gICAgICBiLmN1c3RvbWVyTW9iaWxlLmluY2x1ZGVzKHNlYXJjaFRlcm0pIHx8XG4gICAgICBiLmludm9pY2VOby50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRlcm0udG9Mb3dlckNhc2UoKSkgfHxcbiAgICAgIGIuc2VydmljZU5hbWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhzZWFyY2hUZXJtLnRvTG93ZXJDYXNlKCkpO1xuICAgIGNvbnN0IG1hdGNoZXNEYXRlID0gIWRhdGVGaWx0ZXIgfHwgYi5jcmVhdGVkQXQuaW5jbHVkZXMoZGF0ZUZpbHRlcik7XG4gICAgcmV0dXJuIG1hdGNoZXNTZWFyY2ggJiYgbWF0Y2hlc0RhdGU7XG4gIH0pO1xuXG4gIGNvbnN0IGFjdGl2ZURpc3BsYXlCaWxsID0gYWN0aXZlUHJldmlld0JpbGwgfHwgKGJpbGxzLmxlbmd0aCA+IDAgPyBiaWxsc1swXSA6IG51bGwpO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTVcIj5cbiAgICAgIHsvKiBIZWFkZXIgYmFyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHAtNCByb3VuZGVkLTJ4bCBzaGFkb3ctbWRcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlXCI+QmlsbGluZyBEZXNrICYgUE9TIFN0YXRpb248L2gxPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTQwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIHRleHQteHMgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIGZvbnQtbW9ubyBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAge3NldHRpbmdzLnRoZXJtYWxXaWR0aH0gUE9TIC8gQTRcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTAuNVwiPlxuICAgICAgICAgICAgUXVpY2sgY3VzdG9tZXIgYmlsbGluZywgZHluYW1pYyBVUEkgUVIgcGF5bWVudHMsIDU4bW0vODBtbSB0aGVybWFsIHJlY2VpcHQgcHJpbnRpbmcgJiBXaGF0c0FwcCBub3RpZmljYXRpb25cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVFeHBvcnRDU1Z9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0yMDAgaG92ZXI6dGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14cyBweC0zIHB5LTIgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICB0aXRsZT1cIkV4cG9ydCBCaWxscyBMZWRnZXIgdG8gRXhjZWwgQ1NWXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8RmlsZVNwcmVhZHNoZWV0IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTQwMFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5FeHBvcnQgQ1NWPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogTWFpbiBEdWFsIFBhbmU6IExlZnQgPSBOZXcgQmlsbCBGb3JtLCBSaWdodCA9IExpdmUgUE9TIFJlY2VpcHQgUHJldmlldyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMTIgZ2FwLTUgaXRlbXMtc3RhcnRcIj5cbiAgICAgICAgey8qIExlZnQgU2lkZTogRmFzdCBQT1MgRW50cnkgRm9ybSAoNyBjb2xzKSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi03IHNwYWNlLXktNFwiPlxuICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVDcmVhdGVCaWxsfSBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvOTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC01IHNoYWRvdy1tZCBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcGItM1wiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTIwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8UmVjZWlwdCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkNyZWF0ZSBOZXcgQ3VzdG9tZXIgUmVjZWlwdDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1ibHVlLTQwMCBiZy1ibHVlLTUwMC8xMCBweC0yIHB5LTAuNSByb3VuZGVkIGJvcmRlciBib3JkZXItYmx1ZS01MDAvMjBcIj5cbiAgICAgICAgICAgICAgICBOZXh0OiB7bmV4dEludm9pY2VOb31cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBDdXN0b21lciBOYW1lICYgTW9iaWxlICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC0zIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTMwMCBibG9jayBtYi0xXCI+Q3VzdG9tZXIgRnVsbCBOYW1lICo8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBTaGFpa2ggU2FtZWVyXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXN0b21lck5hbWV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEN1c3RvbWVyTmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQtd2hpdGUgcGxhY2Vob2xkZXItc2xhdGUtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItZW1lcmFsZC01MDAgdGV4dC1zbSBmb250LW1lZGl1bVwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTMwMCBibG9jayBtYi0xXCI+Q3VzdG9tZXIgTW9iaWxlIChXaGF0c0FwcCkgKjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGVsXCJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMTAgZGlnaXQgbW9iaWxlIChlLmcuIDk1NjE0NjAzMTMpXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtjdXN0b21lck1vYmlsZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q3VzdG9tZXJNb2JpbGUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXNsYXRlLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwIHRleHQtc20gZm9udC1tb25vXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogU2VydmljZSBQcmVzZXQgRHJvcGRvd24gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtMzAwIGJsb2NrXCI+U2VsZWN0IFNlcnZpY2UgLyBBcHBsaWNhdGlvbiAqPC9sYWJlbD5cbiAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWxlY3RlZFNlcnZpY2V9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVTZXJ2aWNlU2VsZWN0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMyBweS0yLjUgdGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWVtZXJhbGQtNTAwIHRleHQtc20gZm9udC1tZWRpdW1cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge0NPTU1PTl9TSE9QX1NFUlZJQ0VTLm1hcCgocykgPT4gKFxuICAgICAgICAgICAgICAgICAgPG9wdGlvbiBrZXk9e3MubmFtZX0gdmFsdWU9e3MubmFtZX0+XG4gICAgICAgICAgICAgICAgICAgIHtzLm5hbWV9IChHb3Z0OiDigrl7cy5nb3Z0RmVlfSArIEZlZTog4oK5e3Muc2VydmljZUZlZX0gPSDigrl7cy5nb3Z0RmVlICsgcy5zZXJ2aWNlRmVlfSlcbiAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogRmVlIEJyZWFrZG93biAoR292dCBGZWUgdnMgU2VydmljZSBDaGFyZ2UpICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgYmctc2xhdGUtOTUwLzYwIHAtMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtMyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+R292dCBQb3J0YWwgRmVlICjigrkpPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtnb3Z0RmVlIHx8ICcnfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEdvdnRGZWUoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSB8fCAwKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC13aGl0ZSBmb250LW1vbm8gdGV4dC1zbVwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+U2hvcCBTZXJ2aWNlIEZlZSAo4oK5KTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgICAgIG1pbj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VydmljZUZlZSB8fCAnJ31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZXJ2aWNlRmVlKE51bWJlcihlLnRhcmdldC52YWx1ZSkgfHwgMCl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyBweC0yLjUgcHktMS41IHRleHQtd2hpdGUgZm9udC1tb25vIHRleHQtc21cIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTQwMCBmb250LWJvbGQgYmxvY2sgbWItMVwiPlRvdGFsIEJpbGwgQW1vdW50PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaC04IHJvdW5kZWQtbGcgYmctZW1lcmFsZC05NTAvNDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC80MCBmbGV4IGl0ZW1zLWNlbnRlciBweC0zIGZvbnQtbW9ubyBmb250LWJsYWNrIHRleHQtZW1lcmFsZC00MDAgdGV4dC1iYXNlXCI+XG4gICAgICAgICAgICAgICAgICAgIOKCuXt0b3RhbEFtb3VudH1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogUXVpY2sgQW1vdW50IENoaXBzICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHQtMSBmbGV4LXdyYXAgdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCB0ZXh0LVsxMHB4XVwiPlF1aWNrIEFkZDo8L3NwYW4+XG4gICAgICAgICAgICAgICAge1sxMCwgMjAsIDMwLCA1MCwgNzAsIDEwMCwgMTUwXS5tYXAoKGFtdCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAga2V5PXthbXR9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlcnZpY2VGZWUoKHByZXYpID0+IChOdW1iZXIocHJldikgfHwgMCkgKyBhbXQpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSByb3VuZGVkIGJnLXNsYXRlLTkwMCBob3ZlcjpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgZm9udC1tb25vXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgK+KCuXthbXR9XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0R292dEZlZSgwKTsgc2V0U2VydmljZUZlZSgwKTsgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IHJvdW5kZWQgYmctcm9zZS01MDAvMTAgaG92ZXI6Ymctcm9zZS01MDAvMjAgdGV4dC1yb3NlLTQwMCBib3JkZXIgYm9yZGVyLXJvc2UtNTAwLzMwIGZvbnQtYm9sZCBtbC1hdXRvXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBSZXNldCDigrkwXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBQYXltZW50IE1vZGUgJiBTdGF0dXMgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtMzAwIGJsb2NrIG1iLTFcIj5QYXltZW50IE1ldGhvZDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIHsoWydDYXNoJywgJ1VQSSAvIFFSJywgJ1BlbmRpbmcnXSBhcyBjb25zdCkubWFwKChtb2RlKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e21vZGV9XG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UGF5bWVudE1vZGUobW9kZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHktMS41IHB4LTIgcm91bmRlZC1sZyBmb250LWJvbGQgYm9yZGVyIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYXltZW50TW9kZSA9PT0gbW9kZVxuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1ibHVlLTUwMCBzaGFkb3ctc20nXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTk1MCB0ZXh0LXNsYXRlLTQwMCBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTgwMCdcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHttb2RlfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtMzAwIGJsb2NrIG1iLTFcIj5QYXltZW50IFN0YXR1czwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIHsoWydQYWlkJywgJ0R1ZSddIGFzIGNvbnN0KS5tYXAoKHN0KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e3N0fVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFBheW1lbnRTdGF0dXMoc3QgPT09ICdEdWUnID8gJ0R1ZScgOiAnUGFpZCcpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB5LTEuNSBweC0yIHJvdW5kZWQtbGcgZm9udC1ib2xkIGJvcmRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgcGF5bWVudFN0YXR1cyA9PT0gc3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyBzdCA9PT0gJ1BhaWQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC02MDAgdGV4dC13aGl0ZSBib3JkZXItZW1lcmFsZC01MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctcm9zZS02MDAgdGV4dC13aGl0ZSBib3JkZXItcm9zZS01MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTk1MCB0ZXh0LXNsYXRlLTQwMCBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTgwMCdcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHtzdH1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIE5vdGVzICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+U2VydmljZSBSZW1hcmtzIC8gQWNrIFRva2VuIChPcHRpb25hbCk8L2xhYmVsPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIEFjayB0b2tlbiA4ODEyNCwgMiBjb3BpZXMgcHJpbnRlZFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e25vdGVzfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Tm90ZXMoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTEuNSB0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXNsYXRlLTUwMCB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogU3VibWl0ICYgR2VuZXJhdGUgQnV0dG9uICovfVxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1lbWVyYWxkLTYwMCB0by10ZWFsLTYwMCBob3Zlcjpmcm9tLWVtZXJhbGQtNTAwIGhvdmVyOnRvLXRlYWwtNTAwIHRleHQtd2hpdGUgZm9udC1leHRyYWJvbGQgdGV4dC1zbSBweS0zIHJvdW5kZWQteGwgc2hhZG93LWxnIHNoYWRvdy1lbWVyYWxkLTYwMC8zMCB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzY2FsZS1bMS4wMV0gYWN0aXZlOnNjYWxlLVswLjk5XVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxSZWNlaXB0IGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj5HZW5lcmF0ZSBSZWNlaXB0ICYgU2F2ZSAo4oK5e3RvdGFsQW1vdW50fSk8L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBSaWdodCBTaWRlOiBMaXZlIFRoZXJtYWwgUE9TIFJlY2VpcHQgUHJldmlldyAoNSBjb2xzKSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi01IHNwYWNlLXktM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNCBzaGFkb3cteGxcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgPFByaW50ZXIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1ibHVlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+TGl2ZSBQT1MgVGhlcm1hbCBTbGlwIFByZXZpZXc8L3NwYW4+XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1tb25vIHRleHQtc2xhdGUtNDAwIGJnLXNsYXRlLTgwMCBweC0yIHB5LTAuNSByb3VuZGVkXCI+XG4gICAgICAgICAgICAgICAge3NldHRpbmdzLnRoZXJtYWxXaWR0aH0gTW9ub3NwYWNlXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogV2hpdGUgVGhlcm1hbCBSZWNlaXB0IFNsaXAgQm94ICovfVxuICAgICAgICAgICAge2FjdGl2ZURpc3BsYXlCaWxsID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXdoaXRlIHRleHQtc2xhdGUtOTUwIHAtNSByb3VuZGVkLXhsIHNoYWRvdy0yeGwgZm9udC1tb25vIHRleHQteHMgc2VsZWN0LXRleHQgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgbXgtYXV0byBtYXgtdy1bMzQwcHhdIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgIHsvKiBTaG9wIEhlYWRlciAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHNwYWNlLXktMC41IGJvcmRlci1iIGJvcmRlci1kYXNoZWQgYm9yZGVyLXNsYXRlLTQwMCBwYi0zXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYmxhY2sgdGV4dC1zbSB1cHBlcmNhc2UgdHJhY2tpbmctdGlnaHRcIj57c2V0dGluZ3Muc2hvcE5hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNjAwXCI+e3NldHRpbmdzLnRhZ2xpbmV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNjAwXCI+e3NldHRpbmdzLmFkZHJlc3N9PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZFwiPk1vYjoge3NldHRpbmdzLnBob25lfTwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIEJpbGwgTWV0YWRhdGEgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS0yLjUgYm9yZGVyLWIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtNDAwIHNwYWNlLXktMC41IHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkludm9pY2U6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGRcIj57YWN0aXZlRGlzcGxheUJpbGwuaW52b2ljZU5vfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5EYXRlOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2FjdGl2ZURpc3BsYXlCaWxsLmNyZWF0ZWRBdH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+Q3VzdG9tZXI6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGRcIj57YWN0aXZlRGlzcGxheUJpbGwuY3VzdG9tZXJOYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5QaG9uZTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPnthY3RpdmVEaXNwbGF5QmlsbC5jdXN0b21lck1vYmlsZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBJdGVtcyAmIEZlZXMgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweS0yLjUgYm9yZGVyLWIgYm9yZGVyLWRhc2hlZCBib3JkZXItc2xhdGUtNDAwIHNwYWNlLXktMSB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPnthY3RpdmVEaXNwbGF5QmlsbC5zZXJ2aWNlTmFtZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgIHthY3RpdmVEaXNwbGF5QmlsbC5nb3Z0RmVlID4gMCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Hb3Z0IFBvcnRhbCBGZWU6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPuKCuXthY3RpdmVEaXNwbGF5QmlsbC5nb3Z0RmVlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TZXJ2aWNlIENoYXJnZTo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPuKCuXthY3RpdmVEaXNwbGF5QmlsbC5zZXJ2aWNlRmVlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBmb250LWJsYWNrIHRleHQtc20gcHQtMSBib3JkZXItdCBib3JkZXItc2xhdGUtOTAwIG10LTFcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+TkVUIFRPVEFMOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+4oK5e2FjdGl2ZURpc3BsYXlCaWxsLnRvdGFsfS4wMDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIFBheW1lbnQgJiBRUiAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgdGV4dC1jZW50ZXIgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgUGF5bWVudCBNb2RlOiA8Yj57YWN0aXZlRGlzcGxheUJpbGwucGF5bWVudE1vZGV9PC9iPiAoe2FjdGl2ZURpc3BsYXlCaWxsLnN0YXR1c30pXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAge3NldHRpbmdzLnVwaUlkICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTIgYmctc2xhdGUtNTAgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIG1iLTFcIj5TY2FuIFFSIHZpYSBHUGF5IC8gUGhvbmVQZSAvIFBheXRtOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICB7cXJEYXRhVXJsICYmIDxpbWcgc3JjPXtxckRhdGFVcmx9IGFsdD1cIlVQSSBRUlwiIGNsYXNzTmFtZT1cInctMjggaC0yOFwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCBmb250LW1vbm8gdGV4dC1zbGF0ZS03MDAgbXQtMVwiPntzZXR0aW5ncy51cGlJZH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBwdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICoqKiBUaGFuayBZb3UgVmlzaXQgQWdhaW4gKioqPGJyIC8+XG4gICAgICAgICAgICAgICAgICAgIE11emFtbWlsIE9ubGluZSBTZXJ2aWNlIERpZ2l0YWwgSHViXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtOCB0ZXh0LWNlbnRlciB0ZXh0LXNsYXRlLTUwMCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgTm8gYmlsbCBzZWxlY3RlZC4gQ3JlYXRlIGEgYmlsbCBvbiB0aGUgbGVmdCB0byBzZWUgbGl2ZSBwcmV2aWV3LlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBTbGlwIEFjdGlvbiBCdXR0b25zICovfVxuICAgICAgICAgICAge2FjdGl2ZURpc3BsYXlCaWxsICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC0yIG10LTQgcHQtMyBib3JkZXItdCBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlUHJpbnRUaGVybWFsKGFjdGl2ZURpc3BsYXlCaWxsKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS01MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14cyBweS0yIHJvdW5kZWQteGwgc2hhZG93LW1kIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUHJpbnQgb24gNThtbS84MG1tIFRoZXJtYWwgUHJpbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFByaW50ZXIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+VGhlcm1hbDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVByaW50QTQoYWN0aXZlRGlzcGxheUJpbGwpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMjAwIGhvdmVyOnRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcHktMiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUHJpbnQgT2ZmaWNpYWwgQTQgVGF4IEludm9pY2VcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxQcmludGVyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtcHVycGxlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5BNCBJbnZvaWNlPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICAgIGhyZWY9e2BodHRwczovL3dhLm1lLzkxJHthY3RpdmVEaXNwbGF5QmlsbC5jdXN0b21lck1vYmlsZX0/dGV4dD1IZWxsbyUyMCR7ZW5jb2RlVVJJQ29tcG9uZW50KGFjdGl2ZURpc3BsYXlCaWxsLmN1c3RvbWVyTmFtZSl9LCUyMHlvdXIlMjByZWNlaXB0JTIwZm9yJTIwJHtlbmNvZGVVUklDb21wb25lbnQoYWN0aXZlRGlzcGxheUJpbGwuc2VydmljZU5hbWUpfSUyMGF0JTIwJHtlbmNvZGVVUklDb21wb25lbnQoc2V0dGluZ3Muc2hvcE5hbWUpfSUyMGlzJTIwcmVhZHkuJTIwVG90YWw6JTIwUnMuJHthY3RpdmVEaXNwbGF5QmlsbC50b3RhbH0uJTIwSW52b2ljZTolMjAke2FjdGl2ZURpc3BsYXlCaWxsLmludm9pY2VOb31gfVxuICAgICAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSBiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTUwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXhzIHB5LTIgcm91bmRlZC14bCBzaGFkb3ctbWQgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJTZW5kIFJlY2VpcHQgdmlhIFdoYXRzQXBwXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8U2VuZCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5XaGF0c0FwcDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEJvdHRvbSBTZWN0aW9uOiBGdWxsIEJpbGxpbmcgTGVkZ2VyICYgU2FsZXMgSGlzdG9yeSBUYWJsZSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNSBzaGFkb3ctbWQgc3BhY2UteS00XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1iYXNlIHRleHQtd2hpdGVcIj5CaWxsaW5nIEhpc3RvcnkgJiBTYWxlcyBMZWRnZXI8L2gzPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlRvdGFsIHtiaWxscy5sZW5ndGh9IGJpbGxzIHJlY29yZGVkIGluIGxvY2FsIGRhdGFiYXNlPC9wPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICA8U2VhcmNoIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtc2xhdGUtNDAwIGFic29sdXRlIGxlZnQtMi41IHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMlwiIC8+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkZpbHRlciBieSBjdXN0b21lciwgcGhvbmUsIGludm9pY2UuLi5cIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2hUZXJtfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VhcmNoVGVybShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcGwtOCBwci0zIHB5LTEuNSB0ZXh0LXhzIHRleHQtd2hpdGUgcGxhY2Vob2xkZXItc2xhdGUtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYmx1ZS01MDAgdy01NlwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHRleHQtc2xhdGUtNDAwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5JbnZvaWNlPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5EYXRlICYgVGltZTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zXCI+Q3VzdG9tZXI8L3RoPlxuICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPk1vYmlsZTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zXCI+U2VydmljZTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zIHRleHQtcmlnaHRcIj5Hb3Z0PC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTMgdGV4dC1yaWdodFwiPkZlZTwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zIHRleHQtcmlnaHRcIj5Ub3RhbDwvdGg+XG4gICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zIHRleHQtY2VudGVyXCI+U3RhdHVzPC90aD5cbiAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTMgdGV4dC1yaWdodFwiPkFjdGlvbnM8L3RoPlxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgPC90aGVhZD5cbiAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtODAwLzYwXCI+XG4gICAgICAgICAgICAgIHtmaWx0ZXJlZEJpbGxzLm1hcCgoYikgPT4gKFxuICAgICAgICAgICAgICAgIDx0ciBcbiAgICAgICAgICAgICAgICAgIGtleT17Yi5pZH0gXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVQcmV2aWV3QmlsbChiKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YGN1cnNvci1wb2ludGVyIHRyYW5zaXRpb24tY29sb3JzICR7XG4gICAgICAgICAgICAgICAgICAgIGFjdGl2ZVByZXZpZXdCaWxsPy5pZCA9PT0gYi5pZCA/ICdiZy1ibHVlLTk1MC8zMCcgOiAnaG92ZXI6Ymctc2xhdGUtODAwLzQwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtMyBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtYmx1ZS00MDBcIj57Yi5pbnZvaWNlTm99PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1zbGF0ZS00MDAgZm9udC1tb25vIHRleHQtWzExcHhdXCI+e2IuY3JlYXRlZEF0fTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zIGZvbnQtc2VtaWJvbGQgdGV4dC13aGl0ZVwiPntiLmN1c3RvbWVyTmFtZX08L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtMyBmb250LW1vbm8gdGV4dC1zbGF0ZS00MDBcIj57Yi5jdXN0b21lck1vYmlsZX08L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtMyB0ZXh0LXNsYXRlLTMwMCBtYXgtdy1bMjAwcHhdIHRydW5jYXRlXCI+e2Iuc2VydmljZU5hbWV9PC90ZD5cbiAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1yaWdodCBmb250LW1vbm8gdGV4dC1zbGF0ZS00MDBcIj7igrl7Yi5nb3Z0RmVlfTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zIHRleHQtcmlnaHQgZm9udC1tb25vIHRleHQtc2xhdGUtNDAwXCI+4oK5e2Iuc2VydmljZUZlZX08L3RkPlxuICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtMyB0ZXh0LXJpZ2h0IGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTQwMFwiPuKCuXtiLnRvdGFsfTwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHB4LTIgcHktMC41IHJvdW5kZWQgdGV4dC1bMTBweF0gZm9udC1ib2xkICR7XG4gICAgICAgICAgICAgICAgICAgICAgYi5zdGF0dXMgPT09ICdQYWlkJyBcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNTAwLzIwIHRleHQtZW1lcmFsZC0zMDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCcgXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1hbWJlci01MDAvMjAgdGV4dC1hbWJlci0zMDAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAnXG4gICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICB7Yi5zdGF0dXN9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zIHRleHQtcmlnaHQgc3BhY2UteC0xIHdoaXRlc3BhY2Utbm93cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4geyBlLnN0b3BQcm9wYWdhdGlvbigpOyBoYW5kbGVQcmludFRoZXJtYWwoYik7IH19XG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJQcmludCBUaGVybWFsIFNsaXBcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHJvdW5kZWQtbGcgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTIwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8UHJpbnRlciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGUpID0+IHsgZS5zdG9wUHJvcGFnYXRpb24oKTsgb25EZWxldGVCaWxsKGIuaWQpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRGVsZXRlIEJpbGxcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHJvdW5kZWQtbGcgYmctcm9zZS01MDAvMTAgaG92ZXI6Ymctcm9zZS01MDAvMjAgdGV4dC1yb3NlLTQwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==