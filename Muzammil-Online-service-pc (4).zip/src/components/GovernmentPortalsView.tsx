const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { ExternalLink, Search, FileCheck, CheckCircle, Copy, Check, X, RefreshCw, Globe, Download, FileText, Printer, CreditCard, FolderDown, Columns } from "/node_modules/.vite/deps/lucide-react.js?v=090625a0";
import { ALL_GOV_PORTALS, SERVICE_CATEGORIES } from "/src/data/portalData.ts";
var _jsxFileName = "/app/applet/src/components/GovernmentPortalsView.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
export const GovernmentPortalsView = ({ onAddDownload, onNavigate }) => {
	const [activeCategory, setActiveCategory] = useState("all");
	const [search, setSearch] = useState("");
	const [selectedPortalForDocs, setSelectedPortalForDocs] = useState(null);
	const [copiedId, setCopiedId] = useState(null);
	// In-App Browser State
	const [activePortal, setActivePortal] = useState(null);
	const [browserUrl, setBrowserUrl] = useState("");
	const [iframeKey, setIframeKey] = useState(0);
	const [zoomLevel, setZoomLevel] = useState(100);
	const [isSplitScreen, setIsSplitScreen] = useState(true);
	const [useProxy, setUseProxy] = useState(false);
	// Quick Notes & In-App Document Grabber
	const [notesCustomerName, setNotesCustomerName] = useState("");
	const [notesAckToken, setNotesAckToken] = useState("");
	const [notesAadhaar, setNotesAadhaar] = useState("");
	const [downloadSuccessMsg, setDownloadSuccessMsg] = useState(null);
	const [customUrlInput, setCustomUrlInput] = useState("");
	const handleOpenCustomUrl = () => {
		let url = customUrlInput.trim();
		if (!url) return;
		if (!url.startsWith("http://") && !url.startsWith("https://")) {
			url = "https://" + url;
		}
		const domain = url.replace(/^https?:\/\//, "").split("/")[0];
		const customPortal = {
			id: `custom-${Date.now()}`,
			title: domain.toUpperCase(),
			url,
			category: "utility",
			description: `In-App Web Browser session for ${url}`,
			portalType: "central",
			popular: false,
			requiredDocs: [
				"Aadhaar Card",
				"Mobile OTP",
				"Application ID"
			],
			icon: "🌐"
		};
		handleOpenInsideApp(customPortal);
	};
	const fileInputRef = useRef(null);
	const filteredPortals = ALL_GOV_PORTALS.filter((p) => {
		const matchesCategory = activeCategory === "all" || p.category === activeCategory;
		const matchesSearch = p.title.toLowerCase().includes(search.toLowerCase()) || p.description.toLowerCase().includes(search.toLowerCase());
		return matchesCategory && matchesSearch;
	});
	const handleCopyLink = (portal) => {
		navigator.clipboard.writeText(portal.url);
		setCopiedId(portal.id);
		setTimeout(() => setCopiedId(null), 2e3);
	};
	// Open Portal Inside the App
	const handleOpenInsideApp = (portal) => {
		setActivePortal(portal);
		setBrowserUrl(portal.url);
		setIframeKey((prev) => prev + 1);
		setUseProxy(false);
	};
	// Close In-App Browser
	const handleCloseBrowser = () => {
		setActivePortal(null);
		setBrowserUrl("");
	};
	// Refresh current portal iframe
	const handleReload = () => {
		setIframeKey((prev) => prev + 1);
	};
	// Handle in-app document grab / upload
	const handleInAppDownloadFile = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		const fileExt = file.name.split(".").pop()?.toUpperCase() || "PDF";
		const isImage = file.type.startsWith("image/");
		const isPdf = file.type === "application/pdf" || file.name.endsWith(".pdf");
		const downloadItem = {
			id: `dl-${Date.now()}`,
			title: `${notesCustomerName ? notesCustomerName + " - " : ""}${activePortal?.title || "Portal Document"} (${notesAckToken || "Slip"})`,
			type: isPdf ? "PVC Card PDF" : "Converted JPG",
			size: `${(file.size / 1024).toFixed(1)} KB`,
			timestamp: new Date().toLocaleTimeString([], {
				hour: "2-digit",
				minute: "2-digit"
			}),
			dataUrl: URL.createObjectURL(file)
		};
		if (onAddDownload) {
			onAddDownload(downloadItem);
		}
		setDownloadSuccessMsg(`✅ Document saved to In-App Downloads Vault!`);
		setTimeout(() => setDownloadSuccessMsg(null), 4e3);
	};
	const getEffectiveIframeSrc = () => {
		if (!browserUrl) return "";
		if (useProxy) {
			return `/api/portal-proxy?url=${encodeURIComponent(browserUrl)}`;
		}
		return browserUrl;
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 flex-wrap",
					children: [
						/* @__PURE__ */ _jsxDEV("h1", {
							className: "text-xl font-extrabold text-white flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Globe, { className: "w-5 h-5 text-sky-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 160,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Official Government Portals & In-App Web Browser" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 161,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 159,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "bg-sky-500/20 text-sky-400 border border-sky-500/30 text-xs px-2.5 py-0.5 rounded-full font-mono font-bold",
							children: [ALL_GOV_PORTALS.length, " Central & State Portals"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs px-2.5 py-0.5 rounded-full font-bold",
							children: "In-App Embedded Mode"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 166,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 158,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400 mt-1",
					children: "All 50+ official government websites open directly inside this workstation with built-in document download vault"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 170,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 157,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "relative",
					children: [/* @__PURE__ */ _jsxDEV(Search, { className: "w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 177,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						placeholder: "Search portals (Aadhaar, PAN, Ladki Bahin)...",
						value: search,
						onChange: (e) => setSearch(e.target.value),
						className: "bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 w-full sm:w-72"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 178,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 176,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 156,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-sky-500/30 rounded-2xl p-3.5 shadow-md flex flex-col md:flex-row items-center justify-between gap-3",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2.5 w-full md:w-auto",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "w-8 h-8 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center flex-shrink-0",
						children: /* @__PURE__ */ _jsxDEV(Globe, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 192,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 191,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "font-extrabold text-white text-xs block",
						children: "Universal In-App Web Browser & Downloader"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 195,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-[11px] text-slate-400",
						children: "Open ANY website or citizen portal directly inside this software without external browser"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 196,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 194,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 190,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 w-full md:w-auto flex-1 max-w-xl",
					children: [/* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						placeholder: "Type any URL (e.g. https://google.com, https://pmkisan.gov.in, https://sbi.co.in)...",
						value: customUrlInput,
						onChange: (e) => setCustomUrlInput(e.target.value),
						onKeyDown: (e) => e.key === "Enter" && handleOpenCustomUrl(),
						className: "flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 font-mono"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 201,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						onClick: handleOpenCustomUrl,
						className: "px-4 py-2 bg-gradient-to-r from-sky-600 via-blue-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-md transition-all whitespace-nowrap",
						children: "Open in App"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 209,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 200,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 189,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2 overflow-x-auto pb-1",
				children: SERVICE_CATEGORIES.map((cat) => /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setActiveCategory(cat.id),
					className: `px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap flex items-center gap-1.5 transition-all ${activeCategory === cat.id ? "bg-blue-600 text-white shadow-md shadow-blue-600/30" : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800 hover:bg-slate-800"}`,
					children: [/* @__PURE__ */ _jsxDEV("span", { children: cat.icon }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 231,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: cat.label }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 232,
						columnNumber: 13
					}, this)]
				}, cat.id, true, {
					fileName: _jsxFileName,
					lineNumber: 222,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 220,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
				children: filteredPortals.map((portal) => /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 shadow-md transition-all duration-200 hover:-translate-y-0.5 flex flex-col justify-between",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-start justify-between gap-3 mb-2",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2.5",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-10 h-10 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center text-xl shadow-inner",
								children: portal.icon
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 247,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "font-bold text-sm text-white",
								children: portal.title
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 251,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] font-mono text-slate-400 capitalize",
								children: [
									portal.portalType,
									" Portal • ",
									portal.category.replace("_", " ")
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 252,
								columnNumber: 21
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 250,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 246,
							columnNumber: 17
						}, this), portal.popular && /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[9px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded border border-emerald-500/30",
							children: "High Demand"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 259,
							columnNumber: 19
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 245,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-300 mt-2 leading-relaxed line-clamp-3",
						children: portal.description
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 265,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 244,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setSelectedPortalForDocs(portal),
							className: "text-slate-400 hover:text-blue-400 font-medium flex items-center gap-1 text-[11px]",
							children: [/* @__PURE__ */ _jsxDEV(FileCheck, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 275,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
								"Docs Needed (",
								portal.requiredDocs.length,
								")"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 276,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 271,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => handleCopyLink(portal),
								title: "Copy Direct Official Link",
								className: "p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white",
								children: copiedId === portal.id ? /* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 285,
									columnNumber: 45
								}, this) : /* @__PURE__ */ _jsxDEV(Copy, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 285,
									columnNumber: 98
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 280,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => handleOpenInsideApp(portal),
								className: "flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold text-xs shadow-md transition-all hover:scale-105",
								title: "Open this government portal inside the app",
								children: [/* @__PURE__ */ _jsxDEV(Globe, { className: "w-3 h-3 text-sky-200" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 294,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Open Inside App" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 295,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 289,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 279,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 270,
						columnNumber: 13
					}, this)]
				}, portal.id, true, {
					fileName: _jsxFileName,
					lineNumber: 240,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 238,
				columnNumber: 7
			}, this),
			activePortal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex flex-col p-2 sm:p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-3xl flex-1 flex flex-col overflow-hidden shadow-2xl",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-950 border-b border-slate-800 px-4 py-3 flex items-center justify-between gap-3 flex-wrap",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xl",
									children: activePortal.icon
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 310,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "font-extrabold text-white text-xs leading-none flex items-center gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: activePortal.title }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 313,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-mono font-bold",
										children: "In-App Browser"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 314,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 312,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] text-slate-400 font-mono",
									children: [
										activePortal.portalType,
										" • ",
										activePortal.category
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 318,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 311,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 309,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex-1 max-w-xl flex items-center bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 gap-2 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV(Globe, { className: "w-3.5 h-3.5 text-blue-400 flex-shrink-0" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 324,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: browserUrl,
										onChange: (e) => setBrowserUrl(e.target.value),
										onKeyDown: (e) => e.key === "Enter" && handleReload(),
										className: "bg-transparent text-white font-mono text-[11px] w-full focus:outline-none truncate"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 325,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: handleReload,
										title: "Reload Portal",
										className: "text-slate-400 hover:text-white",
										children: /* @__PURE__ */ _jsxDEV(RefreshCw, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 337,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 332,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 323,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => {
											setUseProxy(!useProxy);
											handleReload();
										},
										className: `px-2.5 py-1.5 rounded-xl text-[11px] font-bold border transition-colors ${useProxy ? "bg-purple-600 text-white border-purple-400 shadow" : "bg-slate-900 text-slate-400 border-slate-800 hover:text-white"}`,
										title: "Toggle In-App Bypass Proxy for restricted portals",
										children: /* @__PURE__ */ _jsxDEV("span", { children: ["Proxy: ", useProxy ? "ON" : "OFF"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 353,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 344,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setIsSplitScreen(!isSplitScreen),
										className: `p-2 rounded-xl border text-xs ${isSplitScreen ? "bg-blue-600 text-white border-blue-400" : "bg-slate-900 text-slate-400 border-slate-800 hover:text-white"}`,
										title: "Toggle Operator Split-Screen Workstation Desk",
										children: /* @__PURE__ */ _jsxDEV(Columns, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 366,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 357,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: handleCloseBrowser,
										className: "p-2 rounded-xl bg-slate-800 hover:bg-rose-600 text-slate-300 hover:text-white transition-colors",
										title: "Close Portal",
										children: /* @__PURE__ */ _jsxDEV(X, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 375,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 370,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 342,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 308,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex-1 flex overflow-hidden",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: `h-full flex flex-col bg-white relative transition-all duration-200 ${isSplitScreen ? "w-full lg:w-8/12" : "w-full"}`,
							children: [/* @__PURE__ */ _jsxDEV("iframe", {
								src: getEffectiveIframeSrc(),
								title: activePortal.title,
								className: "w-full h-full border-none",
								style: {
									transform: `scale(${zoomLevel / 100})`,
									transformOrigin: "0 0"
								},
								sandbox: "allow-same-origin allow-scripts allow-forms allow-popups allow-downloads"
							}, iframeKey, false, {
								fileName: _jsxFileName,
								lineNumber: 386,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "absolute bottom-2 left-3 right-3 bg-slate-950/90 backdrop-blur-md border border-slate-800 p-2 rounded-xl text-[11px] text-slate-300 flex items-center justify-between gap-2 shadow-lg",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1.5 truncate",
									children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-emerald-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 398,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["Live Portal: ", /* @__PURE__ */ _jsxDEV("b", { children: activePortal.title }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 399,
										columnNumber: 40
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 399,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 397,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2 flex-shrink-0",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setUseProxy(!useProxy),
										className: "text-xs text-sky-400 hover:underline font-bold",
										children: useProxy ? "Switch Direct" : "Bypass Frame Restriction"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 402,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("a", {
										href: browserUrl,
										target: "_blank",
										rel: "noopener noreferrer",
										className: "text-xs text-slate-400 hover:text-white flex items-center gap-0.5 font-bold",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "New Window" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 414,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-3 h-3" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 415,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 408,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 401,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 396,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 383,
							columnNumber: 15
						}, this), isSplitScreen && /* @__PURE__ */ _jsxDEV("div", {
							className: "hidden lg:flex lg:w-4/12 h-full bg-slate-900 border-l border-slate-800 flex-col p-4 space-y-4 overflow-y-auto",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("h3", {
										className: "font-extrabold text-white text-xs uppercase tracking-wider flex items-center gap-2 text-emerald-400",
										children: [/* @__PURE__ */ _jsxDEV(FolderDown, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 426,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "In-App Document Grabber & Downloads" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 427,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 425,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-400 leading-snug",
										children: "When citizen acknowledgement slip, e-Aadhaar, or PAN PDF is ready, grab it directly into the in-app vault."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 429,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 424,
									columnNumber: 19
								}, this),
								downloadSuccessMsg && /* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center gap-2 animate-in fade-in",
									children: [/* @__PURE__ */ _jsxDEV(CheckCircle, { className: "w-4 h-4 flex-shrink-0" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 436,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: downloadSuccessMsg }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 437,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 435,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2 text-xs bg-slate-950 p-3 rounded-xl border border-slate-800",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-[11px] text-slate-400 block mb-0.5",
											children: "Citizen Name"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 444,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											placeholder: "e.g. Rahul Sharma",
											value: notesCustomerName,
											onChange: (e) => setNotesCustomerName(e.target.value),
											className: "w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-bold"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 445,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 443,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-[11px] text-slate-400 block mb-0.5",
											children: "Application Token / Ack No."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 455,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											placeholder: "e.g. MH-LBY-2026-98124",
											value: notesAckToken,
											onChange: (e) => setNotesAckToken(e.target.value),
											className: "w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 456,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 454,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-[11px] text-slate-400 block mb-0.5",
											children: "Aadhaar / Mobile (Reference)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 466,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											placeholder: "XXXX-XXXX-XXXX",
											value: notesAadhaar,
											onChange: (e) => setNotesAadhaar(e.target.value),
											className: "w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 467,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 465,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 442,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[11px] font-bold text-slate-300 block",
											children: "Save Portal File to In-App Vault:"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 479,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "file",
											ref: fileInputRef,
											onChange: handleInAppDownloadFile,
											accept: ".pdf,.jpg,.jpeg,.png",
											className: "hidden"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 482,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => fileInputRef.current?.click(),
											className: "w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all hover:scale-102",
											children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 493,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Grab Slip / e-Card (In-App)" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 494,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 489,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 478,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2 pt-2 border-t border-slate-800 text-xs",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] font-bold text-slate-400 uppercase tracking-wider block",
										children: "Transfer to Studio:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 500,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 gap-2",
										children: [
											/* @__PURE__ */ _jsxDEV("button", {
												onClick: () => {
													handleCloseBrowser();
													onNavigate?.("pvc_studio");
												},
												className: "p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-blue-500 text-left transition-colors",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-bold text-white text-[11px] flex items-center gap-1",
													children: [/* @__PURE__ */ _jsxDEV(CreditCard, { className: "w-3 h-3 text-blue-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 510,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: "PVC Studio" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 511,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 509,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "text-[10px] text-slate-400",
													children: "Card Maker"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 513,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 505,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												onClick: () => {
													handleCloseBrowser();
													onNavigate?.("pdf_to_jpg");
												},
												className: "p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-amber-500 text-left transition-colors",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-bold text-white text-[11px] flex items-center gap-1",
													children: [/* @__PURE__ */ _jsxDEV(FileText, { className: "w-3 h-3 text-amber-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 521,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: "PDF to JPG" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 522,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 520,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "text-[10px] text-slate-400",
													children: "Compressor"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 524,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 516,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												onClick: () => {
													handleCloseBrowser();
													onNavigate?.("billing");
												},
												className: "p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-emerald-500 text-left transition-colors",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-bold text-white text-[11px] flex items-center gap-1",
													children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-3 h-3 text-emerald-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 532,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: "POS Billing" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 533,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 531,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "text-[10px] text-slate-400",
													children: "Thermal Slip"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 535,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 527,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												onClick: () => {
													handleCloseBrowser();
													onNavigate?.("downloads");
												},
												className: "p-2 rounded-xl bg-slate-950 border border-slate-800 hover:border-purple-500 text-left transition-colors",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-bold text-white text-[11px] flex items-center gap-1",
													children: [/* @__PURE__ */ _jsxDEV(FolderDown, { className: "w-3 h-3 text-purple-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 543,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Downloads" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 544,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 542,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "text-[10px] text-slate-400",
													children: "Vault History"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 546,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 538,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 504,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 499,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2 text-xs",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-white text-[11px] flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(FileCheck, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 554,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: [activePortal.title, " Checklist:"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 555,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 553,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1",
										children: activePortal.requiredDocs.map((doc, idx) => /* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-start gap-1.5 text-[11px] text-slate-300",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-emerald-400 font-bold",
												children: "✓"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 560,
												columnNumber: 27
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: doc }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 561,
												columnNumber: 27
											}, this)]
										}, idx, true, {
											fileName: _jsxFileName,
											lineNumber: 559,
											columnNumber: 25
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 557,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 552,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 423,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 381,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 306,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 305,
				columnNumber: 9
			}, this),
			selectedPortalForDocs && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/75 z-50 flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-2xl max-w-lg w-full p-5 shadow-2xl space-y-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between border-b border-slate-800 pb-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-2xl",
									children: selectedPortalForDocs.icon
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 579,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-bold text-white text-base",
									children: selectedPortalForDocs.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 581,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-blue-400 font-medium",
									children: "Customer Documents Checklist"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 582,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 580,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 578,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setSelectedPortalForDocs(null),
								className: "p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800",
								children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 589,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 585,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 577,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2 text-xs",
							children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "text-slate-300 leading-relaxed",
								children: [
									"Before applying for ",
									/* @__PURE__ */ _jsxDEV("b", { children: selectedPortalForDocs.title }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 595,
										columnNumber: 37
									}, this),
									", collect the following original documents from the citizen:"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 594,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2.5",
								children: selectedPortalForDocs.requiredDocs.map((doc, idx) => /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-start gap-2.5 text-slate-200",
									children: [/* @__PURE__ */ _jsxDEV(CheckCircle, { className: "w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 601,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "leading-snug",
										children: doc
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 602,
										columnNumber: 21
									}, this)]
								}, idx, true, {
									fileName: _jsxFileName,
									lineNumber: 600,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 598,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 593,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-end gap-2 pt-2 border-t border-slate-800",
							children: /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									const p = selectedPortalForDocs;
									setSelectedPortalForDocs(null);
									handleOpenInsideApp(p);
								},
								className: "px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Globe, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 617,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Open Inside App" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 618,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 609,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 608,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 576,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 575,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 154,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsY0FBYztBQUN4QyxTQUVFLGNBQ0EsUUFDQSxXQUNBLGFBQ0EsTUFDQSxPQUVBLEdBR0EsV0FHQSxPQUNBLFVBQ0EsVUFDQSxTQUNBLFlBRUEsWUFNQSxlQUNLO0FBQ1AsU0FBUyxpQkFBaUIsMEJBQTBCOzs7QUFRcEQsT0FBTyxNQUFNLHlCQUErRCxFQUMxRSxlQUNBLGlCQUNJO0NBQ0osTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBaUIsS0FBSztDQUNsRSxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQWlCLEVBQUU7Q0FDL0MsTUFBTSxDQUFDLHVCQUF1Qiw0QkFBNEIsU0FBNEIsSUFBSTtDQUMxRixNQUFNLENBQUMsVUFBVSxlQUFlLFNBQXdCLElBQUk7O0NBRzVELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUE0QixJQUFJO0NBQ3hFLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFpQixFQUFFO0NBQ3ZELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFpQixDQUFDO0NBQ3BELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFpQixHQUFHO0NBQ3RELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFrQixJQUFJO0NBQ2hFLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBa0IsS0FBSzs7Q0FHdkQsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBaUIsRUFBRTtDQUNyRSxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBaUIsRUFBRTtDQUM3RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBaUIsRUFBRTtDQUMzRCxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUF3QixJQUFJO0NBQ2hGLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQWlCLEVBQUU7Q0FFL0QsTUFBTSw0QkFBNEI7RUFDaEMsSUFBSSxNQUFNLGVBQWUsS0FBSztFQUM5QixJQUFJLENBQUMsS0FBSztFQUNWLElBQUksQ0FBQyxJQUFJLFdBQVcsU0FBUyxLQUFLLENBQUMsSUFBSSxXQUFXLFVBQVUsR0FBRztHQUM3RCxNQUFNLGFBQWE7RUFDckI7RUFDQSxNQUFNLFNBQVMsSUFBSSxRQUFRLGdCQUFnQixFQUFFLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0VBQzFELE1BQU0sZUFBMkI7R0FDL0IsSUFBSSxVQUFVLEtBQUssSUFBSTtHQUN2QixPQUFPLE9BQU8sWUFBWTtHQUMxQjtHQUNBLFVBQVU7R0FDVixhQUFhLGtDQUFrQztHQUMvQyxZQUFZO0dBQ1osU0FBUztHQUNULGNBQWM7SUFBQztJQUFnQjtJQUFjO0dBQWdCO0dBQzdELE1BQU07RUFDUjtFQUNBLG9CQUFvQixZQUFZO0NBQ2xDO0NBRUEsTUFBTSxlQUFlLE9BQXlCLElBQUk7Q0FFbEQsTUFBTSxrQkFBa0IsZ0JBQWdCLFFBQVEsTUFBTTtFQUNwRCxNQUFNLGtCQUFrQixtQkFBbUIsU0FBUyxFQUFFLGFBQWE7RUFDbkUsTUFBTSxnQkFDSixFQUFFLE1BQU0sWUFBWSxDQUFDLENBQUMsU0FBUyxPQUFPLFlBQVksQ0FBQyxLQUNuRCxFQUFFLFlBQVksWUFBWSxDQUFDLENBQUMsU0FBUyxPQUFPLFlBQVksQ0FBQztFQUMzRCxPQUFPLG1CQUFtQjtDQUM1QixDQUFDO0NBRUQsTUFBTSxrQkFBa0IsV0FBdUI7RUFDN0MsVUFBVSxVQUFVLFVBQVUsT0FBTyxHQUFHO0VBQ3hDLFlBQVksT0FBTyxFQUFFO0VBQ3JCLGlCQUFpQixZQUFZLElBQUksR0FBRyxHQUFJO0NBQzFDOztDQUdBLE1BQU0sdUJBQXVCLFdBQXVCO0VBQ2xELGdCQUFnQixNQUFNO0VBQ3RCLGNBQWMsT0FBTyxHQUFHO0VBQ3hCLGNBQWEsU0FBUSxPQUFPLENBQUM7RUFDN0IsWUFBWSxLQUFLO0NBQ25COztDQUdBLE1BQU0sMkJBQTJCO0VBQy9CLGdCQUFnQixJQUFJO0VBQ3BCLGNBQWMsRUFBRTtDQUNsQjs7Q0FHQSxNQUFNLHFCQUFxQjtFQUN6QixjQUFhLFNBQVEsT0FBTyxDQUFDO0NBQy9COztDQUdBLE1BQU0sMkJBQTJCLE1BQTJDO0VBQzFFLE1BQU0sT0FBTyxFQUFFLE9BQU8sUUFBUTtFQUM5QixJQUFJLENBQUMsTUFBTTtFQUVYLE1BQU0sVUFBVSxLQUFLLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxZQUFZLEtBQUs7RUFDN0QsTUFBTSxVQUFVLEtBQUssS0FBSyxXQUFXLFFBQVE7RUFDN0MsTUFBTSxRQUFRLEtBQUssU0FBUyxxQkFBcUIsS0FBSyxLQUFLLFNBQVMsTUFBTTtFQUUxRSxNQUFNLGVBQTZCO0dBQ2pDLElBQUksTUFBTSxLQUFLLElBQUk7R0FDbkIsT0FBTyxHQUFHLG9CQUFvQixvQkFBb0IsUUFBUSxLQUFLLGNBQWMsU0FBUyxrQkFBa0IsSUFBSSxpQkFBaUIsT0FBTztHQUNwSSxNQUFNLFFBQVEsaUJBQWlCO0dBQy9CLE1BQU0sSUFBSSxLQUFLLE9BQU8sS0FBSSxDQUFFLFFBQVEsQ0FBQyxFQUFFO0dBQ3ZDLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHO0lBQUUsTUFBTTtJQUFXLFFBQVE7R0FBVSxDQUFDO0dBQ25GLFNBQVMsSUFBSSxnQkFBZ0IsSUFBSTtFQUNuQztFQUVBLElBQUksZUFBZTtHQUNqQixjQUFjLFlBQVk7RUFDNUI7RUFFQSxzQkFBc0IsNkNBQTZDO0VBQ25FLGlCQUFpQixzQkFBc0IsSUFBSSxHQUFHLEdBQUk7Q0FDcEQ7Q0FFQSxNQUFNLDhCQUE4QjtFQUNsQyxJQUFJLENBQUMsWUFBWSxPQUFPO0VBQ3hCLElBQUksVUFBVTtHQUNaLE9BQU8seUJBQXlCLG1CQUFtQixVQUFVO0VBQy9EO0VBQ0EsT0FBTztDQUNUO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSx1QkFBd0I7Ozs7aUJBQ3pDLHdCQUFDLFFBQUQsWUFBTSxtREFBc0Q7Ozs7ZUFDMUQ7Ozs7OztNQUNKLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFoQixDQUNHLGdCQUFnQixRQUFPLDBCQUNwQjs7Ozs7O01BQ04sd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQStHO01BRXpIOzs7OztLQUNIOzs7OztjQUNMLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQThCO0lBRXhDOzs7O1lBQ0E7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsc0VBQXVFOzs7O2VBQ3pGLHdCQUFDLFNBQUQ7TUFDRSxNQUFLO01BQ0wsYUFBWTtNQUNaLE9BQU87TUFDUCxXQUFXLE1BQU0sVUFBVSxFQUFFLE9BQU8sS0FBSztNQUN6QyxXQUFVO0tBQ1g7Ozs7YUFDRTs7Ozs7WUFDRjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxPQUFELEVBQU8sV0FBVSxVQUFXOzs7OztLQUN6Qjs7OztlQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBMEM7S0FBK0M7Ozs7ZUFDekcsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQTZCO0tBQStGOzs7O2FBQ3pJOzs7O2FBQ0Y7Ozs7O2NBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFNBQUQ7TUFDRSxNQUFLO01BQ0wsYUFBWTtNQUNaLE9BQU87TUFDUCxXQUFXLE1BQU0sa0JBQWtCLEVBQUUsT0FBTyxLQUFLO01BQ2pELFlBQVksTUFBTSxFQUFFLFFBQVEsV0FBVyxvQkFBb0I7TUFDM0QsV0FBVTtLQUNYOzs7O2VBQ0Qsd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxTQUFTO01BQ1QsV0FBVTtnQkFDWDtLQUVPOzs7O2FBQ0w7Ozs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osbUJBQW1CLEtBQUssUUFDdkIsd0JBQUMsVUFBRDtLQUVFLGVBQWUsa0JBQWtCLElBQUksRUFBRTtLQUN2QyxXQUFXLHVHQUNULG1CQUFtQixJQUFJLEtBQ25CLHdEQUNBO2VBTlIsQ0FTRSx3QkFBQyxRQUFELFlBQU8sSUFBSSxLQUFXOzs7O2VBQ3RCLHdCQUFDLFFBQUQsWUFBTyxJQUFJLE1BQVk7Ozs7YUFDakI7T0FWRCxJQUFJOzs7O1dBVUgsQ0FDVDtHQUNFOzs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osZ0JBQWdCLEtBQUssV0FDcEIsd0JBQUMsT0FBRDtLQUVFLFdBQVU7ZUFGWixDQUlFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1osT0FBTztPQUNMOzs7O2lCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZ0MsT0FBTztPQUFVOzs7O2lCQUMvRCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEI7U0FDRyxPQUFPO1NBQVc7U0FBVyxPQUFPLFNBQVMsUUFBUSxLQUFLLEdBQUc7UUFDMUQ7Ozs7O2VBQ0g7Ozs7ZUFDRjs7Ozs7Z0JBRUosT0FBTyxXQUNOLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFzSTtNQUVoSjs7OztjQUVMOzs7OztlQUVMLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUNWLE9BQU87S0FDUDs7OzthQUNBOzs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxVQUFEO09BQ0UsZUFBZSx5QkFBeUIsTUFBTTtPQUM5QyxXQUFVO2lCQUZaLENBSUUsd0JBQUMsV0FBRCxFQUFXLFdBQVUsNEJBQTZCOzs7O2lCQUNsRCx3QkFBQyxRQUFEO1FBQU07UUFBYyxPQUFPLGFBQWE7UUFBTztPQUFPOzs7O2VBQ2hEOzs7OztnQkFFUix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLGVBQWUsTUFBTTtRQUNwQyxPQUFNO1FBQ04sV0FBVTtrQkFFVCxhQUFhLE9BQU8sS0FBSyx3QkFBQyxPQUFELEVBQU8sV0FBVSwrQkFBZ0M7Ozs7bUJBQUksd0JBQUMsTUFBRCxFQUFNLFdBQVUsY0FBZTs7Ozs7T0FDeEc7Ozs7aUJBR1Isd0JBQUMsVUFBRDtRQUNFLGVBQWUsb0JBQW9CLE1BQU07UUFDekMsV0FBVTtRQUNWLE9BQU07a0JBSFIsQ0FLRSx3QkFBQyxPQUFELEVBQU8sV0FBVSx1QkFBd0I7Ozs7a0JBQ3pDLHdCQUFDLFFBQUQsWUFBTSxrQkFBcUI7Ozs7Z0JBQ3JCOzs7OztlQUNMOzs7OztjQUNGOzs7OzthQUNGO09BMURFLE9BQU87Ozs7V0EwRFQsQ0FDTjtHQUNFOzs7OztHQUdKLGdCQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUVFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBVyxhQUFhO1FBQVc7Ozs7a0JBQ25ELHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZCxDQUNFLHdCQUFDLFFBQUQsWUFBTyxhQUFhLE1BQVk7Ozs7bUJBQ2hDLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUF5RjtTQUVuRzs7OztpQkFDSjs7Ozs7a0JBQ0osd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCO1VBQXdELGFBQWE7VUFBVztVQUFJLGFBQWE7U0FBZTs7Ozs7Z0JBQzdHOzs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLDBDQUEyQzs7Ozs7U0FDNUQsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxPQUFPO1VBQ1AsV0FBVyxNQUFNLGNBQWMsRUFBRSxPQUFPLEtBQUs7VUFDN0MsWUFBWSxNQUFNLEVBQUUsUUFBUSxXQUFXLGFBQWE7VUFDcEQsV0FBVTtTQUNYOzs7OztTQUNELHdCQUFDLFVBQUQ7VUFDRSxTQUFTO1VBQ1QsT0FBTTtVQUNOLFdBQVU7b0JBRVYsd0JBQUMsV0FBRCxFQUFXLFdBQVUsY0FBZTs7Ozs7U0FDOUI7Ozs7O1FBQ0w7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBRUUsd0JBQUMsVUFBRDtVQUNFLGVBQWU7V0FBRSxZQUFZLENBQUMsUUFBUTtXQUFHLGFBQWE7VUFBRztVQUN6RCxXQUFXLDJFQUNULFdBQ0ksc0RBQ0E7VUFFTixPQUFNO29CQUVOLHdCQUFDLFFBQUQsYUFBTSxXQUFRLFdBQVcsT0FBTyxLQUFZOzs7OztTQUN0Qzs7Ozs7U0FHUix3QkFBQyxVQUFEO1VBQ0UsZUFBZSxpQkFBaUIsQ0FBQyxhQUFhO1VBQzlDLFdBQVcsaUNBQ1QsZ0JBQ0ksMkNBQ0E7VUFFTixPQUFNO29CQUVOLHdCQUFDLFNBQUQsRUFBUyxXQUFVLGNBQWU7Ozs7O1NBQzVCOzs7OztTQUdSLHdCQUFDLFVBQUQ7VUFDRSxTQUFTO1VBQ1QsV0FBVTtVQUNWLE9BQU07b0JBRU4sd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7U0FDbEI7Ozs7O1FBQ0w7Ozs7OztNQUNGOzs7OztlQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVcsc0VBQ2QsZ0JBQWdCLHFCQUFxQjtpQkFEdkMsQ0FHRSx3QkFBQyxVQUFEO1FBRUUsS0FBSyxzQkFBc0I7UUFDM0IsT0FBTyxhQUFhO1FBQ3BCLFdBQVU7UUFDVixPQUFPO1NBQUUsV0FBVyxTQUFTLFlBQVksSUFBSTtTQUFJLGlCQUFpQjtRQUFNO1FBQ3hFLFNBQVE7T0FDVCxHQU5NOzs7O2NBTU4sR0FHRCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsc0NBQTRDOzs7O21CQUM1RCx3QkFBQyxRQUFELGFBQU0saUJBQWEsd0JBQUMsS0FBRCxZQUFJLGFBQWEsTUFBUzs7OztpQkFBTzs7OztpQkFDakQ7Ozs7O2tCQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsVUFBRDtVQUNFLGVBQWUsWUFBWSxDQUFDLFFBQVE7VUFDcEMsV0FBVTtvQkFFVCxXQUFXLGtCQUFrQjtTQUN4Qjs7OzttQkFDUix3QkFBQyxLQUFEO1VBQ0UsTUFBTTtVQUNOLFFBQU87VUFDUCxLQUFJO1VBQ0osV0FBVTtvQkFKWixDQU1FLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztvQkFDdEIsd0JBQUMsY0FBRCxFQUFjLFdBQVUsVUFBVzs7OztrQkFDbEM7Ozs7O2lCQUNBOzs7OztnQkFDRjs7Ozs7ZUFDRjs7Ozs7Z0JBR0osaUJBQ0Msd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFkLENBQ0Usd0JBQUMsWUFBRCxFQUFZLFdBQVUsVUFBVzs7OztvQkFDakMsd0JBQUMsUUFBRCxZQUFNLHNDQUF5Qzs7OztrQkFDN0M7Ozs7O21CQUNKLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUEwQztTQUVwRDs7OztpQkFDQTs7Ozs7O1FBRUosc0JBQ0Msd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSx3QkFBeUI7Ozs7bUJBQ2hELHdCQUFDLFFBQUQsWUFBTyxtQkFBeUI7Ozs7aUJBQzdCOzs7Ozs7UUFJUCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBMEM7VUFBbUI7Ozs7b0JBQzlFLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsYUFBWTtXQUNaLE9BQU87V0FDUCxXQUFXLE1BQU0scUJBQXFCLEVBQUUsT0FBTyxLQUFLO1dBQ3BELFdBQVU7VUFDWDs7OztrQkFDRTs7Ozs7VUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQTBDO1VBQWtDOzs7O29CQUM3Rix3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLGFBQVk7V0FDWixPQUFPO1dBQ1AsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sS0FBSztXQUNoRCxXQUFVO1VBQ1g7Ozs7a0JBQ0U7Ozs7O1VBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUEwQztVQUFtQzs7OztvQkFDOUYsd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxhQUFZO1dBQ1osT0FBTztXQUNQLFdBQVcsTUFBTSxnQkFBZ0IsRUFBRSxPQUFPLEtBQUs7V0FDL0MsV0FBVTtVQUNYOzs7O2tCQUNFOzs7OztTQUNGOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUE2QztVQUV2RDs7Ozs7VUFDTix3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLEtBQUs7V0FDTCxVQUFVO1dBQ1YsUUFBTztXQUNQLFdBQVU7VUFDWDs7Ozs7VUFDRCx3QkFBQyxVQUFEO1dBQ0UsZUFBZSxhQUFhLFNBQVMsTUFBTTtXQUMzQyxXQUFVO3FCQUZaLENBSUUsd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OztxQkFDL0Isd0JBQUMsUUFBRCxZQUFNLDhCQUFpQzs7OzttQkFDakM7Ozs7OztTQUNMOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFzRTtTQUVoRjs7OzttQkFFTix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLFVBQUQ7WUFDRSxlQUFlO2FBQUUsbUJBQW1CO2FBQUcsYUFBYSxZQUFZO1lBQUc7WUFDbkUsV0FBVTtzQkFGWixDQUlFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsWUFBRCxFQUFZLFdBQVUsd0JBQXlCOzs7O3VCQUMvQyx3QkFBQyxRQUFELFlBQU0sYUFBZ0I7Ozs7cUJBQ25COzs7OztzQkFDTCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBNkI7WUFBZTs7OztvQkFDckQ7Ozs7OztXQUVSLHdCQUFDLFVBQUQ7WUFDRSxlQUFlO2FBQUUsbUJBQW1CO2FBQUcsYUFBYSxZQUFZO1lBQUc7WUFDbkUsV0FBVTtzQkFGWixDQUlFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUseUJBQTBCOzs7O3VCQUM5Qyx3QkFBQyxRQUFELFlBQU0sYUFBZ0I7Ozs7cUJBQ25COzs7OztzQkFDTCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBNkI7WUFBZTs7OztvQkFDckQ7Ozs7OztXQUVSLHdCQUFDLFVBQUQ7WUFDRSxlQUFlO2FBQUUsbUJBQW1CO2FBQUcsYUFBYSxTQUFTO1lBQUc7WUFDaEUsV0FBVTtzQkFGWixDQUlFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUsMkJBQTRCOzs7O3VCQUMvQyx3QkFBQyxRQUFELFlBQU0sY0FBaUI7Ozs7cUJBQ3BCOzs7OztzQkFDTCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBNkI7WUFBaUI7Ozs7b0JBQ3ZEOzs7Ozs7V0FFUix3QkFBQyxVQUFEO1lBQ0UsZUFBZTthQUFFLG1CQUFtQjthQUFHLGFBQWEsV0FBVztZQUFHO1lBQ2xFLFdBQVU7c0JBRlosQ0FJRSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNFLHdCQUFDLFlBQUQsRUFBWSxXQUFVLDBCQUEyQjs7Ozt1QkFDakQsd0JBQUMsUUFBRCxZQUFNLFlBQWU7Ozs7cUJBQ2xCOzs7OztzQkFDTCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBNkI7WUFBa0I7Ozs7b0JBQ3hEOzs7Ozs7VUFDTDs7Ozs7aUJBQ0Y7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQ0Usd0JBQUMsV0FBRCxFQUFXLFdBQVUsNEJBQTZCOzs7O29CQUNsRCx3QkFBQyxRQUFELGFBQU8sYUFBYSxPQUFNLGFBQWlCOzs7O2tCQUN2Qzs7Ozs7bUJBQ04sd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1osYUFBYSxhQUFhLEtBQUssS0FBSyxRQUNuQyx3QkFBQyxPQUFEO1dBQWUsV0FBVTtxQkFBekIsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBNkI7V0FBTzs7OztxQkFDcEQsd0JBQUMsUUFBRCxZQUFPLElBQVU7Ozs7bUJBQ2Q7YUFISzs7OztpQkFHTCxDQUNOO1NBQ0U7Ozs7aUJBQ0Y7Ozs7OztPQUNGOzs7OztjQUVKOzs7OzthQUNGOzs7Ozs7R0FDRjs7Ozs7R0FJTix5QkFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQVksc0JBQXNCO1FBQVc7Ozs7a0JBQzdELHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBa0Msc0JBQXNCO1FBQVU7Ozs7a0JBQ2hGLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFvQztRQUFrQzs7OztnQkFDbkY7Ozs7Z0JBQ0Y7Ozs7O2lCQUNMLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLHlCQUF5QixJQUFJO1FBQzVDLFdBQVU7a0JBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7T0FDbEI7Ozs7ZUFDTDs7Ozs7O01BRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBYjtTQUE4QztTQUN4Qix3QkFBQyxLQUFELFlBQUksc0JBQXNCLE1BQVM7Ozs7O1NBQUM7UUFDdkQ7Ozs7O2lCQUVILHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaLHNCQUFzQixhQUFhLEtBQUssS0FBSyxRQUM1Qyx3QkFBQyxPQUFEO1NBQWUsV0FBVTttQkFBekIsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSxnREFBaUQ7Ozs7bUJBQ3hFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFnQjtTQUFVOzs7O2lCQUN2QztXQUhLOzs7O2VBR0wsQ0FDTjtPQUNFOzs7O2VBQ0Y7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFVBQUQ7UUFDRSxlQUFlO1NBQ2IsTUFBTSxJQUFJO1NBQ1YseUJBQXlCLElBQUk7U0FDN0Isb0JBQW9CLENBQUM7UUFDdkI7UUFDQSxXQUFVO2tCQU5aLENBUUUsd0JBQUMsT0FBRCxFQUFPLFdBQVUsY0FBZTs7OztrQkFDaEMsd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7OztnQkFDckI7Ozs7OztNQUNMOzs7OztLQUNGOzs7Ozs7R0FDRjs7Ozs7RUFFSjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiR292ZXJubWVudFBvcnRhbHNWaWV3LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZVJlZiB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICBMYW5kbWFyaywgXG4gIEV4dGVybmFsTGluaywgXG4gIFNlYXJjaCwgXG4gIEZpbGVDaGVjaywgXG4gIENoZWNrQ2lyY2xlLCBcbiAgQ29weSwgXG4gIENoZWNrLCBcbiAgSGVscENpcmNsZSxcbiAgWCxcbiAgTWF4aW1pemUyLFxuICBNaW5pbWl6ZTIsXG4gIFJlZnJlc2hDdyxcbiAgQXJyb3dMZWZ0LFxuICBBcnJvd1JpZ2h0LFxuICBHbG9iZSxcbiAgRG93bmxvYWQsXG4gIEZpbGVUZXh0LFxuICBQcmludGVyLFxuICBDcmVkaXRDYXJkLFxuICBDYW1lcmEsXG4gIEZvbGRlckRvd24sXG4gIExheWVycyxcbiAgU3BhcmtsZXMsXG4gIFphcCxcbiAgWm9vbUluLFxuICBab29tT3V0LFxuICBDb2x1bW5zXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBBTExfR09WX1BPUlRBTFMsIFNFUlZJQ0VfQ0FURUdPUklFUyB9IGZyb20gJy4uL2RhdGEvcG9ydGFsRGF0YSc7XG5pbXBvcnQgeyBQb3J0YWxJdGVtLCBEb3dubG9hZEl0ZW0gfSBmcm9tICcuLi90eXBlcyc7XG5cbmludGVyZmFjZSBHb3Zlcm5tZW50UG9ydGFsc1ZpZXdQcm9wcyB7XG4gIG9uQWRkRG93bmxvYWQ/OiAoZG93bmxvYWQ6IERvd25sb2FkSXRlbSkgPT4gdm9pZDtcbiAgb25OYXZpZ2F0ZT86ICh0YWI6IHN0cmluZykgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IEdvdmVybm1lbnRQb3J0YWxzVmlldzogUmVhY3QuRkM8R292ZXJubWVudFBvcnRhbHNWaWV3UHJvcHM+ID0gKHtcbiAgb25BZGREb3dubG9hZCxcbiAgb25OYXZpZ2F0ZVxufSkgPT4ge1xuICBjb25zdCBbYWN0aXZlQ2F0ZWdvcnksIHNldEFjdGl2ZUNhdGVnb3J5XSA9IHVzZVN0YXRlPHN0cmluZz4oJ2FsbCcpO1xuICBjb25zdCBbc2VhcmNoLCBzZXRTZWFyY2hdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG4gIGNvbnN0IFtzZWxlY3RlZFBvcnRhbEZvckRvY3MsIHNldFNlbGVjdGVkUG9ydGFsRm9yRG9jc10gPSB1c2VTdGF0ZTxQb3J0YWxJdGVtIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtjb3BpZWRJZCwgc2V0Q29waWVkSWRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gSW4tQXBwIEJyb3dzZXIgU3RhdGVcbiAgY29uc3QgW2FjdGl2ZVBvcnRhbCwgc2V0QWN0aXZlUG9ydGFsXSA9IHVzZVN0YXRlPFBvcnRhbEl0ZW0gfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2Jyb3dzZXJVcmwsIHNldEJyb3dzZXJVcmxdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG4gIGNvbnN0IFtpZnJhbWVLZXksIHNldElmcmFtZUtleV0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCBbem9vbUxldmVsLCBzZXRab29tTGV2ZWxdID0gdXNlU3RhdGU8bnVtYmVyPigxMDApO1xuICBjb25zdCBbaXNTcGxpdFNjcmVlbiwgc2V0SXNTcGxpdFNjcmVlbl0gPSB1c2VTdGF0ZTxib29sZWFuPih0cnVlKTtcbiAgY29uc3QgW3VzZVByb3h5LCBzZXRVc2VQcm94eV0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG5cbiAgLy8gUXVpY2sgTm90ZXMgJiBJbi1BcHAgRG9jdW1lbnQgR3JhYmJlclxuICBjb25zdCBbbm90ZXNDdXN0b21lck5hbWUsIHNldE5vdGVzQ3VzdG9tZXJOYW1lXSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xuICBjb25zdCBbbm90ZXNBY2tUb2tlbiwgc2V0Tm90ZXNBY2tUb2tlbl0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKTtcbiAgY29uc3QgW25vdGVzQWFkaGFhciwgc2V0Tm90ZXNBYWRoYWFyXSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xuICBjb25zdCBbZG93bmxvYWRTdWNjZXNzTXNnLCBzZXREb3dubG9hZFN1Y2Nlc3NNc2ddID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtjdXN0b21VcmxJbnB1dCwgc2V0Q3VzdG9tVXJsSW5wdXRdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG5cbiAgY29uc3QgaGFuZGxlT3BlbkN1c3RvbVVybCA9ICgpID0+IHtcbiAgICBsZXQgdXJsID0gY3VzdG9tVXJsSW5wdXQudHJpbSgpO1xuICAgIGlmICghdXJsKSByZXR1cm47XG4gICAgaWYgKCF1cmwuc3RhcnRzV2l0aCgnaHR0cDovLycpICYmICF1cmwuc3RhcnRzV2l0aCgnaHR0cHM6Ly8nKSkge1xuICAgICAgdXJsID0gJ2h0dHBzOi8vJyArIHVybDtcbiAgICB9XG4gICAgY29uc3QgZG9tYWluID0gdXJsLnJlcGxhY2UoL15odHRwcz86XFwvXFwvLywgJycpLnNwbGl0KCcvJylbMF07XG4gICAgY29uc3QgY3VzdG9tUG9ydGFsOiBQb3J0YWxJdGVtID0ge1xuICAgICAgaWQ6IGBjdXN0b20tJHtEYXRlLm5vdygpfWAsXG4gICAgICB0aXRsZTogZG9tYWluLnRvVXBwZXJDYXNlKCksXG4gICAgICB1cmwsXG4gICAgICBjYXRlZ29yeTogJ3V0aWxpdHknLFxuICAgICAgZGVzY3JpcHRpb246IGBJbi1BcHAgV2ViIEJyb3dzZXIgc2Vzc2lvbiBmb3IgJHt1cmx9YCxcbiAgICAgIHBvcnRhbFR5cGU6ICdjZW50cmFsJyxcbiAgICAgIHBvcHVsYXI6IGZhbHNlLFxuICAgICAgcmVxdWlyZWREb2NzOiBbJ0FhZGhhYXIgQ2FyZCcsICdNb2JpbGUgT1RQJywgJ0FwcGxpY2F0aW9uIElEJ10sXG4gICAgICBpY29uOiAn8J+MkCdcbiAgICB9O1xuICAgIGhhbmRsZU9wZW5JbnNpZGVBcHAoY3VzdG9tUG9ydGFsKTtcbiAgfTtcblxuICBjb25zdCBmaWxlSW5wdXRSZWYgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudD4obnVsbCk7XG5cbiAgY29uc3QgZmlsdGVyZWRQb3J0YWxzID0gQUxMX0dPVl9QT1JUQUxTLmZpbHRlcigocCkgPT4ge1xuICAgIGNvbnN0IG1hdGNoZXNDYXRlZ29yeSA9IGFjdGl2ZUNhdGVnb3J5ID09PSAnYWxsJyB8fCBwLmNhdGVnb3J5ID09PSBhY3RpdmVDYXRlZ29yeTtcbiAgICBjb25zdCBtYXRjaGVzU2VhcmNoID0gXG4gICAgICBwLnRpdGxlLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoLnRvTG93ZXJDYXNlKCkpIHx8XG4gICAgICBwLmRlc2NyaXB0aW9uLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoLnRvTG93ZXJDYXNlKCkpO1xuICAgIHJldHVybiBtYXRjaGVzQ2F0ZWdvcnkgJiYgbWF0Y2hlc1NlYXJjaDtcbiAgfSk7XG5cbiAgY29uc3QgaGFuZGxlQ29weUxpbmsgPSAocG9ydGFsOiBQb3J0YWxJdGVtKSA9PiB7XG4gICAgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQocG9ydGFsLnVybCk7XG4gICAgc2V0Q29waWVkSWQocG9ydGFsLmlkKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldENvcGllZElkKG51bGwpLCAyMDAwKTtcbiAgfTtcblxuICAvLyBPcGVuIFBvcnRhbCBJbnNpZGUgdGhlIEFwcFxuICBjb25zdCBoYW5kbGVPcGVuSW5zaWRlQXBwID0gKHBvcnRhbDogUG9ydGFsSXRlbSkgPT4ge1xuICAgIHNldEFjdGl2ZVBvcnRhbChwb3J0YWwpO1xuICAgIHNldEJyb3dzZXJVcmwocG9ydGFsLnVybCk7XG4gICAgc2V0SWZyYW1lS2V5KHByZXYgPT4gcHJldiArIDEpO1xuICAgIHNldFVzZVByb3h5KGZhbHNlKTtcbiAgfTtcblxuICAvLyBDbG9zZSBJbi1BcHAgQnJvd3NlclxuICBjb25zdCBoYW5kbGVDbG9zZUJyb3dzZXIgPSAoKSA9PiB7XG4gICAgc2V0QWN0aXZlUG9ydGFsKG51bGwpO1xuICAgIHNldEJyb3dzZXJVcmwoJycpO1xuICB9O1xuXG4gIC8vIFJlZnJlc2ggY3VycmVudCBwb3J0YWwgaWZyYW1lXG4gIGNvbnN0IGhhbmRsZVJlbG9hZCA9ICgpID0+IHtcbiAgICBzZXRJZnJhbWVLZXkocHJldiA9PiBwcmV2ICsgMSk7XG4gIH07XG5cbiAgLy8gSGFuZGxlIGluLWFwcCBkb2N1bWVudCBncmFiIC8gdXBsb2FkXG4gIGNvbnN0IGhhbmRsZUluQXBwRG93bmxvYWRGaWxlID0gKGU6IFJlYWN0LkNoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+KSA9PiB7XG4gICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzPy5bMF07XG4gICAgaWYgKCFmaWxlKSByZXR1cm47XG5cbiAgICBjb25zdCBmaWxlRXh0ID0gZmlsZS5uYW1lLnNwbGl0KCcuJykucG9wKCk/LnRvVXBwZXJDYXNlKCkgfHwgJ1BERic7XG4gICAgY29uc3QgaXNJbWFnZSA9IGZpbGUudHlwZS5zdGFydHNXaXRoKCdpbWFnZS8nKTtcbiAgICBjb25zdCBpc1BkZiA9IGZpbGUudHlwZSA9PT0gJ2FwcGxpY2F0aW9uL3BkZicgfHwgZmlsZS5uYW1lLmVuZHNXaXRoKCcucGRmJyk7XG5cbiAgICBjb25zdCBkb3dubG9hZEl0ZW06IERvd25sb2FkSXRlbSA9IHtcbiAgICAgIGlkOiBgZGwtJHtEYXRlLm5vdygpfWAsXG4gICAgICB0aXRsZTogYCR7bm90ZXNDdXN0b21lck5hbWUgPyBub3Rlc0N1c3RvbWVyTmFtZSArICcgLSAnIDogJyd9JHthY3RpdmVQb3J0YWw/LnRpdGxlIHx8ICdQb3J0YWwgRG9jdW1lbnQnfSAoJHtub3Rlc0Fja1Rva2VuIHx8ICdTbGlwJ30pYCxcbiAgICAgIHR5cGU6IGlzUGRmID8gJ1BWQyBDYXJkIFBERicgOiAnQ29udmVydGVkIEpQRycsXG4gICAgICBzaXplOiBgJHsoZmlsZS5zaXplIC8gMTAyNCkudG9GaXhlZCgxKX0gS0JgLFxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZyhbXSwgeyBob3VyOiAnMi1kaWdpdCcsIG1pbnV0ZTogJzItZGlnaXQnIH0pLFxuICAgICAgZGF0YVVybDogVVJMLmNyZWF0ZU9iamVjdFVSTChmaWxlKVxuICAgIH07XG5cbiAgICBpZiAob25BZGREb3dubG9hZCkge1xuICAgICAgb25BZGREb3dubG9hZChkb3dubG9hZEl0ZW0pO1xuICAgIH1cblxuICAgIHNldERvd25sb2FkU3VjY2Vzc01zZyhg4pyFIERvY3VtZW50IHNhdmVkIHRvIEluLUFwcCBEb3dubG9hZHMgVmF1bHQhYCk7XG4gICAgc2V0VGltZW91dCgoKSA9PiBzZXREb3dubG9hZFN1Y2Nlc3NNc2cobnVsbCksIDQwMDApO1xuICB9O1xuXG4gIGNvbnN0IGdldEVmZmVjdGl2ZUlmcmFtZVNyYyA9ICgpID0+IHtcbiAgICBpZiAoIWJyb3dzZXJVcmwpIHJldHVybiAnJztcbiAgICBpZiAodXNlUHJveHkpIHtcbiAgICAgIHJldHVybiBgL2FwaS9wb3J0YWwtcHJveHk/dXJsPSR7ZW5jb2RlVVJJQ29tcG9uZW50KGJyb3dzZXJVcmwpfWA7XG4gICAgfVxuICAgIHJldHVybiBicm93c2VyVXJsO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgIHsvKiBIZWFkZXIgYmFyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHAtNCByb3VuZGVkLTJ4bCBzaGFkb3ctbWRcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZsZXgtd3JhcFwiPlxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8R2xvYmUgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXNreS00MDBcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj5PZmZpY2lhbCBHb3Zlcm5tZW50IFBvcnRhbHMgJiBJbi1BcHAgV2ViIEJyb3dzZXI8L3NwYW4+XG4gICAgICAgICAgICA8L2gxPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctc2t5LTUwMC8yMCB0ZXh0LXNreS00MDAgYm9yZGVyIGJvcmRlci1za3ktNTAwLzMwIHRleHQteHMgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgZm9udC1tb25vIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICB7QUxMX0dPVl9QT1JUQUxTLmxlbmd0aH0gQ2VudHJhbCAmIFN0YXRlIFBvcnRhbHNcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLWVtZXJhbGQtNTAwLzIwIHRleHQtZW1lcmFsZC00MDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCB0ZXh0LXhzIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICBJbi1BcHAgRW1iZWRkZWQgTW9kZVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgbXQtMVwiPlxuICAgICAgICAgICAgQWxsIDUwKyBvZmZpY2lhbCBnb3Zlcm5tZW50IHdlYnNpdGVzIG9wZW4gZGlyZWN0bHkgaW5zaWRlIHRoaXMgd29ya3N0YXRpb24gd2l0aCBidWlsdC1pbiBkb2N1bWVudCBkb3dubG9hZCB2YXVsdFxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFNlYXJjaCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiPlxuICAgICAgICAgIDxTZWFyY2ggY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1zbGF0ZS00MDAgYWJzb2x1dGUgbGVmdC0zIHRvcC0xLzIgLXRyYW5zbGF0ZS15LTEvMlwiIC8+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlYXJjaCBwb3J0YWxzIChBYWRoYWFyLCBQQU4sIExhZGtpIEJhaGluKS4uLlwiXG4gICAgICAgICAgICB2YWx1ZT17c2VhcmNofVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWFyY2goZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcGwtOCBwci0zIHB5LTIgdGV4dC14cyB0ZXh0LXdoaXRlIHBsYWNlaG9sZGVyLXNsYXRlLTUwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLXNreS01MDAgdy1mdWxsIHNtOnctNzJcIlxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBVTklWRVJTQUwgSU4tQVBQIFdFQiBCUk9XU0VSICYgRE9XTkxPQURFUiBMQVVOQ0hFUiAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2t5LTUwMC8zMCByb3VuZGVkLTJ4bCBwLTMuNSBzaGFkb3ctbWQgZmxleCBmbGV4LWNvbCBtZDpmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSB3LWZ1bGwgbWQ6dy1hdXRvXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtbGcgYmctc2t5LTUwMC8yMCB0ZXh0LXNreS00MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZmxleC1zaHJpbmstMFwiPlxuICAgICAgICAgICAgPEdsb2JlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIHRleHQteHMgYmxvY2tcIj5Vbml2ZXJzYWwgSW4tQXBwIFdlYiBCcm93c2VyICYgRG93bmxvYWRlcjwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwXCI+T3BlbiBBTlkgd2Vic2l0ZSBvciBjaXRpemVuIHBvcnRhbCBkaXJlY3RseSBpbnNpZGUgdGhpcyBzb2Z0d2FyZSB3aXRob3V0IGV4dGVybmFsIGJyb3dzZXI8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdy1mdWxsIG1kOnctYXV0byBmbGV4LTEgbWF4LXcteGxcIj5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVHlwZSBhbnkgVVJMIChlLmcuIGh0dHBzOi8vZ29vZ2xlLmNvbSwgaHR0cHM6Ly9wbWtpc2FuLmdvdi5pbiwgaHR0cHM6Ly9zYmkuY28uaW4pLi4uXCJcbiAgICAgICAgICAgIHZhbHVlPXtjdXN0b21VcmxJbnB1dH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q3VzdG9tVXJsSW5wdXQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgb25LZXlEb3duPXsoZSkgPT4gZS5rZXkgPT09ICdFbnRlcicgJiYgaGFuZGxlT3BlbkN1c3RvbVVybCgpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtd2hpdGUgcGxhY2Vob2xkZXItc2xhdGUtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItc2t5LTUwMCBmb250LW1vbm9cIlxuICAgICAgICAgIC8+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVPcGVuQ3VzdG9tVXJsfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1za3ktNjAwIHZpYS1ibHVlLTYwMCB0by1pbmRpZ28tNjAwIGhvdmVyOmZyb20tc2t5LTUwMCBob3Zlcjp0by1pbmRpZ28tNTAwIHRleHQtd2hpdGUgZm9udC1leHRyYWJvbGQgdGV4dC14cyByb3VuZGVkLXhsIHNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbCB3aGl0ZXNwYWNlLW5vd3JhcFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgT3BlbiBpbiBBcHBcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIENhdGVnb3J5IFRhYnMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG92ZXJmbG93LXgtYXV0byBwYi0xXCI+XG4gICAgICAgIHtTRVJWSUNFX0NBVEVHT1JJRVMubWFwKChjYXQpID0+IChcbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBrZXk9e2NhdC5pZH1cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZUNhdGVnb3J5KGNhdC5pZCl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zLjUgcHktMiByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIHdoaXRlc3BhY2Utbm93cmFwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgYWN0aXZlQ2F0ZWdvcnkgPT09IGNhdC5pZFxuICAgICAgICAgICAgICAgID8gJ2JnLWJsdWUtNjAwIHRleHQtd2hpdGUgc2hhZG93LW1kIHNoYWRvdy1ibHVlLTYwMC8zMCdcbiAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS04MDAnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3Bhbj57Y2F0Lmljb259PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4+e2NhdC5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICkpfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBQb3J0YWxzIEdyaWQgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTRcIj5cbiAgICAgICAge2ZpbHRlcmVkUG9ydGFscy5tYXAoKHBvcnRhbCkgPT4gKFxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIGtleT17cG9ydGFsLmlkfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC0yeGwgcC00IHNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0yMDAgaG92ZXI6LXRyYW5zbGF0ZS15LTAuNSBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlblwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBnYXAtMyBtYi0yXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLXhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXhsIHNoYWRvdy1pbm5lclwiPlxuICAgICAgICAgICAgICAgICAgICB7cG9ydGFsLmljb259XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbSB0ZXh0LXdoaXRlXCI+e3BvcnRhbC50aXRsZX08L2gzPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LW1vbm8gdGV4dC1zbGF0ZS00MDAgY2FwaXRhbGl6ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtwb3J0YWwucG9ydGFsVHlwZX0gUG9ydGFsIOKAoiB7cG9ydGFsLmNhdGVnb3J5LnJlcGxhY2UoJ18nLCAnICcpfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHtwb3J0YWwucG9wdWxhciAmJiAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs5cHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYmctZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTQwMCBweC0xLjUgcHktMC41IHJvdW5kZWQgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMFwiPlxuICAgICAgICAgICAgICAgICAgICBIaWdoIERlbWFuZFxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS0zMDAgbXQtMiBsZWFkaW5nLXJlbGF4ZWQgbGluZS1jbGFtcC0zXCI+XG4gICAgICAgICAgICAgICAge3BvcnRhbC5kZXNjcmlwdGlvbn1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBwdC0zIGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkUG9ydGFsRm9yRG9jcyhwb3J0YWwpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtYmx1ZS00MDAgZm9udC1tZWRpdW0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1bMTFweF1cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPEZpbGVDaGVjayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWJsdWUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5Eb2NzIE5lZWRlZCAoe3BvcnRhbC5yZXF1aXJlZERvY3MubGVuZ3RofSk8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUNvcHlMaW5rKHBvcnRhbCl9XG4gICAgICAgICAgICAgICAgICB0aXRsZT1cIkNvcHkgRGlyZWN0IE9mZmljaWFsIExpbmtcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC1sZyBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMzAwIGhvdmVyOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIHtjb3BpZWRJZCA9PT0gcG9ydGFsLmlkID8gPENoZWNrIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtZW1lcmFsZC00MDBcIiAvPiA6IDxDb3B5IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz59XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICB7LyogUHJpbWFyeTogT3BlbiBJbnNpZGUgQXBwbGljYXRpb24gKi99XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlT3Blbkluc2lkZUFwcChwb3J0YWwpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSByb3VuZGVkLXhsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB0by1pbmRpZ28tNjAwIGhvdmVyOmZyb20tYmx1ZS01MDAgaG92ZXI6dG8taW5kaWdvLTUwMCB0ZXh0LXdoaXRlIGZvbnQtZXh0cmFib2xkIHRleHQteHMgc2hhZG93LW1kIHRyYW5zaXRpb24tYWxsIGhvdmVyOnNjYWxlLTEwNVwiXG4gICAgICAgICAgICAgICAgICB0aXRsZT1cIk9wZW4gdGhpcyBnb3Zlcm5tZW50IHBvcnRhbCBpbnNpZGUgdGhlIGFwcFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPEdsb2JlIGNsYXNzTmFtZT1cInctMyBoLTMgdGV4dC1za3ktMjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPk9wZW4gSW5zaWRlIEFwcDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEZVTEwtRkVBVFVSRUQgSU4tQVBQIEVNQkVEREVEIFdFQiBCUk9XU0VSIE1PREFMICovfVxuICAgICAge2FjdGl2ZVBvcnRhbCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjay85MCBiYWNrZHJvcC1ibHVyLW1kIHotNTAgZmxleCBmbGV4LWNvbCBwLTIgc206cC00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgZmxleC0xIGZsZXggZmxleC1jb2wgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy0yeGxcIj5cbiAgICAgICAgICAgIHsvKiBCcm93c2VyIENvbnRyb2wgVG9vbGJhciAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcHgtNCBweS0zIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGxcIj57YWN0aXZlUG9ydGFsLmljb259PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSB0ZXh0LXhzIGxlYWRpbmctbm9uZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPnthY3RpdmVQb3J0YWwudGl0bGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBiZy1lbWVyYWxkLTUwMC8yMCB0ZXh0LWVtZXJhbGQtMzAwIHB4LTIgcHktMC41IHJvdW5kZWQgZm9udC1tb25vIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIEluLUFwcCBCcm93c2VyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBmb250LW1vbm9cIj57YWN0aXZlUG9ydGFsLnBvcnRhbFR5cGV9IOKAoiB7YWN0aXZlUG9ydGFsLmNhdGVnb3J5fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFVSTCBBZGRyZXNzIEJhciAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgbWF4LXcteGwgZmxleCBpdGVtcy1jZW50ZXIgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMyBweS0xLjUgZ2FwLTIgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgIDxHbG9iZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWJsdWUtNDAwIGZsZXgtc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2Jyb3dzZXJVcmx9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEJyb3dzZXJVcmwoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgb25LZXlEb3duPXsoZSkgPT4gZS5rZXkgPT09ICdFbnRlcicgJiYgaGFuZGxlUmVsb2FkKCl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy10cmFuc3BhcmVudCB0ZXh0LXdoaXRlIGZvbnQtbW9ubyB0ZXh0LVsxMXB4XSB3LWZ1bGwgZm9jdXM6b3V0bGluZS1ub25lIHRydW5jYXRlXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVJlbG9hZH1cbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUmVsb2FkIFBvcnRhbFwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8UmVmcmVzaEN3IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIEFjdGlvbiBCdXR0b25zICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgey8qIFByb3h5IFRvZ2dsZSAoVXNlZnVsIGlmIHdlYnNpdGUgcmVzdHJpY3RzIGlmcmFtZXMpICovfVxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0VXNlUHJveHkoIXVzZVByb3h5KTsgaGFuZGxlUmVsb2FkKCk7IH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0yLjUgcHktMS41IHJvdW5kZWQteGwgdGV4dC1bMTFweF0gZm9udC1ib2xkIGJvcmRlciB0cmFuc2l0aW9uLWNvbG9ycyAke1xuICAgICAgICAgICAgICAgICAgICB1c2VQcm94eSBcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1wdXJwbGUtNjAwIHRleHQtd2hpdGUgYm9yZGVyLXB1cnBsZS00MDAgc2hhZG93J1xuICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTQwMCBib3JkZXItc2xhdGUtODAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiVG9nZ2xlIEluLUFwcCBCeXBhc3MgUHJveHkgZm9yIHJlc3RyaWN0ZWQgcG9ydGFsc1wiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+UHJveHk6IHt1c2VQcm94eSA/ICdPTicgOiAnT0ZGJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICB7LyogU3BsaXQgU2NyZWVuIFRvZ2dsZSAqL31cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc1NwbGl0U2NyZWVuKCFpc1NwbGl0U2NyZWVuKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMiByb3VuZGVkLXhsIGJvcmRlciB0ZXh0LXhzICR7XG4gICAgICAgICAgICAgICAgICAgIGlzU3BsaXRTY3JlZW5cbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1ibHVlLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05MDAgdGV4dC1zbGF0ZS00MDAgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICB0aXRsZT1cIlRvZ2dsZSBPcGVyYXRvciBTcGxpdC1TY3JlZW4gV29ya3N0YXRpb24gRGVza1wiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPENvbHVtbnMgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgey8qIENsb3NlIEluLUFwcCBCcm93c2VyICovfVxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNsb3NlQnJvd3Nlcn1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiByb3VuZGVkLXhsIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1yb3NlLTYwMCB0ZXh0LXNsYXRlLTMwMCBob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQ2xvc2UgUG9ydGFsXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEJyb3dzZXIgTWFpbiBCb2R5IChTcGxpdCBvciBGdWxsKSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgIHsvKiBMZWZ0IFNpZGU6IExpdmUgRW1iZWRkZWQgUG9ydGFsICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YGgtZnVsbCBmbGV4IGZsZXgtY29sIGJnLXdoaXRlIHJlbGF0aXZlIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMCAke1xuICAgICAgICAgICAgICAgIGlzU3BsaXRTY3JlZW4gPyAndy1mdWxsIGxnOnctOC8xMicgOiAndy1mdWxsJ1xuICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgPGlmcmFtZVxuICAgICAgICAgICAgICAgICAga2V5PXtpZnJhbWVLZXl9XG4gICAgICAgICAgICAgICAgICBzcmM9e2dldEVmZmVjdGl2ZUlmcmFtZVNyYygpfVxuICAgICAgICAgICAgICAgICAgdGl0bGU9e2FjdGl2ZVBvcnRhbC50aXRsZX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGwgYm9yZGVyLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgdHJhbnNmb3JtOiBgc2NhbGUoJHt6b29tTGV2ZWwgLyAxMDB9KWAsIHRyYW5zZm9ybU9yaWdpbjogJzAgMCcgfX1cbiAgICAgICAgICAgICAgICAgIHNhbmRib3g9XCJhbGxvdy1zYW1lLW9yaWdpbiBhbGxvdy1zY3JpcHRzIGFsbG93LWZvcm1zIGFsbG93LXBvcHVwcyBhbGxvdy1kb3dubG9hZHNcIlxuICAgICAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgICAgICB7LyogQm90dG9tIEZhbGxiYWNrIEluZm8gQmFyICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTIgbGVmdC0zIHJpZ2h0LTMgYmctc2xhdGUtOTUwLzkwIGJhY2tkcm9wLWJsdXItbWQgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcC0yIHJvdW5kZWQteGwgdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS0zMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yIHNoYWRvdy1sZ1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRydW5jYXRlXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtNDAwXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5MaXZlIFBvcnRhbDogPGI+e2FjdGl2ZVBvcnRhbC50aXRsZX08L2I+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZsZXgtc2hyaW5rLTBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFVzZVByb3h5KCF1c2VQcm94eSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNreS00MDAgaG92ZXI6dW5kZXJsaW5lIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7dXNlUHJveHkgPyAnU3dpdGNoIERpcmVjdCcgOiAnQnlwYXNzIEZyYW1lIFJlc3RyaWN0aW9uJ31cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgICAgICAgaHJlZj17YnJvd3NlclVybH1cbiAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ9XCJfYmxhbmtcIlxuICAgICAgICAgICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMC41IGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5OZXcgV2luZG93PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxFeHRlcm5hbExpbmsgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogUmlnaHQgU2lkZTogT3BlcmF0b3IgU3BsaXQtU2NyZWVuICYgSW4tQXBwIERvY3VtZW50IEdyYWJiZXIgKi99XG4gICAgICAgICAgICAgIHtpc1NwbGl0U2NyZWVuICYmIChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBsZzpmbGV4IGxnOnctNC8xMiBoLWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlci1sIGJvcmRlci1zbGF0ZS04MDAgZmxleC1jb2wgcC00IHNwYWNlLXktNCBvdmVyZmxvdy15LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIHRleHQteHMgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtZW1lcmFsZC00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8Rm9sZGVyRG93biBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Jbi1BcHAgRG9jdW1lbnQgR3JhYmJlciAmIERvd25sb2Fkczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgbGVhZGluZy1zbnVnXCI+XG4gICAgICAgICAgICAgICAgICAgICAgV2hlbiBjaXRpemVuIGFja25vd2xlZGdlbWVudCBzbGlwLCBlLUFhZGhhYXIsIG9yIFBBTiBQREYgaXMgcmVhZHksIGdyYWIgaXQgZGlyZWN0bHkgaW50byB0aGUgaW4tYXBwIHZhdWx0LlxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAge2Rvd25sb2FkU3VjY2Vzc01zZyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQteGwgYmctZW1lcmFsZC01MDAvMTAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCB0ZXh0LWVtZXJhbGQtNDAwIHRleHQteHMgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGFuaW1hdGUtaW4gZmFkZS1pblwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00IGZsZXgtc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntkb3dubG9hZFN1Y2Nlc3NNc2d9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBDdXN0b21lciBRdWljayBGaWVsZHMgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMiB0ZXh0LXhzIGJnLXNsYXRlLTk1MCBwLTMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0wLjVcIj5DaXRpemVuIE5hbWU8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIFJhaHVsIFNoYXJtYVwiXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17bm90ZXNDdXN0b21lck5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5vdGVzQ3VzdG9tZXJOYW1lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyBwLTIgdGV4dC13aGl0ZSBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGJsb2NrIG1iLTAuNVwiPkFwcGxpY2F0aW9uIFRva2VuIC8gQWNrIE5vLjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gTUgtTEJZLTIwMjYtOTgxMjRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e25vdGVzQWNrVG9rZW59XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5vdGVzQWNrVG9rZW4oZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHAtMiB0ZXh0LXdoaXRlIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgYmxvY2sgbWItMC41XCI+QWFkaGFhciAvIE1vYmlsZSAoUmVmZXJlbmNlKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlhYWFgtWFhYWC1YWFhYXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtub3Rlc0FhZGhhYXJ9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5vdGVzQWFkaGFhcihlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtbGcgcC0yIHRleHQtd2hpdGUgZm9udC1tb25vXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7LyogMS1DbGljayBEb2N1bWVudCBHcmFiYmVyIEJ1dHRvbiAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXNsYXRlLTk1MCByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDAgYmxvY2tcIj5cbiAgICAgICAgICAgICAgICAgICAgICBTYXZlIFBvcnRhbCBGaWxlIHRvIEluLUFwcCBWYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiZmlsZVwiXG4gICAgICAgICAgICAgICAgICAgICAgcmVmPXtmaWxlSW5wdXRSZWZ9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUluQXBwRG93bmxvYWRGaWxlfVxuICAgICAgICAgICAgICAgICAgICAgIGFjY2VwdD1cIi5wZGYsLmpwZywuanBlZywucG5nXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gZmlsZUlucHV0UmVmLmN1cnJlbnQ/LmNsaWNrKCl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIuNSBiZy1ncmFkaWVudC10by1yIGZyb20tZW1lcmFsZC02MDAgdG8tdGVhbC02MDAgaG92ZXI6ZnJvbS1lbWVyYWxkLTUwMCBob3Zlcjp0by10ZWFsLTUwMCB0ZXh0LXdoaXRlIGZvbnQtZXh0cmFib2xkIHRleHQteHMgcm91bmRlZC14bCBzaGFkb3ctbGcgc2hhZG93LWVtZXJhbGQtNjAwLzIwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHRyYW5zaXRpb24tYWxsIGhvdmVyOnNjYWxlLTEwMlwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+R3JhYiBTbGlwIC8gZS1DYXJkIChJbi1BcHApPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7LyogUXVpY2sgQWN0aW9uIEp1bXAgdG8gU3R1ZGlvcyAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIHB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYmxvY2tcIj5cbiAgICAgICAgICAgICAgICAgICAgICBUcmFuc2ZlciB0byBTdHVkaW86XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IGhhbmRsZUNsb3NlQnJvd3NlcigpOyBvbk5hdmlnYXRlPy4oJ3B2Y19zdHVkaW8nKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiByb3VuZGVkLXhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItYmx1ZS01MDAgdGV4dC1sZWZ0IHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXdoaXRlIHRleHQtWzExcHhdIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxDcmVkaXRDYXJkIGNsYXNzTmFtZT1cInctMyBoLTMgdGV4dC1ibHVlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlBWQyBTdHVkaW88L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDBcIj5DYXJkIE1ha2VyPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IGhhbmRsZUNsb3NlQnJvd3NlcigpOyBvbk5hdmlnYXRlPy4oJ3BkZl90b19qcGcnKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiByb3VuZGVkLXhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItYW1iZXItNTAwIHRleHQtbGVmdCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC13aGl0ZSB0ZXh0LVsxMXB4XSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8RmlsZVRleHQgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlBERiB0byBKUEc8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDBcIj5Db21wcmVzc29yPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IGhhbmRsZUNsb3NlQnJvd3NlcigpOyBvbk5hdmlnYXRlPy4oJ2JpbGxpbmcnKTsgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiByb3VuZGVkLXhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItZW1lcmFsZC01MDAgdGV4dC1sZWZ0IHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXdoaXRlIHRleHQtWzExcHhdIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxQcmludGVyIGNsYXNzTmFtZT1cInctMyBoLTMgdGV4dC1lbWVyYWxkLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlBPUyBCaWxsaW5nPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwXCI+VGhlcm1hbCBTbGlwPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7IGhhbmRsZUNsb3NlQnJvd3NlcigpOyBvbk5hdmlnYXRlPy4oJ2Rvd25sb2FkcycpOyB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQteGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1wdXJwbGUtNTAwIHRleHQtbGVmdCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC13aGl0ZSB0ZXh0LVsxMXB4XSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9sZGVyRG93biBjbGFzc05hbWU9XCJ3LTMgaC0zIHRleHQtcHVycGxlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkRvd25sb2Fkczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPlZhdWx0IEhpc3Rvcnk8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIFJlcXVpcmVkIERvY3VtZW50cyBDaGVja2xpc3QgZm9yIHRoaXMgc3BlY2lmaWMgcG9ydGFsICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgcC0zIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0yIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtd2hpdGUgdGV4dC1bMTFweF0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxGaWxlQ2hlY2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1ibHVlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2FjdGl2ZVBvcnRhbC50aXRsZX0gQ2hlY2tsaXN0Ojwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIHthY3RpdmVQb3J0YWwucmVxdWlyZWREb2NzLm1hcCgoZG9jLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpZHh9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTEuNSB0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtYm9sZFwiPuKckzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2RvY308L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBSZXF1aXJlZCBEb2N1bWVudHMgTW9kYWwgKi99XG4gICAgICB7c2VsZWN0ZWRQb3J0YWxGb3JEb2NzICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIGJnLWJsYWNrLzc1IHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgbWF4LXctbGcgdy1mdWxsIHAtNSBzaGFkb3ctMnhsIHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwYi0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bFwiPntzZWxlY3RlZFBvcnRhbEZvckRvY3MuaWNvbn08L3NwYW4+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC13aGl0ZSB0ZXh0LWJhc2VcIj57c2VsZWN0ZWRQb3J0YWxGb3JEb2NzLnRpdGxlfTwvaDM+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtYmx1ZS00MDAgZm9udC1tZWRpdW1cIj5DdXN0b21lciBEb2N1bWVudHMgQ2hlY2tsaXN0PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkUG9ydGFsRm9yRG9jcyhudWxsKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgaG92ZXI6Ymctc2xhdGUtODAwXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMiB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgIEJlZm9yZSBhcHBseWluZyBmb3IgPGI+e3NlbGVjdGVkUG9ydGFsRm9yRG9jcy50aXRsZX08L2I+LCBjb2xsZWN0IHRoZSBmb2xsb3dpbmcgb3JpZ2luYWwgZG9jdW1lbnRzIGZyb20gdGhlIGNpdGl6ZW46XG4gICAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTIuNVwiPlxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZFBvcnRhbEZvckRvY3MucmVxdWlyZWREb2NzLm1hcCgoZG9jLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpZHh9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTIuNSB0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNDAwIGZsZXgtc2hyaW5rLTAgbXQtMC41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibGVhZGluZy1zbnVnXCI+e2RvY308L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMiBwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHAgPSBzZWxlY3RlZFBvcnRhbEZvckRvY3M7XG4gICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFBvcnRhbEZvckRvY3MobnVsbCk7XG4gICAgICAgICAgICAgICAgICBoYW5kbGVPcGVuSW5zaWRlQXBwKHApO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHJvdW5kZWQteGwgdGV4dC14cyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxHbG9iZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+T3BlbiBJbnNpZGUgQXBwPC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19