const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { ShieldCheck, Lock, User, KeyRound, LogIn, Laptop, AlertCircle, Eye, EyeOff, Cpu } from "/node_modules/.vite/deps/lucide-react.js?v=090625a0";
import { authenticateOperator, getHardwareDeviceId, getHardwareDeviceName } from "/src/utils/deviceSecurity.ts";
import { usePWAInstall } from "/src/hooks/usePWAInstall.ts";
var _jsxFileName = "/app/applet/src/components/LoginScreen.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
export const LoginScreen = ({ settings, onLoginSuccess }) => {
	const [usernameInput, setUsernameInput] = useState("");
	const [passwordInput, setPasswordInput] = useState("");
	const [showPassword, setShowPassword] = useState(false);
	const [errorMessage, setErrorMessage] = useState("");
	const [deviceError, setDeviceError] = useState(null);
	const [isLoading, setIsLoading] = useState(false);
	const { isInstallable, install } = usePWAInstall();
	const currentDeviceId = getHardwareDeviceId();
	const currentDeviceName = getHardwareDeviceName();
	const handleLoginSubmit = (e) => {
		e.preventDefault();
		setErrorMessage("");
		setDeviceError(null);
		setIsLoading(true);
		const cleanUsername = usernameInput.trim().toLowerCase();
		const cleanPassword = passwordInput.trim();
		if (!cleanUsername) {
			setErrorMessage("Kripya apna Operator Username enter karein.");
			setIsLoading(false);
			return;
		}
		if (!cleanPassword) {
			setErrorMessage("Kripya Password enter karein.");
			setIsLoading(false);
			return;
		}
		// Authenticate through Device Security Engine (Strict 1 ID = 1 Device)
		const result = authenticateOperator(cleanUsername, cleanPassword);
		setTimeout(() => {
			setIsLoading(false);
			if (result.success && result.user) {
				onLoginSuccess(result.user);
			} else {
				if (result.deviceLockedToOther) {
					setDeviceError(result.error || "This Operator ID is bound to another device.");
				} else {
					setErrorMessage(result.error || "Login failed. Please verify credentials.");
				}
			}
		}, 250);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-blue-500 selection:text-white relative overflow-hidden font-sans",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { className: "absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-b from-blue-600/15 via-indigo-600/5 to-transparent blur-3xl pointer-events-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("header", {
				className: "border-b border-slate-900 bg-slate-950/80 backdrop-blur-md px-6 py-4 flex items-center justify-between z-10",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-lg shadow-blue-500/20 border border-blue-400/30",
						children: /* @__PURE__ */ _jsxDEV("span", {
							className: "font-extrabold text-white text-base tracking-tighter",
							children: "MOS"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 86,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "font-bold text-white text-sm tracking-tight",
						children: "Muzammil Online service pc"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-[11px] text-slate-400",
						children: [settings.shopName, " • Staff Workstation"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 88,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "hidden sm:flex items-center gap-1.5 px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-full text-[11px] text-amber-300 font-semibold",
							children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-3.5 h-3.5 text-amber-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 97,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Master Admin & Operator Only" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 98,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "hidden sm:flex items-center gap-1.5 px-3 py-1 bg-slate-900 border border-slate-800 rounded-full text-[11px] text-slate-400",
							children: [
								/* @__PURE__ */ _jsxDEV(Cpu, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 103,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "This Device:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 104,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-mono text-slate-200 font-bold",
									children: currentDeviceId
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 105,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1.5 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-[11px] text-emerald-400 font-semibold",
							children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-emerald-400 animate-pulse" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 109,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Security Gate Active" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 110,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 108,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 94,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 83,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 flex items-center justify-center p-4 z-10",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "w-full max-w-md",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl space-y-6",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-center space-y-2",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "w-14 h-14 bg-gradient-to-tr from-blue-600/20 via-indigo-600/20 to-blue-500/20 border border-blue-500/30 rounded-2xl flex items-center justify-center mx-auto text-blue-400 shadow-inner",
										children: /* @__PURE__ */ _jsxDEV(Lock, { className: "w-7 h-7" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 122,
											columnNumber: 17
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 121,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("h2", {
										className: "text-xl font-extrabold text-white tracking-tight",
										children: "Operator Authentication"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 124,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-400",
										children: "Authorized Shop Operators Only • Customer self-registration is disabled"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 125,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 13
							}, this),
							deviceError && /* @__PURE__ */ _jsxDEV("div", {
								className: "p-4 rounded-2xl bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs space-y-2 animate-in fade-in zoom-in-95",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-start gap-2",
									children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 134,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", {
										className: "block text-white font-bold mb-1",
										children: "🚨 SINGLE DEVICE SECURITY ENFORCED:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 136,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("p", {
										className: "text-slate-300 leading-relaxed whitespace-pre-line",
										children: deviceError
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 137,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 135,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 133,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "pt-2 border-t border-rose-500/20 text-[11px] text-slate-400 flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Your Machine ID:" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 141,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("code", {
										className: "text-rose-300 font-mono font-bold bg-slate-950 px-2 py-0.5 rounded",
										children: currentDeviceId
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 142,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 140,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 132,
								columnNumber: 15
							}, this),
							errorMessage && !deviceError && /* @__PURE__ */ _jsxDEV("div", {
								className: "p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2.5 animate-in fade-in",
								children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-4 h-4 flex-shrink-0" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 150,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: errorMessage }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 151,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("form", {
								onSubmit: handleLoginSubmit,
								className: "space-y-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-xs font-semibold text-slate-300 block",
											children: "Operator Username / ID"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 159,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "relative",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500",
												children: /* @__PURE__ */ _jsxDEV(User, { className: "w-4 h-4" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 164,
													columnNumber: 21
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 163,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												required: true,
												autoFocus: true,
												value: usernameInput,
												onChange: (e) => {
													setUsernameInput(e.target.value);
													setErrorMessage("");
													setDeviceError(null);
												},
												placeholder: "e.g. admin or operator1",
												className: "w-full pl-10 pr-4 py-2.5 bg-slate-950/80 border border-slate-800 rounded-xl text-white text-xs font-medium placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all font-mono"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 166,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 162,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 158,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1.5",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-xs font-semibold text-slate-300 block",
											children: "Password"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 184,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "relative",
											children: [
												/* @__PURE__ */ _jsxDEV("div", {
													className: "absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500",
													children: /* @__PURE__ */ _jsxDEV(KeyRound, { className: "w-4 h-4" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 189,
														columnNumber: 21
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 188,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("input", {
													type: showPassword ? "text" : "password",
													required: true,
													value: passwordInput,
													onChange: (e) => {
														setPasswordInput(e.target.value);
														setErrorMessage("");
														setDeviceError(null);
													},
													placeholder: "Enter operator password",
													className: "w-full pl-10 pr-10 py-2.5 bg-slate-950/80 border border-slate-800 rounded-xl text-white text-xs font-medium placeholder-slate-600 focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 191,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("button", {
													type: "button",
													onClick: () => setShowPassword(!showPassword),
													className: "absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-500 hover:text-slate-300 transition-colors",
													tabIndex: -1,
													children: showPassword ? /* @__PURE__ */ _jsxDEV(EyeOff, { className: "w-4 h-4" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 209,
														columnNumber: 37
													}, this) : /* @__PURE__ */ _jsxDEV(Eye, { className: "w-4 h-4" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 209,
														columnNumber: 70
													}, this)
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 203,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 187,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 183,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "submit",
										disabled: isLoading,
										className: "w-full py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed mt-2",
										children: isLoading ? /* @__PURE__ */ _jsxDEV("div", { className: "w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 221,
											columnNumber: 19
										}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(LogIn, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 224,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Authorize & Unlock Workstation" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 225,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 223,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 215,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 156,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 space-y-1",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "flex items-center gap-1",
										children: [/* @__PURE__ */ _jsxDEV(Laptop, { className: "w-3.5 h-3.5 text-slate-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 235,
											columnNumber: 19
										}, this), " Machine Fingerprint:"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 234,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono text-slate-300 font-semibold",
										children: currentDeviceId
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 237,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 233,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-[10px] text-slate-500 leading-tight",
									children: "🔒 Security Note: When an operator logs in, this ID is permanently tied to this machine. Only Master Admin can reset device binding."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 239,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 232,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 117,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 116,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("footer", {
				className: "border-t border-slate-900 bg-slate-950 px-6 py-3 text-center text-xs text-slate-400",
				children: /* @__PURE__ */ _jsxDEV("div", { children: [
					settings.shopName,
					" • ",
					settings.address,
					" • Phone: ",
					settings.phone
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 249,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 248,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 78,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUNFLGFBQ0EsTUFDQSxNQUNBLFVBQ0EsT0FDQSxRQUNBLGFBQ0EsS0FDQSxRQUVBLFdBQ0s7QUFFUCxTQUFTLHNCQUFzQixxQkFBcUIsNkJBQTZCO0FBQ2pGLFNBQVMscUJBQXFCOzs7QUFPOUIsT0FBTyxNQUFNLGVBQTJDLEVBQ3RELFVBQ0EscUJBQ0k7Q0FDSixNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBaUIsRUFBRTtDQUM3RCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBaUIsRUFBRTtDQUM3RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBa0IsS0FBSztDQUMvRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBaUIsRUFBRTtDQUMzRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBd0IsSUFBSTtDQUNsRSxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBa0IsS0FBSztDQUV6RCxNQUFNLEVBQUUsZUFBZSxZQUFZLGNBQWM7Q0FDakQsTUFBTSxrQkFBa0Isb0JBQW9CO0NBQzVDLE1BQU0sb0JBQW9CLHNCQUFzQjtDQUVoRCxNQUFNLHFCQUFxQixNQUF1QjtFQUNoRCxFQUFFLGVBQWU7RUFDakIsZ0JBQWdCLEVBQUU7RUFDbEIsZUFBZSxJQUFJO0VBQ25CLGFBQWEsSUFBSTtFQUVqQixNQUFNLGdCQUFnQixjQUFjLEtBQUssQ0FBQyxDQUFDLFlBQVk7RUFDdkQsTUFBTSxnQkFBZ0IsY0FBYyxLQUFLO0VBRXpDLElBQUksQ0FBQyxlQUFlO0dBQ2xCLGdCQUFnQiw2Q0FBNkM7R0FDN0QsYUFBYSxLQUFLO0dBQ2xCO0VBQ0Y7RUFFQSxJQUFJLENBQUMsZUFBZTtHQUNsQixnQkFBZ0IsK0JBQStCO0dBQy9DLGFBQWEsS0FBSztHQUNsQjtFQUNGOztFQUdBLE1BQU0sU0FBUyxxQkFBcUIsZUFBZSxhQUFhO0VBRWhFLGlCQUFpQjtHQUNmLGFBQWEsS0FBSztHQUNsQixJQUFJLE9BQU8sV0FBVyxPQUFPLE1BQU07SUFDakMsZUFBZSxPQUFPLElBQUk7R0FDNUIsT0FBTztJQUNMLElBQUksT0FBTyxxQkFBcUI7S0FDOUIsZUFBZSxPQUFPLFNBQVMsOENBQThDO0lBQy9FLE9BQU87S0FDTCxnQkFBZ0IsT0FBTyxTQUFTLDBDQUEwQztJQUM1RTtHQUNGO0VBQ0YsR0FBRyxHQUFHO0NBQ1I7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFELEVBQUssV0FBVSxnS0FBaUs7Ozs7O0dBR2hMLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQWxCLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUF1RDtNQUFTOzs7OztLQUM3RTs7OztlQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBOEM7S0FBOEI7Ozs7ZUFDMUYsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWIsQ0FBMkMsU0FBUyxVQUFTLHNCQUF1Qjs7Ozs7YUFDakY7Ozs7YUFDRjs7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSw2QkFBOEI7Ozs7aUJBQ3JELHdCQUFDLFFBQUQsWUFBTSwrQkFBa0M7Ozs7ZUFDckM7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsS0FBRCxFQUFLLFdBQVUsNEJBQTZCOzs7OztRQUM1Qyx3QkFBQyxRQUFELFlBQU0sZUFBa0I7Ozs7O1FBQ3hCLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFzQztRQUFzQjs7Ozs7T0FDekU7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsb0RBQTBEOzs7O2lCQUMxRSx3QkFBQyxRQUFELFlBQU0sdUJBQTBCOzs7O2VBQzdCOzs7Ozs7S0FDRjs7Ozs7WUFDQzs7Ozs7O0dBR1Isd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FDZCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BRUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDYix3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7OztTQUN4Qjs7Ozs7U0FDTCx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBbUQ7U0FBMkI7Ozs7O1NBQzVGLHdCQUFDLEtBQUQ7VUFBRyxXQUFVO29CQUF5QjtTQUVuQzs7Ozs7UUFDQTs7Ozs7O09BR0osZUFDQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUsNkNBQThDOzs7O21CQUNyRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsVUFBRDtVQUFRLFdBQVU7b0JBQWtDO1NBQTJDOzs7O21CQUMvRix3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBc0Q7U0FBZTs7OztpQkFDL0U7Ozs7aUJBQ0Y7Ozs7O2tCQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLG1CQUFzQjs7OzttQkFDNUIsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXNFO1NBQXNCOzs7O2lCQUN6Rzs7Ozs7Z0JBQ0Y7Ozs7OztPQUlOLGdCQUFnQixDQUFDLGVBQ2hCLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUsd0JBQXlCOzs7O2tCQUNoRCx3QkFBQyxRQUFELFlBQU8sYUFBbUI7Ozs7Z0JBQ3ZCOzs7Ozs7T0FJUCx3QkFBQyxRQUFEO1FBQU0sVUFBVTtRQUFtQixXQUFVO2tCQUE3QztTQUVFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQTZDO1VBRXZEOzs7O29CQUNQLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQ2Isd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7Ozs7V0FDeEI7Ozs7cUJBQ0wsd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTDtZQUNBO1lBQ0EsT0FBTztZQUNQLFdBQVcsTUFBTTthQUNmLGlCQUFpQixFQUFFLE9BQU8sS0FBSzthQUMvQixnQkFBZ0IsRUFBRTthQUNsQixlQUFlLElBQUk7WUFDckI7WUFDQSxhQUFZO1lBQ1osV0FBVTtXQUNYOzs7O21CQUNFOzs7OztrQkFDRjs7Ozs7O1NBR0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBNkM7VUFFdkQ7Ozs7b0JBQ1Asd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFDYix3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7OztZQUM1Qjs7Ozs7WUFDTCx3QkFBQyxTQUFEO2FBQ0UsTUFBTSxlQUFlLFNBQVM7YUFDOUI7YUFDQSxPQUFPO2FBQ1AsV0FBVyxNQUFNO2NBQ2YsaUJBQWlCLEVBQUUsT0FBTyxLQUFLO2NBQy9CLGdCQUFnQixFQUFFO2NBQ2xCLGVBQWUsSUFBSTthQUNyQjthQUNBLGFBQVk7YUFDWixXQUFVO1lBQ1g7Ozs7O1lBQ0Qsd0JBQUMsVUFBRDthQUNFLE1BQUs7YUFDTCxlQUFlLGdCQUFnQixDQUFDLFlBQVk7YUFDNUMsV0FBVTthQUNWLFVBQVUsQ0FBQzt1QkFFVixlQUFlLHdCQUFDLFFBQUQsRUFBUSxXQUFVLFVBQVc7Ozs7d0JBQUksd0JBQUMsS0FBRCxFQUFLLFdBQVUsVUFBVzs7Ozs7WUFDckU7Ozs7O1dBQ0w7Ozs7O2tCQUNGOzs7Ozs7U0FHTCx3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLFVBQVU7VUFDVixXQUFVO29CQUVULFlBQ0Msd0JBQUMsT0FBRCxFQUFLLFdBQVUsNEVBQTZFOzs7O3FCQUU1RixnREFDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSxVQUFXOzs7O29CQUM1Qix3QkFBQyxRQUFELFlBQU0saUNBQW9DOzs7O2tCQUMxQzs7Ozs7U0FFRTs7Ozs7UUFDSjs7Ozs7O09BR04sd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDZCQUE4Qjs7OztvQkFBQyx1QkFDN0M7Ozs7O21CQUNOLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUEwQztTQUFzQjs7OztpQkFDN0U7Ozs7O2tCQUNMLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUEyQztRQUVyRDs7OztnQkFDQTs7Ozs7O01BQ0Y7Ozs7OztJQUNGOzs7OztHQUNEOzs7OztHQUdOLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO2NBQ2hCLHdCQUFDLE9BQUQ7S0FDRyxTQUFTO0tBQVM7S0FBSSxTQUFTO0tBQVE7S0FBVyxTQUFTO0lBQ3pEOzs7OztHQUNDOzs7OztFQUNMOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJMb2dpblNjcmVlbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgXG4gIFNoaWVsZENoZWNrLCBcbiAgTG9jaywgXG4gIFVzZXIsIFxuICBLZXlSb3VuZCwgXG4gIExvZ0luLCBcbiAgTGFwdG9wLCBcbiAgQWxlcnRDaXJjbGUsXG4gIEV5ZSxcbiAgRXllT2ZmLFxuICBTbWFydHBob25lLFxuICBDcHVcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IFNob3BTZXR0aW5ncywgVXNlckFjY291bnQgfSBmcm9tICcuLi90eXBlcyc7XG5pbXBvcnQgeyBhdXRoZW50aWNhdGVPcGVyYXRvciwgZ2V0SGFyZHdhcmVEZXZpY2VJZCwgZ2V0SGFyZHdhcmVEZXZpY2VOYW1lIH0gZnJvbSAnLi4vdXRpbHMvZGV2aWNlU2VjdXJpdHknO1xuaW1wb3J0IHsgdXNlUFdBSW5zdGFsbCB9IGZyb20gJy4uL2hvb2tzL3VzZVBXQUluc3RhbGwnO1xuXG5pbnRlcmZhY2UgTG9naW5TY3JlZW5Qcm9wcyB7XG4gIHNldHRpbmdzOiBTaG9wU2V0dGluZ3M7XG4gIG9uTG9naW5TdWNjZXNzOiAodXNlcjogVXNlckFjY291bnQpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBMb2dpblNjcmVlbjogUmVhY3QuRkM8TG9naW5TY3JlZW5Qcm9wcz4gPSAoe1xuICBzZXR0aW5ncyxcbiAgb25Mb2dpblN1Y2Nlc3Ncbn0pID0+IHtcbiAgY29uc3QgW3VzZXJuYW1lSW5wdXQsIHNldFVzZXJuYW1lSW5wdXRdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG4gIGNvbnN0IFtwYXNzd29yZElucHV0LCBzZXRQYXNzd29yZElucHV0XSA9IHVzZVN0YXRlPHN0cmluZz4oJycpO1xuICBjb25zdCBbc2hvd1Bhc3N3b3JkLCBzZXRTaG93UGFzc3dvcmRdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbZXJyb3JNZXNzYWdlLCBzZXRFcnJvck1lc3NhZ2VdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG4gIGNvbnN0IFtkZXZpY2VFcnJvciwgc2V0RGV2aWNlRXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtpc0xvYWRpbmcsIHNldElzTG9hZGluZ10gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG5cbiAgY29uc3QgeyBpc0luc3RhbGxhYmxlLCBpbnN0YWxsIH0gPSB1c2VQV0FJbnN0YWxsKCk7XG4gIGNvbnN0IGN1cnJlbnREZXZpY2VJZCA9IGdldEhhcmR3YXJlRGV2aWNlSWQoKTtcbiAgY29uc3QgY3VycmVudERldmljZU5hbWUgPSBnZXRIYXJkd2FyZURldmljZU5hbWUoKTtcblxuICBjb25zdCBoYW5kbGVMb2dpblN1Ym1pdCA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc2V0RXJyb3JNZXNzYWdlKCcnKTtcbiAgICBzZXREZXZpY2VFcnJvcihudWxsKTtcbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XG5cbiAgICBjb25zdCBjbGVhblVzZXJuYW1lID0gdXNlcm5hbWVJbnB1dC50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgICBjb25zdCBjbGVhblBhc3N3b3JkID0gcGFzc3dvcmRJbnB1dC50cmltKCk7XG5cbiAgICBpZiAoIWNsZWFuVXNlcm5hbWUpIHtcbiAgICAgIHNldEVycm9yTWVzc2FnZSgnS3JpcHlhIGFwbmEgT3BlcmF0b3IgVXNlcm5hbWUgZW50ZXIga2FyZWluLicpO1xuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoIWNsZWFuUGFzc3dvcmQpIHtcbiAgICAgIHNldEVycm9yTWVzc2FnZSgnS3JpcHlhIFBhc3N3b3JkIGVudGVyIGthcmVpbi4nKTtcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gQXV0aGVudGljYXRlIHRocm91Z2ggRGV2aWNlIFNlY3VyaXR5IEVuZ2luZSAoU3RyaWN0IDEgSUQgPSAxIERldmljZSlcbiAgICBjb25zdCByZXN1bHQgPSBhdXRoZW50aWNhdGVPcGVyYXRvcihjbGVhblVzZXJuYW1lLCBjbGVhblBhc3N3b3JkKTtcblxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgc2V0SXNMb2FkaW5nKGZhbHNlKTtcbiAgICAgIGlmIChyZXN1bHQuc3VjY2VzcyAmJiByZXN1bHQudXNlcikge1xuICAgICAgICBvbkxvZ2luU3VjY2VzcyhyZXN1bHQudXNlcik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAocmVzdWx0LmRldmljZUxvY2tlZFRvT3RoZXIpIHtcbiAgICAgICAgICBzZXREZXZpY2VFcnJvcihyZXN1bHQuZXJyb3IgfHwgJ1RoaXMgT3BlcmF0b3IgSUQgaXMgYm91bmQgdG8gYW5vdGhlciBkZXZpY2UuJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgc2V0RXJyb3JNZXNzYWdlKHJlc3VsdC5lcnJvciB8fCAnTG9naW4gZmFpbGVkLiBQbGVhc2UgdmVyaWZ5IGNyZWRlbnRpYWxzLicpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSwgMjUwKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGJnLXNsYXRlLTk1MCB0ZXh0LXNsYXRlLTEwMCBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBzZWxlY3Rpb246YmctYmx1ZS01MDAgc2VsZWN0aW9uOnRleHQtd2hpdGUgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuIGZvbnQtc2Fuc1wiPlxuICAgICAgey8qIEJhY2tncm91bmQgYW1iaWVudCBsaWdodGluZyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgbGVmdC0xLzIgLXRyYW5zbGF0ZS14LTEvMiB3LWZ1bGwgbWF4LXctN3hsIGgtOTYgYmctZ3JhZGllbnQtdG8tYiBmcm9tLWJsdWUtNjAwLzE1IHZpYS1pbmRpZ28tNjAwLzUgdG8tdHJhbnNwYXJlbnQgYmx1ci0zeGwgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG5cbiAgICAgIHsvKiBUb3AgSGVhZGVyIEJyYW5kaW5nIEJhciAqL31cbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTkwMCBiZy1zbGF0ZS05NTAvODAgYmFja2Ryb3AtYmx1ci1tZCBweC02IHB5LTQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHotMTBcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQtMnhsIGJnLWdyYWRpZW50LXRvLXRyIGZyb20tYmx1ZS02MDAgdG8taW5kaWdvLTUwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaGFkb3ctbGcgc2hhZG93LWJsdWUtNTAwLzIwIGJvcmRlciBib3JkZXItYmx1ZS00MDAvMzBcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdGV4dC1iYXNlIHRyYWNraW5nLXRpZ2h0ZXJcIj5NT1M8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC13aGl0ZSB0ZXh0LXNtIHRyYWNraW5nLXRpZ2h0XCI+TXV6YW1taWwgT25saW5lIHNlcnZpY2UgcGM8L2gxPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDBcIj57c2V0dGluZ3Muc2hvcE5hbWV9IOKAoiBTdGFmZiBXb3Jrc3RhdGlvbjwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgIHsvKiBJbnRlcm5hbCBTdGFmZiBCYWRnZSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBzbTpmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMSBiZy1hbWJlci01MDAvMTAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgcm91bmRlZC1mdWxsIHRleHQtWzExcHhdIHRleHQtYW1iZXItMzAwIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgIDxTaGllbGRDaGVjayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5NYXN0ZXIgQWRtaW4gJiBPcGVyYXRvciBPbmx5PC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIEN1cnJlbnQgRGV2aWNlIEhhcmR3YXJlIEJhZGdlICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLWZ1bGwgdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgIDxDcHUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1ibHVlLTQwMFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5UaGlzIERldmljZTo8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1zbGF0ZS0yMDAgZm9udC1ib2xkXCI+e2N1cnJlbnREZXZpY2VJZH08L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xIGJnLWVtZXJhbGQtNTAwLzEwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMjAgcm91bmRlZC1mdWxsIHRleHQtWzExcHhdIHRleHQtZW1lcmFsZC00MDAgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC00MDAgYW5pbWF0ZS1wdWxzZVwiPjwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuPlNlY3VyaXR5IEdhdGUgQWN0aXZlPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvaGVhZGVyPlxuXG4gICAgICB7LyogTWFpbiBDZW50ZXIgTG9naW4gQ2FyZCAqL31cbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgei0xMFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBtYXgtdy1tZFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzkwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtM3hsIHAtNiBzbTpwLTggc2hhZG93LTJ4bCBiYWNrZHJvcC1ibHVyLXhsIHNwYWNlLXktNlwiPlxuICAgICAgICAgICAgey8qIEhlYWRlciBpbmZvICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE0IGgtMTQgYmctZ3JhZGllbnQtdG8tdHIgZnJvbS1ibHVlLTYwMC8yMCB2aWEtaW5kaWdvLTYwMC8yMCB0by1ibHVlLTUwMC8yMCBib3JkZXIgYm9yZGVyLWJsdWUtNTAwLzMwIHJvdW5kZWQtMnhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIG14LWF1dG8gdGV4dC1ibHVlLTQwMCBzaGFkb3ctaW5uZXJcIj5cbiAgICAgICAgICAgICAgICA8TG9jayBjbGFzc05hbWU9XCJ3LTcgaC03XCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj5PcGVyYXRvciBBdXRoZW50aWNhdGlvbjwvaDI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICBBdXRob3JpemVkIFNob3AgT3BlcmF0b3JzIE9ubHkg4oCiIEN1c3RvbWVyIHNlbGYtcmVnaXN0cmF0aW9uIGlzIGRpc2FibGVkXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogRGV2aWNlIExvY2sgRXJyb3IgQmFubmVyIChJZiBJRCBpcyB1c2VkIG9uIGFub3RoZXIgbWFjaGluZSkgKi99XG4gICAgICAgICAgICB7ZGV2aWNlRXJyb3IgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLTJ4bCBiZy1yb3NlLTk1MC80MCBib3JkZXIgYm9yZGVyLXJvc2UtNTAwLzQwIHRleHQtcm9zZS0zMDAgdGV4dC14cyBzcGFjZS15LTIgYW5pbWF0ZS1pbiBmYWRlLWluIHpvb20taW4tOTVcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxBbGVydENpcmNsZSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtcm9zZS00MDAgZmxleC1zaHJpbmstMCBtdC0wLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXdoaXRlIGZvbnQtYm9sZCBtYi0xXCI+8J+aqCBTSU5HTEUgREVWSUNFIFNFQ1VSSVRZIEVORk9SQ0VEOjwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTMwMCBsZWFkaW5nLXJlbGF4ZWQgd2hpdGVzcGFjZS1wcmUtbGluZVwiPntkZXZpY2VFcnJvcn08L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgYm9yZGVyLXQgYm9yZGVyLXJvc2UtNTAwLzIwIHRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+WW91ciBNYWNoaW5lIElEOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxjb2RlIGNsYXNzTmFtZT1cInRleHQtcm9zZS0zMDAgZm9udC1tb25vIGZvbnQtYm9sZCBiZy1zbGF0ZS05NTAgcHgtMiBweS0wLjUgcm91bmRlZFwiPntjdXJyZW50RGV2aWNlSWR9PC9jb2RlPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBHZW5lcmFsIEVycm9yIEJhbm5lciAqL31cbiAgICAgICAgICAgIHtlcnJvck1lc3NhZ2UgJiYgIWRldmljZUVycm9yICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSByb3VuZGVkLXhsIGJnLXJvc2UtNTAwLzEwIGJvcmRlciBib3JkZXItcm9zZS01MDAvMzAgdGV4dC1yb3NlLTQwMCB0ZXh0LXhzIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yLjUgYW5pbWF0ZS1pbiBmYWRlLWluXCI+XG4gICAgICAgICAgICAgICAgPEFsZXJ0Q2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTQgZmxleC1zaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+e2Vycm9yTWVzc2FnZX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIExvZ2luIEZvcm0gKi99XG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlTG9naW5TdWJtaXR9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICB7LyogVXNlcm5hbWUgSW5wdXQgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtMzAwIGJsb2NrXCI+XG4gICAgICAgICAgICAgICAgICBPcGVyYXRvciBVc2VybmFtZSAvIElEXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCBsZWZ0LTAgcGwtMy41IGZsZXggaXRlbXMtY2VudGVyIHBvaW50ZXItZXZlbnRzLW5vbmUgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPFVzZXIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgIGF1dG9Gb2N1c1xuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dXNlcm5hbWVJbnB1dH1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0VXNlcm5hbWVJbnB1dChlLnRhcmdldC52YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0RXJyb3JNZXNzYWdlKCcnKTtcbiAgICAgICAgICAgICAgICAgICAgICBzZXREZXZpY2VFcnJvcihudWxsKTtcbiAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIGFkbWluIG9yIG9wZXJhdG9yMVwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwbC0xMCBwci00IHB5LTIuNSBiZy1zbGF0ZS05NTAvODAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1tZWRpdW0gcGxhY2Vob2xkZXItc2xhdGUtNjAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1ibHVlLTUwMC81MCBmb2N1czpib3JkZXItYmx1ZS01MDAgdHJhbnNpdGlvbi1hbGwgZm9udC1tb25vXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBQYXNzd29yZCBJbnB1dCAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS0zMDAgYmxvY2tcIj5cbiAgICAgICAgICAgICAgICAgIFBhc3N3b3JkXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXktMCBsZWZ0LTAgcGwtMy41IGZsZXggaXRlbXMtY2VudGVyIHBvaW50ZXItZXZlbnRzLW5vbmUgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPEtleVJvdW5kIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT17c2hvd1Bhc3N3b3JkID8gJ3RleHQnIDogJ3Bhc3N3b3JkJ31cbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Bhc3N3b3JkSW5wdXR9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIHNldFBhc3N3b3JkSW5wdXQoZS50YXJnZXQudmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgIHNldEVycm9yTWVzc2FnZSgnJyk7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0RGV2aWNlRXJyb3IobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgb3BlcmF0b3IgcGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcGwtMTAgcHItMTAgcHktMi41IGJnLXNsYXRlLTk1MC84MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHRleHQtd2hpdGUgdGV4dC14cyBmb250LW1lZGl1bSBwbGFjZWhvbGRlci1zbGF0ZS02MDAgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLWJsdWUtNTAwLzUwIGZvY3VzOmJvcmRlci1ibHVlLTUwMCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd1Bhc3N3b3JkKCFzaG93UGFzc3dvcmQpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC15LTAgcmlnaHQtMCBwci0zLjUgZmxleCBpdGVtcy1jZW50ZXIgdGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC1zbGF0ZS0zMDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICB0YWJJbmRleD17LTF9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtzaG93UGFzc3dvcmQgPyA8RXllT2ZmIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiA6IDxFeWUgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+fVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBTdWJtaXQgQnV0dG9uICovfVxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZ31cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMyBiZy1ncmFkaWVudC10by1yIGZyb20tYmx1ZS02MDAgdG8taW5kaWdvLTYwMCBob3Zlcjpmcm9tLWJsdWUtNTAwIGhvdmVyOnRvLWluZGlnby01MDAgdGV4dC13aGl0ZSBmb250LWV4dHJhYm9sZCB0ZXh0LXhzIHJvdW5kZWQteGwgc2hhZG93LWxnIHNoYWRvdy1ibHVlLTYwMC8zMCB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzY2FsZS1bMS4wMl0gYWN0aXZlOnNjYWxlLVswLjk4XSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBkaXNhYmxlZDpvcGFjaXR5LTUwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBtdC0yXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtpc0xvYWRpbmcgPyAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNCBoLTQgYm9yZGVyLTIgYm9yZGVyLXdoaXRlLzMwIGJvcmRlci10LXdoaXRlIHJvdW5kZWQtZnVsbCBhbmltYXRlLXNwaW5cIiAvPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICA8TG9nSW4gY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkF1dGhvcml6ZSAmIFVubG9jayBXb3Jrc3RhdGlvbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9mb3JtPlxuXG4gICAgICAgICAgICB7LyogRGV2aWNlIEhhcmR3YXJlIEluZm8gQm94ICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAvODAgdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgIDxMYXB0b3AgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1zbGF0ZS00MDBcIiAvPiBNYWNoaW5lIEZpbmdlcnByaW50OlxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1zbGF0ZS0zMDAgZm9udC1zZW1pYm9sZFwiPntjdXJyZW50RGV2aWNlSWR9PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgbGVhZGluZy10aWdodFwiPlxuICAgICAgICAgICAgICAgIPCflJIgU2VjdXJpdHkgTm90ZTogV2hlbiBhbiBvcGVyYXRvciBsb2dzIGluLCB0aGlzIElEIGlzIHBlcm1hbmVudGx5IHRpZWQgdG8gdGhpcyBtYWNoaW5lLiBPbmx5IE1hc3RlciBBZG1pbiBjYW4gcmVzZXQgZGV2aWNlIGJpbmRpbmcuXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvbWFpbj5cblxuICAgICAgey8qIEZvb3RlciAqL31cbiAgICAgIDxmb290ZXIgY2xhc3NOYW1lPVwiYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTkwMCBiZy1zbGF0ZS05NTAgcHgtNiBweS0zIHRleHQtY2VudGVyIHRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICB7c2V0dGluZ3Muc2hvcE5hbWV9IOKAoiB7c2V0dGluZ3MuYWRkcmVzc30g4oCiIFBob25lOiB7c2V0dGluZ3MucGhvbmV9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9mb290ZXI+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19