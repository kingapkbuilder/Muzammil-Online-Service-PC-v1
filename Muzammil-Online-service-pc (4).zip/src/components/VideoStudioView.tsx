const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { Film, Play, Pause, RotateCcw, Volume2, VolumeX, RotateCw, Type, Image as ImageIcon, Music, Download, Layers, Sliders, Sparkles, Upload, FastForward, Rewind, Flame, Sun, Contrast, Droplets, CheckCircle2, Camera, SplitSquareVertical, FlipHorizontal, FlipVertical } from "/node_modules/.vite/deps/lucide-react.js?v=090625a0";
var _jsxFileName = "/app/applet/src/components/VideoStudioView.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
export const VideoStudioView = ({ onAddDownload }) => {
	// Video Source & Element
	const [videoSrc, setVideoSrc] = useState(null);
	const [videoFileName, setVideoFileName] = useState("project_video.mp4");
	const videoRef = useRef(null);
	const canvasRef = useRef(null);
	// Secondary Overlay Image/Video Track (Track 2)
	const [overlayImageSrc, setOverlayImageSrc] = useState(null);
	const [overlayScale, setOverlayScale] = useState(.3);
	const [overlayPosition, setOverlayPosition] = useState("top-right");
	const [overlayOpacity, setOverlayOpacity] = useState(.9);
	const overlayImgRef = useRef(null);
	// Audio / Music Track (Track 3)
	const [musicSrc, setMusicSrc] = useState(null);
	const [musicVolume, setMusicVolume] = useState(70);
	const [isMusicMuted, setIsMusicMuted] = useState(false);
	const audioRef = useRef(null);
	// Playback & Timing
	const [isPlaying, setIsPlaying] = useState(false);
	const [currentTime, setCurrentTime] = useState(0);
	const [duration, setDuration] = useState(10);
	const [inPoint, setInPoint] = useState(0);
	const [outPoint, setOutPoint] = useState(10);
	const [playbackSpeed, setPlaybackSpeed] = useState(1);
	const [masterVolume, setMasterVolume] = useState(100);
	const [isMasterMuted, setIsMasterMuted] = useState(false);
	const [isLooping, setIsLooping] = useState(true);
	// Canvas Geometry & Aspect Ratio
	const [aspectRatio, setAspectRatio] = useState("16:9");
	const [rotation, setRotation] = useState(0);
	const [flipH, setFlipH] = useState(false);
	const [flipV, setFlipV] = useState(false);
	const [zoomLevel, setZoomLevel] = useState(1);
	// Color Grading & Filters
	const [brightness, setBrightness] = useState(0);
	const [contrast, setContrast] = useState(0);
	const [saturation, setSaturation] = useState(0);
	const [warmth, setWarmth] = useState(0);
	const [filterPreset, setFilterPreset] = useState("normal");
	// Text & Title Layers (Track 4)
	const [textOverlays, setTextOverlays] = useState([{
		id: "txt-1",
		text: "Muzammil Online Service • CSC Cyber Cafe",
		fontSize: 28,
		color: "#ffffff",
		bgColor: "rgba(15, 23, 42, 0.85)",
		position: "bottom",
		style: "lower_third",
		startTime: 0,
		endTime: 10
	}]);
	const [activeTextId, setActiveTextId] = useState("txt-1");
	// Watermark / Cyber Cafe Stamp (Track 5)
	const [showWatermark, setShowWatermark] = useState(true);
	const [watermarkText, setWatermarkText] = useState("Muzammil Online • 9561460313");
	const [watermarkPos, setWatermarkPos] = useState("top-right");
	const [watermarkOpacity, setWatermarkOpacity] = useState(.8);
	// Active Editing Sub-Deck: 'timeline' | 'color' | 'audio' | 'text' | 'overlay' | 'crop'
	const [activeToolTab, setActiveToolTab] = useState("timeline");
	// Timeline UI state
	const [timelineZoom, setTimelineZoom] = useState(1);
	const [isExporting, setIsExporting] = useState(false);
	const [exportProgress, setExportProgress] = useState(0);
	const [statusAlert, setStatusAlert] = useState(null);
	// MediaRecorder Ref for Video Render
	const recorderRef = useRef(null);
	const recordedBlobsRef = useRef([]);
	// Resolution targets based on aspect ratio
	const getCanvasDimensions = useCallback(() => {
		switch (aspectRatio) {
			case "16:9": return {
				width: 1280,
				height: 720
			};
			case "9:16": return {
				width: 720,
				height: 1280
			};
			case "1:1": return {
				width: 1080,
				height: 1080
			};
			case "4:5": return {
				width: 864,
				height: 1080
			};
			default: return {
				width: 1280,
				height: 720
			};
		}
	}, [aspectRatio]);
	// Format seconds to 00:00:00
	const formatTime = (seconds) => {
		const mins = Math.floor(seconds / 60);
		const secs = Math.floor(seconds % 60);
		const ms = Math.floor(seconds % 1 * 10);
		return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}.${ms}`;
	};
	// 1. Generate Interactive Motion Sample Video on Canvas if no file uploaded
	const handleLoadSampleVideo = () => {
		const sampleCanvas = document.createElement("canvas");
		sampleCanvas.width = 1280;
		sampleCanvas.height = 720;
		const sCtx = sampleCanvas.getContext("2d");
		if (!sCtx) return;
		// Use WebM/MP4 generator stream
		const stream = sampleCanvas.captureStream(30);
		const rec = new MediaRecorder(stream, { mimeType: "video/webm" });
		const chunks = [];
		rec.ondataavailable = (e) => {
			if (e.data.size > 0) chunks.push(e.data);
		};
		rec.onstop = () => {
			const blob = new Blob(chunks, { type: "video/webm" });
			const url = URL.createObjectURL(blob);
			setVideoSrc(url);
			setVideoFileName("CyberCafe_Sample_Demo.webm");
			setDuration(8);
			setInPoint(0);
			setOutPoint(8);
			setCurrentTime(0);
			setStatusAlert("🎬 Sample Cyber Cafe Video clip generated successfully!");
			setTimeout(() => setStatusAlert(null), 3500);
		};
		rec.start();
		// Render 8 seconds of dynamic cyber graphics animation
		let frame = 0;
		const totalFrames = 8 * 30;
		const animInterval = setInterval(() => {
			frame++;
			const progress = frame / totalFrames;
			const timeSec = frame / 30;
			// Dark cyber background
			const grad = sCtx.createLinearGradient(0, 0, 1280, 720);
			grad.addColorStop(0, "#020617");
			grad.addColorStop(.5, "#0f172a");
			grad.addColorStop(1, "#1e1b4b");
			sCtx.fillStyle = grad;
			sCtx.fillRect(0, 0, 1280, 720);
			// Moving Grid lines
			sCtx.strokeStyle = "rgba(56, 189, 248, 0.15)";
			sCtx.lineWidth = 1;
			const offset = frame * 2 % 40;
			for (let x = offset; x < 1280; x += 40) {
				sCtx.beginPath();
				sCtx.moveTo(x, 0);
				sCtx.lineTo(x, 720);
				sCtx.stroke();
			}
			for (let y = offset; y < 720; y += 40) {
				sCtx.beginPath();
				sCtx.moveTo(0, y);
				sCtx.lineTo(1280, y);
				sCtx.stroke();
			}
			// Glowing Center Card
			sCtx.save();
			sCtx.translate(640, 360);
			sCtx.rotate(Math.sin(progress * Math.PI * 2) * .05);
			sCtx.fillStyle = "rgba(15, 23, 42, 0.9)";
			sCtx.strokeStyle = "#38bdf8";
			sCtx.lineWidth = 4;
			sCtx.beginPath();
			sCtx.roundRect(-300, -180, 600, 360, 24);
			sCtx.fill();
			sCtx.stroke();
			// Brand Title
			sCtx.fillStyle = "#ffffff";
			sCtx.font = "bold 38px sans-serif";
			sCtx.textAlign = "center";
			sCtx.fillText("MUZAMMIL ONLINE SERVICE", 0, -60);
			// Subtitle
			sCtx.fillStyle = "#38bdf8";
			sCtx.font = "bold 22px sans-serif";
			sCtx.fillText("CSC & Cyber Cafe Professional Video Studio", 0, -15);
			// Floating particles
			sCtx.fillStyle = "#22c55e";
			sCtx.font = "16px monospace";
			sCtx.fillText(`LIVE TIMECODE: 00:0${Math.floor(timeSec)}.${frame % 30}`, 0, 45);
			sCtx.fillStyle = "#94a3b8";
			sCtx.font = "14px sans-serif";
			sCtx.fillText("PVC Card • Passport Photo • Online Citizen Services", 0, 95);
			sCtx.restore();
			if (frame >= totalFrames) {
				clearInterval(animInterval);
				rec.stop();
			}
		}, 1e3 / 30);
	};
	// Video File Upload Handler
	const handleUploadVideo = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		const url = URL.createObjectURL(file);
		setVideoSrc(url);
		setVideoFileName(file.name);
		setCurrentTime(0);
		setIsPlaying(false);
		setStatusAlert(`🎬 Video "${file.name}" loaded into Multi-Layer Timeline!`);
		setTimeout(() => setStatusAlert(null), 3500);
	};
	// Overlay Image Upload (Track 2)
	const handleUploadOverlayImage = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		const url = URL.createObjectURL(file);
		setOverlayImageSrc(url);
		const img = new Image();
		img.src = url;
		img.onload = () => {
			overlayImgRef.current = img;
		};
		setStatusAlert("🖼️ Overlay Picture-in-Picture added to Track 2!");
		setTimeout(() => setStatusAlert(null), 3e3);
	};
	// Background Audio Upload (Track 3)
	const handleUploadMusic = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		const url = URL.createObjectURL(file);
		setMusicSrc(url);
		setStatusAlert(`🎵 Audio Track "${file.name}" added to Track 3!`);
		setTimeout(() => setStatusAlert(null), 3e3);
	};
	// Video Metadata Loaded
	const handleVideoLoadedMetadata = () => {
		const v = videoRef.current;
		if (!v) return;
		const dur = v.duration || 10;
		setDuration(dur);
		setInPoint(0);
		setOutPoint(dur);
	};
	// Toggle Play / Pause
	const handleTogglePlay = () => {
		const v = videoRef.current;
		if (!v) return;
		if (isPlaying) {
			v.pause();
			if (audioRef.current) audioRef.current.pause();
			setIsPlaying(false);
		} else {
			// Loop if at end
			if (currentTime >= outPoint) {
				v.currentTime = inPoint;
				setCurrentTime(inPoint);
			}
			v.playbackRate = playbackSpeed;
			v.volume = isMasterMuted ? 0 : Math.min(1, masterVolume / 100);
			v.play();
			if (audioRef.current && musicSrc) {
				audioRef.current.currentTime = v.currentTime;
				audioRef.current.volume = isMusicMuted ? 0 : Math.min(1, musicVolume / 100);
				audioRef.current.play();
			}
			setIsPlaying(true);
		}
	};
	// Playhead scrub
	const handleSeek = (newTime) => {
		const clamped = Math.max(0, Math.min(duration, newTime));
		setCurrentTime(clamped);
		if (videoRef.current) {
			videoRef.current.currentTime = clamped;
		}
		if (audioRef.current) {
			audioRef.current.currentTime = clamped;
		}
	};
	// Trim Points
	const handleSetInPoint = () => {
		setInPoint(currentTime);
		setStatusAlert(`✂️ In-Point (Cut Start) set to ${formatTime(currentTime)}`);
		setTimeout(() => setStatusAlert(null), 2500);
	};
	const handleSetOutPoint = () => {
		setOutPoint(currentTime);
		setStatusAlert(`✂️ Out-Point (Cut End) set to ${formatTime(currentTime)}`);
		setTimeout(() => setStatusAlert(null), 2500);
	};
	const handleResetTrim = () => {
		setInPoint(0);
		setOutPoint(duration);
		setStatusAlert("🔄 Trim range reset to full video");
		setTimeout(() => setStatusAlert(null), 2e3);
	};
	// Speed changer
	const handleSpeedChange = (speed) => {
		setPlaybackSpeed(speed);
		if (videoRef.current) {
			videoRef.current.playbackRate = speed;
		}
		setStatusAlert(`⚡ Playback speed set to ${speed}x`);
		setTimeout(() => setStatusAlert(null), 2e3);
	};
	// Snapshot current frame as 1080p JPG
	const handleCaptureSnapshot = () => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		try {
			const dataUrl = canvas.toDataURL("image/jpeg", .95);
			const a = document.createElement("a");
			a.href = dataUrl;
			const fileName = `Video_Snapshot_${Date.now()}.jpg`;
			a.download = fileName;
			a.click();
			if (onAddDownload) {
				onAddDownload({
					id: `vid-snap-${Date.now()}`,
					title: fileName,
					type: "Converted JPG",
					size: `${canvas.width}×${canvas.height} px`,
					timestamp: new Date().toLocaleTimeString("en-IN")
				});
			}
			setStatusAlert("📸 High-Resolution Frame Snapshot downloaded & saved to Vault!");
			setTimeout(() => setStatusAlert(null), 3e3);
		} catch (e) {
			console.error(e);
		}
	};
	// -------------------------------------------------------------
	// MULTI-LAYER VIDEO COMPOSITING LOOP (HTML5 Canvas 60 FPS)
	// -------------------------------------------------------------
	const renderCompositeFrame = useCallback(() => {
		const canvas = canvasRef.current;
		const video = videoRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		const { width: targetW, height: targetH } = getCanvasDimensions();
		canvas.width = targetW;
		canvas.height = targetH;
		// 1. LAYER 0: Canvas Background Fill
		ctx.fillStyle = "#020617";
		ctx.fillRect(0, 0, targetW, targetH);
		// 2. LAYER 1: Main Video Track
		if (video && video.readyState >= 2) {
			ctx.save();
			// Transform, Rotation & Flip
			ctx.translate(targetW / 2, targetH / 2);
			ctx.rotate(rotation * Math.PI / 180);
			ctx.scale(flipH ? -1 : 1, flipV ? -1 : 1);
			ctx.scale(zoomLevel, zoomLevel);
			// Calculate video aspect fit
			const vAspect = video.videoWidth / video.videoHeight;
			const cAspect = targetW / targetH;
			let drawW = targetW;
			let drawH = targetH;
			if (vAspect > cAspect) {
				drawH = targetW / vAspect;
			} else {
				drawW = targetH * vAspect;
			}
			// Color Grading Filters
			let filterStr = `brightness(${100 + brightness}%) contrast(${100 + contrast}%) saturate(${100 + saturation}%)`;
			if (filterPreset === "cinematic") {
				filterStr += " contrast(115%) saturate(125%)";
			} else if (filterPreset === "bw") {
				filterStr += " grayscale(100%) contrast(120%)";
			} else if (filterPreset === "vintage") {
				filterStr += " sepia(50%) contrast(110%)";
			} else if (filterPreset === "neon") {
				filterStr += " saturate(160%) hue-rotate(15deg)";
			}
			ctx.filter = filterStr;
			ctx.drawImage(video, -drawW / 2, -drawH / 2, drawW, drawH);
			// Warmth color overlay
			if (warmth !== 0) {
				ctx.globalCompositeOperation = "color";
				ctx.fillStyle = warmth > 0 ? `rgba(255, 160, 60, ${Math.min(.35, warmth / 100 * .4)})` : `rgba(60, 160, 255, ${Math.min(.35, Math.abs(warmth) / 100 * .4)})`;
				ctx.fillRect(-drawW / 2, -drawH / 2, drawW, drawH);
			}
			ctx.restore();
		} else {
			// Placeholder screen
			ctx.fillStyle = "#64748b";
			ctx.font = "bold 24px sans-serif";
			ctx.textAlign = "center";
			ctx.fillText("Upload Video or Click \"Load Sample Video\"", targetW / 2, targetH / 2 - 15);
			ctx.font = "16px sans-serif";
			ctx.fillStyle = "#94a3b8";
			ctx.fillText("Multi-Layer Timeline Ready (Main Video • Overlay • Audio • Titles • Watermark)", targetW / 2, targetH / 2 + 25);
		}
		// 3. LAYER 2: Overlay B-Roll Picture-in-Picture Track
		if (overlayImgRef.current && overlayImageSrc) {
			ctx.save();
			ctx.globalAlpha = overlayOpacity;
			const img = overlayImgRef.current;
			const imgAspect = img.width / img.height;
			const pipW = targetW * overlayScale;
			const pipH = pipW / imgAspect;
			let px = 20;
			let py = 20;
			if (overlayPosition === "top-right") {
				px = targetW - pipW - 24;
				py = 24;
			} else if (overlayPosition === "top-left") {
				px = 24;
				py = 24;
			} else if (overlayPosition === "bottom-right") {
				px = targetW - pipW - 24;
				py = targetH - pipH - 24;
			} else if (overlayPosition === "bottom-left") {
				px = 24;
				py = targetH - pipH - 24;
			} else {
				px = (targetW - pipW) / 2;
				py = (targetH - pipH) / 2;
			}
			// Border & Shadow
			ctx.fillStyle = "rgba(15, 23, 42, 0.6)";
			ctx.fillRect(px - 4, py - 4, pipW + 8, pipH + 8);
			ctx.strokeStyle = "#38bdf8";
			ctx.lineWidth = 2;
			ctx.strokeRect(px - 4, py - 4, pipW + 8, pipH + 8);
			ctx.drawImage(img, px, py, pipW, pipH);
			ctx.restore();
		}
		// 4. LAYER 4: Animated Lower-Thirds & Text Captions Track
		textOverlays.forEach((txt) => {
			if (currentTime >= txt.startTime && currentTime <= txt.endTime && txt.text.trim()) {
				ctx.save();
				ctx.font = `bold ${txt.fontSize}px sans-serif`;
				ctx.textAlign = "center";
				const textMetrics = ctx.measureText(txt.text);
				const textW = textMetrics.width;
				const boxPaddingX = 24;
				const boxPaddingY = 12;
				const boxH = txt.fontSize + boxPaddingY * 2;
				let ty = targetH - 80;
				if (txt.position === "top") ty = 80;
				else if (txt.position === "center") ty = targetH / 2;
				// Background Banner
				ctx.fillStyle = txt.bgColor;
				ctx.beginPath();
				ctx.roundRect((targetW - textW - boxPaddingX * 2) / 2, ty - boxH / 2, textW + boxPaddingX * 2, boxH, 12);
				ctx.fill();
				if (txt.style === "lower_third") {
					ctx.strokeStyle = "#38bdf8";
					ctx.lineWidth = 2.5;
					ctx.stroke();
				} else if (txt.style === "neon") {
					ctx.shadowColor = "#06b6d4";
					ctx.shadowBlur = 15;
				}
				// Text
				ctx.fillStyle = txt.color;
				ctx.textBaseline = "middle";
				ctx.fillText(txt.text, targetW / 2, ty);
				ctx.restore();
			}
		});
		// 5. LAYER 5: Cyber Cafe Digital Watermark Track
		if (showWatermark && watermarkText.trim()) {
			ctx.save();
			ctx.globalAlpha = watermarkOpacity;
			ctx.font = "bold 15px sans-serif";
			const wMetrics = ctx.measureText(watermarkText);
			const wWidth = wMetrics.width + 24;
			const wHeight = 30;
			let wx = targetW - wWidth - 16;
			let wy = 16;
			if (watermarkPos === "top-left") {
				wx = 16;
				wy = 16;
			} else if (watermarkPos === "bottom-right") {
				wx = targetW - wWidth - 16;
				wy = targetH - wHeight - 16;
			} else if (watermarkPos === "bottom-left") {
				wx = 16;
				wy = targetH - wHeight - 16;
			}
			ctx.fillStyle = "rgba(15, 23, 42, 0.75)";
			ctx.beginPath();
			ctx.roundRect(wx, wy, wWidth, wHeight, 8);
			ctx.fill();
			ctx.strokeStyle = "rgba(56, 189, 248, 0.4)";
			ctx.lineWidth = 1;
			ctx.stroke();
			ctx.fillStyle = "#ffffff";
			ctx.textAlign = "center";
			ctx.textBaseline = "middle";
			ctx.fillText(watermarkText, wx + wWidth / 2, wy + wHeight / 2);
			ctx.restore();
		}
	}, [
		getCanvasDimensions,
		rotation,
		flipH,
		flipV,
		zoomLevel,
		brightness,
		contrast,
		saturation,
		warmth,
		filterPreset,
		overlayImageSrc,
		overlayScale,
		overlayPosition,
		overlayOpacity,
		textOverlays,
		currentTime,
		showWatermark,
		watermarkText,
		watermarkPos,
		watermarkOpacity
	]);
	// Video Time Update Listener Loop
	useEffect(() => {
		const video = videoRef.current;
		if (!video) return;
		let animId;
		const updateLoop = () => {
			if (video && !video.paused && !video.ended) {
				setCurrentTime(video.currentTime);
				// Check Out-Point Trim boundary
				if (video.currentTime >= outPoint) {
					if (isLooping) {
						video.currentTime = inPoint;
						if (audioRef.current) audioRef.current.currentTime = inPoint;
					} else {
						video.pause();
						if (audioRef.current) audioRef.current.pause();
						setIsPlaying(false);
					}
				}
			}
			renderCompositeFrame();
			animId = requestAnimationFrame(updateLoop);
		};
		animId = requestAnimationFrame(updateLoop);
		return () => cancelAnimationFrame(animId);
	}, [
		inPoint,
		outPoint,
		isLooping,
		renderCompositeFrame
	]);
	// Keyboard Spacebar to Play/Pause
	useEffect(() => {
		const handleKeyDown = (e) => {
			if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") {
				return;
			}
			if (e.code === "Space") {
				e.preventDefault();
				handleTogglePlay();
			}
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	});
	// -------------------------------------------------------------
	// REAL VIDEO EXPORT ENGINE (WebM/MP4 Canvas Recorder)
	// -------------------------------------------------------------
	const handleExportVideo = () => {
		const canvas = canvasRef.current;
		const video = videoRef.current;
		if (!canvas) return;
		setIsExporting(true);
		setExportProgress(5);
		try {
			const stream = canvas.captureStream(30);
			const mime = MediaRecorder.isTypeSupported("video/mp4;codecs=avc1") ? "video/mp4;codecs=avc1" : "video/webm;codecs=vp9";
			const recorder = new MediaRecorder(stream, { mimeType: mime });
			recordedBlobsRef.current = [];
			recorder.ondataavailable = (e) => {
				if (e.data.size > 0) recordedBlobsRef.current.push(e.data);
			};
			recorder.onstop = () => {
				const blob = new Blob(recordedBlobsRef.current, { type: mime });
				const ext = mime.includes("mp4") ? "mp4" : "webm";
				const exportName = `Muzammil_Studio_${videoFileName.replace(/\.[^/.]+$/, "")}_Edited.${ext}`;
				const url = URL.createObjectURL(blob);
				const a = document.createElement("a");
				a.href = url;
				a.download = exportName;
				a.click();
				if (onAddDownload) {
					onAddDownload({
						id: `vid-export-${Date.now()}`,
						title: exportName,
						type: "PVC Card PDF",
						size: `${(blob.size / (1024 * 1024)).toFixed(2)} MB (${aspectRatio})`,
						timestamp: new Date().toLocaleTimeString("en-IN")
					});
				}
				setIsExporting(false);
				setExportProgress(100);
				setStatusAlert(`🎉 Video Export Complete! "${exportName}" downloaded.`);
				setTimeout(() => setStatusAlert(null), 4e3);
			};
			recorderRef.current = recorder;
			recorder.start();
			// Reset video to in-point and play to record
			if (video) {
				video.currentTime = inPoint;
				video.playbackRate = 1;
				video.play();
				setIsPlaying(true);
			}
			const totalRecordTime = (outPoint - inPoint) * 1e3;
			const startTime = Date.now();
			const progInterval = setInterval(() => {
				const elapsed = Date.now() - startTime;
				const pct = Math.min(98, Math.round(elapsed / totalRecordTime * 100));
				setExportProgress(pct);
				if (elapsed >= totalRecordTime) {
					clearInterval(progInterval);
					recorder.stop();
					if (video) video.pause();
					setIsPlaying(false);
				}
			}, 200);
		} catch (e) {
			console.error(e);
			setIsExporting(false);
			setStatusAlert("❌ Export error. Try using a standard WebM/MP4 format.");
			setTimeout(() => setStatusAlert(null), 4e3);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4 select-none",
		children: [
			musicSrc && /* @__PURE__ */ _jsxDEV("audio", {
				ref: audioRef,
				src: musicSrc,
				loop: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 784,
				columnNumber: 20
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 flex-wrap",
					children: [
						/* @__PURE__ */ _jsxDEV("h1", {
							className: "text-xl font-extrabold text-white flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Film, { className: "w-5 h-5 text-rose-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 791,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Multi-Layer Video Studio Pro" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 792,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 790,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "bg-rose-500/20 text-rose-400 border border-rose-500/30 text-xs px-2.5 py-0.5 rounded-full font-mono font-bold",
							children: "5 Timeline Tracks"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 794,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "bg-blue-500/20 text-blue-400 border border-blue-500/30 text-xs px-2.5 py-0.5 rounded-full font-bold",
							children: "Full HD 1080p Export"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 797,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "bg-purple-500/20 text-purple-300 border border-purple-500/30 text-xs px-2.5 py-0.5 rounded-full font-bold",
							children: "Reels / YouTube / CSC Branding"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 800,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 789,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400 mt-1",
					children: "Cut, trim, speed control, color grading, lower-thirds, audio mixing, picture-in-picture, and watermark export in 1 click."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 804,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 788,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 flex-wrap",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleLoadSampleVideo,
							className: "flex items-center gap-1.5 px-3 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl shadow-md transition-all hover:scale-105",
							title: "Generate a dynamic CSC Cyber Cafe motion video clip for instant testing",
							children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3.5 h-3.5 text-amber-300" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 817,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Load Sample Clip" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 818,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 811,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("label", {
							className: "flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 hover:text-white font-bold text-xs rounded-xl border border-slate-700 cursor-pointer transition-colors shadow",
							children: [
								/* @__PURE__ */ _jsxDEV(Upload, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 822,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "Upload Video" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 823,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "file",
									accept: "video/*",
									onChange: handleUploadVideo,
									className: "hidden"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 824,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 821,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleCaptureSnapshot,
							className: "flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl border border-slate-700",
							title: "Capture current video frame as high-res JPG",
							children: [/* @__PURE__ */ _jsxDEV(Camera, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 833,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Snapshot JPG" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 834,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 827,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleExportVideo,
							disabled: isExporting,
							className: "flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-rose-600 via-pink-600 to-rose-500 hover:from-rose-500 hover:to-pink-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-rose-600/30 transition-all hover:scale-105 disabled:opacity-50",
							title: "Render and Download Final Video with all 5 layers",
							children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4 text-white" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 844,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: isExporting ? `Exporting (${exportProgress}%)` : "Export Video" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 845,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 837,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 810,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 787,
				columnNumber: 7
			}, this),
			statusAlert && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between animate-in fade-in",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-400 flex-shrink-0" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 854,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: statusAlert }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 855,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 853,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setStatusAlert(null),
					className: "text-emerald-400 hover:text-white",
					children: "✕"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 857,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 852,
				columnNumber: 9
			}, this),
			isExporting && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-rose-500/40 p-3 rounded-xl space-y-2",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex justify-between text-xs text-rose-300 font-bold",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: "Rendering Multi-Layer Video at 30 FPS..." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 865,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: [exportProgress, "%"] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 866,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 864,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "w-full bg-slate-950 h-2 rounded-full overflow-hidden",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-gradient-to-r from-rose-500 to-indigo-500 h-full transition-all duration-200",
						style: { width: `${exportProgress}%` }
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 869,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 868,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 863,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-4 items-start",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-7 bg-slate-950 border border-slate-800 rounded-3xl p-3 sm:p-4 shadow-2xl space-y-3 flex flex-col justify-between min-h-[500px]",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between text-xs text-slate-400 pb-2 border-b border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 font-mono",
								children: [
									/* @__PURE__ */ _jsxDEV("span", { className: "w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 884,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-white font-bold",
										children: videoFileName
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 885,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-600",
										children: "•"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 886,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-sky-400 font-bold",
										children: aspectRatio
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 887,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 883,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1.5 font-mono text-[11px]",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-emerald-400 font-bold",
										children: formatTime(currentTime)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 891,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-600",
										children: "/"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 892,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: formatTime(duration) }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 893,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 890,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 882,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "relative flex-1 flex items-center justify-center p-2 overflow-hidden bg-slate-900/60 rounded-2xl border border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("canvas", {
								ref: canvasRef,
								className: "max-w-full max-h-[440px] w-auto h-auto rounded-lg shadow-2xl cursor-pointer",
								onClick: handleTogglePlay
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 899,
								columnNumber: 13
							}, this), videoSrc && /* @__PURE__ */ _jsxDEV("video", {
								ref: videoRef,
								src: videoSrc,
								onLoadedMetadata: handleVideoLoadedMetadata,
								onEnded: () => {
									if (isLooping) {
										if (videoRef.current) videoRef.current.currentTime = inPoint;
										if (audioRef.current) audioRef.current.currentTime = inPoint;
									} else {
										setIsPlaying(false);
									}
								},
								className: "hidden",
								playsInline: true
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 907,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 898,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-900/90 border border-slate-800 rounded-2xl p-3 space-y-2.5 shadow-inner",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "relative flex items-center",
									children: /* @__PURE__ */ _jsxDEV("input", {
										type: "range",
										min: "0",
										max: duration || 10,
										step: "0.05",
										value: currentTime,
										onChange: (e) => handleSeek(Number(e.target.value)),
										className: "w-full accent-rose-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 930,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 929,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex justify-between text-[10px] font-mono text-slate-500",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-sky-400",
											children: ["In: ", formatTime(inPoint)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 943,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-white font-bold",
											children: formatTime(currentTime)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 944,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-purple-400",
											children: ["Out: ", formatTime(outPoint)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 945,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 942,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 928,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between gap-2 flex-wrap",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1.5",
									children: [
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: handleTogglePlay,
											className: "w-10 h-10 rounded-xl bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 text-white flex items-center justify-center shadow-lg shadow-rose-600/30 transition-transform active:scale-95",
											title: "Play / Pause (Spacebar)",
											children: isPlaying ? /* @__PURE__ */ _jsxDEV(Pause, { className: "w-5 h-5 fill-white" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 959,
												columnNumber: 32
											}, this) : /* @__PURE__ */ _jsxDEV(Play, { className: "w-5 h-5 fill-white ml-0.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 959,
												columnNumber: 75
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 953,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => handleSeek(currentTime - 1),
											className: "p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white",
											title: "Step Back 1s",
											children: /* @__PURE__ */ _jsxDEV(Rewind, { className: "w-4 h-4" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 969,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 963,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => handleSeek(currentTime + 1),
											className: "p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white",
											title: "Step Forward 1s",
											children: /* @__PURE__ */ _jsxDEV(FastForward, { className: "w-4 h-4" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 979,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 973,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: handleSetInPoint,
											className: "px-2.5 py-1.5 rounded-lg bg-sky-500/10 hover:bg-sky-500/20 text-sky-400 border border-sky-500/30 text-xs font-bold font-mono",
											title: "Set In-Point (Cut Start)",
											children: "[ In"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 983,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: handleSetOutPoint,
											className: "px-2.5 py-1.5 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 text-purple-400 border border-purple-500/30 text-xs font-bold font-mono",
											title: "Set Out-Point (Cut End)",
											children: "Out ]"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 993,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: handleResetTrim,
											className: "p-1.5 text-slate-400 hover:text-white text-xs",
											title: "Reset Trim Range",
											children: /* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1008,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1002,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 951,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center bg-slate-950 border border-slate-800 rounded-lg p-0.5 text-[10px] font-bold",
										children: [
											.5,
											1,
											1.5,
											2
										].map((s) => /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => handleSpeedChange(s),
											className: `px-2 py-1 rounded transition-colors ${playbackSpeed === s ? "bg-rose-600 text-white" : "text-slate-400 hover:text-white"}`,
											children: [s, "x"]
										}, s, true, {
											fileName: _jsxFileName,
											lineNumber: 1017,
											columnNumber: 21
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1015,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setIsMasterMuted(!isMasterMuted),
										className: `p-2 rounded-xl border text-xs ${isMasterMuted ? "bg-rose-600/20 text-rose-400 border-rose-500/40" : "bg-slate-800 text-slate-300 border-slate-700"}`,
										title: "Mute / Unmute",
										children: isMasterMuted ? /* @__PURE__ */ _jsxDEV(VolumeX, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1041,
											columnNumber: 36
										}, this) : /* @__PURE__ */ _jsxDEV(Volume2, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1041,
											columnNumber: 70
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1031,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1013,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 950,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 926,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 880,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-5 bg-slate-900 border border-slate-800 rounded-3xl p-4 shadow-xl space-y-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-3 sm:grid-cols-6 gap-1 bg-slate-950 p-1.5 rounded-2xl border border-slate-800 text-[11px] font-bold",
							children: [
								{
									id: "timeline",
									label: "Timeline",
									icon: Layers
								},
								{
									id: "crop",
									label: "Canvas",
									icon: SplitSquareVertical
								},
								{
									id: "color",
									label: "Color",
									icon: Sliders
								},
								{
									id: "text",
									label: "Titles",
									icon: Type
								},
								{
									id: "overlay",
									label: "Overlay",
									icon: ImageIcon
								},
								{
									id: "audio",
									label: "Audio",
									icon: Music
								}
							].map((tab) => {
								const Icon = tab.icon;
								const isActive = activeToolTab === tab.id;
								return /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setActiveToolTab(tab.id),
									className: `py-2 px-1 rounded-xl flex flex-col items-center justify-center gap-1 transition-all ${isActive ? "bg-rose-600 text-white shadow-md shadow-rose-600/30" : "text-slate-400 hover:text-white hover:bg-slate-900"}`,
									children: [/* @__PURE__ */ _jsxDEV(Icon, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1073,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "truncate",
										children: tab.label
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1074,
										columnNumber: 19
									}, this)]
								}, tab.id, true, {
									fileName: _jsxFileName,
									lineNumber: 1063,
									columnNumber: 17
								}, this);
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1051,
							columnNumber: 11
						}, this),
						activeToolTab === "timeline" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3 animate-in fade-in text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between pb-1 border-b border-slate-800",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-extrabold text-white uppercase tracking-wider flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(Layers, { className: "w-4 h-4 text-rose-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1085,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "5-Layer Timeline Tracks" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1086,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1084,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400 font-mono",
										children: "Synchronized"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1088,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1083,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-1.5",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2.5 h-2.5 rounded-full bg-blue-500" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1095,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("strong", {
												className: "text-white",
												children: "Track 1: Main Video"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1096,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1094,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] font-mono text-sky-400",
											children: formatTime(duration)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1098,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1093,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-[11px] text-slate-400 flex items-center justify-between",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: ["Clip: ", videoFileName] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1101,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-emerald-400 font-bold",
											children: "Active"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1102,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1100,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1092,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-1.5",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2.5 h-2.5 rounded-full bg-purple-500" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1110,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("strong", {
												className: "text-white",
												children: "Track 2: Picture-in-Picture Overlay"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1111,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1109,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("label", {
											className: "text-[10px] text-purple-400 hover:underline cursor-pointer font-bold",
											children: ["+ Add Image", /* @__PURE__ */ _jsxDEV("input", {
												type: "file",
												accept: "image/*",
												onChange: handleUploadOverlayImage,
												className: "hidden"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1115,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1113,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1108,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-[11px] text-slate-400 flex items-center justify-between",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: overlayImageSrc ? "Image Overlay Active" : "No Overlay Attached" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1119,
											columnNumber: 19
										}, this), overlayImageSrc && /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setOverlayImageSrc(null),
											className: "text-rose-400 hover:underline",
											children: "Remove"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1121,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1118,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1107,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-1.5",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2.5 h-2.5 rounded-full bg-amber-500" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1132,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("strong", {
												className: "text-white",
												children: "Track 3: Background Audio"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1133,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1131,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("label", {
											className: "text-[10px] text-amber-400 hover:underline cursor-pointer font-bold",
											children: ["+ Add Audio", /* @__PURE__ */ _jsxDEV("input", {
												type: "file",
												accept: "audio/*",
												onChange: handleUploadMusic,
												className: "hidden"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1137,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1135,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1130,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-[11px] text-slate-400 flex items-center justify-between",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: musicSrc ? "Background Music Active" : "Default / Muted" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1141,
											columnNumber: 19
										}, this), musicSrc && /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setMusicSrc(null),
											className: "text-rose-400 hover:underline",
											children: "Remove"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1143,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1140,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1129,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-1.5",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2.5 h-2.5 rounded-full bg-emerald-500" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1154,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("strong", {
												className: "text-white",
												children: "Track 4: Animated Titles & Subtitles"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1155,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1153,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-emerald-400 font-mono font-bold",
											children: [textOverlays.length, " Text Blocks"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1157,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1152,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-[11px] text-slate-400 truncate",
										children: [
											"\"",
											textOverlays[0]?.text || "No Text",
											"\""
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1161,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1151,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-1.5",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2.5 h-2.5 rounded-full bg-rose-500" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1170,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("strong", {
												className: "text-white",
												children: "Track 5: Digital CSC Shop Watermark"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1171,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1169,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "checkbox",
											checked: showWatermark,
											onChange: (e) => setShowWatermark(e.target.checked),
											className: "accent-rose-500 rounded"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1173,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1168,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-[11px] text-slate-400 truncate",
										children: showWatermark ? watermarkText : "Disabled"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1180,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1167,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1082,
							columnNumber: 13
						}, this),
						activeToolTab === "crop" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4 animate-in fade-in text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pb-1 border-b border-slate-800 font-extrabold text-white uppercase tracking-wider",
									children: "Aspect Ratio & Framing Presets"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1190,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 sm:grid-cols-4 gap-2",
									children: [
										{
											id: "16:9",
											label: "16:9",
											desc: "YouTube / PC"
										},
										{
											id: "9:16",
											label: "9:16",
											desc: "Reels / Shorts"
										},
										{
											id: "1:1",
											label: "1:1",
											desc: "Instagram Post"
										},
										{
											id: "4:5",
											label: "4:5",
											desc: "Portrait Feed"
										}
									].map((r) => /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setAspectRatio(r.id),
										className: `p-2.5 rounded-xl border text-center transition-all ${aspectRatio === r.id ? "bg-rose-600/20 border-rose-500 text-white font-extrabold ring-1 ring-rose-500/40" : "bg-slate-950 border-slate-800 text-slate-400 hover:text-white"}`,
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "font-mono text-sm",
											children: r.label
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1212,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-400",
											children: r.desc
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1213,
											columnNumber: 21
										}, this)]
									}, r.id, true, {
										fileName: _jsxFileName,
										lineNumber: 1202,
										columnNumber: 19
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1195,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2 pt-2",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400 font-bold block",
										children: "Orientation & Mirroring:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1220,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-3 gap-2",
										children: [
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => setRotation((prev) => (prev + 90) % 360),
												className: "p-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 hover:text-white flex items-center justify-center gap-1.5 font-bold",
												children: [/* @__PURE__ */ _jsxDEV(RotateCw, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1227,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Rotate 90°" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1228,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1222,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => setFlipH(!flipH),
												className: `p-2 rounded-xl border flex items-center justify-center gap-1.5 font-bold ${flipH ? "bg-sky-600 text-white border-sky-400" : "bg-slate-950 border-slate-800 text-slate-400"}`,
												children: [/* @__PURE__ */ _jsxDEV(FlipHorizontal, { className: "w-3.5 h-3.5" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1238,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Flip H" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1239,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1231,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => setFlipV(!flipV),
												className: `p-2 rounded-xl border flex items-center justify-center gap-1.5 font-bold ${flipV ? "bg-sky-600 text-white border-sky-400" : "bg-slate-950 border-slate-800 text-slate-400"}`,
												children: [/* @__PURE__ */ _jsxDEV(FlipVertical, { className: "w-3.5 h-3.5" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1249,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Flip V" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1250,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1242,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1221,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1219,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1 pt-1",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between text-slate-400 font-semibold",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Frame Scale / Zoom" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1258,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono text-white",
											children: [Math.round(zoomLevel * 100), "%"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1259,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1257,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "range",
										min: "0.5",
										max: "2.0",
										step: "0.05",
										value: zoomLevel,
										onChange: (e) => setZoomLevel(Number(e.target.value)),
										className: "w-full accent-rose-500 h-1.5 bg-slate-800 rounded cursor-pointer"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1261,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1256,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1189,
							columnNumber: 13
						}, this),
						activeToolTab === "color" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3 animate-in fade-in text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between pb-1 border-b border-slate-800 font-extrabold text-white uppercase tracking-wider",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Color Grading & Cinematic Filters" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1278,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => {
											setBrightness(0);
											setContrast(0);
											setSaturation(0);
											setWarmth(0);
											setFilterPreset("normal");
										},
										className: "text-[10px] text-slate-400 hover:text-white",
										children: "Reset"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1279,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1277,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-3 gap-1.5",
									children: [
										{
											id: "normal",
											label: "Original"
										},
										{
											id: "cinematic",
											label: "🎬 35mm Film"
										},
										{
											id: "vintage",
											label: "🎞️ Vintage Sepia"
										},
										{
											id: "neon",
											label: "🔮 Cyber Neon"
										},
										{
											id: "bw",
											label: "🖤 Noir B&W"
										}
									].map((p) => /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setFilterPreset(p.id),
										className: `py-1.5 px-2 rounded-lg border font-bold text-center transition-all ${filterPreset === p.id ? "bg-rose-600 text-white border-rose-400 shadow" : "bg-slate-950 border-slate-800 text-slate-400 hover:text-white"}`,
										children: p.label
									}, p.id, false, {
										fileName: _jsxFileName,
										lineNumber: 1302,
										columnNumber: 19
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1294,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between text-slate-300 font-semibold",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "flex items-center gap-1 text-amber-300",
											children: [/* @__PURE__ */ _jsxDEV(Sun, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1320,
												columnNumber: 76
											}, this), " Brightness"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1320,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono text-white",
											children: [brightness > 0 ? `+${brightness}` : brightness, "%"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1321,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1319,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "range",
										min: "-40",
										max: "40",
										value: brightness,
										onChange: (e) => setBrightness(Number(e.target.value)),
										className: "w-full accent-amber-500 h-1.5 bg-slate-800 rounded cursor-pointer"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1323,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1318,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between text-slate-300 font-semibold",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "flex items-center gap-1 text-sky-300",
											children: [/* @__PURE__ */ _jsxDEV(Contrast, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1336,
												columnNumber: 74
											}, this), " Contrast"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1336,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono text-white",
											children: [contrast > 0 ? `+${contrast}` : contrast, "%"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1337,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1335,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "range",
										min: "-40",
										max: "40",
										value: contrast,
										onChange: (e) => setContrast(Number(e.target.value)),
										className: "w-full accent-sky-500 h-1.5 bg-slate-800 rounded cursor-pointer"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1339,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1334,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between text-slate-300 font-semibold",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "flex items-center gap-1 text-pink-300",
											children: [/* @__PURE__ */ _jsxDEV(Droplets, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1352,
												columnNumber: 75
											}, this), " Saturation"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1352,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono text-white",
											children: [saturation > 0 ? `+${saturation}` : saturation, "%"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1353,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1351,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "range",
										min: "-50",
										max: "50",
										value: saturation,
										onChange: (e) => setSaturation(Number(e.target.value)),
										className: "w-full accent-pink-500 h-1.5 bg-slate-800 rounded cursor-pointer"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1355,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1350,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between text-slate-300 font-semibold",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "flex items-center gap-1 text-orange-300",
											children: [/* @__PURE__ */ _jsxDEV(Flame, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1368,
												columnNumber: 77
											}, this), " Warmth / Color Cast"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1368,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono text-white",
											children: warmth > 0 ? `+${warmth}` : warmth
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1369,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1367,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "range",
										min: "-40",
										max: "40",
										value: warmth,
										onChange: (e) => setWarmth(Number(e.target.value)),
										className: "w-full accent-orange-500 h-1.5 bg-slate-800 rounded cursor-pointer"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1371,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1366,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1276,
							columnNumber: 13
						}, this),
						activeToolTab === "text" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3 animate-in fade-in text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between pb-1 border-b border-slate-800 font-extrabold text-white uppercase tracking-wider",
									children: /* @__PURE__ */ _jsxDEV("span", { children: "Animated Titles & Lower-Thirds" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1387,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1386,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "text-slate-400 font-semibold",
										children: "Overlay Text Content:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1392,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: textOverlays[0]?.text || "",
										onChange: (e) => {
											const val = e.target.value;
											setTextOverlays((prev) => [{
												...prev[0],
												text: val
											}]);
										},
										placeholder: "Enter shop name, offer, or title...",
										className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1393,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1391,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "text-slate-400 font-semibold",
										children: "Screen Position:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1412,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-3 gap-2",
										children: [
											"top",
											"center",
											"bottom"
										].map((pos) => /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => {
												setTextOverlays((prev) => [{
													...prev[0],
													position: pos
												}]);
											},
											className: `py-1.5 rounded-lg border font-bold capitalize ${textOverlays[0]?.position === pos ? "bg-rose-600 text-white border-rose-400 shadow" : "bg-slate-950 border-slate-800 text-slate-400 hover:text-white"}`,
											children: pos
										}, pos, false, {
											fileName: _jsxFileName,
											lineNumber: 1415,
											columnNumber: 21
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1413,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1411,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "text-slate-400 font-semibold",
										children: "Graphic Style:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1437,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 gap-2",
										children: [
											{
												id: "lower_third",
												label: "Broadcast Lower-Third"
											},
											{
												id: "neon",
												label: "Cyber Glow"
											},
											{
												id: "banner",
												label: "Dark Solid Banner"
											},
											{
												id: "clean",
												label: "Minimalist Clean"
											}
										].map((st) => /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => {
												setTextOverlays((prev) => [{
													...prev[0],
													style: st.id
												}]);
											},
											className: `p-2 rounded-lg border text-left font-bold ${textOverlays[0]?.style === st.id ? "bg-purple-600/20 text-purple-300 border-purple-500" : "bg-slate-950 border-slate-800 text-slate-400"}`,
											children: st.label
										}, st.id, false, {
											fileName: _jsxFileName,
											lineNumber: 1445,
											columnNumber: 21
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1438,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1436,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between text-slate-400",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: "Font Size" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1468,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono text-white",
											children: [textOverlays[0]?.fontSize || 28, "px"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1469,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1467,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "range",
										min: "16",
										max: "60",
										value: textOverlays[0]?.fontSize || 28,
										onChange: (e) => {
											const sz = Number(e.target.value);
											setTextOverlays((prev) => [{
												...prev[0],
												fontSize: sz
											}]);
										},
										className: "w-full accent-rose-500 h-1.5 bg-slate-800 rounded cursor-pointer"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1471,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1466,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1385,
							columnNumber: 13
						}, this),
						activeToolTab === "overlay" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4 animate-in fade-in text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pb-1 border-b border-slate-800 font-extrabold text-white uppercase tracking-wider",
									children: "Picture-in-Picture & Watermark"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1489,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-2",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ _jsxDEV("strong", {
												className: "text-white",
												children: "Shop Brand Stamp / Watermark:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1496,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "checkbox",
												checked: showWatermark,
												onChange: (e) => setShowWatermark(e.target.checked),
												className: "accent-rose-500 rounded"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1497,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1495,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: watermarkText,
											onChange: (e) => setWatermarkText(e.target.value),
											placeholder: "e.g. Muzammil Online Service - 9561460313",
											className: "w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-bold"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1504,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "grid grid-cols-4 gap-1.5 pt-1 text-[10px]",
											children: [
												"top-left",
												"top-right",
												"bottom-left",
												"bottom-right"
											].map((pos) => /* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => setWatermarkPos(pos),
												className: `py-1 rounded border capitalize ${watermarkPos === pos ? "bg-rose-600 text-white border-rose-400" : "bg-slate-900 border-slate-800 text-slate-400"}`,
												children: pos.replace("-", " ")
											}, pos, false, {
												fileName: _jsxFileName,
												lineNumber: 1514,
												columnNumber: 21
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1512,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1494,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ _jsxDEV("strong", {
											className: "text-white",
											children: "Picture-in-Picture (Track 2):"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1533,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("label", {
											className: "text-[10px] text-purple-400 font-bold hover:underline cursor-pointer",
											children: ["Upload", /* @__PURE__ */ _jsxDEV("input", {
												type: "file",
												accept: "image/*",
												onChange: handleUploadOverlayImage,
												className: "hidden"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1536,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1534,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1532,
										columnNumber: 17
									}, this), overlayImageSrc ? /* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-2 pt-1",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between text-slate-400",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Overlay Scale" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1543,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "font-mono text-white",
													children: [Math.round(overlayScale * 100), "%"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1544,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1542,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												type: "range",
												min: "0.1",
												max: "0.6",
												step: "0.05",
												value: overlayScale,
												onChange: (e) => setOverlayScale(Number(e.target.value)),
												className: "w-full accent-purple-500 h-1.5 bg-slate-800 rounded cursor-pointer"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1546,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between text-slate-400",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Opacity" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1557,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "font-mono text-white",
													children: [Math.round(overlayOpacity * 100), "%"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1558,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1556,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												type: "range",
												min: "0.2",
												max: "1.0",
												step: "0.05",
												value: overlayOpacity,
												onChange: (e) => setOverlayOpacity(Number(e.target.value)),
												className: "w-full accent-purple-500 h-1.5 bg-slate-800 rounded cursor-pointer"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1560,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1541,
										columnNumber: 19
									}, this) : /* @__PURE__ */ _jsxDEV("p", {
										className: "text-[11px] text-slate-500",
										children: "No image overlay attached. Click Upload to insert a logo or photo inside the video."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1571,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1531,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1488,
							columnNumber: 13
						}, this),
						activeToolTab === "audio" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4 animate-in fade-in text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pb-1 border-b border-slate-800 font-extrabold text-white uppercase tracking-wider",
									children: "Audio Mixing & Soundtracks"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1582,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between text-slate-300 font-semibold",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ _jsxDEV(Volume2, { className: "w-4 h-4 text-blue-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1589,
												columnNumber: 63
											}, this), " Main Video Audio"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1589,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono text-white",
											children: [masterVolume, "%"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1590,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1588,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "range",
										min: "0",
										max: "200",
										value: masterVolume,
										onChange: (e) => {
											const vol = Number(e.target.value);
											setMasterVolume(vol);
											if (videoRef.current) videoRef.current.volume = Math.min(1, vol / 100);
										},
										className: "w-full accent-blue-500 h-1.5 bg-slate-800 rounded cursor-pointer"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1592,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1587,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "bg-slate-950 p-3 rounded-2xl border border-slate-800 space-y-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between text-slate-300 font-semibold",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ _jsxDEV(Music, { className: "w-4 h-4 text-amber-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1609,
												columnNumber: 63
											}, this), " Track 3: BGM Volume"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1609,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono text-white",
											children: [musicVolume, "%"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1610,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1608,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "range",
										min: "0",
										max: "100",
										value: musicVolume,
										onChange: (e) => {
											const vol = Number(e.target.value);
											setMusicVolume(vol);
											if (audioRef.current) audioRef.current.volume = vol / 100;
										},
										className: "w-full accent-amber-500 h-1.5 bg-slate-800 rounded cursor-pointer"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1612,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1607,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1581,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1049,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 878,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 782,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsUUFBUSxXQUFXLG1CQUFtQjtBQUNoRSxTQUNFLE1BRUEsTUFDQSxPQUNBLFdBRUEsU0FDQSxTQUNBLFVBQ0EsTUFDQSxTQUFTLFdBQ1QsT0FDQSxVQUNBLFFBQ0EsU0FDQSxVQUVBLFFBR0EsYUFDQSxRQUtBLE9BQ0EsS0FDQSxVQUNBLFVBQ0EsY0FDQSxRQUdBLHFCQUNBLGdCQUNBLG9CQUNLOzs7QUE4QlAsT0FBTyxNQUFNLG1CQUFtRCxFQUFFLG9CQUFvQjs7Q0FFcEYsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUF3QixJQUFJO0NBQzVELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFpQixtQkFBbUI7Q0FDOUUsTUFBTSxXQUFXLE9BQWdDLElBQUk7Q0FDckQsTUFBTSxZQUFZLE9BQWlDLElBQUk7O0NBR3ZELE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQXdCLElBQUk7Q0FDMUUsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQWlCLEVBQUc7Q0FDNUQsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBK0UsV0FBVztDQUN4SSxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFpQixFQUFHO0NBQ2hFLE1BQU0sZ0JBQWdCLE9BQWdDLElBQUk7O0NBRzFELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBd0IsSUFBSTtDQUM1RCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBaUIsRUFBRTtDQUN6RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBa0IsS0FBSztDQUMvRCxNQUFNLFdBQVcsT0FBZ0MsSUFBSTs7Q0FHckQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQWtCLEtBQUs7Q0FDekQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQWlCLENBQUM7Q0FDeEQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFpQixFQUFFO0NBQ25ELE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBaUIsQ0FBQztDQUNoRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQWlCLEVBQUU7Q0FDbkQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQWlCLENBQUc7Q0FDOUQsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQWlCLEdBQUc7Q0FDNUQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQWtCLEtBQUs7Q0FDakUsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQWtCLElBQUk7O0NBR3hELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFzQixNQUFNO0NBQ2xFLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBaUIsQ0FBQztDQUNsRCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQWtCLEtBQUs7Q0FDakQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFrQixLQUFLO0NBQ2pELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFpQixDQUFHOztDQUd0RCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBaUIsQ0FBQztDQUN0RCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQWlCLENBQUM7Q0FDbEQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQWlCLENBQUM7Q0FDdEQsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFpQixDQUFDO0NBQzlDLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFpQixRQUFROztDQUdqRSxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBd0IsQ0FDOUQ7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLFVBQVU7RUFDVixPQUFPO0VBQ1AsU0FBUztFQUNULFVBQVU7RUFDVixPQUFPO0VBQ1AsV0FBVztFQUNYLFNBQVM7Q0FDWCxDQUNGLENBQUM7Q0FDRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBaUIsT0FBTzs7Q0FHaEUsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQWtCLElBQUk7Q0FDaEUsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQWlCLDhCQUE4QjtDQUN6RixNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBb0UsV0FBVztDQUN2SCxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFpQixFQUFHOztDQUdwRSxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBdUUsVUFBVTs7Q0FHM0gsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQWlCLENBQUM7Q0FDMUQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQWtCLEtBQUs7Q0FDN0QsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBaUIsQ0FBQztDQUM5RCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBd0IsSUFBSTs7Q0FHbEUsTUFBTSxjQUFjLE9BQTZCLElBQUk7Q0FDckQsTUFBTSxtQkFBbUIsT0FBZSxDQUFDLENBQUM7O0NBRzFDLE1BQU0sc0JBQXNCLGtCQUFxRDtFQUMvRSxRQUFRLGFBQVI7R0FDRSxLQUFLLFFBQVEsT0FBTztJQUFFLE9BQU87SUFBTSxRQUFRO0dBQUk7R0FDL0MsS0FBSyxRQUFRLE9BQU87SUFBRSxPQUFPO0lBQUssUUFBUTtHQUFLO0dBQy9DLEtBQUssT0FBTyxPQUFPO0lBQUUsT0FBTztJQUFNLFFBQVE7R0FBSztHQUMvQyxLQUFLLE9BQU8sT0FBTztJQUFFLE9BQU87SUFBSyxRQUFRO0dBQUs7R0FDOUMsU0FBUyxPQUFPO0lBQUUsT0FBTztJQUFNLFFBQVE7R0FBSTtFQUM3QztDQUNGLEdBQUcsQ0FBQyxXQUFXLENBQUM7O0NBR2hCLE1BQU0sY0FBYyxZQUFvQjtFQUN0QyxNQUFNLE9BQU8sS0FBSyxNQUFNLFVBQVUsRUFBRTtFQUNwQyxNQUFNLE9BQU8sS0FBSyxNQUFNLFVBQVUsRUFBRTtFQUNwQyxNQUFNLEtBQUssS0FBSyxNQUFPLFVBQVUsSUFBSyxFQUFFO0VBQ3hDLE9BQU8sR0FBRyxPQUFPLElBQUksQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHLEVBQUUsR0FBRyxPQUFPLElBQUksQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHLEVBQUUsR0FBRztDQUM5RTs7Q0FHQSxNQUFNLDhCQUE4QjtFQUNsQyxNQUFNLGVBQWUsU0FBUyxjQUFjLFFBQVE7RUFDcEQsYUFBYSxRQUFRO0VBQ3JCLGFBQWEsU0FBUztFQUN0QixNQUFNLE9BQU8sYUFBYSxXQUFXLElBQUk7RUFDekMsSUFBSSxDQUFDLE1BQU07O0VBR1gsTUFBTSxTQUFTLGFBQWEsY0FBYyxFQUFFO0VBQzVDLE1BQU0sTUFBTSxJQUFJLGNBQWMsUUFBUSxFQUFFLFVBQVUsYUFBYSxDQUFDO0VBQ2hFLE1BQU0sU0FBaUIsQ0FBQztFQUV4QixJQUFJLG1CQUFtQixNQUFNO0dBQzNCLElBQUksRUFBRSxLQUFLLE9BQU8sR0FBRyxPQUFPLEtBQUssRUFBRSxJQUFJO0VBQ3pDO0VBRUEsSUFBSSxlQUFlO0dBQ2pCLE1BQU0sT0FBTyxJQUFJLEtBQUssUUFBUSxFQUFFLE1BQU0sYUFBYSxDQUFDO0dBQ3BELE1BQU0sTUFBTSxJQUFJLGdCQUFnQixJQUFJO0dBQ3BDLFlBQVksR0FBRztHQUNmLGlCQUFpQiw0QkFBNEI7R0FDN0MsWUFBWSxDQUFDO0dBQ2IsV0FBVyxDQUFDO0dBQ1osWUFBWSxDQUFDO0dBQ2IsZUFBZSxDQUFDO0dBQ2hCLGVBQWUseURBQXlEO0dBQ3hFLGlCQUFpQixlQUFlLElBQUksR0FBRyxJQUFJO0VBQzdDO0VBRUEsSUFBSSxNQUFNOztFQUdWLElBQUksUUFBUTtFQUNaLE1BQU0sY0FBYyxJQUFJO0VBQ3hCLE1BQU0sZUFBZSxrQkFBa0I7R0FDckM7R0FDQSxNQUFNLFdBQVcsUUFBUTtHQUN6QixNQUFNLFVBQVUsUUFBUTs7R0FHeEIsTUFBTSxPQUFPLEtBQUsscUJBQXFCLEdBQUcsR0FBRyxNQUFNLEdBQUc7R0FDdEQsS0FBSyxhQUFhLEdBQUcsU0FBUztHQUM5QixLQUFLLGFBQWEsSUFBSyxTQUFTO0dBQ2hDLEtBQUssYUFBYSxHQUFHLFNBQVM7R0FDOUIsS0FBSyxZQUFZO0dBQ2pCLEtBQUssU0FBUyxHQUFHLEdBQUcsTUFBTSxHQUFHOztHQUc3QixLQUFLLGNBQWM7R0FDbkIsS0FBSyxZQUFZO0dBQ2pCLE1BQU0sU0FBVSxRQUFRLElBQUs7R0FDN0IsS0FBSyxJQUFJLElBQUksUUFBUSxJQUFJLE1BQU0sS0FBSyxJQUFJO0lBQ3RDLEtBQUssVUFBVTtJQUNmLEtBQUssT0FBTyxHQUFHLENBQUM7SUFDaEIsS0FBSyxPQUFPLEdBQUcsR0FBRztJQUNsQixLQUFLLE9BQU87R0FDZDtHQUNBLEtBQUssSUFBSSxJQUFJLFFBQVEsSUFBSSxLQUFLLEtBQUssSUFBSTtJQUNyQyxLQUFLLFVBQVU7SUFDZixLQUFLLE9BQU8sR0FBRyxDQUFDO0lBQ2hCLEtBQUssT0FBTyxNQUFNLENBQUM7SUFDbkIsS0FBSyxPQUFPO0dBQ2Q7O0dBR0EsS0FBSyxLQUFLO0dBQ1YsS0FBSyxVQUFVLEtBQUssR0FBRztHQUN2QixLQUFLLE9BQU8sS0FBSyxJQUFJLFdBQVcsS0FBSyxLQUFLLENBQUMsSUFBSSxHQUFJO0dBRW5ELEtBQUssWUFBWTtHQUNqQixLQUFLLGNBQWM7R0FDbkIsS0FBSyxZQUFZO0dBQ2pCLEtBQUssVUFBVTtHQUNmLEtBQUssVUFBVSxDQUFDLEtBQUssQ0FBQyxLQUFLLEtBQUssS0FBSyxFQUFFO0dBQ3ZDLEtBQUssS0FBSztHQUNWLEtBQUssT0FBTzs7R0FHWixLQUFLLFlBQVk7R0FDakIsS0FBSyxPQUFPO0dBQ1osS0FBSyxZQUFZO0dBQ2pCLEtBQUssU0FBUywyQkFBMkIsR0FBRyxDQUFDLEVBQUU7O0dBRy9DLEtBQUssWUFBWTtHQUNqQixLQUFLLE9BQU87R0FDWixLQUFLLFNBQVMsOENBQThDLEdBQUcsQ0FBQyxFQUFFOztHQUdsRSxLQUFLLFlBQVk7R0FDakIsS0FBSyxPQUFPO0dBQ1osS0FBSyxTQUFTLHNCQUFzQixLQUFLLE1BQU0sT0FBTyxFQUFFLEdBQUksUUFBUSxNQUFPLEdBQUcsRUFBRTtHQUVoRixLQUFLLFlBQVk7R0FDakIsS0FBSyxPQUFPO0dBQ1osS0FBSyxTQUFTLHVEQUF1RCxHQUFHLEVBQUU7R0FFMUUsS0FBSyxRQUFRO0dBRWIsSUFBSSxTQUFTLGFBQWE7SUFDeEIsY0FBYyxZQUFZO0lBQzFCLElBQUksS0FBSztHQUNYO0VBQ0YsR0FBRyxNQUFPLEVBQUU7Q0FDZDs7Q0FHQSxNQUFNLHFCQUFxQixNQUEyQztFQUNwRSxNQUFNLE9BQU8sRUFBRSxPQUFPLFFBQVE7RUFDOUIsSUFBSSxDQUFDLE1BQU07RUFFWCxNQUFNLE1BQU0sSUFBSSxnQkFBZ0IsSUFBSTtFQUNwQyxZQUFZLEdBQUc7RUFDZixpQkFBaUIsS0FBSyxJQUFJO0VBQzFCLGVBQWUsQ0FBQztFQUNoQixhQUFhLEtBQUs7RUFDbEIsZUFBZSxhQUFhLEtBQUssS0FBSyxvQ0FBb0M7RUFDMUUsaUJBQWlCLGVBQWUsSUFBSSxHQUFHLElBQUk7Q0FDN0M7O0NBR0EsTUFBTSw0QkFBNEIsTUFBMkM7RUFDM0UsTUFBTSxPQUFPLEVBQUUsT0FBTyxRQUFRO0VBQzlCLElBQUksQ0FBQyxNQUFNO0VBRVgsTUFBTSxNQUFNLElBQUksZ0JBQWdCLElBQUk7RUFDcEMsbUJBQW1CLEdBQUc7RUFDdEIsTUFBTSxNQUFNLElBQUksTUFBTTtFQUN0QixJQUFJLE1BQU07RUFDVixJQUFJLGVBQWU7R0FDakIsY0FBYyxVQUFVO0VBQzFCO0VBQ0EsZUFBZSxrREFBa0Q7RUFDakUsaUJBQWlCLGVBQWUsSUFBSSxHQUFHLEdBQUk7Q0FDN0M7O0NBR0EsTUFBTSxxQkFBcUIsTUFBMkM7RUFDcEUsTUFBTSxPQUFPLEVBQUUsT0FBTyxRQUFRO0VBQzlCLElBQUksQ0FBQyxNQUFNO0VBRVgsTUFBTSxNQUFNLElBQUksZ0JBQWdCLElBQUk7RUFDcEMsWUFBWSxHQUFHO0VBQ2YsZUFBZSxtQkFBbUIsS0FBSyxLQUFLLG9CQUFvQjtFQUNoRSxpQkFBaUIsZUFBZSxJQUFJLEdBQUcsR0FBSTtDQUM3Qzs7Q0FHQSxNQUFNLGtDQUFrQztFQUN0QyxNQUFNLElBQUksU0FBUztFQUNuQixJQUFJLENBQUMsR0FBRztFQUNSLE1BQU0sTUFBTSxFQUFFLFlBQVk7RUFDMUIsWUFBWSxHQUFHO0VBQ2YsV0FBVyxDQUFDO0VBQ1osWUFBWSxHQUFHO0NBQ2pCOztDQUdBLE1BQU0seUJBQXlCO0VBQzdCLE1BQU0sSUFBSSxTQUFTO0VBQ25CLElBQUksQ0FBQyxHQUFHO0VBRVIsSUFBSSxXQUFXO0dBQ2IsRUFBRSxNQUFNO0dBQ1IsSUFBSSxTQUFTLFNBQVMsU0FBUyxRQUFRLE1BQU07R0FDN0MsYUFBYSxLQUFLO0VBQ3BCLE9BQU87O0dBRUwsSUFBSSxlQUFlLFVBQVU7SUFDM0IsRUFBRSxjQUFjO0lBQ2hCLGVBQWUsT0FBTztHQUN4QjtHQUNBLEVBQUUsZUFBZTtHQUNqQixFQUFFLFNBQVMsZ0JBQWdCLElBQUksS0FBSyxJQUFJLEdBQUssZUFBZSxHQUFHO0dBQy9ELEVBQUUsS0FBSztHQUVQLElBQUksU0FBUyxXQUFXLFVBQVU7SUFDaEMsU0FBUyxRQUFRLGNBQWMsRUFBRTtJQUNqQyxTQUFTLFFBQVEsU0FBUyxlQUFlLElBQUksS0FBSyxJQUFJLEdBQUssY0FBYyxHQUFHO0lBQzVFLFNBQVMsUUFBUSxLQUFLO0dBQ3hCO0dBQ0EsYUFBYSxJQUFJO0VBQ25CO0NBQ0Y7O0NBR0EsTUFBTSxjQUFjLFlBQW9CO0VBQ3RDLE1BQU0sVUFBVSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksVUFBVSxPQUFPLENBQUM7RUFDdkQsZUFBZSxPQUFPO0VBQ3RCLElBQUksU0FBUyxTQUFTO0dBQ3BCLFNBQVMsUUFBUSxjQUFjO0VBQ2pDO0VBQ0EsSUFBSSxTQUFTLFNBQVM7R0FDcEIsU0FBUyxRQUFRLGNBQWM7RUFDakM7Q0FDRjs7Q0FHQSxNQUFNLHlCQUF5QjtFQUM3QixXQUFXLFdBQVc7RUFDdEIsZUFBZSxrQ0FBa0MsV0FBVyxXQUFXLEdBQUc7RUFDMUUsaUJBQWlCLGVBQWUsSUFBSSxHQUFHLElBQUk7Q0FDN0M7Q0FFQSxNQUFNLDBCQUEwQjtFQUM5QixZQUFZLFdBQVc7RUFDdkIsZUFBZSxpQ0FBaUMsV0FBVyxXQUFXLEdBQUc7RUFDekUsaUJBQWlCLGVBQWUsSUFBSSxHQUFHLElBQUk7Q0FDN0M7Q0FFQSxNQUFNLHdCQUF3QjtFQUM1QixXQUFXLENBQUM7RUFDWixZQUFZLFFBQVE7RUFDcEIsZUFBZSxtQ0FBbUM7RUFDbEQsaUJBQWlCLGVBQWUsSUFBSSxHQUFHLEdBQUk7Q0FDN0M7O0NBR0EsTUFBTSxxQkFBcUIsVUFBa0I7RUFDM0MsaUJBQWlCLEtBQUs7RUFDdEIsSUFBSSxTQUFTLFNBQVM7R0FDcEIsU0FBUyxRQUFRLGVBQWU7RUFDbEM7RUFDQSxlQUFlLDJCQUEyQixNQUFNLEVBQUU7RUFDbEQsaUJBQWlCLGVBQWUsSUFBSSxHQUFHLEdBQUk7Q0FDN0M7O0NBR0EsTUFBTSw4QkFBOEI7RUFDbEMsTUFBTSxTQUFTLFVBQVU7RUFDekIsSUFBSSxDQUFDLFFBQVE7RUFFYixJQUFJO0dBQ0YsTUFBTSxVQUFVLE9BQU8sVUFBVSxjQUFjLEdBQUk7R0FDbkQsTUFBTSxJQUFJLFNBQVMsY0FBYyxHQUFHO0dBQ3BDLEVBQUUsT0FBTztHQUNULE1BQU0sV0FBVyxrQkFBa0IsS0FBSyxJQUFJLEVBQUU7R0FDOUMsRUFBRSxXQUFXO0dBQ2IsRUFBRSxNQUFNO0dBRVIsSUFBSSxlQUFlO0lBQ2pCLGNBQWM7S0FDWixJQUFJLFlBQVksS0FBSyxJQUFJO0tBQ3pCLE9BQU87S0FDUCxNQUFNO0tBQ04sTUFBTSxHQUFHLE9BQU8sTUFBTSxHQUFHLE9BQU8sT0FBTztLQUN2QyxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsbUJBQW1CLE9BQU87SUFDbEQsQ0FBQztHQUNIO0dBRUEsZUFBZSxnRUFBZ0U7R0FDL0UsaUJBQWlCLGVBQWUsSUFBSSxHQUFHLEdBQUk7RUFDN0MsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7RUFDakI7Q0FDRjs7OztDQUtBLE1BQU0sdUJBQXVCLGtCQUFrQjtFQUM3QyxNQUFNLFNBQVMsVUFBVTtFQUN6QixNQUFNLFFBQVEsU0FBUztFQUN2QixJQUFJLENBQUMsUUFBUTtFQUNiLE1BQU0sTUFBTSxPQUFPLFdBQVcsSUFBSTtFQUNsQyxJQUFJLENBQUMsS0FBSztFQUVWLE1BQU0sRUFBRSxPQUFPLFNBQVMsUUFBUSxZQUFZLG9CQUFvQjtFQUNoRSxPQUFPLFFBQVE7RUFDZixPQUFPLFNBQVM7O0VBR2hCLElBQUksWUFBWTtFQUNoQixJQUFJLFNBQVMsR0FBRyxHQUFHLFNBQVMsT0FBTzs7RUFHbkMsSUFBSSxTQUFTLE1BQU0sY0FBYyxHQUFHO0dBQ2xDLElBQUksS0FBSzs7R0FHVCxJQUFJLFVBQVUsVUFBVSxHQUFHLFVBQVUsQ0FBQztHQUN0QyxJQUFJLE9BQVEsV0FBVyxLQUFLLEtBQU0sR0FBRztHQUNyQyxJQUFJLE1BQU0sUUFBUSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO0dBQ3hDLElBQUksTUFBTSxXQUFXLFNBQVM7O0dBRzlCLE1BQU0sVUFBVSxNQUFNLGFBQWEsTUFBTTtHQUN6QyxNQUFNLFVBQVUsVUFBVTtHQUMxQixJQUFJLFFBQVE7R0FDWixJQUFJLFFBQVE7R0FFWixJQUFJLFVBQVUsU0FBUztJQUNyQixRQUFRLFVBQVU7R0FDcEIsT0FBTztJQUNMLFFBQVEsVUFBVTtHQUNwQjs7R0FHQSxJQUFJLFlBQVksY0FBYyxNQUFNLFdBQVcsY0FBYyxNQUFNLFNBQVMsY0FBYyxNQUFNLFdBQVc7R0FDM0csSUFBSSxpQkFBaUIsYUFBYTtJQUNoQyxhQUFhO0dBQ2YsT0FBTyxJQUFJLGlCQUFpQixNQUFNO0lBQ2hDLGFBQWE7R0FDZixPQUFPLElBQUksaUJBQWlCLFdBQVc7SUFDckMsYUFBYTtHQUNmLE9BQU8sSUFBSSxpQkFBaUIsUUFBUTtJQUNsQyxhQUFhO0dBQ2Y7R0FDQSxJQUFJLFNBQVM7R0FFYixJQUFJLFVBQVUsT0FBTyxDQUFDLFFBQVEsR0FBRyxDQUFDLFFBQVEsR0FBRyxPQUFPLEtBQUs7O0dBR3pELElBQUksV0FBVyxHQUFHO0lBQ2hCLElBQUksMkJBQTJCO0lBQy9CLElBQUksWUFBWSxTQUFTLElBQ3JCLHNCQUFzQixLQUFLLElBQUksS0FBTyxTQUFTLE1BQU8sRUFBRyxFQUFFLEtBQzNELHNCQUFzQixLQUFLLElBQUksS0FBTyxLQUFLLElBQUksTUFBTSxJQUFJLE1BQU8sRUFBRyxFQUFFO0lBQ3pFLElBQUksU0FBUyxDQUFDLFFBQVEsR0FBRyxDQUFDLFFBQVEsR0FBRyxPQUFPLEtBQUs7R0FDbkQ7R0FFQSxJQUFJLFFBQVE7RUFDZCxPQUFPOztHQUVMLElBQUksWUFBWTtHQUNoQixJQUFJLE9BQU87R0FDWCxJQUFJLFlBQVk7R0FDaEIsSUFBSSxTQUFTLCtDQUE2QyxVQUFVLEdBQUcsVUFBVSxJQUFJLEVBQUU7R0FDdkYsSUFBSSxPQUFPO0dBQ1gsSUFBSSxZQUFZO0dBQ2hCLElBQUksU0FBUyxrRkFBa0YsVUFBVSxHQUFHLFVBQVUsSUFBSSxFQUFFO0VBQzlIOztFQUdBLElBQUksY0FBYyxXQUFXLGlCQUFpQjtHQUM1QyxJQUFJLEtBQUs7R0FDVCxJQUFJLGNBQWM7R0FFbEIsTUFBTSxNQUFNLGNBQWM7R0FDMUIsTUFBTSxZQUFZLElBQUksUUFBUSxJQUFJO0dBQ2xDLE1BQU0sT0FBTyxVQUFVO0dBQ3ZCLE1BQU0sT0FBTyxPQUFPO0dBRXBCLElBQUksS0FBSztHQUNULElBQUksS0FBSztHQUVULElBQUksb0JBQW9CLGFBQWE7SUFDbkMsS0FBSyxVQUFVLE9BQU87SUFDdEIsS0FBSztHQUNQLE9BQU8sSUFBSSxvQkFBb0IsWUFBWTtJQUN6QyxLQUFLO0lBQ0wsS0FBSztHQUNQLE9BQU8sSUFBSSxvQkFBb0IsZ0JBQWdCO0lBQzdDLEtBQUssVUFBVSxPQUFPO0lBQ3RCLEtBQUssVUFBVSxPQUFPO0dBQ3hCLE9BQU8sSUFBSSxvQkFBb0IsZUFBZTtJQUM1QyxLQUFLO0lBQ0wsS0FBSyxVQUFVLE9BQU87R0FDeEIsT0FBTztJQUNMLE1BQU0sVUFBVSxRQUFRO0lBQ3hCLE1BQU0sVUFBVSxRQUFRO0dBQzFCOztHQUdBLElBQUksWUFBWTtHQUNoQixJQUFJLFNBQVMsS0FBSyxHQUFHLEtBQUssR0FBRyxPQUFPLEdBQUcsT0FBTyxDQUFDO0dBQy9DLElBQUksY0FBYztHQUNsQixJQUFJLFlBQVk7R0FDaEIsSUFBSSxXQUFXLEtBQUssR0FBRyxLQUFLLEdBQUcsT0FBTyxHQUFHLE9BQU8sQ0FBQztHQUVqRCxJQUFJLFVBQVUsS0FBSyxJQUFJLElBQUksTUFBTSxJQUFJO0dBQ3JDLElBQUksUUFBUTtFQUNkOztFQUdBLGFBQWEsU0FBUyxRQUFRO0dBQzVCLElBQUksZUFBZSxJQUFJLGFBQWEsZUFBZSxJQUFJLFdBQVcsSUFBSSxLQUFLLEtBQUssR0FBRztJQUNqRixJQUFJLEtBQUs7SUFDVCxJQUFJLE9BQU8sUUFBUSxJQUFJLFNBQVM7SUFDaEMsSUFBSSxZQUFZO0lBRWhCLE1BQU0sY0FBYyxJQUFJLFlBQVksSUFBSSxJQUFJO0lBQzVDLE1BQU0sUUFBUSxZQUFZO0lBQzFCLE1BQU0sY0FBYztJQUNwQixNQUFNLGNBQWM7SUFDcEIsTUFBTSxPQUFPLElBQUksV0FBVyxjQUFjO0lBRTFDLElBQUksS0FBSyxVQUFVO0lBQ25CLElBQUksSUFBSSxhQUFhLE9BQU8sS0FBSztTQUM1QixJQUFJLElBQUksYUFBYSxVQUFVLEtBQUssVUFBVTs7SUFHbkQsSUFBSSxZQUFZLElBQUk7SUFDcEIsSUFBSSxVQUFVO0lBQ2QsSUFBSSxXQUNELFVBQVUsUUFBUSxjQUFjLEtBQUssR0FDdEMsS0FBSyxPQUFPLEdBQ1osUUFBUSxjQUFjLEdBQ3RCLE1BQ0EsRUFDRjtJQUNBLElBQUksS0FBSztJQUVULElBQUksSUFBSSxVQUFVLGVBQWU7S0FDL0IsSUFBSSxjQUFjO0tBQ2xCLElBQUksWUFBWTtLQUNoQixJQUFJLE9BQU87SUFDYixPQUFPLElBQUksSUFBSSxVQUFVLFFBQVE7S0FDL0IsSUFBSSxjQUFjO0tBQ2xCLElBQUksYUFBYTtJQUNuQjs7SUFHQSxJQUFJLFlBQVksSUFBSTtJQUNwQixJQUFJLGVBQWU7SUFDbkIsSUFBSSxTQUFTLElBQUksTUFBTSxVQUFVLEdBQUcsRUFBRTtJQUN0QyxJQUFJLFFBQVE7R0FDZDtFQUNGLENBQUM7O0VBR0QsSUFBSSxpQkFBaUIsY0FBYyxLQUFLLEdBQUc7R0FDekMsSUFBSSxLQUFLO0dBQ1QsSUFBSSxjQUFjO0dBQ2xCLElBQUksT0FBTztHQUVYLE1BQU0sV0FBVyxJQUFJLFlBQVksYUFBYTtHQUM5QyxNQUFNLFNBQVMsU0FBUyxRQUFRO0dBQ2hDLE1BQU0sVUFBVTtHQUVoQixJQUFJLEtBQUssVUFBVSxTQUFTO0dBQzVCLElBQUksS0FBSztHQUVULElBQUksaUJBQWlCLFlBQVk7SUFDL0IsS0FBSztJQUNMLEtBQUs7R0FDUCxPQUFPLElBQUksaUJBQWlCLGdCQUFnQjtJQUMxQyxLQUFLLFVBQVUsU0FBUztJQUN4QixLQUFLLFVBQVUsVUFBVTtHQUMzQixPQUFPLElBQUksaUJBQWlCLGVBQWU7SUFDekMsS0FBSztJQUNMLEtBQUssVUFBVSxVQUFVO0dBQzNCO0dBRUEsSUFBSSxZQUFZO0dBQ2hCLElBQUksVUFBVTtHQUNkLElBQUksVUFBVSxJQUFJLElBQUksUUFBUSxTQUFTLENBQUM7R0FDeEMsSUFBSSxLQUFLO0dBQ1QsSUFBSSxjQUFjO0dBQ2xCLElBQUksWUFBWTtHQUNoQixJQUFJLE9BQU87R0FFWCxJQUFJLFlBQVk7R0FDaEIsSUFBSSxZQUFZO0dBQ2hCLElBQUksZUFBZTtHQUNuQixJQUFJLFNBQVMsZUFBZSxLQUFLLFNBQVMsR0FBRyxLQUFLLFVBQVUsQ0FBQztHQUM3RCxJQUFJLFFBQVE7RUFDZDtDQUNGLEdBQUc7RUFDRDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsQ0FBQzs7Q0FHRCxnQkFBZ0I7RUFDZCxNQUFNLFFBQVEsU0FBUztFQUN2QixJQUFJLENBQUMsT0FBTztFQUVaLElBQUk7RUFDSixNQUFNLG1CQUFtQjtHQUN2QixJQUFJLFNBQVMsQ0FBQyxNQUFNLFVBQVUsQ0FBQyxNQUFNLE9BQU87SUFDMUMsZUFBZSxNQUFNLFdBQVc7O0lBR2hDLElBQUksTUFBTSxlQUFlLFVBQVU7S0FDakMsSUFBSSxXQUFXO01BQ2IsTUFBTSxjQUFjO01BQ3BCLElBQUksU0FBUyxTQUFTLFNBQVMsUUFBUSxjQUFjO0tBQ3ZELE9BQU87TUFDTCxNQUFNLE1BQU07TUFDWixJQUFJLFNBQVMsU0FBUyxTQUFTLFFBQVEsTUFBTTtNQUM3QyxhQUFhLEtBQUs7S0FDcEI7SUFDRjtHQUNGO0dBQ0EscUJBQXFCO0dBQ3JCLFNBQVMsc0JBQXNCLFVBQVU7RUFDM0M7RUFFQSxTQUFTLHNCQUFzQixVQUFVO0VBQ3pDLGFBQWEscUJBQXFCLE1BQU07Q0FDMUMsR0FBRztFQUFDO0VBQVM7RUFBVTtFQUFXO0NBQW9CLENBQUM7O0NBR3ZELGdCQUFnQjtFQUNkLE1BQU0saUJBQWlCLE1BQXFCO0dBQzFDLElBQUssRUFBRSxPQUF1QixZQUFZLFdBQVksRUFBRSxPQUF1QixZQUFZLFlBQVk7SUFDckc7R0FDRjtHQUNBLElBQUksRUFBRSxTQUFTLFNBQVM7SUFDdEIsRUFBRSxlQUFlO0lBQ2pCLGlCQUFpQjtHQUNuQjtFQUNGO0VBQ0EsT0FBTyxpQkFBaUIsV0FBVyxhQUFhO0VBQ2hELGFBQWEsT0FBTyxvQkFBb0IsV0FBVyxhQUFhO0NBQ2xFLENBQUM7Ozs7Q0FLRCxNQUFNLDBCQUEwQjtFQUM5QixNQUFNLFNBQVMsVUFBVTtFQUN6QixNQUFNLFFBQVEsU0FBUztFQUN2QixJQUFJLENBQUMsUUFBUTtFQUViLGVBQWUsSUFBSTtFQUNuQixrQkFBa0IsQ0FBQztFQUVuQixJQUFJO0dBQ0YsTUFBTSxTQUFTLE9BQU8sY0FBYyxFQUFFO0dBQ3RDLE1BQU0sT0FBTyxjQUFjLGdCQUFnQix1QkFBdUIsSUFDOUQsMEJBQ0E7R0FFSixNQUFNLFdBQVcsSUFBSSxjQUFjLFFBQVEsRUFBRSxVQUFVLEtBQUssQ0FBQztHQUM3RCxpQkFBaUIsVUFBVSxDQUFDO0dBRTVCLFNBQVMsbUJBQW1CLE1BQU07SUFDaEMsSUFBSSxFQUFFLEtBQUssT0FBTyxHQUFHLGlCQUFpQixRQUFRLEtBQUssRUFBRSxJQUFJO0dBQzNEO0dBRUEsU0FBUyxlQUFlO0lBQ3RCLE1BQU0sT0FBTyxJQUFJLEtBQUssaUJBQWlCLFNBQVMsRUFBRSxNQUFNLEtBQUssQ0FBQztJQUM5RCxNQUFNLE1BQU0sS0FBSyxTQUFTLEtBQUssSUFBSSxRQUFRO0lBQzNDLE1BQU0sYUFBYSxtQkFBbUIsY0FBYyxRQUFRLGFBQWEsRUFBRSxFQUFFLFVBQVU7SUFDdkYsTUFBTSxNQUFNLElBQUksZ0JBQWdCLElBQUk7SUFDcEMsTUFBTSxJQUFJLFNBQVMsY0FBYyxHQUFHO0lBQ3BDLEVBQUUsT0FBTztJQUNULEVBQUUsV0FBVztJQUNiLEVBQUUsTUFBTTtJQUVSLElBQUksZUFBZTtLQUNqQixjQUFjO01BQ1osSUFBSSxjQUFjLEtBQUssSUFBSTtNQUMzQixPQUFPO01BQ1AsTUFBTTtNQUNOLE1BQU0sSUFBSSxLQUFLLFFBQVEsT0FBTyxNQUFLLENBQUUsUUFBUSxDQUFDLEVBQUUsT0FBTyxZQUFZO01BQ25FLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsT0FBTztLQUNsRCxDQUFDO0lBQ0g7SUFFQSxlQUFlLEtBQUs7SUFDcEIsa0JBQWtCLEdBQUc7SUFDckIsZUFBZSw4QkFBOEIsV0FBVyxjQUFjO0lBQ3RFLGlCQUFpQixlQUFlLElBQUksR0FBRyxHQUFJO0dBQzdDO0dBRUEsWUFBWSxVQUFVO0dBQ3RCLFNBQVMsTUFBTTs7R0FHZixJQUFJLE9BQU87SUFDVCxNQUFNLGNBQWM7SUFDcEIsTUFBTSxlQUFlO0lBQ3JCLE1BQU0sS0FBSztJQUNYLGFBQWEsSUFBSTtHQUNuQjtHQUVBLE1BQU0sbUJBQW1CLFdBQVcsV0FBVztHQUMvQyxNQUFNLFlBQVksS0FBSyxJQUFJO0dBRTNCLE1BQU0sZUFBZSxrQkFBa0I7SUFDckMsTUFBTSxVQUFVLEtBQUssSUFBSSxJQUFJO0lBQzdCLE1BQU0sTUFBTSxLQUFLLElBQUksSUFBSSxLQUFLLE1BQU8sVUFBVSxrQkFBbUIsR0FBRyxDQUFDO0lBQ3RFLGtCQUFrQixHQUFHO0lBRXJCLElBQUksV0FBVyxpQkFBaUI7S0FDOUIsY0FBYyxZQUFZO0tBQzFCLFNBQVMsS0FBSztLQUNkLElBQUksT0FBTyxNQUFNLE1BQU07S0FDdkIsYUFBYSxLQUFLO0lBQ3BCO0dBQ0YsR0FBRyxHQUFHO0VBRVIsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7R0FDZixlQUFlLEtBQUs7R0FDcEIsZUFBZSx1REFBdUQ7R0FDdEUsaUJBQWlCLGVBQWUsSUFBSSxHQUFHLEdBQUk7RUFDN0M7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVHLFlBQVksd0JBQUMsU0FBRDtJQUFPLEtBQUs7SUFBVSxLQUFLO0lBQVU7R0FBTTs7Ozs7R0FHeEQsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSx3QkFBeUI7Ozs7aUJBQ3pDLHdCQUFDLFFBQUQsWUFBTSwrQkFBa0M7Ozs7ZUFDdEM7Ozs7OztNQUNKLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFnSDtNQUUxSDs7Ozs7TUFDTix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBc0c7TUFFaEg7Ozs7O01BQ04sd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQTRHO01BRXRIOzs7OztLQUNIOzs7OztjQUNMLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQThCO0lBRXhDOzs7O1lBQ0E7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxTQUFTO09BQ1QsV0FBVTtPQUNWLE9BQU07aUJBSlIsQ0FNRSx3QkFBQyxVQUFELEVBQVUsV0FBVSw2QkFBOEI7Ozs7aUJBQ2xELHdCQUFDLFFBQUQsWUFBTSxtQkFBc0I7Ozs7ZUFDdEI7Ozs7OztNQUVSLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFqQjtRQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDRCQUE2Qjs7Ozs7UUFDL0Msd0JBQUMsUUFBRCxZQUFNLGVBQWtCOzs7OztRQUN4Qix3QkFBQyxTQUFEO1NBQU8sTUFBSztTQUFPLFFBQU87U0FBVSxVQUFVO1NBQW1CLFdBQVU7UUFBVTs7Ozs7T0FDaEY7Ozs7OztNQUVQLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsU0FBUztPQUNULFdBQVU7T0FDVixPQUFNO2lCQUpSLENBTUUsd0JBQUMsUUFBRCxFQUFRLFdBQVUsK0JBQWdDOzs7O2lCQUNsRCx3QkFBQyxRQUFELFlBQU0sZUFBa0I7Ozs7ZUFDbEI7Ozs7OztNQUVSLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsU0FBUztPQUNULFVBQVU7T0FDVixXQUFVO09BQ1YsT0FBTTtpQkFMUixDQU9FLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHFCQUFzQjs7OztpQkFDMUMsd0JBQUMsUUFBRCxZQUFPLGNBQWMsY0FBYyxlQUFlLE1BQU0sZUFBcUI7Ozs7ZUFDdkU7Ozs7OztLQUNMOzs7OztZQUNGOzs7Ozs7R0FHSixlQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsY0FBRCxFQUFjLFdBQVUseUNBQTBDOzs7O2VBQ2xFLHdCQUFDLFFBQUQsWUFBTyxZQUFrQjs7OzthQUN0Qjs7Ozs7Y0FDTCx3QkFBQyxVQUFEO0tBQVEsZUFBZSxlQUFlLElBQUk7S0FBRyxXQUFVO2VBQW9DO0lBQVM7Ozs7WUFDakc7Ozs7OztHQUlOLGVBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sMkNBQThDOzs7O2VBQ3BELHdCQUFDLFFBQUQsYUFBTyxnQkFBZSxHQUFPOzs7O2FBQzFCOzs7OztjQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsT0FBRDtNQUNFLFdBQVU7TUFDVixPQUFPLEVBQUUsT0FBTyxHQUFHLGVBQWUsR0FBRztLQUN0Qzs7Ozs7SUFDRTs7OztZQUNGOzs7Ozs7R0FJUCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBRUUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUVFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxxREFBMkQ7Ozs7O1NBQzNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUF3QjtTQUFvQjs7Ozs7U0FDNUQsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWlCO1NBQU87Ozs7O1NBQ3hDLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUEwQjtTQUFrQjs7Ozs7UUFDekQ7Ozs7O2lCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQThCLFdBQVcsV0FBVztTQUFROzs7OztTQUM1RSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaUI7U0FBTzs7Ozs7U0FDeEMsd0JBQUMsUUFBRCxZQUFPLFdBQVcsUUFBUSxFQUFROzs7OztRQUMvQjs7Ozs7ZUFDRjs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1FBQ0UsS0FBSztRQUNMLFdBQVU7UUFDVixTQUFTO09BQ1Y7Ozs7aUJBR0EsWUFDQyx3QkFBQyxTQUFEO1FBQ0UsS0FBSztRQUNMLEtBQUs7UUFDTCxrQkFBa0I7UUFDbEIsZUFBZTtTQUNiLElBQUksV0FBVztVQUNiLElBQUksU0FBUyxTQUFTLFNBQVMsUUFBUSxjQUFjO1VBQ3JELElBQUksU0FBUyxTQUFTLFNBQVMsUUFBUSxjQUFjO1NBQ3ZELE9BQU87VUFDTCxhQUFhLEtBQUs7U0FDcEI7UUFDRjtRQUNBLFdBQVU7UUFDVjtPQUNEOzs7O2VBRUE7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBRUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLEtBQUk7VUFDSixLQUFLLFlBQVk7VUFDakIsTUFBSztVQUNMLE9BQU87VUFDUCxXQUFXLE1BQU0sV0FBVyxPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7VUFDbEQsV0FBVTtTQUNYOzs7OztRQUNFOzs7O2tCQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQStCLFFBQUssV0FBVyxPQUFPLENBQVE7Ozs7OztVQUM5RCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBd0IsV0FBVyxXQUFXO1VBQVE7Ozs7O1VBQ3RFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUFrQyxTQUFNLFdBQVcsUUFBUSxDQUFROzs7Ozs7U0FDaEU7Ozs7O2dCQUNGOzs7OztpQkFHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBRUUsd0JBQUMsVUFBRDtXQUNFLE1BQUs7V0FDTCxTQUFTO1dBQ1QsV0FBVTtXQUNWLE9BQU07cUJBRUwsWUFBWSx3QkFBQyxPQUFELEVBQU8sV0FBVSxxQkFBc0I7Ozs7c0JBQUksd0JBQUMsTUFBRCxFQUFNLFdBQVUsNEJBQTZCOzs7OztVQUMvRjs7Ozs7VUFHUix3QkFBQyxVQUFEO1dBQ0UsTUFBSztXQUNMLGVBQWUsV0FBVyxjQUFjLENBQUM7V0FDekMsV0FBVTtXQUNWLE9BQU07cUJBRU4sd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7Ozs7VUFDdkI7Ozs7O1VBR1Isd0JBQUMsVUFBRDtXQUNFLE1BQUs7V0FDTCxlQUFlLFdBQVcsY0FBYyxDQUFDO1dBQ3pDLFdBQVU7V0FDVixPQUFNO3FCQUVOLHdCQUFDLGFBQUQsRUFBYSxXQUFVLFVBQVc7Ozs7O1VBQzVCOzs7OztVQUdSLHdCQUFDLFVBQUQ7V0FDRSxNQUFLO1dBQ0wsU0FBUztXQUNULFdBQVU7V0FDVixPQUFNO3FCQUNQO1VBRU87Ozs7O1VBR1Isd0JBQUMsVUFBRDtXQUNFLE1BQUs7V0FDTCxTQUFTO1dBQ1QsV0FBVTtXQUNWLE9BQU07cUJBQ1A7VUFFTzs7Ozs7VUFFUix3QkFBQyxVQUFEO1dBQ0UsTUFBSztXQUNMLFNBQVM7V0FDVCxXQUFVO1dBQ1YsT0FBTTtxQkFFTix3QkFBQyxXQUFELEVBQVcsV0FBVSxjQUFlOzs7OztVQUM5Qjs7Ozs7U0FDTDs7Ozs7a0JBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FFRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWjtXQUFDO1dBQUs7V0FBSztXQUFLO1VBQUcsQ0FBQyxDQUFDLEtBQUssTUFDekIsd0JBQUMsVUFBRDtXQUVFLE1BQUs7V0FDTCxlQUFlLGtCQUFrQixDQUFDO1dBQ2xDLFdBQVcsdUNBQ1Qsa0JBQWtCLElBQUksMkJBQTJCO3FCQUxyRCxDQVFHLEdBQUUsR0FDRzthQVJEOzs7O2lCQVFDLENBQ1Q7U0FDRTs7OzttQkFHTCx3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLGVBQWUsaUJBQWlCLENBQUMsYUFBYTtVQUM5QyxXQUFXLGlDQUNULGdCQUNJLG9EQUNBO1VBRU4sT0FBTTtvQkFFTCxnQkFBZ0Isd0JBQUMsU0FBRCxFQUFTLFdBQVUsVUFBVzs7OztxQkFBSSx3QkFBQyxTQUFELEVBQVMsV0FBVSxVQUFXOzs7OztTQUMzRTs7OztpQkFDTDs7Ozs7Z0JBQ0Y7Ozs7O2VBQ0Y7Ozs7OztLQUNGOzs7OztjQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFFRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWjtRQUNDO1NBQUUsSUFBSTtTQUFZLE9BQU87U0FBWSxNQUFNO1FBQU87UUFDbEQ7U0FBRSxJQUFJO1NBQVEsT0FBTztTQUFVLE1BQU07UUFBb0I7UUFDekQ7U0FBRSxJQUFJO1NBQVMsT0FBTztTQUFTLE1BQU07UUFBUTtRQUM3QztTQUFFLElBQUk7U0FBUSxPQUFPO1NBQVUsTUFBTTtRQUFLO1FBQzFDO1NBQUUsSUFBSTtTQUFXLE9BQU87U0FBVyxNQUFNO1FBQVU7UUFDbkQ7U0FBRSxJQUFJO1NBQVMsT0FBTztTQUFTLE1BQU07UUFBTTtPQUM3QyxDQUFDLENBQUMsS0FBSyxRQUFRO1FBQ2IsTUFBTSxPQUFPLElBQUk7UUFDakIsTUFBTSxXQUFXLGtCQUFrQixJQUFJO1FBQ3ZDLE9BQ0Usd0JBQUMsVUFBRDtTQUVFLE1BQUs7U0FDTCxlQUFlLGlCQUFpQixJQUFJLEVBQVM7U0FDN0MsV0FBVyx1RkFDVCxXQUNJLHdEQUNBO21CQVBSLENBVUUsd0JBQUMsTUFBRCxFQUFNLFdBQVUsY0FBZTs7OzttQkFDL0Isd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQVksSUFBSTtTQUFZOzs7O2lCQUN0QztXQVhELElBQUk7Ozs7ZUFXSDtPQUVaLENBQUM7TUFDRTs7Ozs7TUFHSixrQkFBa0IsY0FDakIsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHdCQUF5Qjs7OztvQkFDM0Msd0JBQUMsUUFBRCxZQUFNLDBCQUE2Qjs7OztrQkFDL0I7Ozs7O21CQUNOLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUF1QztTQUFrQjs7OztpQkFDdEU7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBTSxXQUFVLHVDQUE2Qzs7OztxQkFDN0Qsd0JBQUMsVUFBRDtZQUFRLFdBQVU7c0JBQWE7V0FBMkI7Ozs7bUJBQ3ZEOzs7OztvQkFDTCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBc0MsV0FBVyxRQUFRO1VBQVE7Ozs7a0JBQzlFOzs7OzttQkFDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQsYUFBTSxVQUFPLGFBQW9COzs7O29CQUNqQyx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBNkI7VUFBWTs7OztrQkFDdEQ7Ozs7O2lCQUNGOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSx5Q0FBK0M7Ozs7cUJBQy9ELHdCQUFDLFVBQUQ7WUFBUSxXQUFVO3NCQUFhO1dBQTJDOzs7O21CQUN2RTs7Ozs7b0JBQ0wsd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQWpCLENBQXdGLGVBRXRGLHdCQUFDLFNBQUQ7WUFBTyxNQUFLO1lBQU8sUUFBTztZQUFVLFVBQVU7WUFBMEIsV0FBVTtXQUFVOzs7O21CQUN2Rjs7Ozs7a0JBQ0o7Ozs7O21CQUNMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFPLGtCQUFrQix5QkFBeUIsc0JBQTRCOzs7O29CQUM3RSxtQkFDQyx3QkFBQyxVQUFEO1dBQVEsZUFBZSxtQkFBbUIsSUFBSTtXQUFHLFdBQVU7cUJBQWdDO1VBRW5GOzs7O2tCQUVQOzs7OztpQkFDRjs7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsd0NBQThDOzs7O3FCQUM5RCx3QkFBQyxVQUFEO1lBQVEsV0FBVTtzQkFBYTtXQUFpQzs7OzttQkFDN0Q7Ozs7O29CQUNMLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUFqQixDQUF1RixlQUVyRix3QkFBQyxTQUFEO1lBQU8sTUFBSztZQUFPLFFBQU87WUFBVSxVQUFVO1lBQW1CLFdBQVU7V0FBVTs7OzttQkFDaEY7Ozs7O2tCQUNKOzs7OzttQkFDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTyxXQUFXLDRCQUE0QixrQkFBd0I7Ozs7b0JBQ3JFLFlBQ0Msd0JBQUMsVUFBRDtXQUFRLGVBQWUsWUFBWSxJQUFJO1dBQUcsV0FBVTtxQkFBZ0M7VUFFNUU7Ozs7a0JBRVA7Ozs7O2lCQUNGOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSwwQ0FBZ0Q7Ozs7cUJBQ2hFLHdCQUFDLFVBQUQ7WUFBUSxXQUFVO3NCQUFhO1dBQTRDOzs7O21CQUN4RTs7Ozs7b0JBQ0wsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQ0csYUFBYSxRQUFPLGNBQ2pCOzs7OztrQkFDSDs7Ozs7bUJBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FBcUQ7V0FDakQsYUFBYSxFQUFFLEVBQUUsUUFBUTtXQUFVO1VBQ2xDOzs7OztpQkFDRjs7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsdUNBQTZDOzs7O3FCQUM3RCx3QkFBQyxVQUFEO1lBQVEsV0FBVTtzQkFBYTtXQUEyQzs7OzttQkFDdkU7Ozs7O29CQUNMLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsU0FBUztXQUNULFdBQVcsTUFBTSxpQkFBaUIsRUFBRSxPQUFPLE9BQU87V0FDbEQsV0FBVTtVQUNYOzs7O2tCQUNFOzs7OzttQkFDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWixnQkFBZ0IsZ0JBQWdCO1NBQzlCOzs7O2lCQUNGOzs7Ozs7T0FDRjs7Ozs7O01BSU4sa0JBQWtCLFVBQ2pCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQW9GO1FBRTlGOzs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaO1VBQ0M7V0FBRSxJQUFJO1dBQVEsT0FBTztXQUFRLE1BQU07VUFBZTtVQUNsRDtXQUFFLElBQUk7V0FBUSxPQUFPO1dBQVEsTUFBTTtVQUFpQjtVQUNwRDtXQUFFLElBQUk7V0FBTyxPQUFPO1dBQU8sTUFBTTtVQUFpQjtVQUNsRDtXQUFFLElBQUk7V0FBTyxPQUFPO1dBQU8sTUFBTTtVQUFnQjtTQUNuRCxDQUFDLENBQUMsS0FBSyxNQUNMLHdCQUFDLFVBQUQ7VUFFRSxNQUFLO1VBQ0wsZUFBZSxlQUFlLEVBQUUsRUFBaUI7VUFDakQsV0FBVyxzREFDVCxnQkFBZ0IsRUFBRSxLQUNkLHFGQUNBO29CQVBSLENBVUUsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQXFCLEVBQUU7VUFBVzs7OztvQkFDakQsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQThCLEVBQUU7VUFBVTs7OztrQkFDbkQ7WUFYRCxFQUFFOzs7O2dCQVdELENBQ1Q7UUFDRTs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFpQztTQUE4Qjs7OzttQkFDL0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxVQUFEO1lBQ0UsTUFBSztZQUNMLGVBQWUsYUFBYSxVQUFVLE9BQU8sTUFBTSxHQUFHO1lBQ3RELFdBQVU7c0JBSFosQ0FLRSx3QkFBQyxVQUFELEVBQVUsV0FBVSw0QkFBNkI7Ozs7c0JBQ2pELHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztvQkFDaEI7Ozs7OztXQUVSLHdCQUFDLFVBQUQ7WUFDRSxNQUFLO1lBQ0wsZUFBZSxTQUFTLENBQUMsS0FBSztZQUM5QixXQUFXLDRFQUNULFFBQVEseUNBQXlDO3NCQUpyRCxDQU9FLHdCQUFDLGdCQUFELEVBQWdCLFdBQVUsY0FBZTs7OztzQkFDekMsd0JBQUMsUUFBRCxZQUFNLFNBQVk7Ozs7b0JBQ1o7Ozs7OztXQUVSLHdCQUFDLFVBQUQ7WUFDRSxNQUFLO1lBQ0wsZUFBZSxTQUFTLENBQUMsS0FBSztZQUM5QixXQUFXLDRFQUNULFFBQVEseUNBQXlDO3NCQUpyRCxDQU9FLHdCQUFDLGNBQUQsRUFBYyxXQUFVLGNBQWU7Ozs7c0JBQ3ZDLHdCQUFDLFFBQUQsWUFBTSxTQUFZOzs7O29CQUNaOzs7Ozs7VUFDTDs7Ozs7aUJBQ0Y7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0scUJBQXdCOzs7O29CQUM5Qix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEIsQ0FBd0MsS0FBSyxNQUFNLFlBQVksR0FBRyxHQUFFLEdBQU87Ozs7O2tCQUN4RTs7Ozs7bUJBQ0wsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxLQUFJO1VBQ0osS0FBSTtVQUNKLE1BQUs7VUFDTCxPQUFPO1VBQ1AsV0FBVyxNQUFNLGFBQWEsT0FBTyxFQUFFLE9BQU8sS0FBSyxDQUFDO1VBQ3BELFdBQVU7U0FDWDs7OztpQkFDRTs7Ozs7O09BQ0Y7Ozs7OztNQUlOLGtCQUFrQixXQUNqQix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLG9DQUF1Qzs7OzttQkFDN0Msd0JBQUMsVUFBRDtVQUNFLGVBQWU7V0FDYixjQUFjLENBQUM7V0FDZixZQUFZLENBQUM7V0FDYixjQUFjLENBQUM7V0FDZixVQUFVLENBQUM7V0FDWCxnQkFBZ0IsUUFBUTtVQUMxQjtVQUNBLFdBQVU7b0JBQ1g7U0FFTzs7OztpQkFDTDs7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ1o7VUFDQztXQUFFLElBQUk7V0FBVSxPQUFPO1VBQVc7VUFDbEM7V0FBRSxJQUFJO1dBQWEsT0FBTztVQUFlO1VBQ3pDO1dBQUUsSUFBSTtXQUFXLE9BQU87VUFBb0I7VUFDNUM7V0FBRSxJQUFJO1dBQVEsT0FBTztVQUFnQjtVQUNyQztXQUFFLElBQUk7V0FBTSxPQUFPO1VBQWM7U0FDbkMsQ0FBQyxDQUFDLEtBQUssTUFDTCx3QkFBQyxVQUFEO1VBRUUsTUFBSztVQUNMLGVBQWUsZ0JBQWdCLEVBQUUsRUFBRTtVQUNuQyxXQUFXLHNFQUNULGlCQUFpQixFQUFFLEtBQ2Ysa0RBQ0E7b0JBR0wsRUFBRTtTQUNHLEdBVkQsRUFBRTs7OztnQkFVRCxDQUNUO1FBQ0U7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUF5RCx3QkFBQyxLQUFELEVBQUssV0FBVSxjQUFlOzs7O3FCQUFDLGFBQWlCOzs7OztvQkFDekcsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQXdDLGFBQWEsSUFBSSxJQUFJLGVBQWUsWUFBVyxHQUFPOzs7OztrQkFDM0Y7Ozs7O21CQUNMLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsS0FBSTtVQUNKLEtBQUk7VUFDSixPQUFPO1VBQ1AsV0FBVyxNQUFNLGNBQWMsT0FBTyxFQUFFLE9BQU8sS0FBSyxDQUFDO1VBQ3JELFdBQVU7U0FDWDs7OztpQkFDRTs7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUF1RCx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7O3FCQUFDLFdBQWU7Ozs7O29CQUMxRyx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEIsQ0FBd0MsV0FBVyxJQUFJLElBQUksYUFBYSxVQUFTLEdBQU87Ozs7O2tCQUNyRjs7Ozs7bUJBQ0wsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxLQUFJO1VBQ0osS0FBSTtVQUNKLE9BQU87VUFDUCxXQUFXLE1BQU0sWUFBWSxPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7VUFDbkQsV0FBVTtTQUNYOzs7O2lCQUNFOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQXdELHdCQUFDLFVBQUQsRUFBVSxXQUFVLGNBQWU7Ozs7cUJBQUMsYUFBaUI7Ozs7O29CQUM3Ryx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEIsQ0FBd0MsYUFBYSxJQUFJLElBQUksZUFBZSxZQUFXLEdBQU87Ozs7O2tCQUMzRjs7Ozs7bUJBQ0wsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxLQUFJO1VBQ0osS0FBSTtVQUNKLE9BQU87VUFDUCxXQUFXLE1BQU0sY0FBYyxPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7VUFDckQsV0FBVTtTQUNYOzs7O2lCQUNFOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQTBELHdCQUFDLE9BQUQsRUFBTyxXQUFVLGNBQWU7Ozs7cUJBQUMsc0JBQTBCOzs7OztvQkFDckgsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXdCLFNBQVMsSUFBSSxJQUFJLFdBQVc7VUFBYTs7OztrQkFDOUU7Ozs7O21CQUNMLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsS0FBSTtVQUNKLEtBQUk7VUFDSixPQUFPO1VBQ1AsV0FBVyxNQUFNLFVBQVUsT0FBTyxFQUFFLE9BQU8sS0FBSyxDQUFDO1VBQ2pELFdBQVU7U0FDWDs7OztpQkFDRTs7Ozs7O09BQ0Y7Ozs7OztNQUlOLGtCQUFrQixVQUNqQix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLFFBQUQsWUFBTSxpQ0FBb0M7Ozs7O1FBQ3ZDOzs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQStCO1NBQTRCOzs7O21CQUM1RSx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLE9BQU8sYUFBYSxFQUFFLEVBQUUsUUFBUTtVQUNoQyxXQUFXLE1BQU07V0FDZixNQUFNLE1BQU0sRUFBRSxPQUFPO1dBQ3JCLGlCQUFpQixTQUFTLENBQ3hCO1lBQ0UsR0FBRyxLQUFLO1lBQ1IsTUFBTTtXQUNSLENBQ0YsQ0FBQztVQUNIO1VBQ0EsYUFBWTtVQUNaLFdBQVU7U0FDWDs7OztpQkFDRTs7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBK0I7U0FBdUI7Ozs7bUJBQ3ZFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNaO1dBQUM7V0FBTztXQUFVO1VBQVEsQ0FBQyxDQUFDLEtBQUssUUFDaEMsd0JBQUMsVUFBRDtXQUVFLE1BQUs7V0FDTCxlQUFlO1lBQ2IsaUJBQWlCLFNBQVMsQ0FDeEI7YUFBRSxHQUFHLEtBQUs7YUFBSSxVQUFVO1lBQVcsQ0FDckMsQ0FBQztXQUNIO1dBQ0EsV0FBVyxpREFDVCxhQUFhLEVBQUUsRUFBRSxhQUFhLE1BQzFCLGtEQUNBO3FCQUdMO1VBQ0ssR0FkRDs7OztpQkFjQyxDQUNUO1NBQ0U7Ozs7aUJBQ0Y7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQStCO1NBQXFCOzs7O21CQUNyRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWjtXQUNDO1lBQUUsSUFBSTtZQUFlLE9BQU87V0FBd0I7V0FDcEQ7WUFBRSxJQUFJO1lBQVEsT0FBTztXQUFhO1dBQ2xDO1lBQUUsSUFBSTtZQUFVLE9BQU87V0FBb0I7V0FDM0M7WUFBRSxJQUFJO1lBQVMsT0FBTztXQUFtQjtVQUMzQyxDQUFDLENBQUMsS0FBSyxPQUNMLHdCQUFDLFVBQUQ7V0FFRSxNQUFLO1dBQ0wsZUFBZTtZQUNiLGlCQUFpQixTQUFTLENBQ3hCO2FBQUUsR0FBRyxLQUFLO2FBQUksT0FBTyxHQUFHO1lBQVUsQ0FDcEMsQ0FBQztXQUNIO1dBQ0EsV0FBVyw2Q0FDVCxhQUFhLEVBQUUsRUFBRSxVQUFVLEdBQUcsS0FDMUIsdURBQ0E7cUJBR0wsR0FBRztVQUNFLEdBZEQsR0FBRzs7OztpQkFjRixDQUNUO1NBQ0U7Ozs7aUJBQ0Y7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sWUFBZTs7OztvQkFDckIsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQXdDLGFBQWEsRUFBRSxFQUFFLFlBQVksSUFBRyxJQUFROzs7OztrQkFDN0U7Ozs7O21CQUNMLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsS0FBSTtVQUNKLEtBQUk7VUFDSixPQUFPLGFBQWEsRUFBRSxFQUFFLFlBQVk7VUFDcEMsV0FBVyxNQUFNO1dBQ2YsTUFBTSxLQUFLLE9BQU8sRUFBRSxPQUFPLEtBQUs7V0FDaEMsaUJBQWlCLFNBQVMsQ0FBQztZQUFFLEdBQUcsS0FBSztZQUFJLFVBQVU7V0FBRyxDQUFDLENBQUM7VUFDMUQ7VUFDQSxXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7OztPQUNGOzs7Ozs7TUFJTixrQkFBa0IsYUFDakIsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBb0Y7UUFFOUY7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFVBQUQ7WUFBUSxXQUFVO3NCQUFhO1dBQXFDOzs7O3FCQUNwRSx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLFNBQVM7WUFDVCxXQUFXLE1BQU0saUJBQWlCLEVBQUUsT0FBTyxPQUFPO1lBQ2xELFdBQVU7V0FDWDs7OzttQkFDRTs7Ozs7O1VBQ0wsd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPO1dBQ1AsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sS0FBSztXQUNoRCxhQUFZO1dBQ1osV0FBVTtVQUNYOzs7OztVQUVELHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUNaO1lBQUM7WUFBWTtZQUFhO1lBQWU7V0FBYyxDQUFDLENBQUMsS0FBSyxRQUM3RCx3QkFBQyxVQUFEO1lBRUUsTUFBSztZQUNMLGVBQWUsZ0JBQWdCLEdBQVU7WUFDekMsV0FBVyxrQ0FDVCxpQkFBaUIsTUFDYiwyQ0FDQTtzQkFHTCxJQUFJLFFBQVEsS0FBSyxHQUFHO1dBQ2YsR0FWRDs7OztrQkFVQyxDQUNUO1VBQ0U7Ozs7O1NBQ0Y7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1dBQVEsV0FBVTtxQkFBYTtVQUFxQzs7OztvQkFDcEUsd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQWpCLENBQXdGLFVBRXRGLHdCQUFDLFNBQUQ7WUFBTyxNQUFLO1lBQU8sUUFBTztZQUFVLFVBQVU7WUFBMEIsV0FBVTtXQUFVOzs7O21CQUN2Rjs7Ozs7a0JBQ0o7Ozs7O21CQUVKLGtCQUNDLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sZ0JBQW1COzs7O3NCQUN6Qix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBaEIsQ0FBd0MsS0FBSyxNQUFNLGVBQWUsR0FBRyxHQUFFLEdBQU87Ozs7O29CQUMzRTs7Ozs7O1dBQ0wsd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxLQUFJO1lBQ0osS0FBSTtZQUNKLE1BQUs7WUFDTCxPQUFPO1lBQ1AsV0FBVyxNQUFNLGdCQUFnQixPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7WUFDdkQsV0FBVTtXQUNYOzs7OztXQUVELHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLFVBQWE7Ozs7c0JBQ25CLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFoQixDQUF3QyxLQUFLLE1BQU0saUJBQWlCLEdBQUcsR0FBRSxHQUFPOzs7OztvQkFDN0U7Ozs7OztXQUNMLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsS0FBSTtZQUNKLEtBQUk7WUFDSixNQUFLO1lBQ0wsT0FBTztZQUNQLFdBQVcsTUFBTSxrQkFBa0IsT0FBTyxFQUFFLE9BQU8sS0FBSyxDQUFDO1lBQ3pELFdBQVU7V0FDWDs7Ozs7VUFDRTs7Ozs7b0JBRUwsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQTZCO1NBRXZDOzs7O2lCQUVGOzs7Ozs7T0FDRjs7Ozs7O01BSU4sa0JBQWtCLFdBQ2pCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQW9GO1FBRTlGOzs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEIsQ0FBNEMsd0JBQUMsU0FBRCxFQUFTLFdBQVUsd0JBQXlCOzs7O3FCQUFDLG1CQUF1Qjs7Ozs7b0JBQ2hILHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUF3QyxjQUFhLEdBQU87Ozs7O2tCQUN6RDs7Ozs7bUJBQ0wsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxLQUFJO1VBQ0osS0FBSTtVQUNKLE9BQU87VUFDUCxXQUFXLE1BQU07V0FDZixNQUFNLE1BQU0sT0FBTyxFQUFFLE9BQU8sS0FBSztXQUNqQyxnQkFBZ0IsR0FBRztXQUNuQixJQUFJLFNBQVMsU0FBUyxTQUFTLFFBQVEsU0FBUyxLQUFLLElBQUksR0FBSyxNQUFNLEdBQUc7VUFDekU7VUFDQSxXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEIsQ0FBNEMsd0JBQUMsT0FBRCxFQUFPLFdBQVUseUJBQTBCOzs7O3FCQUFDLHNCQUEwQjs7Ozs7b0JBQ2xILHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUF3QyxhQUFZLEdBQU87Ozs7O2tCQUN4RDs7Ozs7bUJBQ0wsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxLQUFJO1VBQ0osS0FBSTtVQUNKLE9BQU87VUFDUCxXQUFXLE1BQU07V0FDZixNQUFNLE1BQU0sT0FBTyxFQUFFLE9BQU8sS0FBSztXQUNqQyxlQUFlLEdBQUc7V0FDbEIsSUFBSSxTQUFTLFNBQVMsU0FBUyxRQUFRLFNBQVMsTUFBTTtVQUN4RDtVQUNBLFdBQVU7U0FDWDs7OztpQkFDRTs7Ozs7O09BQ0Y7Ozs7OztLQUVKOzs7OztZQUNGOzs7Ozs7RUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiVmlkZW9TdHVkaW9WaWV3LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZVJlZiwgdXNlRWZmZWN0LCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICBGaWxtLCBcbiAgVmlkZW8sIFxuICBQbGF5LCBcbiAgUGF1c2UsIFxuICBSb3RhdGVDY3csIFxuICBTY2lzc29ycywgXG4gIFZvbHVtZTIsIFxuICBWb2x1bWVYLCBcbiAgUm90YXRlQ3csIFxuICBUeXBlLCBcbiAgSW1hZ2UgYXMgSW1hZ2VJY29uLCBcbiAgTXVzaWMsIFxuICBEb3dubG9hZCwgXG4gIExheWVycywgXG4gIFNsaWRlcnMsIFxuICBTcGFya2xlcywgXG4gIENsb2NrLCBcbiAgVXBsb2FkLCBcbiAgUmVmcmVzaEN3LCBcbiAgQ2hlY2ssIFxuICBGYXN0Rm9yd2FyZCwgXG4gIFJld2luZCwgXG4gIFBsdXMsIFxuICBUcmFzaDIsIFxuICBFeWUsIFxuICBFeWVPZmYsIFxuICBGbGFtZSwgXG4gIFN1biwgXG4gIENvbnRyYXN0LCBcbiAgRHJvcGxldHMsIFxuICBDaGVja0NpcmNsZTIsIFxuICBDYW1lcmEsXG4gIEZvbGRlckRvd24sXG4gIEZpbGVWaWRlbyxcbiAgU3BsaXRTcXVhcmVWZXJ0aWNhbCxcbiAgRmxpcEhvcml6b250YWwsXG4gIEZsaXBWZXJ0aWNhbFxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgRG93bmxvYWRJdGVtIH0gZnJvbSAnLi4vdHlwZXMnO1xuXG5pbnRlcmZhY2UgVmlkZW9TdHVkaW9WaWV3UHJvcHMge1xuICBvbkFkZERvd25sb2FkPzogKGRvd25sb2FkOiBEb3dubG9hZEl0ZW0pID0+IHZvaWQ7XG4gIG9uTmF2aWdhdGU/OiAodGFiOiBzdHJpbmcpID0+IHZvaWQ7XG59XG5cbnR5cGUgQXNwZWN0UmF0aW8gPSAnMTY6OScgfCAnOToxNicgfCAnMToxJyB8ICc0OjUnO1xuXG5pbnRlcmZhY2UgVGV4dE92ZXJsYXkge1xuICBpZDogc3RyaW5nO1xuICB0ZXh0OiBzdHJpbmc7XG4gIGZvbnRTaXplOiBudW1iZXI7XG4gIGNvbG9yOiBzdHJpbmc7XG4gIGJnQ29sb3I6IHN0cmluZztcbiAgcG9zaXRpb246ICd0b3AnIHwgJ2NlbnRlcicgfCAnYm90dG9tJztcbiAgc3R5bGU6ICdiYW5uZXInIHwgJ2NsZWFuJyB8ICduZW9uJyB8ICdsb3dlcl90aGlyZCc7XG4gIHN0YXJ0VGltZTogbnVtYmVyO1xuICBlbmRUaW1lOiBudW1iZXI7XG59XG5cbmludGVyZmFjZSBBdWRpb1RyYWNrIHtcbiAgaWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICBzcmM6IHN0cmluZztcbiAgdm9sdW1lOiBudW1iZXI7XG4gIGlzTXV0ZWQ6IGJvb2xlYW47XG59XG5cbmV4cG9ydCBjb25zdCBWaWRlb1N0dWRpb1ZpZXc6IFJlYWN0LkZDPFZpZGVvU3R1ZGlvVmlld1Byb3BzPiA9ICh7IG9uQWRkRG93bmxvYWQgfSkgPT4ge1xuICAvLyBWaWRlbyBTb3VyY2UgJiBFbGVtZW50XG4gIGNvbnN0IFt2aWRlb1NyYywgc2V0VmlkZW9TcmNdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFt2aWRlb0ZpbGVOYW1lLCBzZXRWaWRlb0ZpbGVOYW1lXSA9IHVzZVN0YXRlPHN0cmluZz4oJ3Byb2plY3RfdmlkZW8ubXA0Jyk7XG4gIGNvbnN0IHZpZGVvUmVmID0gdXNlUmVmPEhUTUxWaWRlb0VsZW1lbnQgfCBudWxsPihudWxsKTtcbiAgY29uc3QgY2FudmFzUmVmID0gdXNlUmVmPEhUTUxDYW52YXNFbGVtZW50IHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gU2Vjb25kYXJ5IE92ZXJsYXkgSW1hZ2UvVmlkZW8gVHJhY2sgKFRyYWNrIDIpXG4gIGNvbnN0IFtvdmVybGF5SW1hZ2VTcmMsIHNldE92ZXJsYXlJbWFnZVNyY10gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW292ZXJsYXlTY2FsZSwgc2V0T3ZlcmxheVNjYWxlXSA9IHVzZVN0YXRlPG51bWJlcj4oMC4zKTtcbiAgY29uc3QgW292ZXJsYXlQb3NpdGlvbiwgc2V0T3ZlcmxheVBvc2l0aW9uXSA9IHVzZVN0YXRlPCd0b3AtcmlnaHQnIHwgJ3RvcC1sZWZ0JyB8ICdib3R0b20tcmlnaHQnIHwgJ2JvdHRvbS1sZWZ0JyB8ICdjZW50ZXInPigndG9wLXJpZ2h0Jyk7XG4gIGNvbnN0IFtvdmVybGF5T3BhY2l0eSwgc2V0T3ZlcmxheU9wYWNpdHldID0gdXNlU3RhdGU8bnVtYmVyPigwLjkpO1xuICBjb25zdCBvdmVybGF5SW1nUmVmID0gdXNlUmVmPEhUTUxJbWFnZUVsZW1lbnQgfCBudWxsPihudWxsKTtcblxuICAvLyBBdWRpbyAvIE11c2ljIFRyYWNrIChUcmFjayAzKVxuICBjb25zdCBbbXVzaWNTcmMsIHNldE11c2ljU3JjXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbbXVzaWNWb2x1bWUsIHNldE11c2ljVm9sdW1lXSA9IHVzZVN0YXRlPG51bWJlcj4oNzApO1xuICBjb25zdCBbaXNNdXNpY011dGVkLCBzZXRJc011c2ljTXV0ZWRdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBhdWRpb1JlZiA9IHVzZVJlZjxIVE1MQXVkaW9FbGVtZW50IHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gUGxheWJhY2sgJiBUaW1pbmdcbiAgY29uc3QgW2lzUGxheWluZywgc2V0SXNQbGF5aW5nXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW2N1cnJlbnRUaW1lLCBzZXRDdXJyZW50VGltZV0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCBbZHVyYXRpb24sIHNldER1cmF0aW9uXSA9IHVzZVN0YXRlPG51bWJlcj4oMTApO1xuICBjb25zdCBbaW5Qb2ludCwgc2V0SW5Qb2ludF0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCBbb3V0UG9pbnQsIHNldE91dFBvaW50XSA9IHVzZVN0YXRlPG51bWJlcj4oMTApO1xuICBjb25zdCBbcGxheWJhY2tTcGVlZCwgc2V0UGxheWJhY2tTcGVlZF0gPSB1c2VTdGF0ZTxudW1iZXI+KDEuMCk7XG4gIGNvbnN0IFttYXN0ZXJWb2x1bWUsIHNldE1hc3RlclZvbHVtZV0gPSB1c2VTdGF0ZTxudW1iZXI+KDEwMCk7XG4gIGNvbnN0IFtpc01hc3Rlck11dGVkLCBzZXRJc01hc3Rlck11dGVkXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW2lzTG9vcGluZywgc2V0SXNMb29waW5nXSA9IHVzZVN0YXRlPGJvb2xlYW4+KHRydWUpO1xuXG4gIC8vIENhbnZhcyBHZW9tZXRyeSAmIEFzcGVjdCBSYXRpb1xuICBjb25zdCBbYXNwZWN0UmF0aW8sIHNldEFzcGVjdFJhdGlvXSA9IHVzZVN0YXRlPEFzcGVjdFJhdGlvPignMTY6OScpO1xuICBjb25zdCBbcm90YXRpb24sIHNldFJvdGF0aW9uXSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7IC8vIDAsIDkwLCAxODAsIDI3MFxuICBjb25zdCBbZmxpcEgsIHNldEZsaXBIXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW2ZsaXBWLCBzZXRGbGlwVl0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG4gIGNvbnN0IFt6b29tTGV2ZWwsIHNldFpvb21MZXZlbF0gPSB1c2VTdGF0ZTxudW1iZXI+KDEuMCk7XG5cbiAgLy8gQ29sb3IgR3JhZGluZyAmIEZpbHRlcnNcbiAgY29uc3QgW2JyaWdodG5lc3MsIHNldEJyaWdodG5lc3NdID0gdXNlU3RhdGU8bnVtYmVyPigwKTtcbiAgY29uc3QgW2NvbnRyYXN0LCBzZXRDb250cmFzdF0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCBbc2F0dXJhdGlvbiwgc2V0U2F0dXJhdGlvbl0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCBbd2FybXRoLCBzZXRXYXJtdGhdID0gdXNlU3RhdGU8bnVtYmVyPigwKTtcbiAgY29uc3QgW2ZpbHRlclByZXNldCwgc2V0RmlsdGVyUHJlc2V0XSA9IHVzZVN0YXRlPHN0cmluZz4oJ25vcm1hbCcpO1xuXG4gIC8vIFRleHQgJiBUaXRsZSBMYXllcnMgKFRyYWNrIDQpXG4gIGNvbnN0IFt0ZXh0T3ZlcmxheXMsIHNldFRleHRPdmVybGF5c10gPSB1c2VTdGF0ZTxUZXh0T3ZlcmxheVtdPihbXG4gICAge1xuICAgICAgaWQ6ICd0eHQtMScsXG4gICAgICB0ZXh0OiAnTXV6YW1taWwgT25saW5lIFNlcnZpY2Ug4oCiIENTQyBDeWJlciBDYWZlJyxcbiAgICAgIGZvbnRTaXplOiAyOCxcbiAgICAgIGNvbG9yOiAnI2ZmZmZmZicsXG4gICAgICBiZ0NvbG9yOiAncmdiYSgxNSwgMjMsIDQyLCAwLjg1KScsXG4gICAgICBwb3NpdGlvbjogJ2JvdHRvbScsXG4gICAgICBzdHlsZTogJ2xvd2VyX3RoaXJkJyxcbiAgICAgIHN0YXJ0VGltZTogMCxcbiAgICAgIGVuZFRpbWU6IDEwXG4gICAgfVxuICBdKTtcbiAgY29uc3QgW2FjdGl2ZVRleHRJZCwgc2V0QWN0aXZlVGV4dElkXSA9IHVzZVN0YXRlPHN0cmluZz4oJ3R4dC0xJyk7XG5cbiAgLy8gV2F0ZXJtYXJrIC8gQ3liZXIgQ2FmZSBTdGFtcCAoVHJhY2sgNSlcbiAgY29uc3QgW3Nob3dXYXRlcm1hcmssIHNldFNob3dXYXRlcm1hcmtdID0gdXNlU3RhdGU8Ym9vbGVhbj4odHJ1ZSk7XG4gIGNvbnN0IFt3YXRlcm1hcmtUZXh0LCBzZXRXYXRlcm1hcmtUZXh0XSA9IHVzZVN0YXRlPHN0cmluZz4oJ011emFtbWlsIE9ubGluZSDigKIgOTU2MTQ2MDMxMycpO1xuICBjb25zdCBbd2F0ZXJtYXJrUG9zLCBzZXRXYXRlcm1hcmtQb3NdID0gdXNlU3RhdGU8J3RvcC1sZWZ0JyB8ICd0b3AtcmlnaHQnIHwgJ2JvdHRvbS1sZWZ0JyB8ICdib3R0b20tcmlnaHQnPigndG9wLXJpZ2h0Jyk7XG4gIGNvbnN0IFt3YXRlcm1hcmtPcGFjaXR5LCBzZXRXYXRlcm1hcmtPcGFjaXR5XSA9IHVzZVN0YXRlPG51bWJlcj4oMC44KTtcblxuICAvLyBBY3RpdmUgRWRpdGluZyBTdWItRGVjazogJ3RpbWVsaW5lJyB8ICdjb2xvcicgfCAnYXVkaW8nIHwgJ3RleHQnIHwgJ292ZXJsYXknIHwgJ2Nyb3AnXG4gIGNvbnN0IFthY3RpdmVUb29sVGFiLCBzZXRBY3RpdmVUb29sVGFiXSA9IHVzZVN0YXRlPCd0aW1lbGluZScgfCAnY29sb3InIHwgJ2F1ZGlvJyB8ICd0ZXh0JyB8ICdvdmVybGF5JyB8ICdjcm9wJz4oJ3RpbWVsaW5lJyk7XG5cbiAgLy8gVGltZWxpbmUgVUkgc3RhdGVcbiAgY29uc3QgW3RpbWVsaW5lWm9vbSwgc2V0VGltZWxpbmVab29tXSA9IHVzZVN0YXRlPG51bWJlcj4oMSk7XG4gIGNvbnN0IFtpc0V4cG9ydGluZywgc2V0SXNFeHBvcnRpbmddID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbZXhwb3J0UHJvZ3Jlc3MsIHNldEV4cG9ydFByb2dyZXNzXSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7XG4gIGNvbnN0IFtzdGF0dXNBbGVydCwgc2V0U3RhdHVzQWxlcnRdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gTWVkaWFSZWNvcmRlciBSZWYgZm9yIFZpZGVvIFJlbmRlclxuICBjb25zdCByZWNvcmRlclJlZiA9IHVzZVJlZjxNZWRpYVJlY29yZGVyIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHJlY29yZGVkQmxvYnNSZWYgPSB1c2VSZWY8QmxvYltdPihbXSk7XG5cbiAgLy8gUmVzb2x1dGlvbiB0YXJnZXRzIGJhc2VkIG9uIGFzcGVjdCByYXRpb1xuICBjb25zdCBnZXRDYW52YXNEaW1lbnNpb25zID0gdXNlQ2FsbGJhY2soKCk6IHsgd2lkdGg6IG51bWJlcjsgaGVpZ2h0OiBudW1iZXIgfSA9PiB7XG4gICAgc3dpdGNoIChhc3BlY3RSYXRpbykge1xuICAgICAgY2FzZSAnMTY6OSc6IHJldHVybiB7IHdpZHRoOiAxMjgwLCBoZWlnaHQ6IDcyMCB9O1xuICAgICAgY2FzZSAnOToxNic6IHJldHVybiB7IHdpZHRoOiA3MjAsIGhlaWdodDogMTI4MCB9O1xuICAgICAgY2FzZSAnMToxJzogcmV0dXJuIHsgd2lkdGg6IDEwODAsIGhlaWdodDogMTA4MCB9O1xuICAgICAgY2FzZSAnNDo1JzogcmV0dXJuIHsgd2lkdGg6IDg2NCwgaGVpZ2h0OiAxMDgwIH07XG4gICAgICBkZWZhdWx0OiByZXR1cm4geyB3aWR0aDogMTI4MCwgaGVpZ2h0OiA3MjAgfTtcbiAgICB9XG4gIH0sIFthc3BlY3RSYXRpb10pO1xuXG4gIC8vIEZvcm1hdCBzZWNvbmRzIHRvIDAwOjAwOjAwXG4gIGNvbnN0IGZvcm1hdFRpbWUgPSAoc2Vjb25kczogbnVtYmVyKSA9PiB7XG4gICAgY29uc3QgbWlucyA9IE1hdGguZmxvb3Ioc2Vjb25kcyAvIDYwKTtcbiAgICBjb25zdCBzZWNzID0gTWF0aC5mbG9vcihzZWNvbmRzICUgNjApO1xuICAgIGNvbnN0IG1zID0gTWF0aC5mbG9vcigoc2Vjb25kcyAlIDEpICogMTApO1xuICAgIHJldHVybiBgJHtTdHJpbmcobWlucykucGFkU3RhcnQoMiwgJzAnKX06JHtTdHJpbmcoc2VjcykucGFkU3RhcnQoMiwgJzAnKX0uJHttc31gO1xuICB9O1xuXG4gIC8vIDEuIEdlbmVyYXRlIEludGVyYWN0aXZlIE1vdGlvbiBTYW1wbGUgVmlkZW8gb24gQ2FudmFzIGlmIG5vIGZpbGUgdXBsb2FkZWRcbiAgY29uc3QgaGFuZGxlTG9hZFNhbXBsZVZpZGVvID0gKCkgPT4ge1xuICAgIGNvbnN0IHNhbXBsZUNhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xuICAgIHNhbXBsZUNhbnZhcy53aWR0aCA9IDEyODA7XG4gICAgc2FtcGxlQ2FudmFzLmhlaWdodCA9IDcyMDtcbiAgICBjb25zdCBzQ3R4ID0gc2FtcGxlQ2FudmFzLmdldENvbnRleHQoJzJkJyk7XG4gICAgaWYgKCFzQ3R4KSByZXR1cm47XG5cbiAgICAvLyBVc2UgV2ViTS9NUDQgZ2VuZXJhdG9yIHN0cmVhbVxuICAgIGNvbnN0IHN0cmVhbSA9IHNhbXBsZUNhbnZhcy5jYXB0dXJlU3RyZWFtKDMwKTtcbiAgICBjb25zdCByZWMgPSBuZXcgTWVkaWFSZWNvcmRlcihzdHJlYW0sIHsgbWltZVR5cGU6ICd2aWRlby93ZWJtJyB9KTtcbiAgICBjb25zdCBjaHVua3M6IEJsb2JbXSA9IFtdO1xuXG4gICAgcmVjLm9uZGF0YWF2YWlsYWJsZSA9IChlKSA9PiB7XG4gICAgICBpZiAoZS5kYXRhLnNpemUgPiAwKSBjaHVua3MucHVzaChlLmRhdGEpO1xuICAgIH07XG5cbiAgICByZWMub25zdG9wID0gKCkgPT4ge1xuICAgICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKGNodW5rcywgeyB0eXBlOiAndmlkZW8vd2VibScgfSk7XG4gICAgICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xuICAgICAgc2V0VmlkZW9TcmModXJsKTtcbiAgICAgIHNldFZpZGVvRmlsZU5hbWUoJ0N5YmVyQ2FmZV9TYW1wbGVfRGVtby53ZWJtJyk7XG4gICAgICBzZXREdXJhdGlvbig4KTtcbiAgICAgIHNldEluUG9pbnQoMCk7XG4gICAgICBzZXRPdXRQb2ludCg4KTtcbiAgICAgIHNldEN1cnJlbnRUaW1lKDApO1xuICAgICAgc2V0U3RhdHVzQWxlcnQoJ/CfjqwgU2FtcGxlIEN5YmVyIENhZmUgVmlkZW8gY2xpcCBnZW5lcmF0ZWQgc3VjY2Vzc2Z1bGx5IScpO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRTdGF0dXNBbGVydChudWxsKSwgMzUwMCk7XG4gICAgfTtcblxuICAgIHJlYy5zdGFydCgpO1xuXG4gICAgLy8gUmVuZGVyIDggc2Vjb25kcyBvZiBkeW5hbWljIGN5YmVyIGdyYXBoaWNzIGFuaW1hdGlvblxuICAgIGxldCBmcmFtZSA9IDA7XG4gICAgY29uc3QgdG90YWxGcmFtZXMgPSA4ICogMzA7IC8vIDI0MCBmcmFtZXNcbiAgICBjb25zdCBhbmltSW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICBmcmFtZSsrO1xuICAgICAgY29uc3QgcHJvZ3Jlc3MgPSBmcmFtZSAvIHRvdGFsRnJhbWVzO1xuICAgICAgY29uc3QgdGltZVNlYyA9IGZyYW1lIC8gMzA7XG5cbiAgICAgIC8vIERhcmsgY3liZXIgYmFja2dyb3VuZFxuICAgICAgY29uc3QgZ3JhZCA9IHNDdHguY3JlYXRlTGluZWFyR3JhZGllbnQoMCwgMCwgMTI4MCwgNzIwKTtcbiAgICAgIGdyYWQuYWRkQ29sb3JTdG9wKDAsICcjMDIwNjE3Jyk7XG4gICAgICBncmFkLmFkZENvbG9yU3RvcCgwLjUsICcjMGYxNzJhJyk7XG4gICAgICBncmFkLmFkZENvbG9yU3RvcCgxLCAnIzFlMWI0YicpO1xuICAgICAgc0N0eC5maWxsU3R5bGUgPSBncmFkO1xuICAgICAgc0N0eC5maWxsUmVjdCgwLCAwLCAxMjgwLCA3MjApO1xuXG4gICAgICAvLyBNb3ZpbmcgR3JpZCBsaW5lc1xuICAgICAgc0N0eC5zdHJva2VTdHlsZSA9ICdyZ2JhKDU2LCAxODksIDI0OCwgMC4xNSknO1xuICAgICAgc0N0eC5saW5lV2lkdGggPSAxO1xuICAgICAgY29uc3Qgb2Zmc2V0ID0gKGZyYW1lICogMikgJSA0MDtcbiAgICAgIGZvciAobGV0IHggPSBvZmZzZXQ7IHggPCAxMjgwOyB4ICs9IDQwKSB7XG4gICAgICAgIHNDdHguYmVnaW5QYXRoKCk7XG4gICAgICAgIHNDdHgubW92ZVRvKHgsIDApO1xuICAgICAgICBzQ3R4LmxpbmVUbyh4LCA3MjApO1xuICAgICAgICBzQ3R4LnN0cm9rZSgpO1xuICAgICAgfVxuICAgICAgZm9yIChsZXQgeSA9IG9mZnNldDsgeSA8IDcyMDsgeSArPSA0MCkge1xuICAgICAgICBzQ3R4LmJlZ2luUGF0aCgpO1xuICAgICAgICBzQ3R4Lm1vdmVUbygwLCB5KTtcbiAgICAgICAgc0N0eC5saW5lVG8oMTI4MCwgeSk7XG4gICAgICAgIHNDdHguc3Ryb2tlKCk7XG4gICAgICB9XG5cbiAgICAgIC8vIEdsb3dpbmcgQ2VudGVyIENhcmRcbiAgICAgIHNDdHguc2F2ZSgpO1xuICAgICAgc0N0eC50cmFuc2xhdGUoNjQwLCAzNjApO1xuICAgICAgc0N0eC5yb3RhdGUoTWF0aC5zaW4ocHJvZ3Jlc3MgKiBNYXRoLlBJICogMikgKiAwLjA1KTtcblxuICAgICAgc0N0eC5maWxsU3R5bGUgPSAncmdiYSgxNSwgMjMsIDQyLCAwLjkpJztcbiAgICAgIHNDdHguc3Ryb2tlU3R5bGUgPSAnIzM4YmRmOCc7XG4gICAgICBzQ3R4LmxpbmVXaWR0aCA9IDQ7XG4gICAgICBzQ3R4LmJlZ2luUGF0aCgpO1xuICAgICAgc0N0eC5yb3VuZFJlY3QoLTMwMCwgLTE4MCwgNjAwLCAzNjAsIDI0KTtcbiAgICAgIHNDdHguZmlsbCgpO1xuICAgICAgc0N0eC5zdHJva2UoKTtcblxuICAgICAgLy8gQnJhbmQgVGl0bGVcbiAgICAgIHNDdHguZmlsbFN0eWxlID0gJyNmZmZmZmYnO1xuICAgICAgc0N0eC5mb250ID0gJ2JvbGQgMzhweCBzYW5zLXNlcmlmJztcbiAgICAgIHNDdHgudGV4dEFsaWduID0gJ2NlbnRlcic7XG4gICAgICBzQ3R4LmZpbGxUZXh0KCdNVVpBTU1JTCBPTkxJTkUgU0VSVklDRScsIDAsIC02MCk7XG5cbiAgICAgIC8vIFN1YnRpdGxlXG4gICAgICBzQ3R4LmZpbGxTdHlsZSA9ICcjMzhiZGY4JztcbiAgICAgIHNDdHguZm9udCA9ICdib2xkIDIycHggc2Fucy1zZXJpZic7XG4gICAgICBzQ3R4LmZpbGxUZXh0KCdDU0MgJiBDeWJlciBDYWZlIFByb2Zlc3Npb25hbCBWaWRlbyBTdHVkaW8nLCAwLCAtMTUpO1xuXG4gICAgICAvLyBGbG9hdGluZyBwYXJ0aWNsZXNcbiAgICAgIHNDdHguZmlsbFN0eWxlID0gJyMyMmM1NWUnO1xuICAgICAgc0N0eC5mb250ID0gJzE2cHggbW9ub3NwYWNlJztcbiAgICAgIHNDdHguZmlsbFRleHQoYExJVkUgVElNRUNPREU6IDAwOjAke01hdGguZmxvb3IodGltZVNlYyl9LiR7KGZyYW1lICUgMzApfWAsIDAsIDQ1KTtcblxuICAgICAgc0N0eC5maWxsU3R5bGUgPSAnIzk0YTNiOCc7XG4gICAgICBzQ3R4LmZvbnQgPSAnMTRweCBzYW5zLXNlcmlmJztcbiAgICAgIHNDdHguZmlsbFRleHQoJ1BWQyBDYXJkIOKAoiBQYXNzcG9ydCBQaG90byDigKIgT25saW5lIENpdGl6ZW4gU2VydmljZXMnLCAwLCA5NSk7XG5cbiAgICAgIHNDdHgucmVzdG9yZSgpO1xuXG4gICAgICBpZiAoZnJhbWUgPj0gdG90YWxGcmFtZXMpIHtcbiAgICAgICAgY2xlYXJJbnRlcnZhbChhbmltSW50ZXJ2YWwpO1xuICAgICAgICByZWMuc3RvcCgpO1xuICAgICAgfVxuICAgIH0sIDEwMDAgLyAzMCk7XG4gIH07XG5cbiAgLy8gVmlkZW8gRmlsZSBVcGxvYWQgSGFuZGxlclxuICBjb25zdCBoYW5kbGVVcGxvYWRWaWRlbyA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xuICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgIGlmICghZmlsZSkgcmV0dXJuO1xuXG4gICAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChmaWxlKTtcbiAgICBzZXRWaWRlb1NyYyh1cmwpO1xuICAgIHNldFZpZGVvRmlsZU5hbWUoZmlsZS5uYW1lKTtcbiAgICBzZXRDdXJyZW50VGltZSgwKTtcbiAgICBzZXRJc1BsYXlpbmcoZmFsc2UpO1xuICAgIHNldFN0YXR1c0FsZXJ0KGDwn46sIFZpZGVvIFwiJHtmaWxlLm5hbWV9XCIgbG9hZGVkIGludG8gTXVsdGktTGF5ZXIgVGltZWxpbmUhYCk7XG4gICAgc2V0VGltZW91dCgoKSA9PiBzZXRTdGF0dXNBbGVydChudWxsKSwgMzUwMCk7XG4gIH07XG5cbiAgLy8gT3ZlcmxheSBJbWFnZSBVcGxvYWQgKFRyYWNrIDIpXG4gIGNvbnN0IGhhbmRsZVVwbG9hZE92ZXJsYXlJbWFnZSA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xuICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgIGlmICghZmlsZSkgcmV0dXJuO1xuXG4gICAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChmaWxlKTtcbiAgICBzZXRPdmVybGF5SW1hZ2VTcmModXJsKTtcbiAgICBjb25zdCBpbWcgPSBuZXcgSW1hZ2UoKTtcbiAgICBpbWcuc3JjID0gdXJsO1xuICAgIGltZy5vbmxvYWQgPSAoKSA9PiB7XG4gICAgICBvdmVybGF5SW1nUmVmLmN1cnJlbnQgPSBpbWc7XG4gICAgfTtcbiAgICBzZXRTdGF0dXNBbGVydCgn8J+WvO+4jyBPdmVybGF5IFBpY3R1cmUtaW4tUGljdHVyZSBhZGRlZCB0byBUcmFjayAyIScpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0U3RhdHVzQWxlcnQobnVsbCksIDMwMDApO1xuICB9O1xuXG4gIC8vIEJhY2tncm91bmQgQXVkaW8gVXBsb2FkIChUcmFjayAzKVxuICBjb25zdCBoYW5kbGVVcGxvYWRNdXNpYyA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PikgPT4ge1xuICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgIGlmICghZmlsZSkgcmV0dXJuO1xuXG4gICAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChmaWxlKTtcbiAgICBzZXRNdXNpY1NyYyh1cmwpO1xuICAgIHNldFN0YXR1c0FsZXJ0KGDwn461IEF1ZGlvIFRyYWNrIFwiJHtmaWxlLm5hbWV9XCIgYWRkZWQgdG8gVHJhY2sgMyFgKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldFN0YXR1c0FsZXJ0KG51bGwpLCAzMDAwKTtcbiAgfTtcblxuICAvLyBWaWRlbyBNZXRhZGF0YSBMb2FkZWRcbiAgY29uc3QgaGFuZGxlVmlkZW9Mb2FkZWRNZXRhZGF0YSA9ICgpID0+IHtcbiAgICBjb25zdCB2ID0gdmlkZW9SZWYuY3VycmVudDtcbiAgICBpZiAoIXYpIHJldHVybjtcbiAgICBjb25zdCBkdXIgPSB2LmR1cmF0aW9uIHx8IDEwO1xuICAgIHNldER1cmF0aW9uKGR1cik7XG4gICAgc2V0SW5Qb2ludCgwKTtcbiAgICBzZXRPdXRQb2ludChkdXIpO1xuICB9O1xuXG4gIC8vIFRvZ2dsZSBQbGF5IC8gUGF1c2VcbiAgY29uc3QgaGFuZGxlVG9nZ2xlUGxheSA9ICgpID0+IHtcbiAgICBjb25zdCB2ID0gdmlkZW9SZWYuY3VycmVudDtcbiAgICBpZiAoIXYpIHJldHVybjtcblxuICAgIGlmIChpc1BsYXlpbmcpIHtcbiAgICAgIHYucGF1c2UoKTtcbiAgICAgIGlmIChhdWRpb1JlZi5jdXJyZW50KSBhdWRpb1JlZi5jdXJyZW50LnBhdXNlKCk7XG4gICAgICBzZXRJc1BsYXlpbmcoZmFsc2UpO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBMb29wIGlmIGF0IGVuZFxuICAgICAgaWYgKGN1cnJlbnRUaW1lID49IG91dFBvaW50KSB7XG4gICAgICAgIHYuY3VycmVudFRpbWUgPSBpblBvaW50O1xuICAgICAgICBzZXRDdXJyZW50VGltZShpblBvaW50KTtcbiAgICAgIH1cbiAgICAgIHYucGxheWJhY2tSYXRlID0gcGxheWJhY2tTcGVlZDtcbiAgICAgIHYudm9sdW1lID0gaXNNYXN0ZXJNdXRlZCA/IDAgOiBNYXRoLm1pbigxLjAsIG1hc3RlclZvbHVtZSAvIDEwMCk7XG4gICAgICB2LnBsYXkoKTtcblxuICAgICAgaWYgKGF1ZGlvUmVmLmN1cnJlbnQgJiYgbXVzaWNTcmMpIHtcbiAgICAgICAgYXVkaW9SZWYuY3VycmVudC5jdXJyZW50VGltZSA9IHYuY3VycmVudFRpbWU7XG4gICAgICAgIGF1ZGlvUmVmLmN1cnJlbnQudm9sdW1lID0gaXNNdXNpY011dGVkID8gMCA6IE1hdGgubWluKDEuMCwgbXVzaWNWb2x1bWUgLyAxMDApO1xuICAgICAgICBhdWRpb1JlZi5jdXJyZW50LnBsYXkoKTtcbiAgICAgIH1cbiAgICAgIHNldElzUGxheWluZyh0cnVlKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gUGxheWhlYWQgc2NydWJcbiAgY29uc3QgaGFuZGxlU2VlayA9IChuZXdUaW1lOiBudW1iZXIpID0+IHtcbiAgICBjb25zdCBjbGFtcGVkID0gTWF0aC5tYXgoMCwgTWF0aC5taW4oZHVyYXRpb24sIG5ld1RpbWUpKTtcbiAgICBzZXRDdXJyZW50VGltZShjbGFtcGVkKTtcbiAgICBpZiAodmlkZW9SZWYuY3VycmVudCkge1xuICAgICAgdmlkZW9SZWYuY3VycmVudC5jdXJyZW50VGltZSA9IGNsYW1wZWQ7XG4gICAgfVxuICAgIGlmIChhdWRpb1JlZi5jdXJyZW50KSB7XG4gICAgICBhdWRpb1JlZi5jdXJyZW50LmN1cnJlbnRUaW1lID0gY2xhbXBlZDtcbiAgICB9XG4gIH07XG5cbiAgLy8gVHJpbSBQb2ludHNcbiAgY29uc3QgaGFuZGxlU2V0SW5Qb2ludCA9ICgpID0+IHtcbiAgICBzZXRJblBvaW50KGN1cnJlbnRUaW1lKTtcbiAgICBzZXRTdGF0dXNBbGVydChg4pyC77iPIEluLVBvaW50IChDdXQgU3RhcnQpIHNldCB0byAke2Zvcm1hdFRpbWUoY3VycmVudFRpbWUpfWApO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0U3RhdHVzQWxlcnQobnVsbCksIDI1MDApO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVNldE91dFBvaW50ID0gKCkgPT4ge1xuICAgIHNldE91dFBvaW50KGN1cnJlbnRUaW1lKTtcbiAgICBzZXRTdGF0dXNBbGVydChg4pyC77iPIE91dC1Qb2ludCAoQ3V0IEVuZCkgc2V0IHRvICR7Zm9ybWF0VGltZShjdXJyZW50VGltZSl9YCk7XG4gICAgc2V0VGltZW91dCgoKSA9PiBzZXRTdGF0dXNBbGVydChudWxsKSwgMjUwMCk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlUmVzZXRUcmltID0gKCkgPT4ge1xuICAgIHNldEluUG9pbnQoMCk7XG4gICAgc2V0T3V0UG9pbnQoZHVyYXRpb24pO1xuICAgIHNldFN0YXR1c0FsZXJ0KCfwn5SEIFRyaW0gcmFuZ2UgcmVzZXQgdG8gZnVsbCB2aWRlbycpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0U3RhdHVzQWxlcnQobnVsbCksIDIwMDApO1xuICB9O1xuXG4gIC8vIFNwZWVkIGNoYW5nZXJcbiAgY29uc3QgaGFuZGxlU3BlZWRDaGFuZ2UgPSAoc3BlZWQ6IG51bWJlcikgPT4ge1xuICAgIHNldFBsYXliYWNrU3BlZWQoc3BlZWQpO1xuICAgIGlmICh2aWRlb1JlZi5jdXJyZW50KSB7XG4gICAgICB2aWRlb1JlZi5jdXJyZW50LnBsYXliYWNrUmF0ZSA9IHNwZWVkO1xuICAgIH1cbiAgICBzZXRTdGF0dXNBbGVydChg4pqhIFBsYXliYWNrIHNwZWVkIHNldCB0byAke3NwZWVkfXhgKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldFN0YXR1c0FsZXJ0KG51bGwpLCAyMDAwKTtcbiAgfTtcblxuICAvLyBTbmFwc2hvdCBjdXJyZW50IGZyYW1lIGFzIDEwODBwIEpQR1xuICBjb25zdCBoYW5kbGVDYXB0dXJlU25hcHNob3QgPSAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gY2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjYW52YXMpIHJldHVybjtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBkYXRhVXJsID0gY2FudmFzLnRvRGF0YVVSTCgnaW1hZ2UvanBlZycsIDAuOTUpO1xuICAgICAgY29uc3QgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcbiAgICAgIGEuaHJlZiA9IGRhdGFVcmw7XG4gICAgICBjb25zdCBmaWxlTmFtZSA9IGBWaWRlb19TbmFwc2hvdF8ke0RhdGUubm93KCl9LmpwZ2A7XG4gICAgICBhLmRvd25sb2FkID0gZmlsZU5hbWU7XG4gICAgICBhLmNsaWNrKCk7XG5cbiAgICAgIGlmIChvbkFkZERvd25sb2FkKSB7XG4gICAgICAgIG9uQWRkRG93bmxvYWQoe1xuICAgICAgICAgIGlkOiBgdmlkLXNuYXAtJHtEYXRlLm5vdygpfWAsXG4gICAgICAgICAgdGl0bGU6IGZpbGVOYW1lLFxuICAgICAgICAgIHR5cGU6ICdDb252ZXJ0ZWQgSlBHJyxcbiAgICAgICAgICBzaXplOiBgJHtjYW52YXMud2lkdGh9w5cke2NhbnZhcy5oZWlnaHR9IHB4YCxcbiAgICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1JTicpXG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICBzZXRTdGF0dXNBbGVydCgn8J+TuCBIaWdoLVJlc29sdXRpb24gRnJhbWUgU25hcHNob3QgZG93bmxvYWRlZCAmIHNhdmVkIHRvIFZhdWx0IScpO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRTdGF0dXNBbGVydChudWxsKSwgMzAwMCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBNVUxUSS1MQVlFUiBWSURFTyBDT01QT1NJVElORyBMT09QIChIVE1MNSBDYW52YXMgNjAgRlBTKVxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIGNvbnN0IHJlbmRlckNvbXBvc2l0ZUZyYW1lID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGNvbnN0IGNhbnZhcyA9IGNhbnZhc1JlZi5jdXJyZW50O1xuICAgIGNvbnN0IHZpZGVvID0gdmlkZW9SZWYuY3VycmVudDtcbiAgICBpZiAoIWNhbnZhcykgcmV0dXJuO1xuICAgIGNvbnN0IGN0eCA9IGNhbnZhcy5nZXRDb250ZXh0KCcyZCcpO1xuICAgIGlmICghY3R4KSByZXR1cm47XG5cbiAgICBjb25zdCB7IHdpZHRoOiB0YXJnZXRXLCBoZWlnaHQ6IHRhcmdldEggfSA9IGdldENhbnZhc0RpbWVuc2lvbnMoKTtcbiAgICBjYW52YXMud2lkdGggPSB0YXJnZXRXO1xuICAgIGNhbnZhcy5oZWlnaHQgPSB0YXJnZXRIO1xuXG4gICAgLy8gMS4gTEFZRVIgMDogQ2FudmFzIEJhY2tncm91bmQgRmlsbFxuICAgIGN0eC5maWxsU3R5bGUgPSAnIzAyMDYxNyc7XG4gICAgY3R4LmZpbGxSZWN0KDAsIDAsIHRhcmdldFcsIHRhcmdldEgpO1xuXG4gICAgLy8gMi4gTEFZRVIgMTogTWFpbiBWaWRlbyBUcmFja1xuICAgIGlmICh2aWRlbyAmJiB2aWRlby5yZWFkeVN0YXRlID49IDIpIHtcbiAgICAgIGN0eC5zYXZlKCk7XG5cbiAgICAgIC8vIFRyYW5zZm9ybSwgUm90YXRpb24gJiBGbGlwXG4gICAgICBjdHgudHJhbnNsYXRlKHRhcmdldFcgLyAyLCB0YXJnZXRIIC8gMik7XG4gICAgICBjdHgucm90YXRlKChyb3RhdGlvbiAqIE1hdGguUEkpIC8gMTgwKTtcbiAgICAgIGN0eC5zY2FsZShmbGlwSCA/IC0xIDogMSwgZmxpcFYgPyAtMSA6IDEpO1xuICAgICAgY3R4LnNjYWxlKHpvb21MZXZlbCwgem9vbUxldmVsKTtcblxuICAgICAgLy8gQ2FsY3VsYXRlIHZpZGVvIGFzcGVjdCBmaXRcbiAgICAgIGNvbnN0IHZBc3BlY3QgPSB2aWRlby52aWRlb1dpZHRoIC8gdmlkZW8udmlkZW9IZWlnaHQ7XG4gICAgICBjb25zdCBjQXNwZWN0ID0gdGFyZ2V0VyAvIHRhcmdldEg7XG4gICAgICBsZXQgZHJhd1cgPSB0YXJnZXRXO1xuICAgICAgbGV0IGRyYXdIID0gdGFyZ2V0SDtcblxuICAgICAgaWYgKHZBc3BlY3QgPiBjQXNwZWN0KSB7XG4gICAgICAgIGRyYXdIID0gdGFyZ2V0VyAvIHZBc3BlY3Q7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBkcmF3VyA9IHRhcmdldEggKiB2QXNwZWN0O1xuICAgICAgfVxuXG4gICAgICAvLyBDb2xvciBHcmFkaW5nIEZpbHRlcnNcbiAgICAgIGxldCBmaWx0ZXJTdHIgPSBgYnJpZ2h0bmVzcygkezEwMCArIGJyaWdodG5lc3N9JSkgY29udHJhc3QoJHsxMDAgKyBjb250cmFzdH0lKSBzYXR1cmF0ZSgkezEwMCArIHNhdHVyYXRpb259JSlgO1xuICAgICAgaWYgKGZpbHRlclByZXNldCA9PT0gJ2NpbmVtYXRpYycpIHtcbiAgICAgICAgZmlsdGVyU3RyICs9ICcgY29udHJhc3QoMTE1JSkgc2F0dXJhdGUoMTI1JSknO1xuICAgICAgfSBlbHNlIGlmIChmaWx0ZXJQcmVzZXQgPT09ICdidycpIHtcbiAgICAgICAgZmlsdGVyU3RyICs9ICcgZ3JheXNjYWxlKDEwMCUpIGNvbnRyYXN0KDEyMCUpJztcbiAgICAgIH0gZWxzZSBpZiAoZmlsdGVyUHJlc2V0ID09PSAndmludGFnZScpIHtcbiAgICAgICAgZmlsdGVyU3RyICs9ICcgc2VwaWEoNTAlKSBjb250cmFzdCgxMTAlKSc7XG4gICAgICB9IGVsc2UgaWYgKGZpbHRlclByZXNldCA9PT0gJ25lb24nKSB7XG4gICAgICAgIGZpbHRlclN0ciArPSAnIHNhdHVyYXRlKDE2MCUpIGh1ZS1yb3RhdGUoMTVkZWcpJztcbiAgICAgIH1cbiAgICAgIGN0eC5maWx0ZXIgPSBmaWx0ZXJTdHI7XG5cbiAgICAgIGN0eC5kcmF3SW1hZ2UodmlkZW8sIC1kcmF3VyAvIDIsIC1kcmF3SCAvIDIsIGRyYXdXLCBkcmF3SCk7XG5cbiAgICAgIC8vIFdhcm10aCBjb2xvciBvdmVybGF5XG4gICAgICBpZiAod2FybXRoICE9PSAwKSB7XG4gICAgICAgIGN0eC5nbG9iYWxDb21wb3NpdGVPcGVyYXRpb24gPSAnY29sb3InO1xuICAgICAgICBjdHguZmlsbFN0eWxlID0gd2FybXRoID4gMFxuICAgICAgICAgID8gYHJnYmEoMjU1LCAxNjAsIDYwLCAke01hdGgubWluKDAuMzUsICh3YXJtdGggLyAxMDApICogMC40KX0pYFxuICAgICAgICAgIDogYHJnYmEoNjAsIDE2MCwgMjU1LCAke01hdGgubWluKDAuMzUsIChNYXRoLmFicyh3YXJtdGgpIC8gMTAwKSAqIDAuNCl9KWA7XG4gICAgICAgIGN0eC5maWxsUmVjdCgtZHJhd1cgLyAyLCAtZHJhd0ggLyAyLCBkcmF3VywgZHJhd0gpO1xuICAgICAgfVxuXG4gICAgICBjdHgucmVzdG9yZSgpO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBQbGFjZWhvbGRlciBzY3JlZW5cbiAgICAgIGN0eC5maWxsU3R5bGUgPSAnIzY0NzQ4Yic7XG4gICAgICBjdHguZm9udCA9ICdib2xkIDI0cHggc2Fucy1zZXJpZic7XG4gICAgICBjdHgudGV4dEFsaWduID0gJ2NlbnRlcic7XG4gICAgICBjdHguZmlsbFRleHQoJ1VwbG9hZCBWaWRlbyBvciBDbGljayBcIkxvYWQgU2FtcGxlIFZpZGVvXCInLCB0YXJnZXRXIC8gMiwgdGFyZ2V0SCAvIDIgLSAxNSk7XG4gICAgICBjdHguZm9udCA9ICcxNnB4IHNhbnMtc2VyaWYnO1xuICAgICAgY3R4LmZpbGxTdHlsZSA9ICcjOTRhM2I4JztcbiAgICAgIGN0eC5maWxsVGV4dCgnTXVsdGktTGF5ZXIgVGltZWxpbmUgUmVhZHkgKE1haW4gVmlkZW8g4oCiIE92ZXJsYXkg4oCiIEF1ZGlvIOKAoiBUaXRsZXMg4oCiIFdhdGVybWFyayknLCB0YXJnZXRXIC8gMiwgdGFyZ2V0SCAvIDIgKyAyNSk7XG4gICAgfVxuXG4gICAgLy8gMy4gTEFZRVIgMjogT3ZlcmxheSBCLVJvbGwgUGljdHVyZS1pbi1QaWN0dXJlIFRyYWNrXG4gICAgaWYgKG92ZXJsYXlJbWdSZWYuY3VycmVudCAmJiBvdmVybGF5SW1hZ2VTcmMpIHtcbiAgICAgIGN0eC5zYXZlKCk7XG4gICAgICBjdHguZ2xvYmFsQWxwaGEgPSBvdmVybGF5T3BhY2l0eTtcblxuICAgICAgY29uc3QgaW1nID0gb3ZlcmxheUltZ1JlZi5jdXJyZW50O1xuICAgICAgY29uc3QgaW1nQXNwZWN0ID0gaW1nLndpZHRoIC8gaW1nLmhlaWdodDtcbiAgICAgIGNvbnN0IHBpcFcgPSB0YXJnZXRXICogb3ZlcmxheVNjYWxlO1xuICAgICAgY29uc3QgcGlwSCA9IHBpcFcgLyBpbWdBc3BlY3Q7XG5cbiAgICAgIGxldCBweCA9IDIwO1xuICAgICAgbGV0IHB5ID0gMjA7XG5cbiAgICAgIGlmIChvdmVybGF5UG9zaXRpb24gPT09ICd0b3AtcmlnaHQnKSB7XG4gICAgICAgIHB4ID0gdGFyZ2V0VyAtIHBpcFcgLSAyNDtcbiAgICAgICAgcHkgPSAyNDtcbiAgICAgIH0gZWxzZSBpZiAob3ZlcmxheVBvc2l0aW9uID09PSAndG9wLWxlZnQnKSB7XG4gICAgICAgIHB4ID0gMjQ7XG4gICAgICAgIHB5ID0gMjQ7XG4gICAgICB9IGVsc2UgaWYgKG92ZXJsYXlQb3NpdGlvbiA9PT0gJ2JvdHRvbS1yaWdodCcpIHtcbiAgICAgICAgcHggPSB0YXJnZXRXIC0gcGlwVyAtIDI0O1xuICAgICAgICBweSA9IHRhcmdldEggLSBwaXBIIC0gMjQ7XG4gICAgICB9IGVsc2UgaWYgKG92ZXJsYXlQb3NpdGlvbiA9PT0gJ2JvdHRvbS1sZWZ0Jykge1xuICAgICAgICBweCA9IDI0O1xuICAgICAgICBweSA9IHRhcmdldEggLSBwaXBIIC0gMjQ7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBweCA9ICh0YXJnZXRXIC0gcGlwVykgLyAyO1xuICAgICAgICBweSA9ICh0YXJnZXRIIC0gcGlwSCkgLyAyO1xuICAgICAgfVxuXG4gICAgICAvLyBCb3JkZXIgJiBTaGFkb3dcbiAgICAgIGN0eC5maWxsU3R5bGUgPSAncmdiYSgxNSwgMjMsIDQyLCAwLjYpJztcbiAgICAgIGN0eC5maWxsUmVjdChweCAtIDQsIHB5IC0gNCwgcGlwVyArIDgsIHBpcEggKyA4KTtcbiAgICAgIGN0eC5zdHJva2VTdHlsZSA9ICcjMzhiZGY4JztcbiAgICAgIGN0eC5saW5lV2lkdGggPSAyO1xuICAgICAgY3R4LnN0cm9rZVJlY3QocHggLSA0LCBweSAtIDQsIHBpcFcgKyA4LCBwaXBIICsgOCk7XG5cbiAgICAgIGN0eC5kcmF3SW1hZ2UoaW1nLCBweCwgcHksIHBpcFcsIHBpcEgpO1xuICAgICAgY3R4LnJlc3RvcmUoKTtcbiAgICB9XG5cbiAgICAvLyA0LiBMQVlFUiA0OiBBbmltYXRlZCBMb3dlci1UaGlyZHMgJiBUZXh0IENhcHRpb25zIFRyYWNrXG4gICAgdGV4dE92ZXJsYXlzLmZvckVhY2goKHR4dCkgPT4ge1xuICAgICAgaWYgKGN1cnJlbnRUaW1lID49IHR4dC5zdGFydFRpbWUgJiYgY3VycmVudFRpbWUgPD0gdHh0LmVuZFRpbWUgJiYgdHh0LnRleHQudHJpbSgpKSB7XG4gICAgICAgIGN0eC5zYXZlKCk7XG4gICAgICAgIGN0eC5mb250ID0gYGJvbGQgJHt0eHQuZm9udFNpemV9cHggc2Fucy1zZXJpZmA7XG4gICAgICAgIGN0eC50ZXh0QWxpZ24gPSAnY2VudGVyJztcblxuICAgICAgICBjb25zdCB0ZXh0TWV0cmljcyA9IGN0eC5tZWFzdXJlVGV4dCh0eHQudGV4dCk7XG4gICAgICAgIGNvbnN0IHRleHRXID0gdGV4dE1ldHJpY3Mud2lkdGg7XG4gICAgICAgIGNvbnN0IGJveFBhZGRpbmdYID0gMjQ7XG4gICAgICAgIGNvbnN0IGJveFBhZGRpbmdZID0gMTI7XG4gICAgICAgIGNvbnN0IGJveEggPSB0eHQuZm9udFNpemUgKyBib3hQYWRkaW5nWSAqIDI7XG5cbiAgICAgICAgbGV0IHR5ID0gdGFyZ2V0SCAtIDgwO1xuICAgICAgICBpZiAodHh0LnBvc2l0aW9uID09PSAndG9wJykgdHkgPSA4MDtcbiAgICAgICAgZWxzZSBpZiAodHh0LnBvc2l0aW9uID09PSAnY2VudGVyJykgdHkgPSB0YXJnZXRIIC8gMjtcblxuICAgICAgICAvLyBCYWNrZ3JvdW5kIEJhbm5lclxuICAgICAgICBjdHguZmlsbFN0eWxlID0gdHh0LmJnQ29sb3I7XG4gICAgICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICAgICAgY3R4LnJvdW5kUmVjdChcbiAgICAgICAgICAodGFyZ2V0VyAtIHRleHRXIC0gYm94UGFkZGluZ1ggKiAyKSAvIDIsXG4gICAgICAgICAgdHkgLSBib3hIIC8gMixcbiAgICAgICAgICB0ZXh0VyArIGJveFBhZGRpbmdYICogMixcbiAgICAgICAgICBib3hILFxuICAgICAgICAgIDEyXG4gICAgICAgICk7XG4gICAgICAgIGN0eC5maWxsKCk7XG5cbiAgICAgICAgaWYgKHR4dC5zdHlsZSA9PT0gJ2xvd2VyX3RoaXJkJykge1xuICAgICAgICAgIGN0eC5zdHJva2VTdHlsZSA9ICcjMzhiZGY4JztcbiAgICAgICAgICBjdHgubGluZVdpZHRoID0gMi41O1xuICAgICAgICAgIGN0eC5zdHJva2UoKTtcbiAgICAgICAgfSBlbHNlIGlmICh0eHQuc3R5bGUgPT09ICduZW9uJykge1xuICAgICAgICAgIGN0eC5zaGFkb3dDb2xvciA9ICcjMDZiNmQ0JztcbiAgICAgICAgICBjdHguc2hhZG93Qmx1ciA9IDE1O1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gVGV4dFxuICAgICAgICBjdHguZmlsbFN0eWxlID0gdHh0LmNvbG9yO1xuICAgICAgICBjdHgudGV4dEJhc2VsaW5lID0gJ21pZGRsZSc7XG4gICAgICAgIGN0eC5maWxsVGV4dCh0eHQudGV4dCwgdGFyZ2V0VyAvIDIsIHR5KTtcbiAgICAgICAgY3R4LnJlc3RvcmUoKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIC8vIDUuIExBWUVSIDU6IEN5YmVyIENhZmUgRGlnaXRhbCBXYXRlcm1hcmsgVHJhY2tcbiAgICBpZiAoc2hvd1dhdGVybWFyayAmJiB3YXRlcm1hcmtUZXh0LnRyaW0oKSkge1xuICAgICAgY3R4LnNhdmUoKTtcbiAgICAgIGN0eC5nbG9iYWxBbHBoYSA9IHdhdGVybWFya09wYWNpdHk7XG4gICAgICBjdHguZm9udCA9ICdib2xkIDE1cHggc2Fucy1zZXJpZic7XG5cbiAgICAgIGNvbnN0IHdNZXRyaWNzID0gY3R4Lm1lYXN1cmVUZXh0KHdhdGVybWFya1RleHQpO1xuICAgICAgY29uc3Qgd1dpZHRoID0gd01ldHJpY3Mud2lkdGggKyAyNDtcbiAgICAgIGNvbnN0IHdIZWlnaHQgPSAzMDtcblxuICAgICAgbGV0IHd4ID0gdGFyZ2V0VyAtIHdXaWR0aCAtIDE2O1xuICAgICAgbGV0IHd5ID0gMTY7XG5cbiAgICAgIGlmICh3YXRlcm1hcmtQb3MgPT09ICd0b3AtbGVmdCcpIHtcbiAgICAgICAgd3ggPSAxNjtcbiAgICAgICAgd3kgPSAxNjtcbiAgICAgIH0gZWxzZSBpZiAod2F0ZXJtYXJrUG9zID09PSAnYm90dG9tLXJpZ2h0Jykge1xuICAgICAgICB3eCA9IHRhcmdldFcgLSB3V2lkdGggLSAxNjtcbiAgICAgICAgd3kgPSB0YXJnZXRIIC0gd0hlaWdodCAtIDE2O1xuICAgICAgfSBlbHNlIGlmICh3YXRlcm1hcmtQb3MgPT09ICdib3R0b20tbGVmdCcpIHtcbiAgICAgICAgd3ggPSAxNjtcbiAgICAgICAgd3kgPSB0YXJnZXRIIC0gd0hlaWdodCAtIDE2O1xuICAgICAgfVxuXG4gICAgICBjdHguZmlsbFN0eWxlID0gJ3JnYmEoMTUsIDIzLCA0MiwgMC43NSknO1xuICAgICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgICAgY3R4LnJvdW5kUmVjdCh3eCwgd3ksIHdXaWR0aCwgd0hlaWdodCwgOCk7XG4gICAgICBjdHguZmlsbCgpO1xuICAgICAgY3R4LnN0cm9rZVN0eWxlID0gJ3JnYmEoNTYsIDE4OSwgMjQ4LCAwLjQpJztcbiAgICAgIGN0eC5saW5lV2lkdGggPSAxO1xuICAgICAgY3R4LnN0cm9rZSgpO1xuXG4gICAgICBjdHguZmlsbFN0eWxlID0gJyNmZmZmZmYnO1xuICAgICAgY3R4LnRleHRBbGlnbiA9ICdjZW50ZXInO1xuICAgICAgY3R4LnRleHRCYXNlbGluZSA9ICdtaWRkbGUnO1xuICAgICAgY3R4LmZpbGxUZXh0KHdhdGVybWFya1RleHQsIHd4ICsgd1dpZHRoIC8gMiwgd3kgKyB3SGVpZ2h0IC8gMik7XG4gICAgICBjdHgucmVzdG9yZSgpO1xuICAgIH1cbiAgfSwgW1xuICAgIGdldENhbnZhc0RpbWVuc2lvbnMsIFxuICAgIHJvdGF0aW9uLCBcbiAgICBmbGlwSCwgXG4gICAgZmxpcFYsIFxuICAgIHpvb21MZXZlbCwgXG4gICAgYnJpZ2h0bmVzcywgXG4gICAgY29udHJhc3QsIFxuICAgIHNhdHVyYXRpb24sIFxuICAgIHdhcm10aCwgXG4gICAgZmlsdGVyUHJlc2V0LCBcbiAgICBvdmVybGF5SW1hZ2VTcmMsIFxuICAgIG92ZXJsYXlTY2FsZSwgXG4gICAgb3ZlcmxheVBvc2l0aW9uLCBcbiAgICBvdmVybGF5T3BhY2l0eSwgXG4gICAgdGV4dE92ZXJsYXlzLCBcbiAgICBjdXJyZW50VGltZSwgXG4gICAgc2hvd1dhdGVybWFyaywgXG4gICAgd2F0ZXJtYXJrVGV4dCwgXG4gICAgd2F0ZXJtYXJrUG9zLCBcbiAgICB3YXRlcm1hcmtPcGFjaXR5XG4gIF0pO1xuXG4gIC8vIFZpZGVvIFRpbWUgVXBkYXRlIExpc3RlbmVyIExvb3BcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCB2aWRlbyA9IHZpZGVvUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCF2aWRlbykgcmV0dXJuO1xuXG4gICAgbGV0IGFuaW1JZDogbnVtYmVyO1xuICAgIGNvbnN0IHVwZGF0ZUxvb3AgPSAoKSA9PiB7XG4gICAgICBpZiAodmlkZW8gJiYgIXZpZGVvLnBhdXNlZCAmJiAhdmlkZW8uZW5kZWQpIHtcbiAgICAgICAgc2V0Q3VycmVudFRpbWUodmlkZW8uY3VycmVudFRpbWUpO1xuXG4gICAgICAgIC8vIENoZWNrIE91dC1Qb2ludCBUcmltIGJvdW5kYXJ5XG4gICAgICAgIGlmICh2aWRlby5jdXJyZW50VGltZSA+PSBvdXRQb2ludCkge1xuICAgICAgICAgIGlmIChpc0xvb3BpbmcpIHtcbiAgICAgICAgICAgIHZpZGVvLmN1cnJlbnRUaW1lID0gaW5Qb2ludDtcbiAgICAgICAgICAgIGlmIChhdWRpb1JlZi5jdXJyZW50KSBhdWRpb1JlZi5jdXJyZW50LmN1cnJlbnRUaW1lID0gaW5Qb2ludDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdmlkZW8ucGF1c2UoKTtcbiAgICAgICAgICAgIGlmIChhdWRpb1JlZi5jdXJyZW50KSBhdWRpb1JlZi5jdXJyZW50LnBhdXNlKCk7XG4gICAgICAgICAgICBzZXRJc1BsYXlpbmcoZmFsc2UpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmVuZGVyQ29tcG9zaXRlRnJhbWUoKTtcbiAgICAgIGFuaW1JZCA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSh1cGRhdGVMb29wKTtcbiAgICB9O1xuXG4gICAgYW5pbUlkID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKHVwZGF0ZUxvb3ApO1xuICAgIHJldHVybiAoKSA9PiBjYW5jZWxBbmltYXRpb25GcmFtZShhbmltSWQpO1xuICB9LCBbaW5Qb2ludCwgb3V0UG9pbnQsIGlzTG9vcGluZywgcmVuZGVyQ29tcG9zaXRlRnJhbWVdKTtcblxuICAvLyBLZXlib2FyZCBTcGFjZWJhciB0byBQbGF5L1BhdXNlXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgaGFuZGxlS2V5RG93biA9IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICBpZiAoKGUudGFyZ2V0IGFzIEhUTUxFbGVtZW50KS50YWdOYW1lID09PSAnSU5QVVQnIHx8IChlLnRhcmdldCBhcyBIVE1MRWxlbWVudCkudGFnTmFtZSA9PT0gJ1RFWFRBUkVBJykge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoZS5jb2RlID09PSAnU3BhY2UnKSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgaGFuZGxlVG9nZ2xlUGxheSgpO1xuICAgICAgfVxuICAgIH07XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBoYW5kbGVLZXlEb3duKTtcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2tleWRvd24nLCBoYW5kbGVLZXlEb3duKTtcbiAgfSk7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBSRUFMIFZJREVPIEVYUE9SVCBFTkdJTkUgKFdlYk0vTVA0IENhbnZhcyBSZWNvcmRlcilcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBjb25zdCBoYW5kbGVFeHBvcnRWaWRlbyA9ICgpID0+IHtcbiAgICBjb25zdCBjYW52YXMgPSBjYW52YXNSZWYuY3VycmVudDtcbiAgICBjb25zdCB2aWRlbyA9IHZpZGVvUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjYW52YXMpIHJldHVybjtcblxuICAgIHNldElzRXhwb3J0aW5nKHRydWUpO1xuICAgIHNldEV4cG9ydFByb2dyZXNzKDUpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHN0cmVhbSA9IGNhbnZhcy5jYXB0dXJlU3RyZWFtKDMwKTtcbiAgICAgIGNvbnN0IG1pbWUgPSBNZWRpYVJlY29yZGVyLmlzVHlwZVN1cHBvcnRlZCgndmlkZW8vbXA0O2NvZGVjcz1hdmMxJylcbiAgICAgICAgPyAndmlkZW8vbXA0O2NvZGVjcz1hdmMxJ1xuICAgICAgICA6ICd2aWRlby93ZWJtO2NvZGVjcz12cDknO1xuXG4gICAgICBjb25zdCByZWNvcmRlciA9IG5ldyBNZWRpYVJlY29yZGVyKHN0cmVhbSwgeyBtaW1lVHlwZTogbWltZSB9KTtcbiAgICAgIHJlY29yZGVkQmxvYnNSZWYuY3VycmVudCA9IFtdO1xuXG4gICAgICByZWNvcmRlci5vbmRhdGFhdmFpbGFibGUgPSAoZSkgPT4ge1xuICAgICAgICBpZiAoZS5kYXRhLnNpemUgPiAwKSByZWNvcmRlZEJsb2JzUmVmLmN1cnJlbnQucHVzaChlLmRhdGEpO1xuICAgICAgfTtcblxuICAgICAgcmVjb3JkZXIub25zdG9wID0gKCkgPT4ge1xuICAgICAgICBjb25zdCBibG9iID0gbmV3IEJsb2IocmVjb3JkZWRCbG9ic1JlZi5jdXJyZW50LCB7IHR5cGU6IG1pbWUgfSk7XG4gICAgICAgIGNvbnN0IGV4dCA9IG1pbWUuaW5jbHVkZXMoJ21wNCcpID8gJ21wNCcgOiAnd2VibSc7XG4gICAgICAgIGNvbnN0IGV4cG9ydE5hbWUgPSBgTXV6YW1taWxfU3R1ZGlvXyR7dmlkZW9GaWxlTmFtZS5yZXBsYWNlKC9cXC5bXi8uXSskLywgXCJcIil9X0VkaXRlZC4ke2V4dH1gO1xuICAgICAgICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xuICAgICAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgICAgICBhLmhyZWYgPSB1cmw7XG4gICAgICAgIGEuZG93bmxvYWQgPSBleHBvcnROYW1lO1xuICAgICAgICBhLmNsaWNrKCk7XG5cbiAgICAgICAgaWYgKG9uQWRkRG93bmxvYWQpIHtcbiAgICAgICAgICBvbkFkZERvd25sb2FkKHtcbiAgICAgICAgICAgIGlkOiBgdmlkLWV4cG9ydC0ke0RhdGUubm93KCl9YCxcbiAgICAgICAgICAgIHRpdGxlOiBleHBvcnROYW1lLFxuICAgICAgICAgICAgdHlwZTogJ1BWQyBDYXJkIFBERicsIC8vIHJldXNlIHZhdWx0IGRvd25sb2FkIGl0ZW0gZm9ybWF0XG4gICAgICAgICAgICBzaXplOiBgJHsoYmxvYi5zaXplIC8gKDEwMjQgKiAxMDI0KSkudG9GaXhlZCgyKX0gTUIgKCR7YXNwZWN0UmF0aW99KWAsXG4gICAgICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1JTicpXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICBzZXRJc0V4cG9ydGluZyhmYWxzZSk7XG4gICAgICAgIHNldEV4cG9ydFByb2dyZXNzKDEwMCk7XG4gICAgICAgIHNldFN0YXR1c0FsZXJ0KGDwn46JIFZpZGVvIEV4cG9ydCBDb21wbGV0ZSEgXCIke2V4cG9ydE5hbWV9XCIgZG93bmxvYWRlZC5gKTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRTdGF0dXNBbGVydChudWxsKSwgNDAwMCk7XG4gICAgICB9O1xuXG4gICAgICByZWNvcmRlclJlZi5jdXJyZW50ID0gcmVjb3JkZXI7XG4gICAgICByZWNvcmRlci5zdGFydCgpO1xuXG4gICAgICAvLyBSZXNldCB2aWRlbyB0byBpbi1wb2ludCBhbmQgcGxheSB0byByZWNvcmRcbiAgICAgIGlmICh2aWRlbykge1xuICAgICAgICB2aWRlby5jdXJyZW50VGltZSA9IGluUG9pbnQ7XG4gICAgICAgIHZpZGVvLnBsYXliYWNrUmF0ZSA9IDEuMDtcbiAgICAgICAgdmlkZW8ucGxheSgpO1xuICAgICAgICBzZXRJc1BsYXlpbmcodHJ1ZSk7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHRvdGFsUmVjb3JkVGltZSA9IChvdXRQb2ludCAtIGluUG9pbnQpICogMTAwMDtcbiAgICAgIGNvbnN0IHN0YXJ0VGltZSA9IERhdGUubm93KCk7XG5cbiAgICAgIGNvbnN0IHByb2dJbnRlcnZhbCA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICAgICAgY29uc3QgZWxhcHNlZCA9IERhdGUubm93KCkgLSBzdGFydFRpbWU7XG4gICAgICAgIGNvbnN0IHBjdCA9IE1hdGgubWluKDk4LCBNYXRoLnJvdW5kKChlbGFwc2VkIC8gdG90YWxSZWNvcmRUaW1lKSAqIDEwMCkpO1xuICAgICAgICBzZXRFeHBvcnRQcm9ncmVzcyhwY3QpO1xuXG4gICAgICAgIGlmIChlbGFwc2VkID49IHRvdGFsUmVjb3JkVGltZSkge1xuICAgICAgICAgIGNsZWFySW50ZXJ2YWwocHJvZ0ludGVydmFsKTtcbiAgICAgICAgICByZWNvcmRlci5zdG9wKCk7XG4gICAgICAgICAgaWYgKHZpZGVvKSB2aWRlby5wYXVzZSgpO1xuICAgICAgICAgIHNldElzUGxheWluZyhmYWxzZSk7XG4gICAgICAgIH1cbiAgICAgIH0sIDIwMCk7XG5cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgc2V0SXNFeHBvcnRpbmcoZmFsc2UpO1xuICAgICAgc2V0U3RhdHVzQWxlcnQoJ+KdjCBFeHBvcnQgZXJyb3IuIFRyeSB1c2luZyBhIHN0YW5kYXJkIFdlYk0vTVA0IGZvcm1hdC4nKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0U3RhdHVzQWxlcnQobnVsbCksIDQwMDApO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00IHNlbGVjdC1ub25lXCI+XG4gICAgICB7LyogSGlkZGVuIGF1ZGlvIGVsZW1lbnQgZm9yIFRyYWNrIDMgKi99XG4gICAgICB7bXVzaWNTcmMgJiYgPGF1ZGlvIHJlZj17YXVkaW9SZWZ9IHNyYz17bXVzaWNTcmN9IGxvb3AgLz59XG5cbiAgICAgIHsvKiBUT1AgSEVBREVSIEJBUiAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBwLTQgcm91bmRlZC0yeGwgc2hhZG93LW1kXCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPEZpbG0gY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXJvc2UtNTAwXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+TXVsdGktTGF5ZXIgVmlkZW8gU3R1ZGlvIFBybzwvc3Bhbj5cbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1yb3NlLTUwMC8yMCB0ZXh0LXJvc2UtNDAwIGJvcmRlciBib3JkZXItcm9zZS01MDAvMzAgdGV4dC14cyBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCBmb250LW1vbm8gZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgIDUgVGltZWxpbmUgVHJhY2tzXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1ibHVlLTUwMC8yMCB0ZXh0LWJsdWUtNDAwIGJvcmRlciBib3JkZXItYmx1ZS01MDAvMzAgdGV4dC14cyBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgRnVsbCBIRCAxMDgwcCBFeHBvcnRcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLXB1cnBsZS01MDAvMjAgdGV4dC1wdXJwbGUtMzAwIGJvcmRlciBib3JkZXItcHVycGxlLTUwMC8zMCB0ZXh0LXhzIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICBSZWVscyAvIFlvdVR1YmUgLyBDU0MgQnJhbmRpbmdcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTFcIj5cbiAgICAgICAgICAgIEN1dCwgdHJpbSwgc3BlZWQgY29udHJvbCwgY29sb3IgZ3JhZGluZywgbG93ZXItdGhpcmRzLCBhdWRpbyBtaXhpbmcsIHBpY3R1cmUtaW4tcGljdHVyZSwgYW5kIHdhdGVybWFyayBleHBvcnQgaW4gMSBjbGljay5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBRdWljayBUb3AgQWN0aW9ucyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmbGV4LXdyYXBcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUxvYWRTYW1wbGVWaWRlb31cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0yIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1wdXJwbGUtNjAwIHRvLWluZGlnby02MDAgaG92ZXI6ZnJvbS1wdXJwbGUtNTAwIGhvdmVyOnRvLWluZGlnby01MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14cyByb3VuZGVkLXhsIHNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzY2FsZS0xMDVcIlxuICAgICAgICAgICAgdGl0bGU9XCJHZW5lcmF0ZSBhIGR5bmFtaWMgQ1NDIEN5YmVyIENhZmUgbW90aW9uIHZpZGVvIGNsaXAgZm9yIGluc3RhbnQgdGVzdGluZ1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYW1iZXItMzAwXCIgLz5cbiAgICAgICAgICAgIDxzcGFuPkxvYWQgU2FtcGxlIENsaXA8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zLjUgcHktMiBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzUwIHRleHQtc2xhdGUtMjAwIGhvdmVyOnRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWNvbG9ycyBzaGFkb3dcIj5cbiAgICAgICAgICAgIDxVcGxvYWQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1ibHVlLTQwMFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5VcGxvYWQgVmlkZW88L3NwYW4+XG4gICAgICAgICAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCJ2aWRlby8qXCIgb25DaGFuZ2U9e2hhbmRsZVVwbG9hZFZpZGVvfSBjbGFzc05hbWU9XCJoaWRkZW5cIiAvPlxuICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNhcHR1cmVTbmFwc2hvdH1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0yIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0yMDAgZm9udC1ib2xkIHRleHQteHMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMFwiXG4gICAgICAgICAgICB0aXRsZT1cIkNhcHR1cmUgY3VycmVudCB2aWRlbyBmcmFtZSBhcyBoaWdoLXJlcyBKUEdcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxDYW1lcmEgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1lbWVyYWxkLTQwMFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5TbmFwc2hvdCBKUEc8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUV4cG9ydFZpZGVvfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzRXhwb3J0aW5nfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC00IHB5LTIgYmctZ3JhZGllbnQtdG8tciBmcm9tLXJvc2UtNjAwIHZpYS1waW5rLTYwMCB0by1yb3NlLTUwMCBob3Zlcjpmcm9tLXJvc2UtNTAwIGhvdmVyOnRvLXBpbmstNTAwIHRleHQtd2hpdGUgZm9udC1leHRyYWJvbGQgdGV4dC14cyByb3VuZGVkLXhsIHNoYWRvdy1sZyBzaGFkb3ctcm9zZS02MDAvMzAgdHJhbnNpdGlvbi1hbGwgaG92ZXI6c2NhbGUtMTA1IGRpc2FibGVkOm9wYWNpdHktNTBcIlxuICAgICAgICAgICAgdGl0bGU9XCJSZW5kZXIgYW5kIERvd25sb2FkIEZpbmFsIFZpZGVvIHdpdGggYWxsIDUgbGF5ZXJzXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXdoaXRlXCIgLz5cbiAgICAgICAgICAgIDxzcGFuPntpc0V4cG9ydGluZyA/IGBFeHBvcnRpbmcgKCR7ZXhwb3J0UHJvZ3Jlc3N9JSlgIDogJ0V4cG9ydCBWaWRlbyd9PC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogU3RhdHVzIEFsZXJ0IEJhbm5lciAqL31cbiAgICAgIHtzdGF0dXNBbGVydCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQteGwgYmctZW1lcmFsZC01MDAvMTAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCB0ZXh0LWVtZXJhbGQtMzAwIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGFuaW1hdGUtaW4gZmFkZS1pblwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNDAwIGZsZXgtc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgPHNwYW4+e3N0YXR1c0FsZXJ0fTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFN0YXR1c0FsZXJ0KG51bGwpfSBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNDAwIGhvdmVyOnRleHQtd2hpdGVcIj7inJU8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogRXhwb3J0IFByb2dyZXNzIEJhciAqL31cbiAgICAgIHtpc0V4cG9ydGluZyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItcm9zZS01MDAvNDAgcC0zIHJvdW5kZWQteGwgc3BhY2UteS0yXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIHRleHQtcm9zZS0zMDAgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICA8c3Bhbj5SZW5kZXJpbmcgTXVsdGktTGF5ZXIgVmlkZW8gYXQgMzAgRlBTLi4uPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4+e2V4cG9ydFByb2dyZXNzfSU8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGgtMiByb3VuZGVkLWZ1bGwgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICA8ZGl2IFxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1ncmFkaWVudC10by1yIGZyb20tcm9zZS01MDAgdG8taW5kaWdvLTUwMCBoLWZ1bGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwXCJcbiAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IGAke2V4cG9ydFByb2dyZXNzfSVgIH19XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBNQUlOIERVQUwtUEFORSBXT1JLU1BBQ0U6IExFRlQgUFJFVklFVyAoNyBDb2xzKSArIFJJR0hUIERFQ0sgKDUgQ29scykgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLTEyIGdhcC00IGl0ZW1zLXN0YXJ0XCI+XG4gICAgICAgIHsvKiBMRUZUOiBNT05JVE9SIFBSRVZJRVcgJiBQTEFZQkFDSyBDT05UUk9MUyAoNyBDb2x1bW5zKSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi03IGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTN4bCBwLTMgc206cC00IHNoYWRvdy0yeGwgc3BhY2UteS0zIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIG1pbi1oLVs1MDBweF1cIj5cbiAgICAgICAgICB7LyogVG9wIE1vbml0b3IgU3RhdHVzIEJhciAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIHBiLTIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yLjUgaC0yLjUgcm91bmRlZC1mdWxsIGJnLXJvc2UtNTAwIGFuaW1hdGUtcHVsc2VcIj48L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgZm9udC1ib2xkXCI+e3ZpZGVvRmlsZU5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMFwiPuKAojwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1za3ktNDAwIGZvbnQtYm9sZFwiPnthc3BlY3RSYXRpb308L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGZvbnQtbW9ubyB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtYm9sZFwiPntmb3JtYXRUaW1lKGN1cnJlbnRUaW1lKX08L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwXCI+Lzwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4+e2Zvcm1hdFRpbWUoZHVyYXRpb24pfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIENlbnRyYWwgQ29tcG9zaXRlIFZpZGVvIENhbnZhcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXgtMSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTIgb3ZlcmZsb3ctaGlkZGVuIGJnLXNsYXRlLTkwMC82MCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgPGNhbnZhc1xuICAgICAgICAgICAgICByZWY9e2NhbnZhc1JlZn1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWF4LXctZnVsbCBtYXgtaC1bNDQwcHhdIHctYXV0byBoLWF1dG8gcm91bmRlZC1sZyBzaGFkb3ctMnhsIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlVG9nZ2xlUGxheX1cbiAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgIHsvKiBIaWRkZW4gSFRNTDUgVmlkZW8gZWxlbWVudCB1c2VkIGFzIHJhdyBzdHJlYW0gc291cmNlICovfVxuICAgICAgICAgICAge3ZpZGVvU3JjICYmIChcbiAgICAgICAgICAgICAgPHZpZGVvXG4gICAgICAgICAgICAgICAgcmVmPXt2aWRlb1JlZn1cbiAgICAgICAgICAgICAgICBzcmM9e3ZpZGVvU3JjfVxuICAgICAgICAgICAgICAgIG9uTG9hZGVkTWV0YWRhdGE9e2hhbmRsZVZpZGVvTG9hZGVkTWV0YWRhdGF9XG4gICAgICAgICAgICAgICAgb25FbmRlZD17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgaWYgKGlzTG9vcGluZykge1xuICAgICAgICAgICAgICAgICAgICBpZiAodmlkZW9SZWYuY3VycmVudCkgdmlkZW9SZWYuY3VycmVudC5jdXJyZW50VGltZSA9IGluUG9pbnQ7XG4gICAgICAgICAgICAgICAgICAgIGlmIChhdWRpb1JlZi5jdXJyZW50KSBhdWRpb1JlZi5jdXJyZW50LmN1cnJlbnRUaW1lID0gaW5Qb2ludDtcbiAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHNldElzUGxheWluZyhmYWxzZSk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoaWRkZW5cIlxuICAgICAgICAgICAgICAgIHBsYXlzSW5saW5lXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFBsYXllciBUcmFuc3BvcnQgQmFyICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzkwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtMyBzcGFjZS15LTIuNSBzaGFkb3ctaW5uZXJcIj5cbiAgICAgICAgICAgIHsvKiBTY3J1YmJlciBSYW5nZSBTbGlkZXIgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXG4gICAgICAgICAgICAgICAgICBtYXg9e2R1cmF0aW9uIHx8IDEwfVxuICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDVcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e2N1cnJlbnRUaW1lfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVTZWVrKE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGFjY2VudC1yb3NlLTUwMCBoLTIgYmctc2xhdGUtODAwIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBUcmltIE1hcmtlcnMgSW5kaWNhdG9ycyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxMHB4XSBmb250LW1vbm8gdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNreS00MDBcIj5Jbjoge2Zvcm1hdFRpbWUoaW5Qb2ludCl9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgZm9udC1ib2xkXCI+e2Zvcm1hdFRpbWUoY3VycmVudFRpbWUpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS00MDBcIj5PdXQ6IHtmb3JtYXRUaW1lKG91dFBvaW50KX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBUcmFuc3BvcnQgQ29udHJvbCBCdXR0b25zICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgZmxleC13cmFwXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIHsvKiBQbGF5IC8gUGF1c2UgKi99XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVUb2dnbGVQbGF5fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLXJvc2UtNjAwIHRvLXBpbmstNjAwIGhvdmVyOmZyb20tcm9zZS01MDAgaG92ZXI6dG8tcGluay01MDAgdGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaGFkb3ctbGcgc2hhZG93LXJvc2UtNjAwLzMwIHRyYW5zaXRpb24tdHJhbnNmb3JtIGFjdGl2ZTpzY2FsZS05NVwiXG4gICAgICAgICAgICAgICAgICB0aXRsZT1cIlBsYXkgLyBQYXVzZSAoU3BhY2ViYXIpXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7aXNQbGF5aW5nID8gPFBhdXNlIGNsYXNzTmFtZT1cInctNSBoLTUgZmlsbC13aGl0ZVwiIC8+IDogPFBsYXkgY2xhc3NOYW1lPVwidy01IGgtNSBmaWxsLXdoaXRlIG1sLTAuNVwiIC8+fVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgey8qIFN0ZXAgLTFzICovfVxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2VlayhjdXJyZW50VGltZSAtIDEpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQteGwgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTMwMCBob3Zlcjp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiU3RlcCBCYWNrIDFzXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8UmV3aW5kIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgey8qIFN0ZXAgKzFzICovfVxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2VlayhjdXJyZW50VGltZSArIDEpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQteGwgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTMwMCBob3Zlcjp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiU3RlcCBGb3J3YXJkIDFzXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8RmFzdEZvcndhcmQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICB7LyogVHJpbSBJbiBCdXR0b24gKi99XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTZXRJblBvaW50fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMi41IHB5LTEuNSByb3VuZGVkLWxnIGJnLXNreS01MDAvMTAgaG92ZXI6Ymctc2t5LTUwMC8yMCB0ZXh0LXNreS00MDAgYm9yZGVyIGJvcmRlci1za3ktNTAwLzMwIHRleHQteHMgZm9udC1ib2xkIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgICAgICB0aXRsZT1cIlNldCBJbi1Qb2ludCAoQ3V0IFN0YXJ0KVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgWyBJblxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgey8qIFRyaW0gT3V0IEJ1dHRvbiAqL31cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNldE91dFBvaW50fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMi41IHB5LTEuNSByb3VuZGVkLWxnIGJnLXB1cnBsZS01MDAvMTAgaG92ZXI6YmctcHVycGxlLTUwMC8yMCB0ZXh0LXB1cnBsZS00MDAgYm9yZGVyIGJvcmRlci1wdXJwbGUtNTAwLzMwIHRleHQteHMgZm9udC1ib2xkIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgICAgICB0aXRsZT1cIlNldCBPdXQtUG9pbnQgKEN1dCBFbmQpXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBPdXQgXVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVSZXNldFRyaW19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlIHRleHQteHNcIlxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJSZXNldCBUcmltIFJhbmdlXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8Um90YXRlQ2N3IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFNwZWVkICYgQXVkaW8gY29udHJvbHMgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICB7LyogU3BlZWQgc2VsZWN0b3IgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBwLTAuNSB0ZXh0LVsxMHB4XSBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgIHtbMC41LCAxLjAsIDEuNSwgMi4wXS5tYXAoKHMpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIGtleT17c31cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTcGVlZENoYW5nZShzKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0yIHB5LTEgcm91bmRlZCB0cmFuc2l0aW9uLWNvbG9ycyAke1xuICAgICAgICAgICAgICAgICAgICAgICAgcGxheWJhY2tTcGVlZCA9PT0gcyA/ICdiZy1yb3NlLTYwMCB0ZXh0LXdoaXRlJyA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge3N9eFxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIFZvbHVtZSB0b2dnbGUgKi99XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc01hc3Rlck11dGVkKCFpc01hc3Rlck11dGVkKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMiByb3VuZGVkLXhsIGJvcmRlciB0ZXh0LXhzICR7XG4gICAgICAgICAgICAgICAgICAgIGlzTWFzdGVyTXV0ZWRcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1yb3NlLTYwMC8yMCB0ZXh0LXJvc2UtNDAwIGJvcmRlci1yb3NlLTUwMC80MCdcbiAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgYm9yZGVyLXNsYXRlLTcwMCdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgdGl0bGU9XCJNdXRlIC8gVW5tdXRlXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7aXNNYXN0ZXJNdXRlZCA/IDxWb2x1bWVYIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiA6IDxWb2x1bWUyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPn1cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFJJR0hUOiBNVUxUSS1MQVlFUiBUT09MUyAmIEFUVFJJQlVURVMgREVDSyAoNSBDb2x1bW5zKSAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi01IGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTN4bCBwLTQgc2hhZG93LXhsIHNwYWNlLXktNFwiPlxuICAgICAgICAgIHsvKiBTdWItRGVjayBOYXZpZ2F0aW9uIFRhYnMgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIHNtOmdyaWQtY29scy02IGdhcC0xIGJnLXNsYXRlLTk1MCBwLTEuNSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LVsxMXB4XSBmb250LWJvbGRcIj5cbiAgICAgICAgICAgIHtbXG4gICAgICAgICAgICAgIHsgaWQ6ICd0aW1lbGluZScsIGxhYmVsOiAnVGltZWxpbmUnLCBpY29uOiBMYXllcnMgfSxcbiAgICAgICAgICAgICAgeyBpZDogJ2Nyb3AnLCBsYWJlbDogJ0NhbnZhcycsIGljb246IFNwbGl0U3F1YXJlVmVydGljYWwgfSxcbiAgICAgICAgICAgICAgeyBpZDogJ2NvbG9yJywgbGFiZWw6ICdDb2xvcicsIGljb246IFNsaWRlcnMgfSxcbiAgICAgICAgICAgICAgeyBpZDogJ3RleHQnLCBsYWJlbDogJ1RpdGxlcycsIGljb246IFR5cGUgfSxcbiAgICAgICAgICAgICAgeyBpZDogJ292ZXJsYXknLCBsYWJlbDogJ092ZXJsYXknLCBpY29uOiBJbWFnZUljb24gfSxcbiAgICAgICAgICAgICAgeyBpZDogJ2F1ZGlvJywgbGFiZWw6ICdBdWRpbycsIGljb246IE11c2ljIH1cbiAgICAgICAgICAgIF0ubWFwKCh0YWIpID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgSWNvbiA9IHRhYi5pY29uO1xuICAgICAgICAgICAgICBjb25zdCBpc0FjdGl2ZSA9IGFjdGl2ZVRvb2xUYWIgPT09IHRhYi5pZDtcbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBrZXk9e3RhYi5pZH1cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVG9vbFRhYih0YWIuaWQgYXMgYW55KX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB5LTIgcHgtMSByb3VuZGVkLXhsIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgIGlzQWN0aXZlXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctcm9zZS02MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQgc2hhZG93LXJvc2UtNjAwLzMwJ1xuICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUgaG92ZXI6Ymctc2xhdGUtOTAwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPEljb24gY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidHJ1bmNhdGVcIj57dGFiLmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pfVxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFRBQiAxOiBNVUxUSS1MQVlFUiBUSU1FTElORSBUUkFDS1MgT1ZFUlZJRVcgKi99XG4gICAgICAgICAge2FjdGl2ZVRvb2xUYWIgPT09ICd0aW1lbGluZScgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgYW5pbWF0ZS1pbiBmYWRlLWluIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPExheWVycyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtcm9zZS01MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+NS1MYXllciBUaW1lbGluZSBUcmFja3M8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPlN5bmNocm9uaXplZDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFRyYWNrIDE6IE1haW4gVmlkZW8gKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHAtMyByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMi41IGgtMi41IHJvdW5kZWQtZnVsbCBiZy1ibHVlLTUwMFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlXCI+VHJhY2sgMTogTWFpbiBWaWRlbzwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LW1vbm8gdGV4dC1za3ktNDAwXCI+e2Zvcm1hdFRpbWUoZHVyYXRpb24pfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+Q2xpcDoge3ZpZGVvRmlsZU5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTQwMCBmb250LWJvbGRcIj5BY3RpdmU8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBUcmFjayAyOiBPdmVybGF5IEItUm9sbCAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgcC0zIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yLjUgaC0yLjUgcm91bmRlZC1mdWxsIGJnLXB1cnBsZS01MDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC13aGl0ZVwiPlRyYWNrIDI6IFBpY3R1cmUtaW4tUGljdHVyZSBPdmVybGF5PC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXB1cnBsZS00MDAgaG92ZXI6dW5kZXJsaW5lIGN1cnNvci1wb2ludGVyIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICArIEFkZCBJbWFnZVxuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCJpbWFnZS8qXCIgb25DaGFuZ2U9e2hhbmRsZVVwbG9hZE92ZXJsYXlJbWFnZX0gY2xhc3NOYW1lPVwiaGlkZGVuXCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPntvdmVybGF5SW1hZ2VTcmMgPyAnSW1hZ2UgT3ZlcmxheSBBY3RpdmUnIDogJ05vIE92ZXJsYXkgQXR0YWNoZWQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtvdmVybGF5SW1hZ2VTcmMgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldE92ZXJsYXlJbWFnZVNyYyhudWxsKX0gY2xhc3NOYW1lPVwidGV4dC1yb3NlLTQwMCBob3Zlcjp1bmRlcmxpbmVcIj5cbiAgICAgICAgICAgICAgICAgICAgICBSZW1vdmVcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogVHJhY2sgMzogQXVkaW8gLyBNdXNpYyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgcC0zIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yLjUgaC0yLjUgcm91bmRlZC1mdWxsIGJnLWFtYmVyLTUwMFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlXCI+VHJhY2sgMzogQmFja2dyb3VuZCBBdWRpbzwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1hbWJlci00MDAgaG92ZXI6dW5kZXJsaW5lIGN1cnNvci1wb2ludGVyIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICArIEFkZCBBdWRpb1xuICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCJhdWRpby8qXCIgb25DaGFuZ2U9e2hhbmRsZVVwbG9hZE11c2ljfSBjbGFzc05hbWU9XCJoaWRkZW5cIiAvPlxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+e211c2ljU3JjID8gJ0JhY2tncm91bmQgTXVzaWMgQWN0aXZlJyA6ICdEZWZhdWx0IC8gTXV0ZWQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHttdXNpY1NyYyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0TXVzaWNTcmMobnVsbCl9IGNsYXNzTmFtZT1cInRleHQtcm9zZS00MDAgaG92ZXI6dW5kZXJsaW5lXCI+XG4gICAgICAgICAgICAgICAgICAgICAgUmVtb3ZlXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFRyYWNrIDQ6IExvd2VyLVRoaXJkcyAmIFRpdGxlcyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgcC0zIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yLjUgaC0yLjUgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtNTAwXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtd2hpdGVcIj5UcmFjayA0OiBBbmltYXRlZCBUaXRsZXMgJiBTdWJ0aXRsZXM8L3N0cm9uZz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1lbWVyYWxkLTQwMCBmb250LW1vbm8gZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgIHt0ZXh0T3ZlcmxheXMubGVuZ3RofSBUZXh0IEJsb2Nrc1xuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAgICAgIFwie3RleHRPdmVybGF5c1swXT8udGV4dCB8fCAnTm8gVGV4dCd9XCJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIFRyYWNrIDU6IEN5YmVyIENhZmUgV2F0ZXJtYXJrICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBwLTMgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTIuNSBoLTIuNSByb3VuZGVkLWZ1bGwgYmctcm9zZS01MDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC13aGl0ZVwiPlRyYWNrIDU6IERpZ2l0YWwgQ1NDIFNob3AgV2F0ZXJtYXJrPC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtzaG93V2F0ZXJtYXJrfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNob3dXYXRlcm1hcmsoZS50YXJnZXQuY2hlY2tlZCl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFjY2VudC1yb3NlLTUwMCByb3VuZGVkXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCB0cnVuY2F0ZVwiPlxuICAgICAgICAgICAgICAgICAge3Nob3dXYXRlcm1hcmsgPyB3YXRlcm1hcmtUZXh0IDogJ0Rpc2FibGVkJ31cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIFRBQiAyOiBDQU5WQVMgUkFUSU8sIEdFT01FVFJZICYgUk9UQVRJT04gKi99XG4gICAgICAgICAge2FjdGl2ZVRvb2xUYWIgPT09ICdjcm9wJyAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCBhbmltYXRlLWluIGZhZGUtaW4gdGV4dC14c1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBiLTEgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICAgIEFzcGVjdCBSYXRpbyAmIEZyYW1pbmcgUHJlc2V0c1xuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogUmF0aW8gcHJlc2V0cyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIHNtOmdyaWQtY29scy00IGdhcC0yXCI+XG4gICAgICAgICAgICAgICAge1tcbiAgICAgICAgICAgICAgICAgIHsgaWQ6ICcxNjo5JywgbGFiZWw6ICcxNjo5JywgZGVzYzogJ1lvdVR1YmUgLyBQQycgfSxcbiAgICAgICAgICAgICAgICAgIHsgaWQ6ICc5OjE2JywgbGFiZWw6ICc5OjE2JywgZGVzYzogJ1JlZWxzIC8gU2hvcnRzJyB9LFxuICAgICAgICAgICAgICAgICAgeyBpZDogJzE6MScsIGxhYmVsOiAnMToxJywgZGVzYzogJ0luc3RhZ3JhbSBQb3N0JyB9LFxuICAgICAgICAgICAgICAgICAgeyBpZDogJzQ6NScsIGxhYmVsOiAnNDo1JywgZGVzYzogJ1BvcnRyYWl0IEZlZWQnIH1cbiAgICAgICAgICAgICAgICBdLm1hcCgocikgPT4gKFxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBrZXk9e3IuaWR9XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBc3BlY3RSYXRpbyhyLmlkIGFzIEFzcGVjdFJhdGlvKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yLjUgcm91bmRlZC14bCBib3JkZXIgdGV4dC1jZW50ZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICBhc3BlY3RSYXRpbyA9PT0gci5pZFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctcm9zZS02MDAvMjAgYm9yZGVyLXJvc2UtNTAwIHRleHQtd2hpdGUgZm9udC1leHRyYWJvbGQgcmluZy0xIHJpbmctcm9zZS01MDAvNDAnXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05NTAgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1zbVwiPntyLmxhYmVsfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwXCI+e3IuZGVzY308L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogUm90YXRpb24gJiBGbGlwIENvbnRyb2xzICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMiBwdC0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgZm9udC1ib2xkIGJsb2NrXCI+T3JpZW50YXRpb24gJiBNaXJyb3Jpbmc6PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Um90YXRpb24oKHByZXYpID0+IChwcmV2ICsgOTApICUgMzYwKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQteGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtMjAwIGhvdmVyOnRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEuNSBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8Um90YXRlQ3cgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1ibHVlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlJvdGF0ZSA5MMKwPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZsaXBIKCFmbGlwSCl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMiByb3VuZGVkLXhsIGJvcmRlciBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IGZvbnQtYm9sZCAke1xuICAgICAgICAgICAgICAgICAgICAgIGZsaXBIID8gJ2JnLXNreS02MDAgdGV4dC13aGl0ZSBib3JkZXItc2t5LTQwMCcgOiAnYmctc2xhdGUtOTUwIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS00MDAnXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8RmxpcEhvcml6b250YWwgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5GbGlwIEg8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RmxpcFYoIWZsaXBWKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQteGwgYm9yZGVyIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgZm9udC1ib2xkICR7XG4gICAgICAgICAgICAgICAgICAgICAgZmxpcFYgPyAnYmctc2t5LTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1za3ktNDAwJyA6ICdiZy1zbGF0ZS05NTAgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxGbGlwVmVydGljYWwgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5GbGlwIFY8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIEZyYW1lIFpvb20gKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xIHB0LTFcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtNDAwIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkZyYW1lIFNjYWxlIC8gWm9vbTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXdoaXRlXCI+e01hdGgucm91bmQoem9vbUxldmVsICogMTAwKX0lPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgIG1pbj1cIjAuNVwiXG4gICAgICAgICAgICAgICAgICBtYXg9XCIyLjBcIlxuICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDVcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3pvb21MZXZlbH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Wm9vbUxldmVsKE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGFjY2VudC1yb3NlLTUwMCBoLTEuNSBiZy1zbGF0ZS04MDAgcm91bmRlZCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIFRBQiAzOiBDT0xPUiBHUkFESU5HICYgQ0lORU1BVElDIEZJTFRFUlMgKi99XG4gICAgICAgICAge2FjdGl2ZVRvb2xUYWIgPT09ICdjb2xvcicgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgYW5pbWF0ZS1pbiBmYWRlLWluIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+Q29sb3IgR3JhZGluZyAmIENpbmVtYXRpYyBGaWx0ZXJzPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0QnJpZ2h0bmVzcygwKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0Q29udHJhc3QoMCk7XG4gICAgICAgICAgICAgICAgICAgIHNldFNhdHVyYXRpb24oMCk7XG4gICAgICAgICAgICAgICAgICAgIHNldFdhcm10aCgwKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0RmlsdGVyUHJlc2V0KCdub3JtYWwnKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBSZXNldFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogUHJlc2V0cyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICB7W1xuICAgICAgICAgICAgICAgICAgeyBpZDogJ25vcm1hbCcsIGxhYmVsOiAnT3JpZ2luYWwnIH0sXG4gICAgICAgICAgICAgICAgICB7IGlkOiAnY2luZW1hdGljJywgbGFiZWw6ICfwn46sIDM1bW0gRmlsbScgfSxcbiAgICAgICAgICAgICAgICAgIHsgaWQ6ICd2aW50YWdlJywgbGFiZWw6ICfwn46e77iPIFZpbnRhZ2UgU2VwaWEnIH0sXG4gICAgICAgICAgICAgICAgICB7IGlkOiAnbmVvbicsIGxhYmVsOiAn8J+UriBDeWJlciBOZW9uJyB9LFxuICAgICAgICAgICAgICAgICAgeyBpZDogJ2J3JywgbGFiZWw6ICfwn5akIE5vaXIgQiZXJyB9XG4gICAgICAgICAgICAgICAgXS5tYXAoKHApID0+IChcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAga2V5PXtwLmlkfVxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RmlsdGVyUHJlc2V0KHAuaWQpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0xLjUgcHgtMiByb3VuZGVkLWxnIGJvcmRlciBmb250LWJvbGQgdGV4dC1jZW50ZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICBmaWx0ZXJQcmVzZXQgPT09IHAuaWRcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXJvc2UtNjAwIHRleHQtd2hpdGUgYm9yZGVyLXJvc2UtNDAwIHNoYWRvdydcbiAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTk1MCBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICB7cC5sYWJlbH1cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogQnJpZ2h0bmVzcyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtMzAwIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQtYW1iZXItMzAwXCI+PFN1biBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+IEJyaWdodG5lc3M8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC13aGl0ZVwiPnticmlnaHRuZXNzID4gMCA/IGArJHticmlnaHRuZXNzfWAgOiBicmlnaHRuZXNzfSU8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICAgICAgbWluPVwiLTQwXCJcbiAgICAgICAgICAgICAgICAgIG1heD1cIjQwXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXticmlnaHRuZXNzfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRCcmlnaHRuZXNzKE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGFjY2VudC1hbWJlci01MDAgaC0xLjUgYmctc2xhdGUtODAwIHJvdW5kZWQgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBDb250cmFzdCAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtMzAwIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQtc2t5LTMwMFwiPjxDb250cmFzdCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+IENvbnRyYXN0PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtd2hpdGVcIj57Y29udHJhc3QgPiAwID8gYCske2NvbnRyYXN0fWAgOiBjb250cmFzdH0lPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgIG1pbj1cIi00MFwiXG4gICAgICAgICAgICAgICAgICBtYXg9XCI0MFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17Y29udHJhc3R9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENvbnRyYXN0KE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGFjY2VudC1za3ktNTAwIGgtMS41IGJnLXNsYXRlLTgwMCByb3VuZGVkIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogU2F0dXJhdGlvbiAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtMzAwIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQtcGluay0zMDBcIj48RHJvcGxldHMgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiBTYXR1cmF0aW9uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtd2hpdGVcIj57c2F0dXJhdGlvbiA+IDAgPyBgKyR7c2F0dXJhdGlvbn1gIDogc2F0dXJhdGlvbn0lPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgIG1pbj1cIi01MFwiXG4gICAgICAgICAgICAgICAgICBtYXg9XCI1MFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17c2F0dXJhdGlvbn1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2F0dXJhdGlvbihOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBhY2NlbnQtcGluay01MDAgaC0xLjUgYmctc2xhdGUtODAwIHJvdW5kZWQgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBXYXJtdGggKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNsYXRlLTMwMCBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LW9yYW5nZS0zMDBcIj48RmxhbWUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiBXYXJtdGggLyBDb2xvciBDYXN0PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtd2hpdGVcIj57d2FybXRoID4gMCA/IGArJHt3YXJtdGh9YCA6IHdhcm10aH08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICAgICAgbWluPVwiLTQwXCJcbiAgICAgICAgICAgICAgICAgIG1heD1cIjQwXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt3YXJtdGh9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFdhcm10aChOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBhY2NlbnQtb3JhbmdlLTUwMCBoLTEuNSBiZy1zbGF0ZS04MDAgcm91bmRlZCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIFRBQiA0OiBUSVRMRVMsIExPV0VSLVRISVJEUyAmIENBUFRJT05TICovfVxuICAgICAgICAgIHthY3RpdmVUb29sVGFiID09PSAndGV4dCcgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgYW5pbWF0ZS1pbiBmYWRlLWluIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+QW5pbWF0ZWQgVGl0bGVzICYgTG93ZXItVGhpcmRzPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogVGV4dCBJbnB1dCAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgZm9udC1zZW1pYm9sZFwiPk92ZXJsYXkgVGV4dCBDb250ZW50OjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17dGV4dE92ZXJsYXlzWzBdPy50ZXh0IHx8ICcnfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbCA9IGUudGFyZ2V0LnZhbHVlO1xuICAgICAgICAgICAgICAgICAgICBzZXRUZXh0T3ZlcmxheXMoKHByZXYpID0+IFtcbiAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2WzBdLFxuICAgICAgICAgICAgICAgICAgICAgICAgdGV4dDogdmFsXG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBdKTtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHNob3AgbmFtZSwgb2ZmZXIsIG9yIHRpdGxlLi4uXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC13aGl0ZSBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBQb3NpdGlvbiAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgZm9udC1zZW1pYm9sZFwiPlNjcmVlbiBQb3NpdGlvbjo8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMyBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAge1sndG9wJywgJ2NlbnRlcicsICdib3R0b20nXS5tYXAoKHBvcykgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtwb3N9XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGV4dE92ZXJsYXlzKChwcmV2KSA9PiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsgLi4ucHJldlswXSwgcG9zaXRpb246IHBvcyBhcyBhbnkgfVxuICAgICAgICAgICAgICAgICAgICAgICAgXSk7XG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0xLjUgcm91bmRlZC1sZyBib3JkZXIgZm9udC1ib2xkIGNhcGl0YWxpemUgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRleHRPdmVybGF5c1swXT8ucG9zaXRpb24gPT09IHBvc1xuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1yb3NlLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1yb3NlLTQwMCBzaGFkb3cnXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTk1MCBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7cG9zfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogU3R5bGUgUHJlc2V0cyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgZm9udC1zZW1pYm9sZFwiPkdyYXBoaWMgU3R5bGU6PC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIHtbXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdsb3dlcl90aGlyZCcsIGxhYmVsOiAnQnJvYWRjYXN0IExvd2VyLVRoaXJkJyB9LFxuICAgICAgICAgICAgICAgICAgICB7IGlkOiAnbmVvbicsIGxhYmVsOiAnQ3liZXIgR2xvdycgfSxcbiAgICAgICAgICAgICAgICAgICAgeyBpZDogJ2Jhbm5lcicsIGxhYmVsOiAnRGFyayBTb2xpZCBCYW5uZXInIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdjbGVhbicsIGxhYmVsOiAnTWluaW1hbGlzdCBDbGVhbicgfVxuICAgICAgICAgICAgICAgICAgXS5tYXAoKHN0KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e3N0LmlkfVxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFRleHRPdmVybGF5cygocHJldikgPT4gW1xuICAgICAgICAgICAgICAgICAgICAgICAgICB7IC4uLnByZXZbMF0sIHN0eWxlOiBzdC5pZCBhcyBhbnkgfVxuICAgICAgICAgICAgICAgICAgICAgICAgXSk7XG4gICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTIgcm91bmRlZC1sZyBib3JkZXIgdGV4dC1sZWZ0IGZvbnQtYm9sZCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgdGV4dE92ZXJsYXlzWzBdPy5zdHlsZSA9PT0gc3QuaWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctcHVycGxlLTYwMC8yMCB0ZXh0LXB1cnBsZS0zMDAgYm9yZGVyLXB1cnBsZS01MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTk1MCBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge3N0LmxhYmVsfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogRm9udCBTaXplICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkZvbnQgU2l6ZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXdoaXRlXCI+e3RleHRPdmVybGF5c1swXT8uZm9udFNpemUgfHwgMjh9cHg8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICAgICAgbWluPVwiMTZcIlxuICAgICAgICAgICAgICAgICAgbWF4PVwiNjBcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3RleHRPdmVybGF5c1swXT8uZm9udFNpemUgfHwgMjh9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgc3ogPSBOdW1iZXIoZS50YXJnZXQudmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICBzZXRUZXh0T3ZlcmxheXMoKHByZXYpID0+IFt7IC4uLnByZXZbMF0sIGZvbnRTaXplOiBzeiB9XSk7XG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGFjY2VudC1yb3NlLTUwMCBoLTEuNSBiZy1zbGF0ZS04MDAgcm91bmRlZCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIFRBQiA1OiBPVkVSTEFZIEItUk9MTCAmIFdBVEVSTUFSSyAqL31cbiAgICAgICAgICB7YWN0aXZlVG9vbFRhYiA9PT0gJ292ZXJsYXknICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00IGFuaW1hdGUtaW4gZmFkZS1pbiB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGItMSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgICAgUGljdHVyZS1pbi1QaWN0dXJlICYgV2F0ZXJtYXJrXG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBXYXRlcm1hcmsgU2VjdGlvbiAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgcC0zIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtd2hpdGVcIj5TaG9wIEJyYW5kIFN0YW1wIC8gV2F0ZXJtYXJrOjwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3Nob3dXYXRlcm1hcmt9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2hvd1dhdGVybWFyayhlLnRhcmdldC5jaGVja2VkKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWNjZW50LXJvc2UtNTAwIHJvdW5kZWRcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt3YXRlcm1hcmtUZXh0fVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRXYXRlcm1hcmtUZXh0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBNdXphbW1pbCBPbmxpbmUgU2VydmljZSAtIDk1NjE0NjAzMTNcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLWxnIHB4LTIuNSBweS0xLjUgdGV4dC13aGl0ZSBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTQgZ2FwLTEuNSBwdC0xIHRleHQtWzEwcHhdXCI+XG4gICAgICAgICAgICAgICAgICB7Wyd0b3AtbGVmdCcsICd0b3AtcmlnaHQnLCAnYm90dG9tLWxlZnQnLCAnYm90dG9tLXJpZ2h0J10ubWFwKChwb3MpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIGtleT17cG9zfVxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFdhdGVybWFya1Bvcyhwb3MgYXMgYW55KX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0xIHJvdW5kZWQgYm9yZGVyIGNhcGl0YWxpemUgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHdhdGVybWFya1BvcyA9PT0gcG9zXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXJvc2UtNjAwIHRleHQtd2hpdGUgYm9yZGVyLXJvc2UtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05MDAgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIHtwb3MucmVwbGFjZSgnLScsICcgJyl9XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBPdmVybGF5IEltYWdlIENvbnRyb2xzICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBwLTMgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC13aGl0ZVwiPlBpY3R1cmUtaW4tUGljdHVyZSAoVHJhY2sgMik6PC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1wdXJwbGUtNDAwIGZvbnQtYm9sZCBob3Zlcjp1bmRlcmxpbmUgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgICAgVXBsb2FkXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cImltYWdlLypcIiBvbkNoYW5nZT17aGFuZGxlVXBsb2FkT3ZlcmxheUltYWdlfSBjbGFzc05hbWU9XCJoaWRkZW5cIiAvPlxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHtvdmVybGF5SW1hZ2VTcmMgPyAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMiBwdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5PdmVybGF5IFNjYWxlPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXdoaXRlXCI+e01hdGgucm91bmQob3ZlcmxheVNjYWxlICogMTAwKX0lPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgICAgICBtaW49XCIwLjFcIlxuICAgICAgICAgICAgICAgICAgICAgIG1heD1cIjAuNlwiXG4gICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDVcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtvdmVybGF5U2NhbGV9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRPdmVybGF5U2NhbGUoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGFjY2VudC1wdXJwbGUtNTAwIGgtMS41IGJnLXNsYXRlLTgwMCByb3VuZGVkIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+T3BhY2l0eTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC13aGl0ZVwiPntNYXRoLnJvdW5kKG92ZXJsYXlPcGFjaXR5ICogMTAwKX0lPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgICAgICBtaW49XCIwLjJcIlxuICAgICAgICAgICAgICAgICAgICAgIG1heD1cIjEuMFwiXG4gICAgICAgICAgICAgICAgICAgICAgc3RlcD1cIjAuMDVcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtvdmVybGF5T3BhY2l0eX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE92ZXJsYXlPcGFjaXR5KE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBhY2NlbnQtcHVycGxlLTUwMCBoLTEuNSBiZy1zbGF0ZS04MDAgcm91bmRlZCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgTm8gaW1hZ2Ugb3ZlcmxheSBhdHRhY2hlZC4gQ2xpY2sgVXBsb2FkIHRvIGluc2VydCBhIGxvZ28gb3IgcGhvdG8gaW5zaWRlIHRoZSB2aWRlby5cbiAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogVEFCIDY6IEFVRElPIE1JWElORyAmIFNPVU5EICovfVxuICAgICAgICAgIHthY3RpdmVUb29sVGFiID09PSAnYXVkaW8nICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00IGFuaW1hdGUtaW4gZmFkZS1pbiB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGItMSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XG4gICAgICAgICAgICAgICAgQXVkaW8gTWl4aW5nICYgU291bmR0cmFja3NcbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIE1hc3RlciBWaWRlbyBWb2x1bWUgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHAtMyByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtMzAwIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj48Vm9sdW1lMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYmx1ZS00MDBcIiAvPiBNYWluIFZpZGVvIEF1ZGlvPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtd2hpdGVcIj57bWFzdGVyVm9sdW1lfSU8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXG4gICAgICAgICAgICAgICAgICBtYXg9XCIyMDBcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e21hc3RlclZvbHVtZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB2b2wgPSBOdW1iZXIoZS50YXJnZXQudmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICBzZXRNYXN0ZXJWb2x1bWUodm9sKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHZpZGVvUmVmLmN1cnJlbnQpIHZpZGVvUmVmLmN1cnJlbnQudm9sdW1lID0gTWF0aC5taW4oMS4wLCB2b2wgLyAxMDApO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBhY2NlbnQtYmx1ZS01MDAgaC0xLjUgYmctc2xhdGUtODAwIHJvdW5kZWQgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBCYWNrZ3JvdW5kIE11c2ljIFZvbHVtZSAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgcC0zIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS0zMDAgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPjxNdXNpYyBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYW1iZXItNDAwXCIgLz4gVHJhY2sgMzogQkdNIFZvbHVtZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXdoaXRlXCI+e211c2ljVm9sdW1lfSU8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICAgICAgbWluPVwiMFwiXG4gICAgICAgICAgICAgICAgICBtYXg9XCIxMDBcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e211c2ljVm9sdW1lfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHZvbCA9IE51bWJlcihlLnRhcmdldC52YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIHNldE11c2ljVm9sdW1lKHZvbCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChhdWRpb1JlZi5jdXJyZW50KSBhdWRpb1JlZi5jdXJyZW50LnZvbHVtZSA9IHZvbCAvIDEwMDtcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYWNjZW50LWFtYmVyLTUwMCBoLTEuNSBiZy1zbGF0ZS04MDAgcm91bmRlZCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==