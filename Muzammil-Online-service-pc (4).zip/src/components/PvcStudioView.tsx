const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { Upload, Printer, Download, Move, Check, Layers, ArrowUpDown, Sun, Contrast, Square, Sliders, Droplets, Flame, CheckCircle2 } from "/node_modules/.vite/deps/lucide-react.js?v=090625a0";
import { jsPDF } from "/node_modules/.vite/deps/jspdf.js?v=090625a0";
import { addDownloadRecord } from "/src/utils/storage.ts";
import { printImageSheet } from "/src/utils/printer.ts";
var _jsxFileName = "/app/applet/src/components/PvcStudioView.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
export const PvcStudioView = () => {
	// Canvas references
	const canvasRef = useRef(null);
	// Card images (Data URLs or Image objects)
	const [card1Src, setCard1Src] = useState(null);
	const [card2Src, setCard2Src] = useState(null);
	// Active editing card: 'card1' | 'card2'
	const [activeCard, setActiveCard] = useState("card1");
	// Adjustments per card
	const [card1Config, setCard1Config] = useState({
		x: 0,
		y: 0,
		scale: 1,
		rotation: 0
	});
	const [card2Config, setCard2Config] = useState({
		x: 0,
		y: 0,
		scale: 1,
		rotation: 0
	});
	// Global card adjustments
	const [brightness, setBrightness] = useState(0);
	const [contrast, setContrast] = useState(0);
	const [showCutMarks, setShowCutMarks] = useState(true);
	const [roundedCorners, setRoundedCorners] = useState(true);
	const [borderStroke, setBorderStroke] = useState(true);
	const [isProcessing, setIsProcessing] = useState(false);
	const [printAlert, setPrintAlert] = useState(null);
	// SECTION SELECTION TOOL & LOCAL COLOR GRADING STATE
	const [interactionMode, setInteractionMode] = useState("move");
	const [card1Section, setCard1Section] = useState(null);
	const [card2Section, setCard2Section] = useState(null);
	// Local Color Grading parameters for the selected section
	const [sectionBrightness, setSectionBrightness] = useState(15);
	const [sectionContrast, setSectionContrast] = useState(10);
	const [sectionSaturation, setSectionSaturation] = useState(0);
	const [sectionWarmth, setSectionWarmth] = useState(0);
	const [sectionFeather, setSectionFeather] = useState(6);
	// Interactive mouse dragging & box selection state
	const [isDragging, setIsDragging] = useState(false);
	const [dragCard, setDragCard] = useState(null);
	const [dragStart, setDragStart] = useState({
		x: 0,
		y: 0
	});
	const [isSelectingBox, setIsSelectingBox] = useState(false);
	const [selectionStartNorm, setSelectionStartNorm] = useState(null);
	// 300 DPI constants for 4x6 inch paper:
	// 4 inches = 1200 px, 6 inches = 1800 px
	const CANVAS_WIDTH = 1200;
	const CANVAS_HEIGHT = 1800;
	// Exact 5.5 cm × 8.5 cm (85 mm × 55 mm) dimensions at 300 DPI:
	// 1 inch = 2.54 cm -> 300 px / 2.54 cm = 118.1102 px per cm
	// Width: 8.5 cm * 118.1102 ≈ 1004 px
	// Height: 5.5 cm * 118.1102 ≈ 650 px
	const CARD_WIDTH = 1004;
	const CARD_HEIGHT = 650;
	// Position on 4x6 inch Portrait Sheet (1200 x 1800 px):
	// X Center: 1200 / 2 = 600 px (98 px margin on left and right = ~8.3 mm)
	// Top Card Center (Front): Y = 465 px
	// Center Cut Guideline: Y = 900 px
	// Bottom Card Center (Back): Y = 1335 px
	const CARD_CENTER_X = 600;
	const CARD1_DEFAULT_Y = 465;
	const CARD2_DEFAULT_Y = 1335;
	// Pre-load images for canvas drawing
	const card1ImgRef = useRef(null);
	const card2ImgRef = useRef(null);
	// Load card 1 image
	useEffect(() => {
		if (card1Src) {
			const img = new Image();
			img.crossOrigin = "anonymous";
			img.onload = () => {
				card1ImgRef.current = img;
				renderCanvas();
			};
			img.src = card1Src;
		} else {
			card1ImgRef.current = null;
			renderCanvas();
		}
	}, [card1Src]);
	// Load card 2 image
	useEffect(() => {
		if (card2Src) {
			const img = new Image();
			img.crossOrigin = "anonymous";
			img.onload = () => {
				card2ImgRef.current = img;
				renderCanvas();
			};
			img.src = card2Src;
		} else {
			card2ImgRef.current = null;
			renderCanvas();
		}
	}, [card2Src]);
	// Global Keyboard shortcuts listener (Ctrl+P, Ctrl+S, Ctrl+J)
	useEffect(() => {
		const handleGlobalPrint = () => handleDirectPrint();
		const handleGlobalPdf = () => handleDownloadPDF();
		const handleGlobalJpg = () => handleDownloadJPG();
		window.addEventListener("app-direct-print", handleGlobalPrint);
		window.addEventListener("app-direct-pdf", handleGlobalPdf);
		window.addEventListener("app-direct-jpg", handleGlobalJpg);
		return () => {
			window.removeEventListener("app-direct-print", handleGlobalPrint);
			window.removeEventListener("app-direct-pdf", handleGlobalPdf);
			window.removeEventListener("app-direct-jpg", handleGlobalJpg);
		};
	});
	// Re-render canvas whenever configs or section adjustments change
	useEffect(() => {
		renderCanvas();
	}, [
		card1Config,
		card2Config,
		brightness,
		contrast,
		showCutMarks,
		roundedCorners,
		borderStroke,
		card1Section,
		card2Section,
		sectionBrightness,
		sectionContrast,
		sectionSaturation,
		sectionWarmth,
		sectionFeather,
		interactionMode,
		activeCard
	]);
	// Main Render Function to Canvas @ 300 DPI
	const renderCanvas = (hideMarquee = false) => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		// Clear background to pure white (for photo paper print)
		ctx.fillStyle = "#ffffff";
		ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
		// Global filter string
		const globalFilterStr = `brightness(${100 + brightness}%) contrast(${100 + contrast}%)`;
		// 1. Draw Card 1 (Top / Front)
		drawSingleCard(ctx, card1ImgRef.current, CARD_CENTER_X + card1Config.x, CARD1_DEFAULT_Y + card1Config.y, card1Config.scale, card1Config.rotation, "Card 1 (Front)", globalFilterStr, card1Section, activeCard === "card1", hideMarquee);
		// 2. Draw Card 2 (Bottom / Back)
		drawSingleCard(ctx, card2ImgRef.current, CARD_CENTER_X + card2Config.x, CARD2_DEFAULT_Y + card2Config.y, card2Config.scale, card2Config.rotation, "Card 2 (Back)", globalFilterStr, card2Section, activeCard === "card2", hideMarquee);
		// 3. Draw Cut Guide Line between cards
		if (showCutMarks) {
			ctx.save();
			ctx.strokeStyle = "#94a3b8";
			ctx.lineWidth = 2;
			ctx.setLineDash([8, 8]);
			// Horizontal center cut mark (exact center of 4x6 inch sheet)
			const midY = 900;
			ctx.beginPath();
			ctx.moveTo(40, midY);
			ctx.lineTo(CANVAS_WIDTH - 40, midY);
			ctx.stroke();
			// Scissor indicator text
			ctx.setLineDash([]);
			ctx.fillStyle = "#64748b";
			ctx.font = "bold 20px sans-serif";
			ctx.textAlign = "center";
			ctx.fillText("✂ Cut Here (Fold / Separate • 5.5 cm × 8.5 cm Each)", CANVAS_WIDTH / 2, midY - 12);
			// Sheet boundary crop corners
			drawCropMarks(ctx, 40, 40);
			drawCropMarks(ctx, CANVAS_WIDTH - 40, 40);
			drawCropMarks(ctx, 40, CANVAS_HEIGHT - 40);
			drawCropMarks(ctx, CANVAS_WIDTH - 40, CANVAS_HEIGHT - 40);
			ctx.restore();
		}
	};
	const drawCropMarks = (ctx, x, y) => {
		ctx.strokeStyle = "#cbd5e1";
		ctx.lineWidth = 2;
		ctx.beginPath();
		ctx.moveTo(x - 20, y);
		ctx.lineTo(x + 20, y);
		ctx.moveTo(x, y - 20);
		ctx.lineTo(x, y + 20);
		ctx.stroke();
	};
	const drawSingleCard = (ctx, img, centerX, centerY, scale, rotation, placeholderLabel, filter, section, isActiveCard, hideMarquee = false) => {
		const w = CARD_WIDTH;
		const h = CARD_HEIGHT;
		const left = centerX - w / 2;
		const top = centerY - h / 2;
		ctx.save();
		// Clip to rounded CR-80 card standard boundary (3.18mm radius = ~35px @ 300 DPI)
		const radius = roundedCorners ? 35 : 0;
		ctx.beginPath();
		ctx.roundRect(left, top, w, h, radius);
		ctx.clip();
		if (img) {
			// 1. Draw base card image
			ctx.save();
			ctx.filter = filter;
			ctx.translate(centerX, centerY);
			ctx.rotate(rotation * Math.PI / 180);
			ctx.scale(scale, scale);
			ctx.drawImage(img, -w / 2, -h / 2, w, h);
			ctx.restore();
			// 2. Draw Local Section Color Grading if a section is defined on this card
			if (section && section.w > .01 && section.h > .01) {
				ctx.save();
				// Calculate section box in canvas pixels
				const secX = left + section.x * w;
				const secY = top + section.y * h;
				const secW = section.w * w;
				const secH = section.h * h;
				// Clip to the selected section box with optional feathering
				ctx.save();
				ctx.beginPath();
				ctx.rect(secX, secY, secW, secH);
				ctx.clip();
				// Local filter string
				const effBright = 100 + brightness + sectionBrightness;
				const effCont = 100 + contrast + sectionContrast;
				const effSat = 100 + sectionSaturation;
				ctx.filter = `brightness(${effBright}%) contrast(${effCont}%) saturate(${effSat}%)`;
				// Redraw image inside the clipped section with the enhanced color grading
				ctx.translate(centerX, centerY);
				ctx.rotate(rotation * Math.PI / 180);
				ctx.scale(scale, scale);
				ctx.drawImage(img, -w / 2, -h / 2, w, h);
				ctx.restore();
				// Apply warmth overlay to the section if set
				if (sectionWarmth !== 0) {
					ctx.save();
					ctx.beginPath();
					ctx.rect(secX, secY, secW, secH);
					ctx.clip();
					ctx.globalCompositeOperation = "color";
					ctx.fillStyle = sectionWarmth > 0 ? `rgba(255, 170, 70, ${Math.min(.4, sectionWarmth / 100 * .5)})` : `rgba(70, 160, 255, ${Math.min(.4, Math.abs(sectionWarmth) / 100 * .5)})`;
					ctx.fillRect(secX, secY, secW, secH);
					ctx.restore();
				}
				// Draw animated/high-visibility selection dashed marquee border only in screen UI mode
				if (!hideMarquee) {
					ctx.save();
					ctx.strokeStyle = isActiveCard ? "#06b6d4" : "#64748b";
					ctx.lineWidth = 3;
					ctx.setLineDash([8, 6]);
					ctx.strokeRect(secX, secY, secW, secH);
					// Selection Tag Badge
					ctx.fillStyle = isActiveCard ? "rgba(6, 182, 212, 0.9)" : "rgba(100, 116, 139, 0.8)";
					ctx.fillRect(secX, Math.max(top, secY - 24), 160, 22);
					ctx.fillStyle = "#ffffff";
					ctx.font = "bold 12px sans-serif";
					ctx.fillText(`🎯 Section (${sectionBrightness > 0 ? "+" : ""}${sectionBrightness}B / ${sectionContrast > 0 ? "+" : ""}${sectionContrast}C)`, secX + 6, Math.max(top, secY - 24) + 16);
					ctx.restore();
				}
				ctx.restore();
			}
		} else {
			// Empty placeholder slot
			ctx.fillStyle = "#f8fafc";
			ctx.fill();
			ctx.strokeStyle = "#cbd5e1";
			ctx.lineWidth = 4;
			ctx.setLineDash([12, 8]);
			ctx.stroke();
			// Placeholder text
			ctx.fillStyle = "#64748b";
			ctx.font = "bold 36px sans-serif";
			ctx.textAlign = "center";
			ctx.fillText(placeholderLabel, centerX, centerY - 20);
			ctx.font = "24px sans-serif";
			ctx.fillStyle = "#94a3b8";
			ctx.fillText("Drop image or PDF to place here", centerX, centerY + 30);
			ctx.fillText("Official Size: 5.5 cm × 8.5 cm (85 mm × 55 mm)", centerX, centerY + 70);
		}
		// Border line around card
		if (borderStroke) {
			ctx.beginPath();
			ctx.roundRect(left, top, w, h, radius);
			ctx.strokeStyle = !hideMarquee && isActiveCard && interactionMode === "section_select" ? "#38bdf8" : "#1e293b";
			ctx.lineWidth = !hideMarquee && isActiveCard && interactionMode === "section_select" ? 3 : 2;
			ctx.setLineDash([]);
			ctx.stroke();
		}
		ctx.restore();
	};
	// Convert click on canvas to card-normalized coordinate (0..1)
	const getCardNormalizedCoords = (canvasX, canvasY, targetCard) => {
		const centerX = CARD_CENTER_X + (targetCard === "card1" ? card1Config.x : card2Config.x);
		const centerY = (targetCard === "card1" ? CARD1_DEFAULT_Y : CARD2_DEFAULT_Y) + (targetCard === "card1" ? card1Config.y : card2Config.y);
		const left = centerX - CARD_WIDTH / 2;
		const top = centerY - CARD_HEIGHT / 2;
		const normX = (canvasX - left) / CARD_WIDTH;
		const normY = (canvasY - top) / CARD_HEIGHT;
		return {
			normX,
			normY,
			isInside: normX >= 0 && normX <= 1 && normY >= 0 && normY <= 1
		};
	};
	// Upload handler for Card 1 or Card 2
	const handleFileUpload = (e, target) => {
		const file = e.target.files?.[0];
		if (!file) return;
		const reader = new FileReader();
		reader.onload = (event) => {
			const result = event.target?.result;
			if (target === "card1") {
				setCard1Src(result);
				setActiveCard("card1");
			} else {
				setCard2Src(result);
				setActiveCard("card2");
			}
		};
		reader.readAsDataURL(file);
		e.target.value = "";
	};
	// Swap Front & Back cards
	const handleSwapCards = () => {
		const tempSrc = card1Src;
		setCard1Src(card2Src);
		setCard2Src(tempSrc);
		const tempCfg = { ...card1Config };
		setCard1Config({ ...card2Config });
		setCard2Config(tempCfg);
		const tempSec = card1Section;
		setCard1Section(card2Section);
		setCard2Section(tempSec);
	};
	// Quick Preset Selection on active card
	const handleApplyPresetSection = (preset) => {
		let box;
		switch (preset) {
			case "photo":
				// Standard ID photo region on citizen cards (top-left)
				box = {
					x: .04,
					y: .18,
					w: .34,
					h: .64
				};
				break;
			case "details":
				// Name, address, DOB text region (center-right)
				box = {
					x: .4,
					y: .18,
					w: .56,
					h: .68
				};
				break;
			case "qr":
				// QR Code region (bottom or right)
				box = {
					x: .62,
					y: .18,
					w: .34,
					h: .64
				};
				break;
			case "signature":
				// Signature box
				box = {
					x: .04,
					y: .68,
					w: .42,
					h: .28
				};
				break;
		}
		if (activeCard === "card1") {
			setCard1Section(box);
		} else {
			setCard2Section(box);
		}
		setInteractionMode("section_select");
	};
	// Bake Section Color Grading directly into the Card image
	const handleBakeSectionGrading = () => {
		const targetSrc = activeCard === "card1" ? card1Src : card2Src;
		const targetSection = activeCard === "card1" ? card1Section : card2Section;
		if (!targetSrc || !targetSection) return;
		setIsProcessing(true);
		try {
			const img = new Image();
			img.crossOrigin = "anonymous";
			img.onload = () => {
				const offCanvas = document.createElement("canvas");
				offCanvas.width = img.width;
				offCanvas.height = img.height;
				const ctx = offCanvas.getContext("2d");
				if (!ctx) return;
				// 1. Draw original base
				ctx.drawImage(img, 0, 0);
				// 2. Draw graded section on top
				const secX = targetSection.x * img.width;
				const secY = targetSection.y * img.height;
				const secW = targetSection.w * img.width;
				const secH = targetSection.h * img.height;
				ctx.save();
				ctx.beginPath();
				ctx.rect(secX, secY, secW, secH);
				ctx.clip();
				const effBright = 100 + sectionBrightness;
				const effCont = 100 + sectionContrast;
				const effSat = 100 + sectionSaturation;
				ctx.filter = `brightness(${effBright}%) contrast(${effCont}%) saturate(${effSat}%)`;
				ctx.drawImage(img, 0, 0);
				if (sectionWarmth !== 0) {
					ctx.globalCompositeOperation = "color";
					ctx.fillStyle = sectionWarmth > 0 ? `rgba(255, 170, 70, ${Math.min(.4, sectionWarmth / 100 * .5)})` : `rgba(70, 160, 255, ${Math.min(.4, Math.abs(sectionWarmth) / 100 * .5)})`;
					ctx.fillRect(secX, secY, secW, secH);
				}
				ctx.restore();
				const bakedUrl = offCanvas.toDataURL("image/jpeg", .98);
				if (activeCard === "card1") {
					setCard1Src(bakedUrl);
					setCard1Section(null);
				} else {
					setCard2Src(bakedUrl);
					setCard2Section(null);
				}
				setPrintAlert(`✅ Section grading permanently baked into ${activeCard === "card1" ? "Card 1 (Front)" : "Card 2 (Back)"}!`);
				setTimeout(() => setPrintAlert(null), 4e3);
			};
			img.src = targetSrc;
		} catch (e) {
			console.error(e);
		} finally {
			setIsProcessing(false);
		}
	};
	// Clear Section Box
	const handleClearSection = () => {
		if (activeCard === "card1") {
			setCard1Section(null);
		} else {
			setCard2Section(null);
		}
	};
	// Download High-Res 300 DPI JPG
	const handleDownloadJPG = () => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		setIsProcessing(true);
		try {
			// Re-render without marquee for pristine export
			renderCanvas(true);
			const dataUrl = canvas.toDataURL("image/jpeg", .98);
			// Restore interactive UI canvas
			renderCanvas(false);
			const a = document.createElement("a");
			a.href = dataUrl;
			const fileName = `PVC_Card_5.5x8.5cm_4x6_${Date.now()}.jpg`;
			a.download = fileName;
			a.click();
			addDownloadRecord({
				id: `pvc-jpg-${Date.now()}`,
				title: fileName,
				type: "PVC Card JPG",
				size: "1200×1800 px (300 DPI)",
				timestamp: new Date().toLocaleTimeString("en-IN")
			});
		} catch (e) {
			console.error(e);
			renderCanvas(false);
		} finally {
			setIsProcessing(false);
		}
	};
	// Download 300 DPI PDF (Exact 4x6 inch paper size)
	const handleDownloadPDF = () => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		setIsProcessing(true);
		try {
			// Re-render without marquee for pristine export
			renderCanvas(true);
			const dataUrl = canvas.toDataURL("image/jpeg", .98);
			// Restore interactive UI canvas
			renderCanvas(false);
			const pdf = new jsPDF({
				orientation: "portrait",
				unit: "in",
				format: [4, 6]
			});
			pdf.addImage(dataUrl, "JPEG", 0, 0, 4, 6);
			const fileName = `PVC_Card_5.5x8.5cm_4x6_${Date.now()}.pdf`;
			pdf.save(fileName);
			addDownloadRecord({
				id: `pvc-pdf-${Date.now()}`,
				title: fileName,
				type: "PVC Card PDF",
				size: "4×6 inch (300 DPI)",
				timestamp: new Date().toLocaleTimeString("en-IN")
			});
		} catch (e) {
			console.error(e);
			renderCanvas(false);
		} finally {
			setIsProcessing(false);
		}
	};
	// Direct Browser Print (Formatted for 4x6 photo paper)
	const handleDirectPrint = () => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		try {
			// Re-render without marquee for pristine print
			renderCanvas(true);
			const dataUrl = canvas.toDataURL("image/jpeg", 1);
			// Restore interactive UI canvas
			renderCanvas(false);
			printImageSheet(dataUrl, {
				paperFormat: "4x6_portrait",
				title: "PVC_Card_5.5x8.5cm_Print"
			});
			setPrintAlert("🖨️ PVC Card print command sent to printer! (4×6 Photo Paper Portrait • Exact 5.5 cm × 8.5 cm)");
			setTimeout(() => setPrintAlert(null), 4e3);
		} catch (e) {
			console.error(e);
			renderCanvas(false);
			window.print();
		}
	};
	// Interactive Mouse Down on Canvas (Supports Move Card and Drag-to-Select-Section)
	const handleMouseDown = (e) => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const rect = canvas.getBoundingClientRect();
		const scaleX = CANVAS_WIDTH / rect.width;
		const scaleY = CANVAS_HEIGHT / rect.height;
		const mouseX = (e.clientX - rect.left) * scaleX;
		const mouseY = (e.clientY - rect.top) * scaleY;
		// Detect clicked card
		const clickedCard = mouseY < CANVAS_HEIGHT / 2 ? "card1" : "card2";
		setActiveCard(clickedCard);
		if (interactionMode === "section_select") {
			// Start drag box selection on clicked card
			const coords = getCardNormalizedCoords(mouseX, mouseY, clickedCard);
			if (coords.isInside) {
				setIsSelectingBox(true);
				setSelectionStartNorm({
					x: coords.normX,
					y: coords.normY
				});
				const initialBox = {
					x: coords.normX,
					y: coords.normY,
					w: .01,
					h: .01
				};
				if (clickedCard === "card1") setCard1Section(initialBox);
				else setCard2Section(initialBox);
			}
		} else {
			// Move mode
			setDragCard(clickedCard);
			setIsDragging(true);
			const cfg = clickedCard === "card1" ? card1Config : card2Config;
			setDragStart({
				x: mouseX - cfg.x,
				y: mouseY - cfg.y
			});
		}
	};
	const handleMouseMove = (e) => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const rect = canvas.getBoundingClientRect();
		const scaleX = CANVAS_WIDTH / rect.width;
		const scaleY = CANVAS_HEIGHT / rect.height;
		const mouseX = (e.clientX - rect.left) * scaleX;
		const mouseY = (e.clientY - rect.top) * scaleY;
		// If drawing a selection marquee box
		if (isSelectingBox && selectionStartNorm) {
			const coords = getCardNormalizedCoords(mouseX, mouseY, activeCard);
			const currentX = Math.max(0, Math.min(1, coords.normX));
			const currentY = Math.max(0, Math.min(1, coords.normY));
			const boxX = Math.min(selectionStartNorm.x, currentX);
			const boxY = Math.min(selectionStartNorm.y, currentY);
			const boxW = Math.max(.01, Math.abs(currentX - selectionStartNorm.x));
			const boxH = Math.max(.01, Math.abs(currentY - selectionStartNorm.y));
			const updatedBox = {
				x: boxX,
				y: boxY,
				w: boxW,
				h: boxH
			};
			if (activeCard === "card1") setCard1Section(updatedBox);
			else setCard2Section(updatedBox);
			return;
		}
		// If dragging card position
		if (isDragging && dragCard) {
			if (dragCard === "card1") {
				setCard1Config((prev) => ({
					...prev,
					x: Math.round(mouseX - dragStart.x),
					y: Math.round(mouseY - dragStart.y)
				}));
			} else {
				setCard2Config((prev) => ({
					...prev,
					x: Math.round(mouseX - dragStart.x),
					y: Math.round(mouseY - dragStart.y)
				}));
			}
		}
	};
	const handleMouseUp = () => {
		setIsDragging(false);
		setDragCard(null);
		setIsSelectingBox(false);
		setSelectionStartNorm(null);
	};
	const activeCardSection = activeCard === "card1" ? card1Section : card2Section;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 flex-wrap",
					children: [
						/* @__PURE__ */ _jsxDEV("h1", {
							className: "text-xl font-extrabold text-white flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Layers, { className: "w-5 h-5 text-blue-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 756,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "PVC Smart Card Studio (5.5 cm × 8.5 cm)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 757,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 755,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "bg-blue-500/20 text-blue-400 border border-blue-500/30 text-xs px-2.5 py-0.5 rounded-full font-mono font-bold",
							children: "300 DPI Ultra HD"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 759,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs px-2.5 py-0.5 rounded-full font-bold",
							children: "4×6 inch Portrait Layout"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 762,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("span", {
							className: "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs px-2.5 py-0.5 rounded-full font-bold flex items-center gap-1",
							children: [/* @__PURE__ */ _jsxDEV(Square, { className: "w-3 h-3" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 766,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Section Color Grading Active" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 767,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 765,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 754,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400 mt-1",
					children: "Print 5.5 cm × 8.5 cm CR-80 cards on 4×6 inch portrait photo paper with pinpoint local color grading for dark photos & faint text."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 770,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 753,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 flex-wrap",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleDirectPrint,
							className: "flex items-center gap-2 bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-105 active:scale-95 border border-blue-400/30",
							title: "Direct Print to Epson / Canon (Ctrl + P)",
							children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-4 h-4 text-white" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 782,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "🖨️ Direct Print PVC Card" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 783,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 777,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleDownloadPDF,
							disabled: isProcessing,
							className: "flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs px-3.5 py-2.5 rounded-xl shadow-lg shadow-indigo-600/30 transition-all hover:scale-105 disabled:opacity-50",
							title: "Download Printable 300 DPI PDF",
							children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 792,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "📄 PDF (4×6)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 793,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 786,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleDownloadJPG,
							disabled: isProcessing,
							className: "flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white font-bold text-xs px-3 py-2.5 rounded-xl border border-slate-700 transition-all",
							title: "Download High-Res 1200x1800 JPG",
							children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 802,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "🖼️ HD JPG" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 803,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 796,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 776,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 752,
				columnNumber: 7
			}, this),
			printAlert && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2 animate-in fade-in",
				children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4 text-emerald-400 flex-shrink-0" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 811,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: printAlert }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 812,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 810,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-5 items-start",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-5 space-y-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-slate-300 uppercase tracking-wider",
										children: "Card Slots & Images"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 823,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: handleSwapCards,
										className: "text-xs font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1",
										title: "Swap Front and Back Cards",
										children: [/* @__PURE__ */ _jsxDEV(ArrowUpDown, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 829,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Swap Front/Back" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 830,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 824,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 822,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: `p-3 rounded-xl border transition-all ${activeCard === "card1" ? "bg-blue-950/30 border-blue-500/50 shadow-sm" : "bg-slate-950/40 border-slate-800 hover:border-slate-700"}`,
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between mb-2",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-blue-500" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 842,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-xs text-white",
												children: "Card 1 (Front Side)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 843,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 841,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setActiveCard("card1"),
											className: `text-[11px] px-2 py-0.5 rounded font-bold transition-colors ${activeCard === "card1" ? "bg-blue-600 text-white" : "text-slate-400 hover:text-white"}`,
											children: "Active"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 845,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 840,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "flex-1 flex items-center justify-center gap-2 py-2 px-3 bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold rounded-lg cursor-pointer border border-slate-700 transition-colors",
											children: [
												/* @__PURE__ */ _jsxDEV(Upload, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 857,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("span", { children: card1Src ? "Change Front Photo/PDF" : "Upload Card 1 (Front)" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 858,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("input", {
													type: "file",
													accept: "image/*,.pdf",
													onChange: (e) => handleFileUpload(e, "card1"),
													className: "hidden"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 859,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 856,
											columnNumber: 17
										}, this), card1Src && /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setCard1Src(null),
											className: "p-2 text-rose-400 hover:bg-rose-500/10 rounded-lg text-xs",
											title: "Remove Card 1",
											children: "✕"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 862,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 855,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 835,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: `p-3 rounded-xl border transition-all ${activeCard === "card2" ? "bg-purple-950/30 border-purple-500/50 shadow-sm" : "bg-slate-950/40 border-slate-800 hover:border-slate-700"}`,
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between mb-2",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-purple-500" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 881,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-xs text-white",
												children: "Card 2 (Back Side)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 882,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 880,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setActiveCard("card2"),
											className: `text-[11px] px-2 py-0.5 rounded font-bold transition-colors ${activeCard === "card2" ? "bg-purple-600 text-white" : "text-slate-400 hover:text-white"}`,
											children: "Active"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 884,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 879,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "flex-1 flex items-center justify-center gap-2 py-2 px-3 bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold rounded-lg cursor-pointer border border-slate-700 transition-colors",
											children: [
												/* @__PURE__ */ _jsxDEV(Upload, { className: "w-3.5 h-3.5 text-purple-400" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 896,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("span", { children: card2Src ? "Change Back Photo/PDF" : "Upload Card 2 (Back)" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 897,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("input", {
													type: "file",
													accept: "image/*,.pdf",
													onChange: (e) => handleFileUpload(e, "card2"),
													className: "hidden"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 898,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 895,
											columnNumber: 17
										}, this), card2Src && /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setCard2Src(null),
											className: "p-2 text-rose-400 hover:bg-rose-500/10 rounded-lg text-xs",
											title: "Remove Card 2",
											children: "✕"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 901,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 894,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 874,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 821,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-900 border border-cyan-500/30 rounded-2xl p-4 shadow-xl space-y-3",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between pb-2 border-b border-slate-800",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV(Square, { className: "w-4 h-4 text-cyan-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 917,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-extrabold text-white uppercase tracking-wider",
											children: "Section Selection & Color Grading"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 918,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 916,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] bg-cyan-500/20 text-cyan-300 font-bold px-2 py-0.5 rounded font-mono",
										children: activeCard === "card1" ? "Card 1 Front" : "Card 2 Back"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 922,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 915,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-300 leading-snug",
									children: [
										"Card ke kisi bhi hisse (e.g. Aadhaar Photo, Address Text, QR Code) ko select karke ",
										/* @__PURE__ */ _jsxDEV("b", { children: "sirf usi jagah ki Brightness aur Contrast" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 928,
											columnNumber: 98
										}, this),
										" adjust karein."
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 927,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-2 text-xs",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setInteractionMode("move"),
										className: `py-2 px-3 rounded-xl font-bold flex items-center justify-center gap-1.5 border transition-all ${interactionMode === "move" ? "bg-blue-600 text-white border-blue-400 shadow-md" : "bg-slate-950 text-slate-400 border-slate-800 hover:text-white"}`,
										children: [/* @__PURE__ */ _jsxDEV(Move, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 942,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Move Card Position" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 943,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 933,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setInteractionMode("section_select"),
										className: `py-2 px-3 rounded-xl font-bold flex items-center justify-center gap-1.5 border transition-all ${interactionMode === "section_select" ? "bg-gradient-to-r from-cyan-600 to-blue-600 text-white border-cyan-400 shadow-md shadow-cyan-600/30" : "bg-slate-950 text-slate-400 border-slate-800 hover:text-white"}`,
										children: [/* @__PURE__ */ _jsxDEV(Square, { className: "w-3.5 h-3.5 text-cyan-300" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 955,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Select Section Tool" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 956,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 946,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 932,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1.5 pt-1",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400 font-bold uppercase tracking-wider block",
										children: "1-Click Quick Select Preset:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 962,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-[11px]",
										children: [
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => handleApplyPresetSection("photo"),
												className: "p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-center",
												children: "👤 Photo Box"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 966,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => handleApplyPresetSection("details"),
												className: "p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-center",
												children: "📝 Details Text"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 973,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => handleApplyPresetSection("qr"),
												className: "p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-center",
												children: "📱 QR Code"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 980,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => handleApplyPresetSection("signature"),
												className: "p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-center",
												children: "✍️ Signature"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 987,
												columnNumber: 17
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 965,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 961,
									columnNumber: 13
								}, this),
								activeCardSection ? /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-3 pt-2 border-t border-slate-800/80 animate-in fade-in",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between text-xs",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "font-extrabold text-cyan-300 flex items-center gap-1",
												children: [/* @__PURE__ */ _jsxDEV(Sliders, { className: "w-3.5 h-3.5" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1002,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Grading Selected Region Only" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1003,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1001,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("button", {
												onClick: handleClearSection,
												className: "text-[10px] text-rose-400 hover:underline font-bold",
												children: "Clear Box"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1005,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1e3,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-xs space-y-1",
											children: [
												/* @__PURE__ */ _jsxDEV("div", {
													className: "flex justify-between text-slate-300 font-semibold",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "flex items-center gap-1.5 text-amber-300",
														children: [/* @__PURE__ */ _jsxDEV(Sun, { className: "w-3.5 h-3.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1017,
															columnNumber: 23
														}, this), " Section Brightness"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1016,
														columnNumber: 21
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "font-mono text-white",
														children: [sectionBrightness > 0 ? `+${sectionBrightness}` : sectionBrightness, "%"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1019,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1015,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("input", {
													type: "range",
													min: "-50",
													max: "50",
													value: sectionBrightness,
													onChange: (e) => setSectionBrightness(Number(e.target.value)),
													className: "w-full accent-amber-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1021,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "flex justify-between text-[10px] text-slate-500 font-mono",
													children: [
														/* @__PURE__ */ _jsxDEV("span", { children: "Darken -50%" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1030,
															columnNumber: 21
														}, this),
														/* @__PURE__ */ _jsxDEV("span", { children: "0" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1031,
															columnNumber: 21
														}, this),
														/* @__PURE__ */ _jsxDEV("span", { children: "Brighten +50%" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1032,
															columnNumber: 21
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1029,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1014,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-xs space-y-1",
											children: [
												/* @__PURE__ */ _jsxDEV("div", {
													className: "flex justify-between text-slate-300 font-semibold",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "flex items-center gap-1.5 text-sky-300",
														children: [/* @__PURE__ */ _jsxDEV(Contrast, { className: "w-3.5 h-3.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1040,
															columnNumber: 23
														}, this), " Section Contrast & Sharpness"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1039,
														columnNumber: 21
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "font-mono text-white",
														children: [sectionContrast > 0 ? `+${sectionContrast}` : sectionContrast, "%"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1042,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1038,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("input", {
													type: "range",
													min: "-50",
													max: "50",
													value: sectionContrast,
													onChange: (e) => setSectionContrast(Number(e.target.value)),
													className: "w-full accent-sky-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1044,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "flex justify-between text-[10px] text-slate-500 font-mono",
													children: [
														/* @__PURE__ */ _jsxDEV("span", { children: "Soft" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1053,
															columnNumber: 21
														}, this),
														/* @__PURE__ */ _jsxDEV("span", { children: "0" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1054,
															columnNumber: 21
														}, this),
														/* @__PURE__ */ _jsxDEV("span", { children: "Deep Contrast +50%" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1055,
															columnNumber: 21
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1052,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1037,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-xs space-y-1",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between text-slate-300 font-semibold",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "flex items-center gap-1.5 text-pink-300",
													children: [/* @__PURE__ */ _jsxDEV(Droplets, { className: "w-3.5 h-3.5" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1063,
														columnNumber: 23
													}, this), " Section Saturation"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1062,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "font-mono text-white",
													children: [sectionSaturation > 0 ? `+${sectionSaturation}` : sectionSaturation, "%"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1065,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1061,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "range",
												min: "-50",
												max: "50",
												value: sectionSaturation,
												onChange: (e) => setSectionSaturation(Number(e.target.value)),
												className: "w-full accent-pink-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1067,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1060,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-xs space-y-1",
											children: [
												/* @__PURE__ */ _jsxDEV("div", {
													className: "flex justify-between text-slate-300 font-semibold",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "flex items-center gap-1.5 text-orange-300",
														children: [/* @__PURE__ */ _jsxDEV(Flame, { className: "w-3.5 h-3.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1081,
															columnNumber: 23
														}, this), " Section Warmth / Tone"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1080,
														columnNumber: 21
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "font-mono text-white",
														children: sectionWarmth > 0 ? `+${sectionWarmth}` : sectionWarmth
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1083,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1079,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("input", {
													type: "range",
													min: "-50",
													max: "50",
													value: sectionWarmth,
													onChange: (e) => setSectionWarmth(Number(e.target.value)),
													className: "w-full accent-orange-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1085,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "flex justify-between text-[10px] text-slate-500 font-mono",
													children: [
														/* @__PURE__ */ _jsxDEV("span", { children: "Cool Blue" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1094,
															columnNumber: 21
														}, this),
														/* @__PURE__ */ _jsxDEV("span", { children: "Neutral" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1095,
															columnNumber: 21
														}, this),
														/* @__PURE__ */ _jsxDEV("span", { children: "Warm Glow" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1096,
															columnNumber: 21
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1093,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1078,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "pt-2 flex items-center gap-2",
											children: [/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: handleBakeSectionGrading,
												disabled: isProcessing,
												className: "flex-1 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs rounded-xl shadow-md flex items-center justify-center gap-1.5 transition-all",
												children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1108,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Apply / Bake to Card Image" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1109,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1102,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: handleClearSection,
												className: "px-3 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 text-xs font-bold rounded-xl",
												children: "Cancel"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1112,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1101,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 999,
									columnNumber: 15
								}, this) : /* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-[11px] text-slate-400 space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-slate-300 block",
										children: "💡 How to Select:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1123,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
										"Click ",
										/* @__PURE__ */ _jsxDEV("b", { children: "\"Select Section Tool\"" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1124,
											columnNumber: 29
										}, this),
										" above, then drag a rectangle over the dark photo or text area directly on the card preview!"
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1124,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1122,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 914,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-md space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-bold text-slate-300 uppercase tracking-wider block",
								children: "Whole Card Exposure & Cutting Guides"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1131,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between text-slate-400 mb-1",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ _jsxDEV(Sun, { className: "w-3.5 h-3.5 text-amber-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1138,
												columnNumber: 63
											}, this), " Whole Card Brightness"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1138,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono text-slate-200",
											children: brightness > 0 ? `+${brightness}` : brightness
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1139,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1137,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "range",
										min: "-30",
										max: "30",
										value: brightness,
										onChange: (e) => setBrightness(parseInt(e.target.value)),
										className: "w-full accent-amber-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1141,
										columnNumber: 17
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1136,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex justify-between text-slate-400 mb-1",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ _jsxDEV(Contrast, { className: "w-3.5 h-3.5 text-sky-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1153,
												columnNumber: 63
											}, this), " Whole Card Contrast"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1153,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-mono text-slate-200",
											children: contrast > 0 ? `+${contrast}` : contrast
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1154,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1152,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "range",
										min: "-30",
										max: "30",
										value: contrast,
										onChange: (e) => setContrast(parseInt(e.target.value)),
										className: "w-full accent-sky-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1156,
										columnNumber: 17
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1151,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "pt-2 border-t border-slate-800 grid grid-cols-2 gap-2",
										children: [
											/* @__PURE__ */ _jsxDEV("label", {
												className: "flex items-center gap-2 cursor-pointer text-slate-300",
												children: [/* @__PURE__ */ _jsxDEV("input", {
													type: "checkbox",
													checked: showCutMarks,
													onChange: (e) => setShowCutMarks(e.target.checked),
													className: "rounded accent-blue-600"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1168,
													columnNumber: 19
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "✂ Center Cut Line" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1174,
													columnNumber: 19
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1167,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("label", {
												className: "flex items-center gap-2 cursor-pointer text-slate-300",
												children: [/* @__PURE__ */ _jsxDEV("input", {
													type: "checkbox",
													checked: roundedCorners,
													onChange: (e) => setRoundedCorners(e.target.checked),
													className: "rounded accent-blue-600"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1178,
													columnNumber: 19
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Rounded CR80 Corner" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1184,
													columnNumber: 19
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1177,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("label", {
												className: "flex items-center gap-2 cursor-pointer text-slate-300",
												children: [/* @__PURE__ */ _jsxDEV("input", {
													type: "checkbox",
													checked: borderStroke,
													onChange: (e) => setBorderStroke(e.target.checked),
													className: "rounded accent-blue-600"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1188,
													columnNumber: 19
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Card Outline Border" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1194,
													columnNumber: 19
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1187,
												columnNumber: 17
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1166,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1135,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1130,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 819,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-7 space-y-3",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between mb-3 text-xs flex-wrap gap-2",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-extrabold text-white text-sm",
										children: "4×6 inch Portrait Sheet Preview"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1206,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] px-2 py-0.5 rounded font-mono font-bold",
										children: "Exact 5.5 cm × 8.5 cm"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1207,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400 font-mono",
										children: "1200×1800 px @ 300 DPI"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1210,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1205,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1.5",
								children: /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => setInteractionMode(interactionMode === "move" ? "section_select" : "move"),
									className: `px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1 border transition-all ${interactionMode === "section_select" ? "bg-cyan-600 text-white border-cyan-400 shadow" : "bg-slate-800 text-slate-300 border-slate-700"}`,
									children: [interactionMode === "section_select" ? /* @__PURE__ */ _jsxDEV(Square, { className: "w-3.5 h-3.5 text-cyan-200" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1224,
										columnNumber: 59
									}, this) : /* @__PURE__ */ _jsxDEV(Move, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1224,
										columnNumber: 110
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: interactionMode === "section_select" ? "Tool: Drag Selection Box" : "Tool: Drag to Move" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1225,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1215,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1214,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1204,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "relative bg-slate-950 p-2 sm:p-4 rounded-xl border border-slate-800 overflow-hidden flex items-center justify-center shadow-inner",
							children: [/* @__PURE__ */ _jsxDEV("canvas", {
								ref: canvasRef,
								width: CANVAS_WIDTH,
								height: CANVAS_HEIGHT,
								onMouseDown: handleMouseDown,
								onMouseMove: handleMouseMove,
								onMouseUp: handleMouseUp,
								onMouseLeave: handleMouseUp,
								className: `max-w-full h-auto bg-white rounded-lg shadow-2xl transition-all ${interactionMode === "section_select" ? "cursor-crosshair" : "cursor-move"}`,
								style: { maxHeight: "720px" }
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1232,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "absolute bottom-6 left-6 right-6 bg-slate-950/85 backdrop-blur-md border border-slate-800 p-2 rounded-xl text-[11px] text-slate-300 flex items-center justify-between gap-2 shadow-lg pointer-events-none",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-cyan-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1249,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: interactionMode === "section_select" ? "Drag over dark photo or text to color grade only that section" : "Drag Card 1 or Card 2 to align" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1250,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1248,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "font-mono text-cyan-300 font-bold",
									children: "CR-80: 5.5 cm × 8.5 cm"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1252,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1247,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1231,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1203,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1202,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 817,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 750,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsUUFBUSxpQkFBaUI7QUFDbkQsU0FDRSxRQUNBLFNBQ0EsVUFJQSxNQUdBLE9BRUEsUUFDQSxhQUNBLEtBQ0EsVUFHQSxRQUNBLFNBRUEsVUFDQSxPQUNBLG9CQUNLO0FBQ1AsU0FBUyxhQUFhO0FBQ3RCLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMsdUJBQXVCOzs7QUFTaEMsT0FBTyxNQUFNLHNCQUFnQzs7Q0FFM0MsTUFBTSxZQUFZLE9BQWlDLElBQUk7O0NBR3ZELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBd0IsSUFBSTtDQUM1RCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQXdCLElBQUk7O0NBRzVELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUE0QixPQUFPOztDQUd2RSxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUztFQUM3QyxHQUFHO0VBQ0gsR0FBRztFQUNILE9BQU87RUFDUCxVQUFVO0NBQ1osQ0FBQztDQUVELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTO0VBQzdDLEdBQUc7RUFDSCxHQUFHO0VBQ0gsT0FBTztFQUNQLFVBQVU7Q0FDWixDQUFDOztDQUdELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFpQixDQUFDO0NBQ3RELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBaUIsQ0FBQztDQUNsRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBa0IsSUFBSTtDQUM5RCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFrQixJQUFJO0NBQ2xFLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFrQixJQUFJO0NBQzlELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFrQixLQUFLO0NBQy9ELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUF3QixJQUFJOztDQUdoRSxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFvQyxNQUFNO0NBQ3hGLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUE0QixJQUFJO0NBQ3hFLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUE0QixJQUFJOztDQUd4RSxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFpQixFQUFFO0NBQ3JFLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQWlCLEVBQUU7Q0FDakUsTUFBTSxDQUFDLG1CQUFtQix3QkFBd0IsU0FBaUIsQ0FBQztDQUNwRSxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBaUIsQ0FBQztDQUM1RCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFpQixDQUFDOztDQUc5RCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBa0IsS0FBSztDQUMzRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQW1DLElBQUk7Q0FDdkUsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQW1DO0VBQUUsR0FBRztFQUFHLEdBQUc7Q0FBRSxDQUFDO0NBQ25GLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQWtCLEtBQUs7Q0FDbkUsTUFBTSxDQUFDLG9CQUFvQix5QkFBeUIsU0FBMEMsSUFBSTs7O0NBSWxHLE1BQU0sZUFBZTtDQUNyQixNQUFNLGdCQUFnQjs7Ozs7Q0FNdEIsTUFBTSxhQUFhO0NBQ25CLE1BQU0sY0FBYzs7Ozs7O0NBT3BCLE1BQU0sZ0JBQWdCO0NBQ3RCLE1BQU0sa0JBQWtCO0NBQ3hCLE1BQU0sa0JBQWtCOztDQUd4QixNQUFNLGNBQWMsT0FBZ0MsSUFBSTtDQUN4RCxNQUFNLGNBQWMsT0FBZ0MsSUFBSTs7Q0FHeEQsZ0JBQWdCO0VBQ2QsSUFBSSxVQUFVO0dBQ1osTUFBTSxNQUFNLElBQUksTUFBTTtHQUN0QixJQUFJLGNBQWM7R0FDbEIsSUFBSSxlQUFlO0lBQ2pCLFlBQVksVUFBVTtJQUN0QixhQUFhO0dBQ2Y7R0FDQSxJQUFJLE1BQU07RUFDWixPQUFPO0dBQ0wsWUFBWSxVQUFVO0dBQ3RCLGFBQWE7RUFDZjtDQUNGLEdBQUcsQ0FBQyxRQUFRLENBQUM7O0NBR2IsZ0JBQWdCO0VBQ2QsSUFBSSxVQUFVO0dBQ1osTUFBTSxNQUFNLElBQUksTUFBTTtHQUN0QixJQUFJLGNBQWM7R0FDbEIsSUFBSSxlQUFlO0lBQ2pCLFlBQVksVUFBVTtJQUN0QixhQUFhO0dBQ2Y7R0FDQSxJQUFJLE1BQU07RUFDWixPQUFPO0dBQ0wsWUFBWSxVQUFVO0dBQ3RCLGFBQWE7RUFDZjtDQUNGLEdBQUcsQ0FBQyxRQUFRLENBQUM7O0NBR2IsZ0JBQWdCO0VBQ2QsTUFBTSwwQkFBMEIsa0JBQWtCO0VBQ2xELE1BQU0sd0JBQXdCLGtCQUFrQjtFQUNoRCxNQUFNLHdCQUF3QixrQkFBa0I7RUFFaEQsT0FBTyxpQkFBaUIsb0JBQW9CLGlCQUFpQjtFQUM3RCxPQUFPLGlCQUFpQixrQkFBa0IsZUFBZTtFQUN6RCxPQUFPLGlCQUFpQixrQkFBa0IsZUFBZTtFQUV6RCxhQUFhO0dBQ1gsT0FBTyxvQkFBb0Isb0JBQW9CLGlCQUFpQjtHQUNoRSxPQUFPLG9CQUFvQixrQkFBa0IsZUFBZTtHQUM1RCxPQUFPLG9CQUFvQixrQkFBa0IsZUFBZTtFQUM5RDtDQUNGLENBQUM7O0NBR0QsZ0JBQWdCO0VBQ2QsYUFBYTtDQUNmLEdBQUc7RUFDRDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGLENBQUM7O0NBR0QsTUFBTSxnQkFBZ0IsY0FBdUIsVUFBVTtFQUNyRCxNQUFNLFNBQVMsVUFBVTtFQUN6QixJQUFJLENBQUMsUUFBUTtFQUNiLE1BQU0sTUFBTSxPQUFPLFdBQVcsSUFBSTtFQUNsQyxJQUFJLENBQUMsS0FBSzs7RUFHVixJQUFJLFlBQVk7RUFDaEIsSUFBSSxTQUFTLEdBQUcsR0FBRyxjQUFjLGFBQWE7O0VBRzlDLE1BQU0sa0JBQWtCLGNBQWMsTUFBTSxXQUFXLGNBQWMsTUFBTSxTQUFTOztFQUdwRixlQUNFLEtBQ0EsWUFBWSxTQUNaLGdCQUFnQixZQUFZLEdBQzVCLGtCQUFrQixZQUFZLEdBQzlCLFlBQVksT0FDWixZQUFZLFVBQ1osa0JBQ0EsaUJBQ0EsY0FDQSxlQUFlLFNBQ2YsV0FDRjs7RUFHQSxlQUNFLEtBQ0EsWUFBWSxTQUNaLGdCQUFnQixZQUFZLEdBQzVCLGtCQUFrQixZQUFZLEdBQzlCLFlBQVksT0FDWixZQUFZLFVBQ1osaUJBQ0EsaUJBQ0EsY0FDQSxlQUFlLFNBQ2YsV0FDRjs7RUFHQSxJQUFJLGNBQWM7R0FDaEIsSUFBSSxLQUFLO0dBQ1QsSUFBSSxjQUFjO0dBQ2xCLElBQUksWUFBWTtHQUNoQixJQUFJLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQzs7R0FHdEIsTUFBTSxPQUFPO0dBQ2IsSUFBSSxVQUFVO0dBQ2QsSUFBSSxPQUFPLElBQUksSUFBSTtHQUNuQixJQUFJLE9BQU8sZUFBZSxJQUFJLElBQUk7R0FDbEMsSUFBSSxPQUFPOztHQUdYLElBQUksWUFBWSxDQUFDLENBQUM7R0FDbEIsSUFBSSxZQUFZO0dBQ2hCLElBQUksT0FBTztHQUNYLElBQUksWUFBWTtHQUNoQixJQUFJLFNBQVMsdURBQXVELGVBQWUsR0FBRyxPQUFPLEVBQUU7O0dBRy9GLGNBQWMsS0FBSyxJQUFJLEVBQUU7R0FDekIsY0FBYyxLQUFLLGVBQWUsSUFBSSxFQUFFO0dBQ3hDLGNBQWMsS0FBSyxJQUFJLGdCQUFnQixFQUFFO0dBQ3pDLGNBQWMsS0FBSyxlQUFlLElBQUksZ0JBQWdCLEVBQUU7R0FFeEQsSUFBSSxRQUFRO0VBQ2Q7Q0FDRjtDQUVBLE1BQU0saUJBQWlCLEtBQStCLEdBQVcsTUFBYztFQUM3RSxJQUFJLGNBQWM7RUFDbEIsSUFBSSxZQUFZO0VBQ2hCLElBQUksVUFBVTtFQUNkLElBQUksT0FBTyxJQUFJLElBQUksQ0FBQztFQUNwQixJQUFJLE9BQU8sSUFBSSxJQUFJLENBQUM7RUFDcEIsSUFBSSxPQUFPLEdBQUcsSUFBSSxFQUFFO0VBQ3BCLElBQUksT0FBTyxHQUFHLElBQUksRUFBRTtFQUNwQixJQUFJLE9BQU87Q0FDYjtDQUVBLE1BQU0sa0JBQ0osS0FDQSxLQUNBLFNBQ0EsU0FDQSxPQUNBLFVBQ0Esa0JBQ0EsUUFDQSxTQUNBLGNBQ0EsY0FBdUIsVUFDcEI7RUFDSCxNQUFNLElBQUk7RUFDVixNQUFNLElBQUk7RUFDVixNQUFNLE9BQU8sVUFBVSxJQUFJO0VBQzNCLE1BQU0sTUFBTSxVQUFVLElBQUk7RUFFMUIsSUFBSSxLQUFLOztFQUdULE1BQU0sU0FBUyxpQkFBaUIsS0FBSztFQUNyQyxJQUFJLFVBQVU7RUFDZCxJQUFJLFVBQVUsTUFBTSxLQUFLLEdBQUcsR0FBRyxNQUFNO0VBQ3JDLElBQUksS0FBSztFQUVULElBQUksS0FBSzs7R0FFUCxJQUFJLEtBQUs7R0FDVCxJQUFJLFNBQVM7R0FDYixJQUFJLFVBQVUsU0FBUyxPQUFPO0dBQzlCLElBQUksT0FBUSxXQUFXLEtBQUssS0FBTSxHQUFHO0dBQ3JDLElBQUksTUFBTSxPQUFPLEtBQUs7R0FDdEIsSUFBSSxVQUFVLEtBQUssQ0FBQyxJQUFJLEdBQUcsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDO0dBQ3ZDLElBQUksUUFBUTs7R0FHWixJQUFJLFdBQVcsUUFBUSxJQUFJLE9BQVEsUUFBUSxJQUFJLEtBQU07SUFDbkQsSUFBSSxLQUFLOztJQUdULE1BQU0sT0FBTyxPQUFPLFFBQVEsSUFBSTtJQUNoQyxNQUFNLE9BQU8sTUFBTSxRQUFRLElBQUk7SUFDL0IsTUFBTSxPQUFPLFFBQVEsSUFBSTtJQUN6QixNQUFNLE9BQU8sUUFBUSxJQUFJOztJQUd6QixJQUFJLEtBQUs7SUFDVCxJQUFJLFVBQVU7SUFDZCxJQUFJLEtBQUssTUFBTSxNQUFNLE1BQU0sSUFBSTtJQUMvQixJQUFJLEtBQUs7O0lBR1QsTUFBTSxZQUFZLE1BQU0sYUFBYTtJQUNyQyxNQUFNLFVBQVUsTUFBTSxXQUFXO0lBQ2pDLE1BQU0sU0FBUyxNQUFNO0lBQ3JCLElBQUksU0FBUyxjQUFjLFVBQVUsY0FBYyxRQUFRLGNBQWMsT0FBTzs7SUFHaEYsSUFBSSxVQUFVLFNBQVMsT0FBTztJQUM5QixJQUFJLE9BQVEsV0FBVyxLQUFLLEtBQU0sR0FBRztJQUNyQyxJQUFJLE1BQU0sT0FBTyxLQUFLO0lBQ3RCLElBQUksVUFBVSxLQUFLLENBQUMsSUFBSSxHQUFHLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztJQUN2QyxJQUFJLFFBQVE7O0lBR1osSUFBSSxrQkFBa0IsR0FBRztLQUN2QixJQUFJLEtBQUs7S0FDVCxJQUFJLFVBQVU7S0FDZCxJQUFJLEtBQUssTUFBTSxNQUFNLE1BQU0sSUFBSTtLQUMvQixJQUFJLEtBQUs7S0FDVCxJQUFJLDJCQUEyQjtLQUMvQixJQUFJLFlBQVksZ0JBQWdCLElBQzVCLHNCQUFzQixLQUFLLElBQUksSUFBTSxnQkFBZ0IsTUFBTyxFQUFHLEVBQUUsS0FDakUsc0JBQXNCLEtBQUssSUFBSSxJQUFNLEtBQUssSUFBSSxhQUFhLElBQUksTUFBTyxFQUFHLEVBQUU7S0FDL0UsSUFBSSxTQUFTLE1BQU0sTUFBTSxNQUFNLElBQUk7S0FDbkMsSUFBSSxRQUFRO0lBQ2Q7O0lBR0EsSUFBSSxDQUFDLGFBQWE7S0FDaEIsSUFBSSxLQUFLO0tBQ1QsSUFBSSxjQUFjLGVBQWUsWUFBWTtLQUM3QyxJQUFJLFlBQVk7S0FDaEIsSUFBSSxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDdEIsSUFBSSxXQUFXLE1BQU0sTUFBTSxNQUFNLElBQUk7O0tBR3JDLElBQUksWUFBWSxlQUFlLDJCQUEyQjtLQUMxRCxJQUFJLFNBQVMsTUFBTSxLQUFLLElBQUksS0FBSyxPQUFPLEVBQUUsR0FBRyxLQUFLLEVBQUU7S0FDcEQsSUFBSSxZQUFZO0tBQ2hCLElBQUksT0FBTztLQUNYLElBQUksU0FBUyxlQUFlLG9CQUFvQixJQUFJLE1BQU0sS0FBSyxrQkFBa0IsTUFBTSxrQkFBa0IsSUFBSSxNQUFNLEtBQUssZ0JBQWdCLEtBQUssT0FBTyxHQUFHLEtBQUssSUFBSSxLQUFLLE9BQU8sRUFBRSxJQUFJLEVBQUU7S0FDcEwsSUFBSSxRQUFRO0lBQ2Q7SUFFQSxJQUFJLFFBQVE7R0FDZDtFQUNGLE9BQU87O0dBRUwsSUFBSSxZQUFZO0dBQ2hCLElBQUksS0FBSztHQUVULElBQUksY0FBYztHQUNsQixJQUFJLFlBQVk7R0FDaEIsSUFBSSxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7R0FDdkIsSUFBSSxPQUFPOztHQUdYLElBQUksWUFBWTtHQUNoQixJQUFJLE9BQU87R0FDWCxJQUFJLFlBQVk7R0FDaEIsSUFBSSxTQUFTLGtCQUFrQixTQUFTLFVBQVUsRUFBRTtHQUNwRCxJQUFJLE9BQU87R0FDWCxJQUFJLFlBQVk7R0FDaEIsSUFBSSxTQUFTLG1DQUFtQyxTQUFTLFVBQVUsRUFBRTtHQUNyRSxJQUFJLFNBQVMsa0RBQWtELFNBQVMsVUFBVSxFQUFFO0VBQ3RGOztFQUdBLElBQUksY0FBYztHQUNoQixJQUFJLFVBQVU7R0FDZCxJQUFJLFVBQVUsTUFBTSxLQUFLLEdBQUcsR0FBRyxNQUFNO0dBQ3JDLElBQUksY0FBZSxDQUFDLGVBQWUsZ0JBQWdCLG9CQUFvQixtQkFBb0IsWUFBWTtHQUN2RyxJQUFJLFlBQWEsQ0FBQyxlQUFlLGdCQUFnQixvQkFBb0IsbUJBQW9CLElBQUk7R0FDN0YsSUFBSSxZQUFZLENBQUMsQ0FBQztHQUNsQixJQUFJLE9BQU87RUFDYjtFQUVBLElBQUksUUFBUTtDQUNkOztDQUdBLE1BQU0sMkJBQTJCLFNBQWlCLFNBQWlCLGVBQWtDO0VBQ25HLE1BQU0sVUFBVSxpQkFBaUIsZUFBZSxVQUFVLFlBQVksSUFBSSxZQUFZO0VBQ3RGLE1BQU0sV0FBVyxlQUFlLFVBQVUsa0JBQWtCLG9CQUFvQixlQUFlLFVBQVUsWUFBWSxJQUFJLFlBQVk7RUFDckksTUFBTSxPQUFPLFVBQVUsYUFBYTtFQUNwQyxNQUFNLE1BQU0sVUFBVSxjQUFjO0VBRXBDLE1BQU0sU0FBUyxVQUFVLFFBQVE7RUFDakMsTUFBTSxTQUFTLFVBQVUsT0FBTztFQUVoQyxPQUFPO0dBQ0w7R0FDQTtHQUNBLFVBQVUsU0FBUyxLQUFLLFNBQVMsS0FBSyxTQUFTLEtBQUssU0FBUztFQUMvRDtDQUNGOztDQUdBLE1BQU0sb0JBQW9CLEdBQXdDLFdBQThCO0VBQzlGLE1BQU0sT0FBTyxFQUFFLE9BQU8sUUFBUTtFQUM5QixJQUFJLENBQUMsTUFBTTtFQUVYLE1BQU0sU0FBUyxJQUFJLFdBQVc7RUFDOUIsT0FBTyxVQUFVLFVBQVU7R0FDekIsTUFBTSxTQUFTLE1BQU0sUUFBUTtHQUM3QixJQUFJLFdBQVcsU0FBUztJQUN0QixZQUFZLE1BQU07SUFDbEIsY0FBYyxPQUFPO0dBQ3ZCLE9BQU87SUFDTCxZQUFZLE1BQU07SUFDbEIsY0FBYyxPQUFPO0dBQ3ZCO0VBQ0Y7RUFDQSxPQUFPLGNBQWMsSUFBSTtFQUN6QixFQUFFLE9BQU8sUUFBUTtDQUNuQjs7Q0FHQSxNQUFNLHdCQUF3QjtFQUM1QixNQUFNLFVBQVU7RUFDaEIsWUFBWSxRQUFRO0VBQ3BCLFlBQVksT0FBTztFQUVuQixNQUFNLFVBQVUsRUFBRSxHQUFHLFlBQVk7RUFDakMsZUFBZSxFQUFFLEdBQUcsWUFBWSxDQUFDO0VBQ2pDLGVBQWUsT0FBTztFQUV0QixNQUFNLFVBQVU7RUFDaEIsZ0JBQWdCLFlBQVk7RUFDNUIsZ0JBQWdCLE9BQU87Q0FDekI7O0NBR0EsTUFBTSw0QkFBNEIsV0FBcUQ7RUFDckYsSUFBSTtFQUNKLFFBQVEsUUFBUjtHQUNFLEtBQUs7O0lBRUgsTUFBTTtLQUFFLEdBQUc7S0FBTSxHQUFHO0tBQU0sR0FBRztLQUFNLEdBQUc7SUFBSztJQUMzQztHQUNGLEtBQUs7O0lBRUgsTUFBTTtLQUFFLEdBQUc7S0FBTSxHQUFHO0tBQU0sR0FBRztLQUFNLEdBQUc7SUFBSztJQUMzQztHQUNGLEtBQUs7O0lBRUgsTUFBTTtLQUFFLEdBQUc7S0FBTSxHQUFHO0tBQU0sR0FBRztLQUFNLEdBQUc7SUFBSztJQUMzQztHQUNGLEtBQUs7O0lBRUgsTUFBTTtLQUFFLEdBQUc7S0FBTSxHQUFHO0tBQU0sR0FBRztLQUFNLEdBQUc7SUFBSztJQUMzQztFQUNKO0VBRUEsSUFBSSxlQUFlLFNBQVM7R0FDMUIsZ0JBQWdCLEdBQUc7RUFDckIsT0FBTztHQUNMLGdCQUFnQixHQUFHO0VBQ3JCO0VBQ0EsbUJBQW1CLGdCQUFnQjtDQUNyQzs7Q0FHQSxNQUFNLGlDQUFpQztFQUNyQyxNQUFNLFlBQVksZUFBZSxVQUFVLFdBQVc7RUFDdEQsTUFBTSxnQkFBZ0IsZUFBZSxVQUFVLGVBQWU7RUFDOUQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxlQUFlO0VBRWxDLGdCQUFnQixJQUFJO0VBRXBCLElBQUk7R0FDRixNQUFNLE1BQU0sSUFBSSxNQUFNO0dBQ3RCLElBQUksY0FBYztHQUNsQixJQUFJLGVBQWU7SUFDakIsTUFBTSxZQUFZLFNBQVMsY0FBYyxRQUFRO0lBQ2pELFVBQVUsUUFBUSxJQUFJO0lBQ3RCLFVBQVUsU0FBUyxJQUFJO0lBQ3ZCLE1BQU0sTUFBTSxVQUFVLFdBQVcsSUFBSTtJQUNyQyxJQUFJLENBQUMsS0FBSzs7SUFHVixJQUFJLFVBQVUsS0FBSyxHQUFHLENBQUM7O0lBR3ZCLE1BQU0sT0FBTyxjQUFjLElBQUksSUFBSTtJQUNuQyxNQUFNLE9BQU8sY0FBYyxJQUFJLElBQUk7SUFDbkMsTUFBTSxPQUFPLGNBQWMsSUFBSSxJQUFJO0lBQ25DLE1BQU0sT0FBTyxjQUFjLElBQUksSUFBSTtJQUVuQyxJQUFJLEtBQUs7SUFDVCxJQUFJLFVBQVU7SUFDZCxJQUFJLEtBQUssTUFBTSxNQUFNLE1BQU0sSUFBSTtJQUMvQixJQUFJLEtBQUs7SUFFVCxNQUFNLFlBQVksTUFBTTtJQUN4QixNQUFNLFVBQVUsTUFBTTtJQUN0QixNQUFNLFNBQVMsTUFBTTtJQUNyQixJQUFJLFNBQVMsY0FBYyxVQUFVLGNBQWMsUUFBUSxjQUFjLE9BQU87SUFDaEYsSUFBSSxVQUFVLEtBQUssR0FBRyxDQUFDO0lBRXZCLElBQUksa0JBQWtCLEdBQUc7S0FDdkIsSUFBSSwyQkFBMkI7S0FDL0IsSUFBSSxZQUFZLGdCQUFnQixJQUM1QixzQkFBc0IsS0FBSyxJQUFJLElBQU0sZ0JBQWdCLE1BQU8sRUFBRyxFQUFFLEtBQ2pFLHNCQUFzQixLQUFLLElBQUksSUFBTSxLQUFLLElBQUksYUFBYSxJQUFJLE1BQU8sRUFBRyxFQUFFO0tBQy9FLElBQUksU0FBUyxNQUFNLE1BQU0sTUFBTSxJQUFJO0lBQ3JDO0lBRUEsSUFBSSxRQUFRO0lBRVosTUFBTSxXQUFXLFVBQVUsVUFBVSxjQUFjLEdBQUk7SUFDdkQsSUFBSSxlQUFlLFNBQVM7S0FDMUIsWUFBWSxRQUFRO0tBQ3BCLGdCQUFnQixJQUFJO0lBQ3RCLE9BQU87S0FDTCxZQUFZLFFBQVE7S0FDcEIsZ0JBQWdCLElBQUk7SUFDdEI7SUFFQSxjQUFjLDRDQUE0QyxlQUFlLFVBQVUsbUJBQW1CLGdCQUFnQixFQUFFO0lBQ3hILGlCQUFpQixjQUFjLElBQUksR0FBRyxHQUFJO0dBQzVDO0dBQ0EsSUFBSSxNQUFNO0VBQ1osU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7RUFDakIsVUFBVTtHQUNSLGdCQUFnQixLQUFLO0VBQ3ZCO0NBQ0Y7O0NBR0EsTUFBTSwyQkFBMkI7RUFDL0IsSUFBSSxlQUFlLFNBQVM7R0FDMUIsZ0JBQWdCLElBQUk7RUFDdEIsT0FBTztHQUNMLGdCQUFnQixJQUFJO0VBQ3RCO0NBQ0Y7O0NBR0EsTUFBTSwwQkFBMEI7RUFDOUIsTUFBTSxTQUFTLFVBQVU7RUFDekIsSUFBSSxDQUFDLFFBQVE7RUFDYixnQkFBZ0IsSUFBSTtFQUVwQixJQUFJOztHQUVGLGFBQWEsSUFBSTtHQUNqQixNQUFNLFVBQVUsT0FBTyxVQUFVLGNBQWMsR0FBSTs7R0FFbkQsYUFBYSxLQUFLO0dBRWxCLE1BQU0sSUFBSSxTQUFTLGNBQWMsR0FBRztHQUNwQyxFQUFFLE9BQU87R0FDVCxNQUFNLFdBQVcsMEJBQTBCLEtBQUssSUFBSSxFQUFFO0dBQ3RELEVBQUUsV0FBVztHQUNiLEVBQUUsTUFBTTtHQUVSLGtCQUFrQjtJQUNoQixJQUFJLFdBQVcsS0FBSyxJQUFJO0lBQ3hCLE9BQU87SUFDUCxNQUFNO0lBQ04sTUFBTTtJQUNOLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsT0FBTztHQUNsRCxDQUFDO0VBQ0gsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7R0FDZixhQUFhLEtBQUs7RUFDcEIsVUFBVTtHQUNSLGdCQUFnQixLQUFLO0VBQ3ZCO0NBQ0Y7O0NBR0EsTUFBTSwwQkFBMEI7RUFDOUIsTUFBTSxTQUFTLFVBQVU7RUFDekIsSUFBSSxDQUFDLFFBQVE7RUFDYixnQkFBZ0IsSUFBSTtFQUVwQixJQUFJOztHQUVGLGFBQWEsSUFBSTtHQUNqQixNQUFNLFVBQVUsT0FBTyxVQUFVLGNBQWMsR0FBSTs7R0FFbkQsYUFBYSxLQUFLO0dBRWxCLE1BQU0sTUFBTSxJQUFJLE1BQU07SUFDcEIsYUFBYTtJQUNiLE1BQU07SUFDTixRQUFRLENBQUMsR0FBRyxDQUFDO0dBQ2YsQ0FBQztHQUVELElBQUksU0FBUyxTQUFTLFFBQVEsR0FBRyxHQUFHLEdBQUcsQ0FBQztHQUN4QyxNQUFNLFdBQVcsMEJBQTBCLEtBQUssSUFBSSxFQUFFO0dBQ3RELElBQUksS0FBSyxRQUFRO0dBRWpCLGtCQUFrQjtJQUNoQixJQUFJLFdBQVcsS0FBSyxJQUFJO0lBQ3hCLE9BQU87SUFDUCxNQUFNO0lBQ04sTUFBTTtJQUNOLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsT0FBTztHQUNsRCxDQUFDO0VBQ0gsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7R0FDZixhQUFhLEtBQUs7RUFDcEIsVUFBVTtHQUNSLGdCQUFnQixLQUFLO0VBQ3ZCO0NBQ0Y7O0NBR0EsTUFBTSwwQkFBMEI7RUFDOUIsTUFBTSxTQUFTLFVBQVU7RUFDekIsSUFBSSxDQUFDLFFBQVE7RUFDYixJQUFJOztHQUVGLGFBQWEsSUFBSTtHQUNqQixNQUFNLFVBQVUsT0FBTyxVQUFVLGNBQWMsQ0FBRzs7R0FFbEQsYUFBYSxLQUFLO0dBRWxCLGdCQUFnQixTQUFTO0lBQ3ZCLGFBQWE7SUFDYixPQUFPO0dBQ1QsQ0FBQztHQUNELGNBQWMsZ0dBQWdHO0dBQzlHLGlCQUFpQixjQUFjLElBQUksR0FBRyxHQUFJO0VBQzVDLFNBQVMsR0FBRztHQUNWLFFBQVEsTUFBTSxDQUFDO0dBQ2YsYUFBYSxLQUFLO0dBQ2xCLE9BQU8sTUFBTTtFQUNmO0NBQ0Y7O0NBR0EsTUFBTSxtQkFBbUIsTUFBMkM7RUFDbEUsTUFBTSxTQUFTLFVBQVU7RUFDekIsSUFBSSxDQUFDLFFBQVE7RUFDYixNQUFNLE9BQU8sT0FBTyxzQkFBc0I7RUFDMUMsTUFBTSxTQUFTLGVBQWUsS0FBSztFQUNuQyxNQUFNLFNBQVMsZ0JBQWdCLEtBQUs7RUFFcEMsTUFBTSxVQUFVLEVBQUUsVUFBVSxLQUFLLFFBQVE7RUFDekMsTUFBTSxVQUFVLEVBQUUsVUFBVSxLQUFLLE9BQU87O0VBR3hDLE1BQU0sY0FBYyxTQUFTLGdCQUFnQixJQUFJLFVBQVU7RUFDM0QsY0FBYyxXQUFXO0VBRXpCLElBQUksb0JBQW9CLGtCQUFrQjs7R0FFeEMsTUFBTSxTQUFTLHdCQUF3QixRQUFRLFFBQVEsV0FBVztHQUNsRSxJQUFJLE9BQU8sVUFBVTtJQUNuQixrQkFBa0IsSUFBSTtJQUN0QixzQkFBc0I7S0FBRSxHQUFHLE9BQU87S0FBTyxHQUFHLE9BQU87SUFBTSxDQUFDO0lBQzFELE1BQU0sYUFBeUI7S0FBRSxHQUFHLE9BQU87S0FBTyxHQUFHLE9BQU87S0FBTyxHQUFHO0tBQU0sR0FBRztJQUFLO0lBQ3BGLElBQUksZ0JBQWdCLFNBQVMsZ0JBQWdCLFVBQVU7U0FDbEQsZ0JBQWdCLFVBQVU7R0FDakM7RUFDRixPQUFPOztHQUVMLFlBQVksV0FBVztHQUN2QixjQUFjLElBQUk7R0FDbEIsTUFBTSxNQUFNLGdCQUFnQixVQUFVLGNBQWM7R0FDcEQsYUFBYTtJQUFFLEdBQUcsU0FBUyxJQUFJO0lBQUcsR0FBRyxTQUFTLElBQUk7R0FBRSxDQUFDO0VBQ3ZEO0NBQ0Y7Q0FFQSxNQUFNLG1CQUFtQixNQUEyQztFQUNsRSxNQUFNLFNBQVMsVUFBVTtFQUN6QixJQUFJLENBQUMsUUFBUTtFQUNiLE1BQU0sT0FBTyxPQUFPLHNCQUFzQjtFQUMxQyxNQUFNLFNBQVMsZUFBZSxLQUFLO0VBQ25DLE1BQU0sU0FBUyxnQkFBZ0IsS0FBSztFQUVwQyxNQUFNLFVBQVUsRUFBRSxVQUFVLEtBQUssUUFBUTtFQUN6QyxNQUFNLFVBQVUsRUFBRSxVQUFVLEtBQUssT0FBTzs7RUFHeEMsSUFBSSxrQkFBa0Isb0JBQW9CO0dBQ3hDLE1BQU0sU0FBUyx3QkFBd0IsUUFBUSxRQUFRLFVBQVU7R0FDakUsTUFBTSxXQUFXLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxHQUFHLE9BQU8sS0FBSyxDQUFDO0dBQ3RELE1BQU0sV0FBVyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksR0FBRyxPQUFPLEtBQUssQ0FBQztHQUV0RCxNQUFNLE9BQU8sS0FBSyxJQUFJLG1CQUFtQixHQUFHLFFBQVE7R0FDcEQsTUFBTSxPQUFPLEtBQUssSUFBSSxtQkFBbUIsR0FBRyxRQUFRO0dBQ3BELE1BQU0sT0FBTyxLQUFLLElBQUksS0FBTSxLQUFLLElBQUksV0FBVyxtQkFBbUIsQ0FBQyxDQUFDO0dBQ3JFLE1BQU0sT0FBTyxLQUFLLElBQUksS0FBTSxLQUFLLElBQUksV0FBVyxtQkFBbUIsQ0FBQyxDQUFDO0dBRXJFLE1BQU0sYUFBeUI7SUFBRSxHQUFHO0lBQU0sR0FBRztJQUFNLEdBQUc7SUFBTSxHQUFHO0dBQUs7R0FDcEUsSUFBSSxlQUFlLFNBQVMsZ0JBQWdCLFVBQVU7UUFDakQsZ0JBQWdCLFVBQVU7R0FDL0I7RUFDRjs7RUFHQSxJQUFJLGNBQWMsVUFBVTtHQUMxQixJQUFJLGFBQWEsU0FBUztJQUN4QixnQkFBZSxVQUFTO0tBQ3RCLEdBQUc7S0FDSCxHQUFHLEtBQUssTUFBTSxTQUFTLFVBQVUsQ0FBQztLQUNsQyxHQUFHLEtBQUssTUFBTSxTQUFTLFVBQVUsQ0FBQztJQUNwQyxFQUFFO0dBQ0osT0FBTztJQUNMLGdCQUFlLFVBQVM7S0FDdEIsR0FBRztLQUNILEdBQUcsS0FBSyxNQUFNLFNBQVMsVUFBVSxDQUFDO0tBQ2xDLEdBQUcsS0FBSyxNQUFNLFNBQVMsVUFBVSxDQUFDO0lBQ3BDLEVBQUU7R0FDSjtFQUNGO0NBQ0Y7Q0FFQSxNQUFNLHNCQUFzQjtFQUMxQixjQUFjLEtBQUs7RUFDbkIsWUFBWSxJQUFJO0VBQ2hCLGtCQUFrQixLQUFLO0VBQ3ZCLHNCQUFzQixJQUFJO0NBQzVCO0NBRUEsTUFBTSxvQkFBb0IsZUFBZSxVQUFVLGVBQWU7Q0FFbEUsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSx3QkFBeUI7Ozs7aUJBQzNDLHdCQUFDLFFBQUQsWUFBTSwwQ0FBNkM7Ozs7ZUFDakQ7Ozs7OztNQUNKLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFnSDtNQUUxSDs7Ozs7TUFDTix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBK0c7TUFFekg7Ozs7O01BQ04sd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7OztpQkFDN0Isd0JBQUMsUUFBRCxZQUFNLCtCQUFrQzs7OztlQUNwQzs7Ozs7O0tBQ0g7Ozs7O2NBQ0wsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBOEI7SUFFeEM7Ozs7WUFDQTs7OztjQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFdBQVU7T0FDVixPQUFNO2lCQUhSLENBS0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUscUJBQXNCOzs7O2lCQUN6Qyx3QkFBQyxRQUFELFlBQU0sNEJBQStCOzs7O2VBQy9COzs7Ozs7TUFFUix3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFVBQVU7T0FDVixXQUFVO09BQ1YsT0FBTTtpQkFKUixDQU1FLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFVBQVc7Ozs7aUJBQy9CLHdCQUFDLFFBQUQsWUFBTSxlQUFrQjs7OztlQUNsQjs7Ozs7O01BRVIsd0JBQUMsVUFBRDtPQUNFLFNBQVM7T0FDVCxVQUFVO09BQ1YsV0FBVTtPQUNWLE9BQU07aUJBSlIsQ0FNRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7O2lCQUNuQyx3QkFBQyxRQUFELFlBQU0sYUFBZ0I7Ozs7ZUFDaEI7Ozs7OztLQUNMOzs7OztZQUNGOzs7Ozs7R0FHSixjQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSx5Q0FBMEM7Ozs7Y0FDM0Qsd0JBQUMsUUFBRCxZQUFPLFdBQWlCOzs7O1lBQ3JCOzs7Ozs7R0FJUCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBRUUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUVFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBNEQ7U0FBeUI7Ozs7bUJBQ3JHLHdCQUFDLFVBQUQ7VUFDRSxTQUFTO1VBQ1QsV0FBVTtVQUNWLE9BQU07b0JBSFIsQ0FLRSx3QkFBQyxhQUFELEVBQWEsV0FBVSxjQUFlOzs7O29CQUN0Qyx3QkFBQyxRQUFELFlBQU0sa0JBQXFCOzs7O2tCQUNyQjs7Ozs7aUJBQ0w7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFXLHdDQUNkLGVBQWUsVUFDWCxnREFDQTttQkFITixDQUtFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxtQ0FBeUM7Ozs7cUJBQ3pELHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUErQjtXQUF5Qjs7OzttQkFDckU7Ozs7O29CQUNMLHdCQUFDLFVBQUQ7V0FDRSxlQUFlLGNBQWMsT0FBTztXQUNwQyxXQUFXLCtEQUNULGVBQWUsVUFBVSwyQkFBMkI7cUJBRXZEO1VBRU87Ozs7a0JBQ0w7Ozs7O21CQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQWpCO1lBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsNEJBQTZCOzs7OztZQUMvQyx3QkFBQyxRQUFELFlBQU8sV0FBVywyQkFBMkIsd0JBQThCOzs7OztZQUMzRSx3QkFBQyxTQUFEO2FBQU8sTUFBSzthQUFPLFFBQU87YUFBZSxXQUFXLE1BQU0saUJBQWlCLEdBQUcsT0FBTzthQUFHLFdBQVU7WUFBVTs7Ozs7V0FDdkc7Ozs7O29CQUNOLFlBQ0Msd0JBQUMsVUFBRDtXQUNFLGVBQWUsWUFBWSxJQUFJO1dBQy9CLFdBQVU7V0FDVixPQUFNO3FCQUNQO1VBRU87Ozs7a0JBRVA7Ozs7O2lCQUNGOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVyx3Q0FDZCxlQUFlLFVBQ1gsb0RBQ0E7bUJBSE4sQ0FLRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUscUNBQTJDOzs7O3FCQUMzRCx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBK0I7V0FBd0I7Ozs7bUJBQ3BFOzs7OztvQkFDTCx3QkFBQyxVQUFEO1dBQ0UsZUFBZSxjQUFjLE9BQU87V0FDcEMsV0FBVywrREFDVCxlQUFlLFVBQVUsNkJBQTZCO3FCQUV6RDtVQUVPOzs7O2tCQUNMOzs7OzttQkFFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUFqQjtZQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDhCQUErQjs7Ozs7WUFDakQsd0JBQUMsUUFBRCxZQUFPLFdBQVcsMEJBQTBCLHVCQUE2Qjs7Ozs7WUFDekUsd0JBQUMsU0FBRDthQUFPLE1BQUs7YUFBTyxRQUFPO2FBQWUsV0FBVyxNQUFNLGlCQUFpQixHQUFHLE9BQU87YUFBRyxXQUFVO1lBQVU7Ozs7O1dBQ3ZHOzs7OztvQkFDTixZQUNDLHdCQUFDLFVBQUQ7V0FDRSxlQUFlLFlBQVksSUFBSTtXQUMvQixXQUFVO1dBQ1YsT0FBTTtxQkFDUDtVQUVPOzs7O2tCQUVQOzs7OztpQkFDRjs7Ozs7O09BQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLHdCQUF5Qjs7OztvQkFDM0Msd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTZEO1VBRXZFOzs7O2tCQUNIOzs7OzttQkFDTCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFDYixlQUFlLFVBQVUsaUJBQWlCO1NBQ3ZDOzs7O2lCQUNIOzs7Ozs7UUFFTCx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBYjtVQUF1RDtVQUM4Qix3QkFBQyxLQUFELFlBQUcsNENBQTRDOzs7OztVQUFDO1NBQ2xJOzs7Ozs7UUFHSCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsZUFBZSxtQkFBbUIsTUFBTTtVQUN4QyxXQUFXLGlHQUNULG9CQUFvQixTQUNoQixxREFDQTtvQkFOUixDQVNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLGNBQWU7Ozs7b0JBQy9CLHdCQUFDLFFBQUQsWUFBTSxxQkFBd0I7Ozs7a0JBQ3hCOzs7OzttQkFFUix3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLGVBQWUsbUJBQW1CLGdCQUFnQjtVQUNsRCxXQUFXLGlHQUNULG9CQUFvQixtQkFDaEIsdUdBQ0E7b0JBTlIsQ0FTRSx3QkFBQyxRQUFELEVBQVEsV0FBVSw0QkFBNkI7Ozs7b0JBQy9DLHdCQUFDLFFBQUQsWUFBTSxzQkFBeUI7Ozs7a0JBQ3pCOzs7OztpQkFDTDs7Ozs7O1FBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBc0U7U0FFaEY7Ozs7bUJBQ04sd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxVQUFEO1lBQ0UsTUFBSztZQUNMLGVBQWUseUJBQXlCLE9BQU87WUFDL0MsV0FBVTtzQkFDWDtXQUVPOzs7OztXQUNSLHdCQUFDLFVBQUQ7WUFDRSxNQUFLO1lBQ0wsZUFBZSx5QkFBeUIsU0FBUztZQUNqRCxXQUFVO3NCQUNYO1dBRU87Ozs7O1dBQ1Isd0JBQUMsVUFBRDtZQUNFLE1BQUs7WUFDTCxlQUFlLHlCQUF5QixJQUFJO1lBQzVDLFdBQVU7c0JBQ1g7V0FFTzs7Ozs7V0FDUix3QkFBQyxVQUFEO1lBQ0UsTUFBSztZQUNMLGVBQWUseUJBQXlCLFdBQVc7WUFDbkQsV0FBVTtzQkFDWDtXQUVPOzs7OztVQUNMOzs7OztpQkFDRjs7Ozs7O1FBR0osb0JBQ0Msd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFoQixDQUNFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLGNBQWU7Ozs7c0JBQ2xDLHdCQUFDLFFBQUQsWUFBTSwrQkFBa0M7Ozs7b0JBQ3BDOzs7OztxQkFDTix3QkFBQyxVQUFEO1lBQ0UsU0FBUztZQUNULFdBQVU7c0JBQ1g7V0FFTzs7OzttQkFDTDs7Ozs7O1VBR0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNFLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFoQixDQUNFLHdCQUFDLEtBQUQsRUFBSyxXQUFVLGNBQWU7Ozs7d0JBQUMscUJBQzNCOzs7Ozt1QkFDTix3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBaEIsQ0FBd0Msb0JBQW9CLElBQUksSUFBSSxzQkFBc0IsbUJBQWtCLEdBQU87Ozs7O3FCQUNoSDs7Ozs7O1lBQ0wsd0JBQUMsU0FBRDthQUNFLE1BQUs7YUFDTCxLQUFJO2FBQ0osS0FBSTthQUNKLE9BQU87YUFDUCxXQUFXLE1BQU0scUJBQXFCLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQzthQUM1RCxXQUFVO1lBQ1g7Ozs7O1lBQ0Qsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWY7Y0FDRSx3QkFBQyxRQUFELFlBQU0sY0FBaUI7Ozs7O2NBQ3ZCLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7OztjQUNiLHdCQUFDLFFBQUQsWUFBTSxnQkFBbUI7Ozs7O2FBQ3RCOzs7Ozs7V0FDRjs7Ozs7O1VBR0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNFLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFoQixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLGNBQWU7Ozs7d0JBQUMsK0JBQ2hDOzs7Ozt1QkFDTix3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBaEIsQ0FBd0Msa0JBQWtCLElBQUksSUFBSSxvQkFBb0IsaUJBQWdCLEdBQU87Ozs7O3FCQUMxRzs7Ozs7O1lBQ0wsd0JBQUMsU0FBRDthQUNFLE1BQUs7YUFDTCxLQUFJO2FBQ0osS0FBSTthQUNKLE9BQU87YUFDUCxXQUFXLE1BQU0sbUJBQW1CLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQzthQUMxRCxXQUFVO1lBQ1g7Ozs7O1lBQ0Qsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWY7Y0FDRSx3QkFBQyxRQUFELFlBQU0sT0FBVTs7Ozs7Y0FDaEIsd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7O2NBQ2Isd0JBQUMsUUFBRCxZQUFNLHFCQUF3Qjs7Ozs7YUFDM0I7Ozs7OztXQUNGOzs7Ozs7VUFHTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWhCLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsY0FBZTs7Ozt1QkFBQyxxQkFDaEM7Ozs7O3NCQUNOLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFoQixDQUF3QyxvQkFBb0IsSUFBSSxJQUFJLHNCQUFzQixtQkFBa0IsR0FBTzs7Ozs7b0JBQ2hIOzs7OztxQkFDTCx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLEtBQUk7WUFDSixLQUFJO1lBQ0osT0FBTztZQUNQLFdBQVcsTUFBTSxxQkFBcUIsT0FBTyxFQUFFLE9BQU8sS0FBSyxDQUFDO1lBQzVELFdBQVU7V0FDWDs7OzttQkFDRTs7Ozs7O1VBR0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNFLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFoQixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLGNBQWU7Ozs7d0JBQUMsd0JBQzdCOzs7Ozt1QkFDTix3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBd0IsZ0JBQWdCLElBQUksSUFBSSxrQkFBa0I7YUFBb0I7Ozs7cUJBQ25HOzs7Ozs7WUFDTCx3QkFBQyxTQUFEO2FBQ0UsTUFBSzthQUNMLEtBQUk7YUFDSixLQUFJO2FBQ0osT0FBTzthQUNQLFdBQVcsTUFBTSxpQkFBaUIsT0FBTyxFQUFFLE9BQU8sS0FBSyxDQUFDO2FBQ3hELFdBQVU7WUFDWDs7Ozs7WUFDRCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZjtjQUNFLHdCQUFDLFFBQUQsWUFBTSxZQUFlOzs7OztjQUNyQix3QkFBQyxRQUFELFlBQU0sVUFBYTs7Ozs7Y0FDbkIsd0JBQUMsUUFBRCxZQUFNLFlBQWU7Ozs7O2FBQ2xCOzs7Ozs7V0FDRjs7Ozs7O1VBR0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1lBQ0UsTUFBSztZQUNMLFNBQVM7WUFDVCxVQUFVO1lBQ1YsV0FBVTtzQkFKWixDQU1FLHdCQUFDLGNBQUQsRUFBYyxXQUFVLFVBQVc7Ozs7c0JBQ25DLHdCQUFDLFFBQUQsWUFBTSw2QkFBZ0M7Ozs7b0JBQ2hDOzs7OztxQkFFUix3QkFBQyxVQUFEO1lBQ0UsTUFBSztZQUNMLFNBQVM7WUFDVCxXQUFVO3NCQUNYO1dBRU87Ozs7bUJBQ0w7Ozs7OztTQUNGOzs7OzttQkFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFpQztTQUF1Qjs7OzttQkFDeEUsd0JBQUMsUUFBRDtVQUFNO1VBQU0sd0JBQUMsS0FBRCxZQUFHLDBCQUF3Qjs7Ozs7VUFBQztTQUFrRzs7OztpQkFDdkk7Ozs7OztPQUVKOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFrRTtPQUU1RTs7OztpQkFFTix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUE0Qyx3QkFBQyxLQUFELEVBQUssV0FBVSw2QkFBOEI7Ozs7cUJBQUMsd0JBQTRCOzs7OztvQkFDdEgsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTRCLGFBQWEsSUFBSSxJQUFJLGVBQWU7VUFBaUI7Ozs7a0JBQzlGOzs7OzttQkFDTCx3QkFBQyxTQUFEO1VBQ0UsTUFBSztVQUNMLEtBQUk7VUFDSixLQUFJO1VBQ0osT0FBTztVQUNQLFdBQVcsTUFBTSxjQUFjLFNBQVMsRUFBRSxPQUFPLEtBQUssQ0FBQztVQUN2RCxXQUFVO1NBQ1g7Ozs7aUJBQ0U7Ozs7O1NBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQTRDLHdCQUFDLFVBQUQsRUFBVSxXQUFVLDJCQUE0Qjs7OztxQkFBQyxzQkFBMEI7Ozs7O29CQUN2SCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBNEIsV0FBVyxJQUFJLElBQUksYUFBYTtVQUFlOzs7O2tCQUN4Rjs7Ozs7bUJBQ0wsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxLQUFJO1VBQ0osS0FBSTtVQUNKLE9BQU87VUFDUCxXQUFXLE1BQU0sWUFBWSxTQUFTLEVBQUUsT0FBTyxLQUFLLENBQUM7VUFDckQsV0FBVTtTQUNYOzs7O2lCQUNFOzs7OztTQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQWpCLENBQ0Usd0JBQUMsU0FBRDthQUNFLE1BQUs7YUFDTCxTQUFTO2FBQ1QsV0FBVyxNQUFNLGdCQUFnQixFQUFFLE9BQU8sT0FBTzthQUNqRCxXQUFVO1lBQ1g7Ozs7c0JBQ0Qsd0JBQUMsUUFBRCxZQUFNLG9CQUF1Qjs7OztvQkFDeEI7Ozs7OztXQUVQLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUFqQixDQUNFLHdCQUFDLFNBQUQ7YUFDRSxNQUFLO2FBQ0wsU0FBUzthQUNULFdBQVcsTUFBTSxrQkFBa0IsRUFBRSxPQUFPLE9BQU87YUFDbkQsV0FBVTtZQUNYOzs7O3NCQUNELHdCQUFDLFFBQUQsWUFBTSxzQkFBeUI7Ozs7b0JBQzFCOzs7Ozs7V0FFUCx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFBakIsQ0FDRSx3QkFBQyxTQUFEO2FBQ0UsTUFBSzthQUNMLFNBQVM7YUFDVCxXQUFXLE1BQU0sZ0JBQWdCLEVBQUUsT0FBTyxPQUFPO2FBQ2pELFdBQVU7WUFDWDs7OztzQkFDRCx3QkFBQyxRQUFELFlBQU0sc0JBQXlCOzs7O29CQUMxQjs7Ozs7O1VBQ0o7Ozs7OztRQUNGOzs7OztlQUNGOzs7Ozs7S0FDRjs7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFvQztTQUFxQzs7Ozs7U0FDekYsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXNIO1NBRWhJOzs7OztTQUNOLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUF1QztTQUE0Qjs7Ozs7UUFDaEY7Ozs7O2lCQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZSxtQkFBbUIsb0JBQW9CLFNBQVMsbUJBQW1CLE1BQU07U0FDeEYsV0FBVywwRkFDVCxvQkFBb0IsbUJBQ2hCLGtEQUNBO21CQU5SLENBU0csb0JBQW9CLG1CQUFtQix3QkFBQyxRQUFELEVBQVEsV0FBVSw0QkFBNkI7Ozs7b0JBQUksd0JBQUMsTUFBRCxFQUFNLFdBQVUsY0FBZTs7OzttQkFDMUgsd0JBQUMsUUFBRCxZQUFPLG9CQUFvQixtQkFBbUIsNkJBQTZCLHFCQUEyQjs7OztpQkFDaEc7Ozs7OztPQUNMOzs7O2VBQ0Y7Ozs7O2dCQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRDtRQUNFLEtBQUs7UUFDTCxPQUFPO1FBQ1AsUUFBUTtRQUNSLGFBQWE7UUFDYixhQUFhO1FBQ2IsV0FBVztRQUNYLGNBQWM7UUFDZCxXQUFXLG1FQUNULG9CQUFvQixtQkFBbUIscUJBQXFCO1FBRTlELE9BQU8sRUFBRSxXQUFXLFFBQVE7T0FDN0I7Ozs7aUJBR0Qsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBTSxXQUFVLG1DQUF5Qzs7OzttQkFDekQsd0JBQUMsUUFBRCxZQUFPLG9CQUFvQixtQkFBbUIsa0VBQWtFLGlDQUF1Qzs7OztpQkFDcEo7Ozs7O2tCQUNMLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFvQztRQUE0Qjs7OztnQkFDN0U7Ozs7O2VBQ0Y7Ozs7O2NBQ0Y7Ozs7OztJQUNGOzs7O1lBQ0Y7Ozs7OztFQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQdmNTdHVkaW9WaWV3LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZVJlZiwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgXG4gIFVwbG9hZCwgXG4gIFByaW50ZXIsIFxuICBEb3dubG9hZCwgXG4gIFJvdGF0ZUN3LCBcbiAgWm9vbUluLCBcbiAgWm9vbU91dCwgXG4gIE1vdmUsIFxuICBTcGFya2xlcywgXG4gIFJlZnJlc2hDdywgXG4gIENoZWNrLCBcbiAgU2Npc3NvcnMsIFxuICBMYXllcnMsIFxuICBBcnJvd1VwRG93biwgXG4gIFN1biwgXG4gIENvbnRyYXN0LCBcbiAgSGVscENpcmNsZSxcbiAgRmlsZVRleHQsXG4gIFNxdWFyZSxcbiAgU2xpZGVycyxcbiAgWCxcbiAgRHJvcGxldHMsXG4gIEZsYW1lLFxuICBDaGVja0NpcmNsZTJcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IGpzUERGIH0gZnJvbSAnanNwZGYnO1xuaW1wb3J0IHsgYWRkRG93bmxvYWRSZWNvcmQgfSBmcm9tICcuLi91dGlscy9zdG9yYWdlJztcbmltcG9ydCB7IHByaW50SW1hZ2VTaGVldCB9IGZyb20gJy4uL3V0aWxzL3ByaW50ZXInO1xuXG5pbnRlcmZhY2UgU2VjdGlvbkJveCB7XG4gIHg6IG51bWJlcjsgLy8gMC4uMSByZWxhdGl2ZSB0byBjYXJkIHdpZHRoXG4gIHk6IG51bWJlcjsgLy8gMC4uMSByZWxhdGl2ZSB0byBjYXJkIGhlaWdodFxuICB3OiBudW1iZXI7IC8vIDAuLjEgcmVsYXRpdmUgdG8gY2FyZCB3aWR0aFxuICBoOiBudW1iZXI7IC8vIDAuLjEgcmVsYXRpdmUgdG8gY2FyZCBoZWlnaHRcbn1cblxuZXhwb3J0IGNvbnN0IFB2Y1N0dWRpb1ZpZXc6IFJlYWN0LkZDID0gKCkgPT4ge1xuICAvLyBDYW52YXMgcmVmZXJlbmNlc1xuICBjb25zdCBjYW52YXNSZWYgPSB1c2VSZWY8SFRNTENhbnZhc0VsZW1lbnQgfCBudWxsPihudWxsKTtcblxuICAvLyBDYXJkIGltYWdlcyAoRGF0YSBVUkxzIG9yIEltYWdlIG9iamVjdHMpXG4gIGNvbnN0IFtjYXJkMVNyYywgc2V0Q2FyZDFTcmNdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtjYXJkMlNyYywgc2V0Q2FyZDJTcmNdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gQWN0aXZlIGVkaXRpbmcgY2FyZDogJ2NhcmQxJyB8ICdjYXJkMidcbiAgY29uc3QgW2FjdGl2ZUNhcmQsIHNldEFjdGl2ZUNhcmRdID0gdXNlU3RhdGU8J2NhcmQxJyB8ICdjYXJkMic+KCdjYXJkMScpO1xuXG4gIC8vIEFkanVzdG1lbnRzIHBlciBjYXJkXG4gIGNvbnN0IFtjYXJkMUNvbmZpZywgc2V0Q2FyZDFDb25maWddID0gdXNlU3RhdGUoe1xuICAgIHg6IDAsXG4gICAgeTogMCxcbiAgICBzY2FsZTogMS4wLFxuICAgIHJvdGF0aW9uOiAwXG4gIH0pO1xuXG4gIGNvbnN0IFtjYXJkMkNvbmZpZywgc2V0Q2FyZDJDb25maWddID0gdXNlU3RhdGUoe1xuICAgIHg6IDAsXG4gICAgeTogMCxcbiAgICBzY2FsZTogMS4wLFxuICAgIHJvdGF0aW9uOiAwXG4gIH0pO1xuXG4gIC8vIEdsb2JhbCBjYXJkIGFkanVzdG1lbnRzXG4gIGNvbnN0IFticmlnaHRuZXNzLCBzZXRCcmlnaHRuZXNzXSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7XG4gIGNvbnN0IFtjb250cmFzdCwgc2V0Q29udHJhc3RdID0gdXNlU3RhdGU8bnVtYmVyPigwKTtcbiAgY29uc3QgW3Nob3dDdXRNYXJrcywgc2V0U2hvd0N1dE1hcmtzXSA9IHVzZVN0YXRlPGJvb2xlYW4+KHRydWUpO1xuICBjb25zdCBbcm91bmRlZENvcm5lcnMsIHNldFJvdW5kZWRDb3JuZXJzXSA9IHVzZVN0YXRlPGJvb2xlYW4+KHRydWUpO1xuICBjb25zdCBbYm9yZGVyU3Ryb2tlLCBzZXRCb3JkZXJTdHJva2VdID0gdXNlU3RhdGU8Ym9vbGVhbj4odHJ1ZSk7XG4gIGNvbnN0IFtpc1Byb2Nlc3NpbmcsIHNldElzUHJvY2Vzc2luZ10gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG4gIGNvbnN0IFtwcmludEFsZXJ0LCBzZXRQcmludEFsZXJ0XSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIC8vIFNFQ1RJT04gU0VMRUNUSU9OIFRPT0wgJiBMT0NBTCBDT0xPUiBHUkFESU5HIFNUQVRFXG4gIGNvbnN0IFtpbnRlcmFjdGlvbk1vZGUsIHNldEludGVyYWN0aW9uTW9kZV0gPSB1c2VTdGF0ZTwnbW92ZScgfCAnc2VjdGlvbl9zZWxlY3QnPignbW92ZScpO1xuICBjb25zdCBbY2FyZDFTZWN0aW9uLCBzZXRDYXJkMVNlY3Rpb25dID0gdXNlU3RhdGU8U2VjdGlvbkJveCB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbY2FyZDJTZWN0aW9uLCBzZXRDYXJkMlNlY3Rpb25dID0gdXNlU3RhdGU8U2VjdGlvbkJveCB8IG51bGw+KG51bGwpO1xuICBcbiAgLy8gTG9jYWwgQ29sb3IgR3JhZGluZyBwYXJhbWV0ZXJzIGZvciB0aGUgc2VsZWN0ZWQgc2VjdGlvblxuICBjb25zdCBbc2VjdGlvbkJyaWdodG5lc3MsIHNldFNlY3Rpb25CcmlnaHRuZXNzXSA9IHVzZVN0YXRlPG51bWJlcj4oMTUpO1xuICBjb25zdCBbc2VjdGlvbkNvbnRyYXN0LCBzZXRTZWN0aW9uQ29udHJhc3RdID0gdXNlU3RhdGU8bnVtYmVyPigxMCk7XG4gIGNvbnN0IFtzZWN0aW9uU2F0dXJhdGlvbiwgc2V0U2VjdGlvblNhdHVyYXRpb25dID0gdXNlU3RhdGU8bnVtYmVyPigwKTtcbiAgY29uc3QgW3NlY3Rpb25XYXJtdGgsIHNldFNlY3Rpb25XYXJtdGhdID0gdXNlU3RhdGU8bnVtYmVyPigwKTtcbiAgY29uc3QgW3NlY3Rpb25GZWF0aGVyLCBzZXRTZWN0aW9uRmVhdGhlcl0gPSB1c2VTdGF0ZTxudW1iZXI+KDYpO1xuXG4gIC8vIEludGVyYWN0aXZlIG1vdXNlIGRyYWdnaW5nICYgYm94IHNlbGVjdGlvbiBzdGF0ZVxuICBjb25zdCBbaXNEcmFnZ2luZywgc2V0SXNEcmFnZ2luZ10gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG4gIGNvbnN0IFtkcmFnQ2FyZCwgc2V0RHJhZ0NhcmRdID0gdXNlU3RhdGU8J2NhcmQxJyB8ICdjYXJkMicgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2RyYWdTdGFydCwgc2V0RHJhZ1N0YXJ0XSA9IHVzZVN0YXRlPHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfT4oeyB4OiAwLCB5OiAwIH0pO1xuICBjb25zdCBbaXNTZWxlY3RpbmdCb3gsIHNldElzU2VsZWN0aW5nQm94XSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW3NlbGVjdGlvblN0YXJ0Tm9ybSwgc2V0U2VsZWN0aW9uU3RhcnROb3JtXSA9IHVzZVN0YXRlPHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfSB8IG51bGw+KG51bGwpO1xuXG4gIC8vIDMwMCBEUEkgY29uc3RhbnRzIGZvciA0eDYgaW5jaCBwYXBlcjpcbiAgLy8gNCBpbmNoZXMgPSAxMjAwIHB4LCA2IGluY2hlcyA9IDE4MDAgcHhcbiAgY29uc3QgQ0FOVkFTX1dJRFRIID0gMTIwMDtcbiAgY29uc3QgQ0FOVkFTX0hFSUdIVCA9IDE4MDA7XG5cbiAgLy8gRXhhY3QgNS41IGNtIMOXIDguNSBjbSAoODUgbW0gw5cgNTUgbW0pIGRpbWVuc2lvbnMgYXQgMzAwIERQSTpcbiAgLy8gMSBpbmNoID0gMi41NCBjbSAtPiAzMDAgcHggLyAyLjU0IGNtID0gMTE4LjExMDIgcHggcGVyIGNtXG4gIC8vIFdpZHRoOiA4LjUgY20gKiAxMTguMTEwMiDiiYggMTAwNCBweFxuICAvLyBIZWlnaHQ6IDUuNSBjbSAqIDExOC4xMTAyIOKJiCA2NTAgcHhcbiAgY29uc3QgQ0FSRF9XSURUSCA9IDEwMDQ7XG4gIGNvbnN0IENBUkRfSEVJR0hUID0gNjUwO1xuXG4gIC8vIFBvc2l0aW9uIG9uIDR4NiBpbmNoIFBvcnRyYWl0IFNoZWV0ICgxMjAwIHggMTgwMCBweCk6XG4gIC8vIFggQ2VudGVyOiAxMjAwIC8gMiA9IDYwMCBweCAoOTggcHggbWFyZ2luIG9uIGxlZnQgYW5kIHJpZ2h0ID0gfjguMyBtbSlcbiAgLy8gVG9wIENhcmQgQ2VudGVyIChGcm9udCk6IFkgPSA0NjUgcHhcbiAgLy8gQ2VudGVyIEN1dCBHdWlkZWxpbmU6IFkgPSA5MDAgcHhcbiAgLy8gQm90dG9tIENhcmQgQ2VudGVyIChCYWNrKTogWSA9IDEzMzUgcHhcbiAgY29uc3QgQ0FSRF9DRU5URVJfWCA9IDYwMDtcbiAgY29uc3QgQ0FSRDFfREVGQVVMVF9ZID0gNDY1O1xuICBjb25zdCBDQVJEMl9ERUZBVUxUX1kgPSAxMzM1O1xuXG4gIC8vIFByZS1sb2FkIGltYWdlcyBmb3IgY2FudmFzIGRyYXdpbmdcbiAgY29uc3QgY2FyZDFJbWdSZWYgPSB1c2VSZWY8SFRNTEltYWdlRWxlbWVudCB8IG51bGw+KG51bGwpO1xuICBjb25zdCBjYXJkMkltZ1JlZiA9IHVzZVJlZjxIVE1MSW1hZ2VFbGVtZW50IHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gTG9hZCBjYXJkIDEgaW1hZ2VcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoY2FyZDFTcmMpIHtcbiAgICAgIGNvbnN0IGltZyA9IG5ldyBJbWFnZSgpO1xuICAgICAgaW1nLmNyb3NzT3JpZ2luID0gJ2Fub255bW91cyc7XG4gICAgICBpbWcub25sb2FkID0gKCkgPT4ge1xuICAgICAgICBjYXJkMUltZ1JlZi5jdXJyZW50ID0gaW1nO1xuICAgICAgICByZW5kZXJDYW52YXMoKTtcbiAgICAgIH07XG4gICAgICBpbWcuc3JjID0gY2FyZDFTcmM7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNhcmQxSW1nUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgcmVuZGVyQ2FudmFzKCk7XG4gICAgfVxuICB9LCBbY2FyZDFTcmNdKTtcblxuICAvLyBMb2FkIGNhcmQgMiBpbWFnZVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChjYXJkMlNyYykge1xuICAgICAgY29uc3QgaW1nID0gbmV3IEltYWdlKCk7XG4gICAgICBpbWcuY3Jvc3NPcmlnaW4gPSAnYW5vbnltb3VzJztcbiAgICAgIGltZy5vbmxvYWQgPSAoKSA9PiB7XG4gICAgICAgIGNhcmQySW1nUmVmLmN1cnJlbnQgPSBpbWc7XG4gICAgICAgIHJlbmRlckNhbnZhcygpO1xuICAgICAgfTtcbiAgICAgIGltZy5zcmMgPSBjYXJkMlNyYztcbiAgICB9IGVsc2Uge1xuICAgICAgY2FyZDJJbWdSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICByZW5kZXJDYW52YXMoKTtcbiAgICB9XG4gIH0sIFtjYXJkMlNyY10pO1xuXG4gIC8vIEdsb2JhbCBLZXlib2FyZCBzaG9ydGN1dHMgbGlzdGVuZXIgKEN0cmwrUCwgQ3RybCtTLCBDdHJsK0opXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgaGFuZGxlR2xvYmFsUHJpbnQgPSAoKSA9PiBoYW5kbGVEaXJlY3RQcmludCgpO1xuICAgIGNvbnN0IGhhbmRsZUdsb2JhbFBkZiA9ICgpID0+IGhhbmRsZURvd25sb2FkUERGKCk7XG4gICAgY29uc3QgaGFuZGxlR2xvYmFsSnBnID0gKCkgPT4gaGFuZGxlRG93bmxvYWRKUEcoKTtcblxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdhcHAtZGlyZWN0LXByaW50JywgaGFuZGxlR2xvYmFsUHJpbnQpO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdhcHAtZGlyZWN0LXBkZicsIGhhbmRsZUdsb2JhbFBkZik7XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2FwcC1kaXJlY3QtanBnJywgaGFuZGxlR2xvYmFsSnBnKTtcblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignYXBwLWRpcmVjdC1wcmludCcsIGhhbmRsZUdsb2JhbFByaW50KTtcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdhcHAtZGlyZWN0LXBkZicsIGhhbmRsZUdsb2JhbFBkZik7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignYXBwLWRpcmVjdC1qcGcnLCBoYW5kbGVHbG9iYWxKcGcpO1xuICAgIH07XG4gIH0pO1xuXG4gIC8vIFJlLXJlbmRlciBjYW52YXMgd2hlbmV2ZXIgY29uZmlncyBvciBzZWN0aW9uIGFkanVzdG1lbnRzIGNoYW5nZVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHJlbmRlckNhbnZhcygpO1xuICB9LCBbXG4gICAgY2FyZDFDb25maWcsIFxuICAgIGNhcmQyQ29uZmlnLCBcbiAgICBicmlnaHRuZXNzLCBcbiAgICBjb250cmFzdCwgXG4gICAgc2hvd0N1dE1hcmtzLCBcbiAgICByb3VuZGVkQ29ybmVycywgXG4gICAgYm9yZGVyU3Ryb2tlLCBcbiAgICBjYXJkMVNlY3Rpb24sIFxuICAgIGNhcmQyU2VjdGlvbiwgXG4gICAgc2VjdGlvbkJyaWdodG5lc3MsIFxuICAgIHNlY3Rpb25Db250cmFzdCwgXG4gICAgc2VjdGlvblNhdHVyYXRpb24sIFxuICAgIHNlY3Rpb25XYXJtdGgsIFxuICAgIHNlY3Rpb25GZWF0aGVyLFxuICAgIGludGVyYWN0aW9uTW9kZSxcbiAgICBhY3RpdmVDYXJkXG4gIF0pO1xuXG4gIC8vIE1haW4gUmVuZGVyIEZ1bmN0aW9uIHRvIENhbnZhcyBAIDMwMCBEUElcbiAgY29uc3QgcmVuZGVyQ2FudmFzID0gKGhpZGVNYXJxdWVlOiBib29sZWFuID0gZmFsc2UpID0+IHtcbiAgICBjb25zdCBjYW52YXMgPSBjYW52YXNSZWYuY3VycmVudDtcbiAgICBpZiAoIWNhbnZhcykgcmV0dXJuO1xuICAgIGNvbnN0IGN0eCA9IGNhbnZhcy5nZXRDb250ZXh0KCcyZCcpO1xuICAgIGlmICghY3R4KSByZXR1cm47XG5cbiAgICAvLyBDbGVhciBiYWNrZ3JvdW5kIHRvIHB1cmUgd2hpdGUgKGZvciBwaG90byBwYXBlciBwcmludClcbiAgICBjdHguZmlsbFN0eWxlID0gJyNmZmZmZmYnO1xuICAgIGN0eC5maWxsUmVjdCgwLCAwLCBDQU5WQVNfV0lEVEgsIENBTlZBU19IRUlHSFQpO1xuXG4gICAgLy8gR2xvYmFsIGZpbHRlciBzdHJpbmdcbiAgICBjb25zdCBnbG9iYWxGaWx0ZXJTdHIgPSBgYnJpZ2h0bmVzcygkezEwMCArIGJyaWdodG5lc3N9JSkgY29udHJhc3QoJHsxMDAgKyBjb250cmFzdH0lKWA7XG5cbiAgICAvLyAxLiBEcmF3IENhcmQgMSAoVG9wIC8gRnJvbnQpXG4gICAgZHJhd1NpbmdsZUNhcmQoXG4gICAgICBjdHgsXG4gICAgICBjYXJkMUltZ1JlZi5jdXJyZW50LFxuICAgICAgQ0FSRF9DRU5URVJfWCArIGNhcmQxQ29uZmlnLngsXG4gICAgICBDQVJEMV9ERUZBVUxUX1kgKyBjYXJkMUNvbmZpZy55LFxuICAgICAgY2FyZDFDb25maWcuc2NhbGUsXG4gICAgICBjYXJkMUNvbmZpZy5yb3RhdGlvbixcbiAgICAgICdDYXJkIDEgKEZyb250KScsXG4gICAgICBnbG9iYWxGaWx0ZXJTdHIsXG4gICAgICBjYXJkMVNlY3Rpb24sXG4gICAgICBhY3RpdmVDYXJkID09PSAnY2FyZDEnLFxuICAgICAgaGlkZU1hcnF1ZWVcbiAgICApO1xuXG4gICAgLy8gMi4gRHJhdyBDYXJkIDIgKEJvdHRvbSAvIEJhY2spXG4gICAgZHJhd1NpbmdsZUNhcmQoXG4gICAgICBjdHgsXG4gICAgICBjYXJkMkltZ1JlZi5jdXJyZW50LFxuICAgICAgQ0FSRF9DRU5URVJfWCArIGNhcmQyQ29uZmlnLngsXG4gICAgICBDQVJEMl9ERUZBVUxUX1kgKyBjYXJkMkNvbmZpZy55LFxuICAgICAgY2FyZDJDb25maWcuc2NhbGUsXG4gICAgICBjYXJkMkNvbmZpZy5yb3RhdGlvbixcbiAgICAgICdDYXJkIDIgKEJhY2spJyxcbiAgICAgIGdsb2JhbEZpbHRlclN0cixcbiAgICAgIGNhcmQyU2VjdGlvbixcbiAgICAgIGFjdGl2ZUNhcmQgPT09ICdjYXJkMicsXG4gICAgICBoaWRlTWFycXVlZVxuICAgICk7XG5cbiAgICAvLyAzLiBEcmF3IEN1dCBHdWlkZSBMaW5lIGJldHdlZW4gY2FyZHNcbiAgICBpZiAoc2hvd0N1dE1hcmtzKSB7XG4gICAgICBjdHguc2F2ZSgpO1xuICAgICAgY3R4LnN0cm9rZVN0eWxlID0gJyM5NGEzYjgnO1xuICAgICAgY3R4LmxpbmVXaWR0aCA9IDI7XG4gICAgICBjdHguc2V0TGluZURhc2goWzgsIDhdKTtcblxuICAgICAgLy8gSG9yaXpvbnRhbCBjZW50ZXIgY3V0IG1hcmsgKGV4YWN0IGNlbnRlciBvZiA0eDYgaW5jaCBzaGVldClcbiAgICAgIGNvbnN0IG1pZFkgPSA5MDA7XG4gICAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgICBjdHgubW92ZVRvKDQwLCBtaWRZKTtcbiAgICAgIGN0eC5saW5lVG8oQ0FOVkFTX1dJRFRIIC0gNDAsIG1pZFkpO1xuICAgICAgY3R4LnN0cm9rZSgpO1xuXG4gICAgICAvLyBTY2lzc29yIGluZGljYXRvciB0ZXh0XG4gICAgICBjdHguc2V0TGluZURhc2goW10pO1xuICAgICAgY3R4LmZpbGxTdHlsZSA9ICcjNjQ3NDhiJztcbiAgICAgIGN0eC5mb250ID0gJ2JvbGQgMjBweCBzYW5zLXNlcmlmJztcbiAgICAgIGN0eC50ZXh0QWxpZ24gPSAnY2VudGVyJztcbiAgICAgIGN0eC5maWxsVGV4dCgn4pyCIEN1dCBIZXJlIChGb2xkIC8gU2VwYXJhdGUg4oCiIDUuNSBjbSDDlyA4LjUgY20gRWFjaCknLCBDQU5WQVNfV0lEVEggLyAyLCBtaWRZIC0gMTIpO1xuXG4gICAgICAvLyBTaGVldCBib3VuZGFyeSBjcm9wIGNvcm5lcnNcbiAgICAgIGRyYXdDcm9wTWFya3MoY3R4LCA0MCwgNDApO1xuICAgICAgZHJhd0Nyb3BNYXJrcyhjdHgsIENBTlZBU19XSURUSCAtIDQwLCA0MCk7XG4gICAgICBkcmF3Q3JvcE1hcmtzKGN0eCwgNDAsIENBTlZBU19IRUlHSFQgLSA0MCk7XG4gICAgICBkcmF3Q3JvcE1hcmtzKGN0eCwgQ0FOVkFTX1dJRFRIIC0gNDAsIENBTlZBU19IRUlHSFQgLSA0MCk7XG5cbiAgICAgIGN0eC5yZXN0b3JlKCk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGRyYXdDcm9wTWFya3MgPSAoY3R4OiBDYW52YXNSZW5kZXJpbmdDb250ZXh0MkQsIHg6IG51bWJlciwgeTogbnVtYmVyKSA9PiB7XG4gICAgY3R4LnN0cm9rZVN0eWxlID0gJyNjYmQ1ZTEnO1xuICAgIGN0eC5saW5lV2lkdGggPSAyO1xuICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICBjdHgubW92ZVRvKHggLSAyMCwgeSk7XG4gICAgY3R4LmxpbmVUbyh4ICsgMjAsIHkpO1xuICAgIGN0eC5tb3ZlVG8oeCwgeSAtIDIwKTtcbiAgICBjdHgubGluZVRvKHgsIHkgKyAyMCk7XG4gICAgY3R4LnN0cm9rZSgpO1xuICB9O1xuXG4gIGNvbnN0IGRyYXdTaW5nbGVDYXJkID0gKFxuICAgIGN0eDogQ2FudmFzUmVuZGVyaW5nQ29udGV4dDJELFxuICAgIGltZzogSFRNTEltYWdlRWxlbWVudCB8IG51bGwsXG4gICAgY2VudGVyWDogbnVtYmVyLFxuICAgIGNlbnRlclk6IG51bWJlcixcbiAgICBzY2FsZTogbnVtYmVyLFxuICAgIHJvdGF0aW9uOiBudW1iZXIsXG4gICAgcGxhY2Vob2xkZXJMYWJlbDogc3RyaW5nLFxuICAgIGZpbHRlcjogc3RyaW5nLFxuICAgIHNlY3Rpb246IFNlY3Rpb25Cb3ggfCBudWxsLFxuICAgIGlzQWN0aXZlQ2FyZDogYm9vbGVhbixcbiAgICBoaWRlTWFycXVlZTogYm9vbGVhbiA9IGZhbHNlXG4gICkgPT4ge1xuICAgIGNvbnN0IHcgPSBDQVJEX1dJRFRIO1xuICAgIGNvbnN0IGggPSBDQVJEX0hFSUdIVDtcbiAgICBjb25zdCBsZWZ0ID0gY2VudGVyWCAtIHcgLyAyO1xuICAgIGNvbnN0IHRvcCA9IGNlbnRlclkgLSBoIC8gMjtcblxuICAgIGN0eC5zYXZlKCk7XG5cbiAgICAvLyBDbGlwIHRvIHJvdW5kZWQgQ1ItODAgY2FyZCBzdGFuZGFyZCBib3VuZGFyeSAoMy4xOG1tIHJhZGl1cyA9IH4zNXB4IEAgMzAwIERQSSlcbiAgICBjb25zdCByYWRpdXMgPSByb3VuZGVkQ29ybmVycyA/IDM1IDogMDtcbiAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgY3R4LnJvdW5kUmVjdChsZWZ0LCB0b3AsIHcsIGgsIHJhZGl1cyk7XG4gICAgY3R4LmNsaXAoKTtcblxuICAgIGlmIChpbWcpIHtcbiAgICAgIC8vIDEuIERyYXcgYmFzZSBjYXJkIGltYWdlXG4gICAgICBjdHguc2F2ZSgpO1xuICAgICAgY3R4LmZpbHRlciA9IGZpbHRlcjtcbiAgICAgIGN0eC50cmFuc2xhdGUoY2VudGVyWCwgY2VudGVyWSk7XG4gICAgICBjdHgucm90YXRlKChyb3RhdGlvbiAqIE1hdGguUEkpIC8gMTgwKTtcbiAgICAgIGN0eC5zY2FsZShzY2FsZSwgc2NhbGUpO1xuICAgICAgY3R4LmRyYXdJbWFnZShpbWcsIC13IC8gMiwgLWggLyAyLCB3LCBoKTtcbiAgICAgIGN0eC5yZXN0b3JlKCk7XG5cbiAgICAgIC8vIDIuIERyYXcgTG9jYWwgU2VjdGlvbiBDb2xvciBHcmFkaW5nIGlmIGEgc2VjdGlvbiBpcyBkZWZpbmVkIG9uIHRoaXMgY2FyZFxuICAgICAgaWYgKHNlY3Rpb24gJiYgc2VjdGlvbi53ID4gMC4wMSAmJiBzZWN0aW9uLmggPiAwLjAxKSB7XG4gICAgICAgIGN0eC5zYXZlKCk7XG5cbiAgICAgICAgLy8gQ2FsY3VsYXRlIHNlY3Rpb24gYm94IGluIGNhbnZhcyBwaXhlbHNcbiAgICAgICAgY29uc3Qgc2VjWCA9IGxlZnQgKyBzZWN0aW9uLnggKiB3O1xuICAgICAgICBjb25zdCBzZWNZID0gdG9wICsgc2VjdGlvbi55ICogaDtcbiAgICAgICAgY29uc3Qgc2VjVyA9IHNlY3Rpb24udyAqIHc7XG4gICAgICAgIGNvbnN0IHNlY0ggPSBzZWN0aW9uLmggKiBoO1xuXG4gICAgICAgIC8vIENsaXAgdG8gdGhlIHNlbGVjdGVkIHNlY3Rpb24gYm94IHdpdGggb3B0aW9uYWwgZmVhdGhlcmluZ1xuICAgICAgICBjdHguc2F2ZSgpO1xuICAgICAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgICAgIGN0eC5yZWN0KHNlY1gsIHNlY1ksIHNlY1csIHNlY0gpO1xuICAgICAgICBjdHguY2xpcCgpO1xuXG4gICAgICAgIC8vIExvY2FsIGZpbHRlciBzdHJpbmdcbiAgICAgICAgY29uc3QgZWZmQnJpZ2h0ID0gMTAwICsgYnJpZ2h0bmVzcyArIHNlY3Rpb25CcmlnaHRuZXNzO1xuICAgICAgICBjb25zdCBlZmZDb250ID0gMTAwICsgY29udHJhc3QgKyBzZWN0aW9uQ29udHJhc3Q7XG4gICAgICAgIGNvbnN0IGVmZlNhdCA9IDEwMCArIHNlY3Rpb25TYXR1cmF0aW9uO1xuICAgICAgICBjdHguZmlsdGVyID0gYGJyaWdodG5lc3MoJHtlZmZCcmlnaHR9JSkgY29udHJhc3QoJHtlZmZDb250fSUpIHNhdHVyYXRlKCR7ZWZmU2F0fSUpYDtcblxuICAgICAgICAvLyBSZWRyYXcgaW1hZ2UgaW5zaWRlIHRoZSBjbGlwcGVkIHNlY3Rpb24gd2l0aCB0aGUgZW5oYW5jZWQgY29sb3IgZ3JhZGluZ1xuICAgICAgICBjdHgudHJhbnNsYXRlKGNlbnRlclgsIGNlbnRlclkpO1xuICAgICAgICBjdHgucm90YXRlKChyb3RhdGlvbiAqIE1hdGguUEkpIC8gMTgwKTtcbiAgICAgICAgY3R4LnNjYWxlKHNjYWxlLCBzY2FsZSk7XG4gICAgICAgIGN0eC5kcmF3SW1hZ2UoaW1nLCAtdyAvIDIsIC1oIC8gMiwgdywgaCk7XG4gICAgICAgIGN0eC5yZXN0b3JlKCk7XG5cbiAgICAgICAgLy8gQXBwbHkgd2FybXRoIG92ZXJsYXkgdG8gdGhlIHNlY3Rpb24gaWYgc2V0XG4gICAgICAgIGlmIChzZWN0aW9uV2FybXRoICE9PSAwKSB7XG4gICAgICAgICAgY3R4LnNhdmUoKTtcbiAgICAgICAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgICAgICAgY3R4LnJlY3Qoc2VjWCwgc2VjWSwgc2VjVywgc2VjSCk7XG4gICAgICAgICAgY3R4LmNsaXAoKTtcbiAgICAgICAgICBjdHguZ2xvYmFsQ29tcG9zaXRlT3BlcmF0aW9uID0gJ2NvbG9yJztcbiAgICAgICAgICBjdHguZmlsbFN0eWxlID0gc2VjdGlvbldhcm10aCA+IDAgXG4gICAgICAgICAgICA/IGByZ2JhKDI1NSwgMTcwLCA3MCwgJHtNYXRoLm1pbigwLjQsIChzZWN0aW9uV2FybXRoIC8gMTAwKSAqIDAuNSl9KWBcbiAgICAgICAgICAgIDogYHJnYmEoNzAsIDE2MCwgMjU1LCAke01hdGgubWluKDAuNCwgKE1hdGguYWJzKHNlY3Rpb25XYXJtdGgpIC8gMTAwKSAqIDAuNSl9KWA7XG4gICAgICAgICAgY3R4LmZpbGxSZWN0KHNlY1gsIHNlY1ksIHNlY1csIHNlY0gpO1xuICAgICAgICAgIGN0eC5yZXN0b3JlKCk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBEcmF3IGFuaW1hdGVkL2hpZ2gtdmlzaWJpbGl0eSBzZWxlY3Rpb24gZGFzaGVkIG1hcnF1ZWUgYm9yZGVyIG9ubHkgaW4gc2NyZWVuIFVJIG1vZGVcbiAgICAgICAgaWYgKCFoaWRlTWFycXVlZSkge1xuICAgICAgICAgIGN0eC5zYXZlKCk7XG4gICAgICAgICAgY3R4LnN0cm9rZVN0eWxlID0gaXNBY3RpdmVDYXJkID8gJyMwNmI2ZDQnIDogJyM2NDc0OGInO1xuICAgICAgICAgIGN0eC5saW5lV2lkdGggPSAzO1xuICAgICAgICAgIGN0eC5zZXRMaW5lRGFzaChbOCwgNl0pO1xuICAgICAgICAgIGN0eC5zdHJva2VSZWN0KHNlY1gsIHNlY1ksIHNlY1csIHNlY0gpO1xuXG4gICAgICAgICAgLy8gU2VsZWN0aW9uIFRhZyBCYWRnZVxuICAgICAgICAgIGN0eC5maWxsU3R5bGUgPSBpc0FjdGl2ZUNhcmQgPyAncmdiYSg2LCAxODIsIDIxMiwgMC45KScgOiAncmdiYSgxMDAsIDExNiwgMTM5LCAwLjgpJztcbiAgICAgICAgICBjdHguZmlsbFJlY3Qoc2VjWCwgTWF0aC5tYXgodG9wLCBzZWNZIC0gMjQpLCAxNjAsIDIyKTtcbiAgICAgICAgICBjdHguZmlsbFN0eWxlID0gJyNmZmZmZmYnO1xuICAgICAgICAgIGN0eC5mb250ID0gJ2JvbGQgMTJweCBzYW5zLXNlcmlmJztcbiAgICAgICAgICBjdHguZmlsbFRleHQoYPCfjq8gU2VjdGlvbiAoJHtzZWN0aW9uQnJpZ2h0bmVzcyA+IDAgPyAnKycgOiAnJ30ke3NlY3Rpb25CcmlnaHRuZXNzfUIgLyAke3NlY3Rpb25Db250cmFzdCA+IDAgPyAnKycgOiAnJ30ke3NlY3Rpb25Db250cmFzdH1DKWAsIHNlY1ggKyA2LCBNYXRoLm1heCh0b3AsIHNlY1kgLSAyNCkgKyAxNik7XG4gICAgICAgICAgY3R4LnJlc3RvcmUoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGN0eC5yZXN0b3JlKCk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIEVtcHR5IHBsYWNlaG9sZGVyIHNsb3RcbiAgICAgIGN0eC5maWxsU3R5bGUgPSAnI2Y4ZmFmYyc7XG4gICAgICBjdHguZmlsbCgpO1xuXG4gICAgICBjdHguc3Ryb2tlU3R5bGUgPSAnI2NiZDVlMSc7XG4gICAgICBjdHgubGluZVdpZHRoID0gNDtcbiAgICAgIGN0eC5zZXRMaW5lRGFzaChbMTIsIDhdKTtcbiAgICAgIGN0eC5zdHJva2UoKTtcblxuICAgICAgLy8gUGxhY2Vob2xkZXIgdGV4dFxuICAgICAgY3R4LmZpbGxTdHlsZSA9ICcjNjQ3NDhiJztcbiAgICAgIGN0eC5mb250ID0gJ2JvbGQgMzZweCBzYW5zLXNlcmlmJztcbiAgICAgIGN0eC50ZXh0QWxpZ24gPSAnY2VudGVyJztcbiAgICAgIGN0eC5maWxsVGV4dChwbGFjZWhvbGRlckxhYmVsLCBjZW50ZXJYLCBjZW50ZXJZIC0gMjApO1xuICAgICAgY3R4LmZvbnQgPSAnMjRweCBzYW5zLXNlcmlmJztcbiAgICAgIGN0eC5maWxsU3R5bGUgPSAnIzk0YTNiOCc7XG4gICAgICBjdHguZmlsbFRleHQoJ0Ryb3AgaW1hZ2Ugb3IgUERGIHRvIHBsYWNlIGhlcmUnLCBjZW50ZXJYLCBjZW50ZXJZICsgMzApO1xuICAgICAgY3R4LmZpbGxUZXh0KCdPZmZpY2lhbCBTaXplOiA1LjUgY20gw5cgOC41IGNtICg4NSBtbSDDlyA1NSBtbSknLCBjZW50ZXJYLCBjZW50ZXJZICsgNzApO1xuICAgIH1cblxuICAgIC8vIEJvcmRlciBsaW5lIGFyb3VuZCBjYXJkXG4gICAgaWYgKGJvcmRlclN0cm9rZSkge1xuICAgICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgICAgY3R4LnJvdW5kUmVjdChsZWZ0LCB0b3AsIHcsIGgsIHJhZGl1cyk7XG4gICAgICBjdHguc3Ryb2tlU3R5bGUgPSAoIWhpZGVNYXJxdWVlICYmIGlzQWN0aXZlQ2FyZCAmJiBpbnRlcmFjdGlvbk1vZGUgPT09ICdzZWN0aW9uX3NlbGVjdCcpID8gJyMzOGJkZjgnIDogJyMxZTI5M2InO1xuICAgICAgY3R4LmxpbmVXaWR0aCA9ICghaGlkZU1hcnF1ZWUgJiYgaXNBY3RpdmVDYXJkICYmIGludGVyYWN0aW9uTW9kZSA9PT0gJ3NlY3Rpb25fc2VsZWN0JykgPyAzIDogMjtcbiAgICAgIGN0eC5zZXRMaW5lRGFzaChbXSk7XG4gICAgICBjdHguc3Ryb2tlKCk7XG4gICAgfVxuXG4gICAgY3R4LnJlc3RvcmUoKTtcbiAgfTtcblxuICAvLyBDb252ZXJ0IGNsaWNrIG9uIGNhbnZhcyB0byBjYXJkLW5vcm1hbGl6ZWQgY29vcmRpbmF0ZSAoMC4uMSlcbiAgY29uc3QgZ2V0Q2FyZE5vcm1hbGl6ZWRDb29yZHMgPSAoY2FudmFzWDogbnVtYmVyLCBjYW52YXNZOiBudW1iZXIsIHRhcmdldENhcmQ6ICdjYXJkMScgfCAnY2FyZDInKSA9PiB7XG4gICAgY29uc3QgY2VudGVyWCA9IENBUkRfQ0VOVEVSX1ggKyAodGFyZ2V0Q2FyZCA9PT0gJ2NhcmQxJyA/IGNhcmQxQ29uZmlnLnggOiBjYXJkMkNvbmZpZy54KTtcbiAgICBjb25zdCBjZW50ZXJZID0gKHRhcmdldENhcmQgPT09ICdjYXJkMScgPyBDQVJEMV9ERUZBVUxUX1kgOiBDQVJEMl9ERUZBVUxUX1kpICsgKHRhcmdldENhcmQgPT09ICdjYXJkMScgPyBjYXJkMUNvbmZpZy55IDogY2FyZDJDb25maWcueSk7XG4gICAgY29uc3QgbGVmdCA9IGNlbnRlclggLSBDQVJEX1dJRFRIIC8gMjtcbiAgICBjb25zdCB0b3AgPSBjZW50ZXJZIC0gQ0FSRF9IRUlHSFQgLyAyO1xuXG4gICAgY29uc3Qgbm9ybVggPSAoY2FudmFzWCAtIGxlZnQpIC8gQ0FSRF9XSURUSDtcbiAgICBjb25zdCBub3JtWSA9IChjYW52YXNZIC0gdG9wKSAvIENBUkRfSEVJR0hUO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIG5vcm1YLFxuICAgICAgbm9ybVksXG4gICAgICBpc0luc2lkZTogbm9ybVggPj0gMCAmJiBub3JtWCA8PSAxICYmIG5vcm1ZID49IDAgJiYgbm9ybVkgPD0gMVxuICAgIH07XG4gIH07XG5cbiAgLy8gVXBsb2FkIGhhbmRsZXIgZm9yIENhcmQgMSBvciBDYXJkIDJcbiAgY29uc3QgaGFuZGxlRmlsZVVwbG9hZCA9IChlOiBSZWFjdC5DaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50PiwgdGFyZ2V0OiAnY2FyZDEnIHwgJ2NhcmQyJykgPT4ge1xuICAgIGNvbnN0IGZpbGUgPSBlLnRhcmdldC5maWxlcz8uWzBdO1xuICAgIGlmICghZmlsZSkgcmV0dXJuO1xuXG4gICAgY29uc3QgcmVhZGVyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICByZWFkZXIub25sb2FkID0gKGV2ZW50KSA9PiB7XG4gICAgICBjb25zdCByZXN1bHQgPSBldmVudC50YXJnZXQ/LnJlc3VsdCBhcyBzdHJpbmc7XG4gICAgICBpZiAodGFyZ2V0ID09PSAnY2FyZDEnKSB7XG4gICAgICAgIHNldENhcmQxU3JjKHJlc3VsdCk7XG4gICAgICAgIHNldEFjdGl2ZUNhcmQoJ2NhcmQxJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRDYXJkMlNyYyhyZXN1bHQpO1xuICAgICAgICBzZXRBY3RpdmVDYXJkKCdjYXJkMicpO1xuICAgICAgfVxuICAgIH07XG4gICAgcmVhZGVyLnJlYWRBc0RhdGFVUkwoZmlsZSk7XG4gICAgZS50YXJnZXQudmFsdWUgPSAnJztcbiAgfTtcblxuICAvLyBTd2FwIEZyb250ICYgQmFjayBjYXJkc1xuICBjb25zdCBoYW5kbGVTd2FwQ2FyZHMgPSAoKSA9PiB7XG4gICAgY29uc3QgdGVtcFNyYyA9IGNhcmQxU3JjO1xuICAgIHNldENhcmQxU3JjKGNhcmQyU3JjKTtcbiAgICBzZXRDYXJkMlNyYyh0ZW1wU3JjKTtcblxuICAgIGNvbnN0IHRlbXBDZmcgPSB7IC4uLmNhcmQxQ29uZmlnIH07XG4gICAgc2V0Q2FyZDFDb25maWcoeyAuLi5jYXJkMkNvbmZpZyB9KTtcbiAgICBzZXRDYXJkMkNvbmZpZyh0ZW1wQ2ZnKTtcblxuICAgIGNvbnN0IHRlbXBTZWMgPSBjYXJkMVNlY3Rpb247XG4gICAgc2V0Q2FyZDFTZWN0aW9uKGNhcmQyU2VjdGlvbik7XG4gICAgc2V0Q2FyZDJTZWN0aW9uKHRlbXBTZWMpO1xuICB9O1xuXG4gIC8vIFF1aWNrIFByZXNldCBTZWxlY3Rpb24gb24gYWN0aXZlIGNhcmRcbiAgY29uc3QgaGFuZGxlQXBwbHlQcmVzZXRTZWN0aW9uID0gKHByZXNldDogJ3Bob3RvJyB8ICdkZXRhaWxzJyB8ICdxcicgfCAnc2lnbmF0dXJlJykgPT4ge1xuICAgIGxldCBib3g6IFNlY3Rpb25Cb3g7XG4gICAgc3dpdGNoIChwcmVzZXQpIHtcbiAgICAgIGNhc2UgJ3Bob3RvJzpcbiAgICAgICAgLy8gU3RhbmRhcmQgSUQgcGhvdG8gcmVnaW9uIG9uIGNpdGl6ZW4gY2FyZHMgKHRvcC1sZWZ0KVxuICAgICAgICBib3ggPSB7IHg6IDAuMDQsIHk6IDAuMTgsIHc6IDAuMzQsIGg6IDAuNjQgfTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICdkZXRhaWxzJzpcbiAgICAgICAgLy8gTmFtZSwgYWRkcmVzcywgRE9CIHRleHQgcmVnaW9uIChjZW50ZXItcmlnaHQpXG4gICAgICAgIGJveCA9IHsgeDogMC40MCwgeTogMC4xOCwgdzogMC41NiwgaDogMC42OCB9O1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ3FyJzpcbiAgICAgICAgLy8gUVIgQ29kZSByZWdpb24gKGJvdHRvbSBvciByaWdodClcbiAgICAgICAgYm94ID0geyB4OiAwLjYyLCB5OiAwLjE4LCB3OiAwLjM0LCBoOiAwLjY0IH07XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnc2lnbmF0dXJlJzpcbiAgICAgICAgLy8gU2lnbmF0dXJlIGJveFxuICAgICAgICBib3ggPSB7IHg6IDAuMDQsIHk6IDAuNjgsIHc6IDAuNDIsIGg6IDAuMjggfTtcbiAgICAgICAgYnJlYWs7XG4gICAgfVxuXG4gICAgaWYgKGFjdGl2ZUNhcmQgPT09ICdjYXJkMScpIHtcbiAgICAgIHNldENhcmQxU2VjdGlvbihib3gpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRDYXJkMlNlY3Rpb24oYm94KTtcbiAgICB9XG4gICAgc2V0SW50ZXJhY3Rpb25Nb2RlKCdzZWN0aW9uX3NlbGVjdCcpO1xuICB9O1xuXG4gIC8vIEJha2UgU2VjdGlvbiBDb2xvciBHcmFkaW5nIGRpcmVjdGx5IGludG8gdGhlIENhcmQgaW1hZ2VcbiAgY29uc3QgaGFuZGxlQmFrZVNlY3Rpb25HcmFkaW5nID0gKCkgPT4ge1xuICAgIGNvbnN0IHRhcmdldFNyYyA9IGFjdGl2ZUNhcmQgPT09ICdjYXJkMScgPyBjYXJkMVNyYyA6IGNhcmQyU3JjO1xuICAgIGNvbnN0IHRhcmdldFNlY3Rpb24gPSBhY3RpdmVDYXJkID09PSAnY2FyZDEnID8gY2FyZDFTZWN0aW9uIDogY2FyZDJTZWN0aW9uO1xuICAgIGlmICghdGFyZ2V0U3JjIHx8ICF0YXJnZXRTZWN0aW9uKSByZXR1cm47XG5cbiAgICBzZXRJc1Byb2Nlc3NpbmcodHJ1ZSk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgaW1nID0gbmV3IEltYWdlKCk7XG4gICAgICBpbWcuY3Jvc3NPcmlnaW4gPSAnYW5vbnltb3VzJztcbiAgICAgIGltZy5vbmxvYWQgPSAoKSA9PiB7XG4gICAgICAgIGNvbnN0IG9mZkNhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xuICAgICAgICBvZmZDYW52YXMud2lkdGggPSBpbWcud2lkdGg7XG4gICAgICAgIG9mZkNhbnZhcy5oZWlnaHQgPSBpbWcuaGVpZ2h0O1xuICAgICAgICBjb25zdCBjdHggPSBvZmZDYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcbiAgICAgICAgaWYgKCFjdHgpIHJldHVybjtcblxuICAgICAgICAvLyAxLiBEcmF3IG9yaWdpbmFsIGJhc2VcbiAgICAgICAgY3R4LmRyYXdJbWFnZShpbWcsIDAsIDApO1xuXG4gICAgICAgIC8vIDIuIERyYXcgZ3JhZGVkIHNlY3Rpb24gb24gdG9wXG4gICAgICAgIGNvbnN0IHNlY1ggPSB0YXJnZXRTZWN0aW9uLnggKiBpbWcud2lkdGg7XG4gICAgICAgIGNvbnN0IHNlY1kgPSB0YXJnZXRTZWN0aW9uLnkgKiBpbWcuaGVpZ2h0O1xuICAgICAgICBjb25zdCBzZWNXID0gdGFyZ2V0U2VjdGlvbi53ICogaW1nLndpZHRoO1xuICAgICAgICBjb25zdCBzZWNIID0gdGFyZ2V0U2VjdGlvbi5oICogaW1nLmhlaWdodDtcblxuICAgICAgICBjdHguc2F2ZSgpO1xuICAgICAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgICAgIGN0eC5yZWN0KHNlY1gsIHNlY1ksIHNlY1csIHNlY0gpO1xuICAgICAgICBjdHguY2xpcCgpO1xuXG4gICAgICAgIGNvbnN0IGVmZkJyaWdodCA9IDEwMCArIHNlY3Rpb25CcmlnaHRuZXNzO1xuICAgICAgICBjb25zdCBlZmZDb250ID0gMTAwICsgc2VjdGlvbkNvbnRyYXN0O1xuICAgICAgICBjb25zdCBlZmZTYXQgPSAxMDAgKyBzZWN0aW9uU2F0dXJhdGlvbjtcbiAgICAgICAgY3R4LmZpbHRlciA9IGBicmlnaHRuZXNzKCR7ZWZmQnJpZ2h0fSUpIGNvbnRyYXN0KCR7ZWZmQ29udH0lKSBzYXR1cmF0ZSgke2VmZlNhdH0lKWA7XG4gICAgICAgIGN0eC5kcmF3SW1hZ2UoaW1nLCAwLCAwKTtcblxuICAgICAgICBpZiAoc2VjdGlvbldhcm10aCAhPT0gMCkge1xuICAgICAgICAgIGN0eC5nbG9iYWxDb21wb3NpdGVPcGVyYXRpb24gPSAnY29sb3InO1xuICAgICAgICAgIGN0eC5maWxsU3R5bGUgPSBzZWN0aW9uV2FybXRoID4gMCBcbiAgICAgICAgICAgID8gYHJnYmEoMjU1LCAxNzAsIDcwLCAke01hdGgubWluKDAuNCwgKHNlY3Rpb25XYXJtdGggLyAxMDApICogMC41KX0pYFxuICAgICAgICAgICAgOiBgcmdiYSg3MCwgMTYwLCAyNTUsICR7TWF0aC5taW4oMC40LCAoTWF0aC5hYnMoc2VjdGlvbldhcm10aCkgLyAxMDApICogMC41KX0pYDtcbiAgICAgICAgICBjdHguZmlsbFJlY3Qoc2VjWCwgc2VjWSwgc2VjVywgc2VjSCk7XG4gICAgICAgIH1cblxuICAgICAgICBjdHgucmVzdG9yZSgpO1xuXG4gICAgICAgIGNvbnN0IGJha2VkVXJsID0gb2ZmQ2FudmFzLnRvRGF0YVVSTCgnaW1hZ2UvanBlZycsIDAuOTgpO1xuICAgICAgICBpZiAoYWN0aXZlQ2FyZCA9PT0gJ2NhcmQxJykge1xuICAgICAgICAgIHNldENhcmQxU3JjKGJha2VkVXJsKTtcbiAgICAgICAgICBzZXRDYXJkMVNlY3Rpb24obnVsbCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgc2V0Q2FyZDJTcmMoYmFrZWRVcmwpO1xuICAgICAgICAgIHNldENhcmQyU2VjdGlvbihudWxsKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHNldFByaW50QWxlcnQoYOKchSBTZWN0aW9uIGdyYWRpbmcgcGVybWFuZW50bHkgYmFrZWQgaW50byAke2FjdGl2ZUNhcmQgPT09ICdjYXJkMScgPyAnQ2FyZCAxIChGcm9udCknIDogJ0NhcmQgMiAoQmFjayknfSFgKTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRQcmludEFsZXJ0KG51bGwpLCA0MDAwKTtcbiAgICAgIH07XG4gICAgICBpbWcuc3JjID0gdGFyZ2V0U3JjO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzUHJvY2Vzc2luZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIENsZWFyIFNlY3Rpb24gQm94XG4gIGNvbnN0IGhhbmRsZUNsZWFyU2VjdGlvbiA9ICgpID0+IHtcbiAgICBpZiAoYWN0aXZlQ2FyZCA9PT0gJ2NhcmQxJykge1xuICAgICAgc2V0Q2FyZDFTZWN0aW9uKG51bGwpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRDYXJkMlNlY3Rpb24obnVsbCk7XG4gICAgfVxuICB9O1xuXG4gIC8vIERvd25sb2FkIEhpZ2gtUmVzIDMwMCBEUEkgSlBHXG4gIGNvbnN0IGhhbmRsZURvd25sb2FkSlBHID0gKCkgPT4ge1xuICAgIGNvbnN0IGNhbnZhcyA9IGNhbnZhc1JlZi5jdXJyZW50O1xuICAgIGlmICghY2FudmFzKSByZXR1cm47XG4gICAgc2V0SXNQcm9jZXNzaW5nKHRydWUpO1xuXG4gICAgdHJ5IHtcbiAgICAgIC8vIFJlLXJlbmRlciB3aXRob3V0IG1hcnF1ZWUgZm9yIHByaXN0aW5lIGV4cG9ydFxuICAgICAgcmVuZGVyQ2FudmFzKHRydWUpO1xuICAgICAgY29uc3QgZGF0YVVybCA9IGNhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL2pwZWcnLCAwLjk4KTtcbiAgICAgIC8vIFJlc3RvcmUgaW50ZXJhY3RpdmUgVUkgY2FudmFzXG4gICAgICByZW5kZXJDYW52YXMoZmFsc2UpO1xuXG4gICAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgICAgYS5ocmVmID0gZGF0YVVybDtcbiAgICAgIGNvbnN0IGZpbGVOYW1lID0gYFBWQ19DYXJkXzUuNXg4LjVjbV80eDZfJHtEYXRlLm5vdygpfS5qcGdgO1xuICAgICAgYS5kb3dubG9hZCA9IGZpbGVOYW1lO1xuICAgICAgYS5jbGljaygpO1xuXG4gICAgICBhZGREb3dubG9hZFJlY29yZCh7XG4gICAgICAgIGlkOiBgcHZjLWpwZy0ke0RhdGUubm93KCl9YCxcbiAgICAgICAgdGl0bGU6IGZpbGVOYW1lLFxuICAgICAgICB0eXBlOiAnUFZDIENhcmQgSlBHJyxcbiAgICAgICAgc2l6ZTogJzEyMDDDlzE4MDAgcHggKDMwMCBEUEkpJyxcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZygnZW4tSU4nKVxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgIHJlbmRlckNhbnZhcyhmYWxzZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzUHJvY2Vzc2luZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIERvd25sb2FkIDMwMCBEUEkgUERGIChFeGFjdCA0eDYgaW5jaCBwYXBlciBzaXplKVxuICBjb25zdCBoYW5kbGVEb3dubG9hZFBERiA9ICgpID0+IHtcbiAgICBjb25zdCBjYW52YXMgPSBjYW52YXNSZWYuY3VycmVudDtcbiAgICBpZiAoIWNhbnZhcykgcmV0dXJuO1xuICAgIHNldElzUHJvY2Vzc2luZyh0cnVlKTtcblxuICAgIHRyeSB7XG4gICAgICAvLyBSZS1yZW5kZXIgd2l0aG91dCBtYXJxdWVlIGZvciBwcmlzdGluZSBleHBvcnRcbiAgICAgIHJlbmRlckNhbnZhcyh0cnVlKTtcbiAgICAgIGNvbnN0IGRhdGFVcmwgPSBjYW52YXMudG9EYXRhVVJMKCdpbWFnZS9qcGVnJywgMC45OCk7XG4gICAgICAvLyBSZXN0b3JlIGludGVyYWN0aXZlIFVJIGNhbnZhc1xuICAgICAgcmVuZGVyQ2FudmFzKGZhbHNlKTtcblxuICAgICAgY29uc3QgcGRmID0gbmV3IGpzUERGKHtcbiAgICAgICAgb3JpZW50YXRpb246ICdwb3J0cmFpdCcsXG4gICAgICAgIHVuaXQ6ICdpbicsXG4gICAgICAgIGZvcm1hdDogWzQsIDZdXG4gICAgICB9KTtcblxuICAgICAgcGRmLmFkZEltYWdlKGRhdGFVcmwsICdKUEVHJywgMCwgMCwgNCwgNik7XG4gICAgICBjb25zdCBmaWxlTmFtZSA9IGBQVkNfQ2FyZF81LjV4OC41Y21fNHg2XyR7RGF0ZS5ub3coKX0ucGRmYDtcbiAgICAgIHBkZi5zYXZlKGZpbGVOYW1lKTtcblxuICAgICAgYWRkRG93bmxvYWRSZWNvcmQoe1xuICAgICAgICBpZDogYHB2Yy1wZGYtJHtEYXRlLm5vdygpfWAsXG4gICAgICAgIHRpdGxlOiBmaWxlTmFtZSxcbiAgICAgICAgdHlwZTogJ1BWQyBDYXJkIFBERicsXG4gICAgICAgIHNpemU6ICc0w5c2IGluY2ggKDMwMCBEUEkpJyxcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZygnZW4tSU4nKVxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgIHJlbmRlckNhbnZhcyhmYWxzZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzUHJvY2Vzc2luZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIERpcmVjdCBCcm93c2VyIFByaW50IChGb3JtYXR0ZWQgZm9yIDR4NiBwaG90byBwYXBlcilcbiAgY29uc3QgaGFuZGxlRGlyZWN0UHJpbnQgPSAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gY2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjYW52YXMpIHJldHVybjtcbiAgICB0cnkge1xuICAgICAgLy8gUmUtcmVuZGVyIHdpdGhvdXQgbWFycXVlZSBmb3IgcHJpc3RpbmUgcHJpbnRcbiAgICAgIHJlbmRlckNhbnZhcyh0cnVlKTtcbiAgICAgIGNvbnN0IGRhdGFVcmwgPSBjYW52YXMudG9EYXRhVVJMKCdpbWFnZS9qcGVnJywgMS4wKTtcbiAgICAgIC8vIFJlc3RvcmUgaW50ZXJhY3RpdmUgVUkgY2FudmFzXG4gICAgICByZW5kZXJDYW52YXMoZmFsc2UpO1xuXG4gICAgICBwcmludEltYWdlU2hlZXQoZGF0YVVybCwge1xuICAgICAgICBwYXBlckZvcm1hdDogJzR4Nl9wb3J0cmFpdCcsXG4gICAgICAgIHRpdGxlOiAnUFZDX0NhcmRfNS41eDguNWNtX1ByaW50J1xuICAgICAgfSk7XG4gICAgICBzZXRQcmludEFsZXJ0KCfwn5ao77iPIFBWQyBDYXJkIHByaW50IGNvbW1hbmQgc2VudCB0byBwcmludGVyISAoNMOXNiBQaG90byBQYXBlciBQb3J0cmFpdCDigKIgRXhhY3QgNS41IGNtIMOXIDguNSBjbSknKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0UHJpbnRBbGVydChudWxsKSwgNDAwMCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgIHJlbmRlckNhbnZhcyhmYWxzZSk7XG4gICAgICB3aW5kb3cucHJpbnQoKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gSW50ZXJhY3RpdmUgTW91c2UgRG93biBvbiBDYW52YXMgKFN1cHBvcnRzIE1vdmUgQ2FyZCBhbmQgRHJhZy10by1TZWxlY3QtU2VjdGlvbilcbiAgY29uc3QgaGFuZGxlTW91c2VEb3duID0gKGU6IFJlYWN0Lk1vdXNlRXZlbnQ8SFRNTENhbnZhc0VsZW1lbnQ+KSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gY2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjYW52YXMpIHJldHVybjtcbiAgICBjb25zdCByZWN0ID0gY2FudmFzLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIGNvbnN0IHNjYWxlWCA9IENBTlZBU19XSURUSCAvIHJlY3Qud2lkdGg7XG4gICAgY29uc3Qgc2NhbGVZID0gQ0FOVkFTX0hFSUdIVCAvIHJlY3QuaGVpZ2h0O1xuXG4gICAgY29uc3QgbW91c2VYID0gKGUuY2xpZW50WCAtIHJlY3QubGVmdCkgKiBzY2FsZVg7XG4gICAgY29uc3QgbW91c2VZID0gKGUuY2xpZW50WSAtIHJlY3QudG9wKSAqIHNjYWxlWTtcblxuICAgIC8vIERldGVjdCBjbGlja2VkIGNhcmRcbiAgICBjb25zdCBjbGlja2VkQ2FyZCA9IG1vdXNlWSA8IENBTlZBU19IRUlHSFQgLyAyID8gJ2NhcmQxJyA6ICdjYXJkMic7XG4gICAgc2V0QWN0aXZlQ2FyZChjbGlja2VkQ2FyZCk7XG5cbiAgICBpZiAoaW50ZXJhY3Rpb25Nb2RlID09PSAnc2VjdGlvbl9zZWxlY3QnKSB7XG4gICAgICAvLyBTdGFydCBkcmFnIGJveCBzZWxlY3Rpb24gb24gY2xpY2tlZCBjYXJkXG4gICAgICBjb25zdCBjb29yZHMgPSBnZXRDYXJkTm9ybWFsaXplZENvb3Jkcyhtb3VzZVgsIG1vdXNlWSwgY2xpY2tlZENhcmQpO1xuICAgICAgaWYgKGNvb3Jkcy5pc0luc2lkZSkge1xuICAgICAgICBzZXRJc1NlbGVjdGluZ0JveCh0cnVlKTtcbiAgICAgICAgc2V0U2VsZWN0aW9uU3RhcnROb3JtKHsgeDogY29vcmRzLm5vcm1YLCB5OiBjb29yZHMubm9ybVkgfSk7XG4gICAgICAgIGNvbnN0IGluaXRpYWxCb3g6IFNlY3Rpb25Cb3ggPSB7IHg6IGNvb3Jkcy5ub3JtWCwgeTogY29vcmRzLm5vcm1ZLCB3OiAwLjAxLCBoOiAwLjAxIH07XG4gICAgICAgIGlmIChjbGlja2VkQ2FyZCA9PT0gJ2NhcmQxJykgc2V0Q2FyZDFTZWN0aW9uKGluaXRpYWxCb3gpO1xuICAgICAgICBlbHNlIHNldENhcmQyU2VjdGlvbihpbml0aWFsQm94KTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgLy8gTW92ZSBtb2RlXG4gICAgICBzZXREcmFnQ2FyZChjbGlja2VkQ2FyZCk7XG4gICAgICBzZXRJc0RyYWdnaW5nKHRydWUpO1xuICAgICAgY29uc3QgY2ZnID0gY2xpY2tlZENhcmQgPT09ICdjYXJkMScgPyBjYXJkMUNvbmZpZyA6IGNhcmQyQ29uZmlnO1xuICAgICAgc2V0RHJhZ1N0YXJ0KHsgeDogbW91c2VYIC0gY2ZnLngsIHk6IG1vdXNlWSAtIGNmZy55IH0pO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVNb3VzZU1vdmUgPSAoZTogUmVhY3QuTW91c2VFdmVudDxIVE1MQ2FudmFzRWxlbWVudD4pID0+IHtcbiAgICBjb25zdCBjYW52YXMgPSBjYW52YXNSZWYuY3VycmVudDtcbiAgICBpZiAoIWNhbnZhcykgcmV0dXJuO1xuICAgIGNvbnN0IHJlY3QgPSBjYW52YXMuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgY29uc3Qgc2NhbGVYID0gQ0FOVkFTX1dJRFRIIC8gcmVjdC53aWR0aDtcbiAgICBjb25zdCBzY2FsZVkgPSBDQU5WQVNfSEVJR0hUIC8gcmVjdC5oZWlnaHQ7XG5cbiAgICBjb25zdCBtb3VzZVggPSAoZS5jbGllbnRYIC0gcmVjdC5sZWZ0KSAqIHNjYWxlWDtcbiAgICBjb25zdCBtb3VzZVkgPSAoZS5jbGllbnRZIC0gcmVjdC50b3ApICogc2NhbGVZO1xuXG4gICAgLy8gSWYgZHJhd2luZyBhIHNlbGVjdGlvbiBtYXJxdWVlIGJveFxuICAgIGlmIChpc1NlbGVjdGluZ0JveCAmJiBzZWxlY3Rpb25TdGFydE5vcm0pIHtcbiAgICAgIGNvbnN0IGNvb3JkcyA9IGdldENhcmROb3JtYWxpemVkQ29vcmRzKG1vdXNlWCwgbW91c2VZLCBhY3RpdmVDYXJkKTtcbiAgICAgIGNvbnN0IGN1cnJlbnRYID0gTWF0aC5tYXgoMCwgTWF0aC5taW4oMSwgY29vcmRzLm5vcm1YKSk7XG4gICAgICBjb25zdCBjdXJyZW50WSA9IE1hdGgubWF4KDAsIE1hdGgubWluKDEsIGNvb3Jkcy5ub3JtWSkpO1xuXG4gICAgICBjb25zdCBib3hYID0gTWF0aC5taW4oc2VsZWN0aW9uU3RhcnROb3JtLngsIGN1cnJlbnRYKTtcbiAgICAgIGNvbnN0IGJveFkgPSBNYXRoLm1pbihzZWxlY3Rpb25TdGFydE5vcm0ueSwgY3VycmVudFkpO1xuICAgICAgY29uc3QgYm94VyA9IE1hdGgubWF4KDAuMDEsIE1hdGguYWJzKGN1cnJlbnRYIC0gc2VsZWN0aW9uU3RhcnROb3JtLngpKTtcbiAgICAgIGNvbnN0IGJveEggPSBNYXRoLm1heCgwLjAxLCBNYXRoLmFicyhjdXJyZW50WSAtIHNlbGVjdGlvblN0YXJ0Tm9ybS55KSk7XG5cbiAgICAgIGNvbnN0IHVwZGF0ZWRCb3g6IFNlY3Rpb25Cb3ggPSB7IHg6IGJveFgsIHk6IGJveFksIHc6IGJveFcsIGg6IGJveEggfTtcbiAgICAgIGlmIChhY3RpdmVDYXJkID09PSAnY2FyZDEnKSBzZXRDYXJkMVNlY3Rpb24odXBkYXRlZEJveCk7XG4gICAgICBlbHNlIHNldENhcmQyU2VjdGlvbih1cGRhdGVkQm94KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBJZiBkcmFnZ2luZyBjYXJkIHBvc2l0aW9uXG4gICAgaWYgKGlzRHJhZ2dpbmcgJiYgZHJhZ0NhcmQpIHtcbiAgICAgIGlmIChkcmFnQ2FyZCA9PT0gJ2NhcmQxJykge1xuICAgICAgICBzZXRDYXJkMUNvbmZpZyhwcmV2ID0+ICh7XG4gICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICB4OiBNYXRoLnJvdW5kKG1vdXNlWCAtIGRyYWdTdGFydC54KSxcbiAgICAgICAgICB5OiBNYXRoLnJvdW5kKG1vdXNlWSAtIGRyYWdTdGFydC55KVxuICAgICAgICB9KSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzZXRDYXJkMkNvbmZpZyhwcmV2ID0+ICh7XG4gICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICB4OiBNYXRoLnJvdW5kKG1vdXNlWCAtIGRyYWdTdGFydC54KSxcbiAgICAgICAgICB5OiBNYXRoLnJvdW5kKG1vdXNlWSAtIGRyYWdTdGFydC55KVxuICAgICAgICB9KSk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZU1vdXNlVXAgPSAoKSA9PiB7XG4gICAgc2V0SXNEcmFnZ2luZyhmYWxzZSk7XG4gICAgc2V0RHJhZ0NhcmQobnVsbCk7XG4gICAgc2V0SXNTZWxlY3RpbmdCb3goZmFsc2UpO1xuICAgIHNldFNlbGVjdGlvblN0YXJ0Tm9ybShudWxsKTtcbiAgfTtcblxuICBjb25zdCBhY3RpdmVDYXJkU2VjdGlvbiA9IGFjdGl2ZUNhcmQgPT09ICdjYXJkMScgPyBjYXJkMVNlY3Rpb24gOiBjYXJkMlNlY3Rpb247XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgey8qIEhlYWRlciBiYXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcC00IHJvdW5kZWQtMnhsIHNoYWRvdy1tZFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZmxleC13cmFwXCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxMYXllcnMgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LWJsdWUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+UFZDIFNtYXJ0IENhcmQgU3R1ZGlvICg1LjUgY20gw5cgOC41IGNtKTwvc3Bhbj5cbiAgICAgICAgICAgIDwvaDE+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1ibHVlLTUwMC8yMCB0ZXh0LWJsdWUtNDAwIGJvcmRlciBib3JkZXItYmx1ZS01MDAvMzAgdGV4dC14cyBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCBmb250LW1vbm8gZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgIDMwMCBEUEkgVWx0cmEgSERcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJnLWVtZXJhbGQtNTAwLzIwIHRleHQtZW1lcmFsZC00MDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCB0ZXh0LXhzIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICA0w5c2IGluY2ggUG9ydHJhaXQgTGF5b3V0XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1jeWFuLTUwMC8yMCB0ZXh0LWN5YW4tMzAwIGJvcmRlciBib3JkZXItY3lhbi01MDAvMzAgdGV4dC14cyBweC0yLjUgcHktMC41IHJvdW5kZWQtZnVsbCBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgPFNxdWFyZSBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+U2VjdGlvbiBDb2xvciBHcmFkaW5nIEFjdGl2ZTwvc3Bhbj5cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTFcIj5cbiAgICAgICAgICAgIFByaW50IDUuNSBjbSDDlyA4LjUgY20gQ1ItODAgY2FyZHMgb24gNMOXNiBpbmNoIHBvcnRyYWl0IHBob3RvIHBhcGVyIHdpdGggcGlucG9pbnQgbG9jYWwgY29sb3IgZ3JhZGluZyBmb3IgZGFyayBwaG90b3MgJiBmYWludCB0ZXh0LlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFByaW1hcnkgRXhwb3J0IEFjdGlvbnMgZm9yIFBDICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZsZXgtd3JhcFwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURpcmVjdFByaW50fVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctZ3JhZGllbnQtdG8tciBmcm9tLWJsdWUtNjAwIHZpYS1pbmRpZ28tNjAwIHRvLWJsdWUtNTAwIGhvdmVyOmZyb20tYmx1ZS01MDAgaG92ZXI6dG8taW5kaWdvLTUwMCB0ZXh0LXdoaXRlIGZvbnQtZXh0cmFib2xkIHRleHQteHMgcHgtNCBweS0yLjUgcm91bmRlZC14bCBzaGFkb3ctbGcgc2hhZG93LWJsdWUtNjAwLzMwIHRyYW5zaXRpb24tYWxsIGhvdmVyOnNjYWxlLTEwNSBhY3RpdmU6c2NhbGUtOTUgYm9yZGVyIGJvcmRlci1ibHVlLTQwMC8zMFwiXG4gICAgICAgICAgICB0aXRsZT1cIkRpcmVjdCBQcmludCB0byBFcHNvbiAvIENhbm9uIChDdHJsICsgUClcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxQcmludGVyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC13aGl0ZVwiIC8+XG4gICAgICAgICAgICA8c3Bhbj7wn5ao77iPIERpcmVjdCBQcmludCBQVkMgQ2FyZDwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURvd25sb2FkUERGfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzUHJvY2Vzc2luZ31cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYmctaW5kaWdvLTYwMCBob3ZlcjpiZy1pbmRpZ28tNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcHgtMy41IHB5LTIuNSByb3VuZGVkLXhsIHNoYWRvdy1sZyBzaGFkb3ctaW5kaWdvLTYwMC8zMCB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzY2FsZS0xMDUgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICB0aXRsZT1cIkRvd25sb2FkIFByaW50YWJsZSAzMDAgRFBJIFBERlwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgPHNwYW4+8J+ThCBQREYgKDTDlzYpPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRG93bmxvYWRKUEd9XG4gICAgICAgICAgICBkaXNhYmxlZD17aXNQcm9jZXNzaW5nfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMjAwIGhvdmVyOnRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcHgtMyBweS0yLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICB0aXRsZT1cIkRvd25sb2FkIEhpZ2gtUmVzIDEyMDB4MTgwMCBKUEdcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICA8c3Bhbj7wn5a877iPIEhEIEpQRzwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFByaW50IE5vdGlmaWNhdGlvbiBCYW5uZXIgKi99XG4gICAgICB7cHJpbnRBbGVydCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQteGwgYmctZW1lcmFsZC01MDAvMTAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCB0ZXh0LWVtZXJhbGQtNDAwIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYW5pbWF0ZS1pbiBmYWRlLWluXCI+XG4gICAgICAgICAgPENoZWNrIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTQwMCBmbGV4LXNocmluay0wXCIgLz5cbiAgICAgICAgICA8c3Bhbj57cHJpbnRBbGVydH08L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIE1haW4gRHVhbC1QYW5lIFBDIFdvcmtzcGFjZSAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMTIgZ2FwLTUgaXRlbXMtc3RhcnRcIj5cbiAgICAgICAgey8qIExlZnQgU2lkZTogQ29udHJvbHMgJiBVcGxvYWRzICg1IGNvbHVtbnMpICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTUgc3BhY2UteS00XCI+XG4gICAgICAgICAgey8qIENhcmQgU2xvdHMgKENhcmQgMSAmIENhcmQgMikgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvOTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC00IHNoYWRvdy1tZCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMzAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPkNhcmQgU2xvdHMgJiBJbWFnZXM8L3NwYW4+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVTd2FwQ2FyZHN9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtYmx1ZS00MDAgaG92ZXI6dGV4dC1ibHVlLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJTd2FwIEZyb250IGFuZCBCYWNrIENhcmRzXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxBcnJvd1VwRG93biBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+U3dhcCBGcm9udC9CYWNrPC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQ2FyZCAxIFNsb3QgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHAtMyByb3VuZGVkLXhsIGJvcmRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICBhY3RpdmVDYXJkID09PSAnY2FyZDEnIFxuICAgICAgICAgICAgICAgID8gJ2JnLWJsdWUtOTUwLzMwIGJvcmRlci1ibHVlLTUwMC81MCBzaGFkb3ctc20nIFxuICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTk1MC80MCBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1zbGF0ZS03MDAnXG4gICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTIgaC0yIHJvdW5kZWQtZnVsbCBiZy1ibHVlLTUwMFwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXhzIHRleHQtd2hpdGVcIj5DYXJkIDEgKEZyb250IFNpZGUpPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZUNhcmQoJ2NhcmQxJyl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LVsxMXB4XSBweC0yIHB5LTAuNSByb3VuZGVkIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWNvbG9ycyAke1xuICAgICAgICAgICAgICAgICAgICBhY3RpdmVDYXJkID09PSAnY2FyZDEnID8gJ2JnLWJsdWUtNjAwIHRleHQtd2hpdGUnIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBBY3RpdmVcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4LTEgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgcHktMiBweC0zIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03NTAgdGV4dC1zbGF0ZS0yMDAgdGV4dC14cyBmb250LXNlbWlib2xkIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXIgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgdHJhbnNpdGlvbi1jb2xvcnNcIj5cbiAgICAgICAgICAgICAgICAgIDxVcGxvYWQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1ibHVlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj57Y2FyZDFTcmMgPyAnQ2hhbmdlIEZyb250IFBob3RvL1BERicgOiAnVXBsb2FkIENhcmQgMSAoRnJvbnQpJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiBhY2NlcHQ9XCJpbWFnZS8qLC5wZGZcIiBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUZpbGVVcGxvYWQoZSwgJ2NhcmQxJyl9IGNsYXNzTmFtZT1cImhpZGRlblwiIC8+XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICB7Y2FyZDFTcmMgJiYgKFxuICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q2FyZDFTcmMobnVsbCl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiB0ZXh0LXJvc2UtNDAwIGhvdmVyOmJnLXJvc2UtNTAwLzEwIHJvdW5kZWQtbGcgdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUmVtb3ZlIENhcmQgMVwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIOKclVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIENhcmQgMiBTbG90ICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2BwLTMgcm91bmRlZC14bCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgYWN0aXZlQ2FyZCA9PT0gJ2NhcmQyJyBcbiAgICAgICAgICAgICAgICA/ICdiZy1wdXJwbGUtOTUwLzMwIGJvcmRlci1wdXJwbGUtNTAwLzUwIHNoYWRvdy1zbScgXG4gICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTUwLzQwIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCdcbiAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gbWItMlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLXB1cnBsZS01MDBcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC14cyB0ZXh0LXdoaXRlXCI+Q2FyZCAyIChCYWNrIFNpZGUpPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZUNhcmQoJ2NhcmQyJyl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B0ZXh0LVsxMXB4XSBweC0yIHB5LTAuNSByb3VuZGVkIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWNvbG9ycyAke1xuICAgICAgICAgICAgICAgICAgICBhY3RpdmVDYXJkID09PSAnY2FyZDInID8gJ2JnLXB1cnBsZS02MDAgdGV4dC13aGl0ZScgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIEFjdGl2ZVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXgtMSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBweS0yIHB4LTMgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTc1MCB0ZXh0LXNsYXRlLTIwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgcm91bmRlZC1sZyBjdXJzb3ItcG9pbnRlciBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgPFVwbG9hZCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXB1cnBsZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+e2NhcmQyU3JjID8gJ0NoYW5nZSBCYWNrIFBob3RvL1BERicgOiAnVXBsb2FkIENhcmQgMiAoQmFjayknfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cImltYWdlLyosLnBkZlwiIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlRmlsZVVwbG9hZChlLCAnY2FyZDInKX0gY2xhc3NOYW1lPVwiaGlkZGVuXCIgLz5cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIHtjYXJkMlNyYyAmJiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uIFxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDYXJkMlNyYyhudWxsKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0yIHRleHQtcm9zZS00MDAgaG92ZXI6Ymctcm9zZS01MDAvMTAgcm91bmRlZC1sZyB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJSZW1vdmUgQ2FyZCAyXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAg4pyVXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFNFQ1RJT04gU0VMRUNUSU9OIFRPT0wgJiBMT0NBTCBDT0xPUiBHUkFESU5HIFBBTkVMICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItY3lhbi01MDAvMzAgcm91bmRlZC0yeGwgcC00IHNoYWRvdy14bCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPFNxdWFyZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtY3lhbi00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgICAgICAgIFNlY3Rpb24gU2VsZWN0aW9uICYgQ29sb3IgR3JhZGluZ1xuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGJnLWN5YW4tNTAwLzIwIHRleHQtY3lhbi0zMDAgZm9udC1ib2xkIHB4LTIgcHktMC41IHJvdW5kZWQgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAge2FjdGl2ZUNhcmQgPT09ICdjYXJkMScgPyAnQ2FyZCAxIEZyb250JyA6ICdDYXJkIDIgQmFjayd9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTMwMCBsZWFkaW5nLXNudWdcIj5cbiAgICAgICAgICAgICAgQ2FyZCBrZSBraXNpIGJoaSBoaXNzZSAoZS5nLiBBYWRoYWFyIFBob3RvLCBBZGRyZXNzIFRleHQsIFFSIENvZGUpIGtvIHNlbGVjdCBrYXJrZSA8Yj5zaXJmIHVzaSBqYWdhaCBraSBCcmlnaHRuZXNzIGF1ciBDb250cmFzdDwvYj4gYWRqdXN0IGthcmVpbi5cbiAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgey8qIE1vZGUgU3dpdGNoZXIgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTIgdGV4dC14c1wiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SW50ZXJhY3Rpb25Nb2RlKCdtb3ZlJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHktMiBweC0zIHJvdW5kZWQteGwgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgYm9yZGVyIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICBpbnRlcmFjdGlvbk1vZGUgPT09ICdtb3ZlJ1xuICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1ibHVlLTQwMCBzaGFkb3ctbWQnXG4gICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTk1MCB0ZXh0LXNsYXRlLTQwMCBib3JkZXItc2xhdGUtODAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8TW92ZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+TW92ZSBDYXJkIFBvc2l0aW9uPC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SW50ZXJhY3Rpb25Nb2RlKCdzZWN0aW9uX3NlbGVjdCcpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB5LTIgcHgtMyByb3VuZGVkLXhsIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IGJvcmRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgaW50ZXJhY3Rpb25Nb2RlID09PSAnc2VjdGlvbl9zZWxlY3QnXG4gICAgICAgICAgICAgICAgICAgID8gJ2JnLWdyYWRpZW50LXRvLXIgZnJvbS1jeWFuLTYwMCB0by1ibHVlLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1jeWFuLTQwMCBzaGFkb3ctbWQgc2hhZG93LWN5YW4tNjAwLzMwJ1xuICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05NTAgdGV4dC1zbGF0ZS00MDAgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFNxdWFyZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWN5YW4tMzAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5TZWxlY3QgU2VjdGlvbiBUb29sPC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogUXVpY2sgUHJlc2V0IFNlbGVjdGlvbiBCb3hlcyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xLjUgcHQtMVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGJsb2NrXCI+XG4gICAgICAgICAgICAgICAgMS1DbGljayBRdWljayBTZWxlY3QgUHJlc2V0OlxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBzbTpncmlkLWNvbHMtNCBnYXAtMS41IHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVBcHBseVByZXNldFNlY3Rpb24oJ3Bob3RvJyl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSByb3VuZGVkLWxnIGJnLXNsYXRlLTk1MCBob3ZlcjpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgZm9udC1ib2xkIHRleHQtY2VudGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICDwn5GkIFBob3RvIEJveFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQXBwbHlQcmVzZXRTZWN0aW9uKCdkZXRhaWxzJyl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSByb3VuZGVkLWxnIGJnLXNsYXRlLTk1MCBob3ZlcjpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgZm9udC1ib2xkIHRleHQtY2VudGVyXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICDwn5OdIERldGFpbHMgVGV4dFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQXBwbHlQcmVzZXRTZWN0aW9uKCdxcicpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC1sZyBiZy1zbGF0ZS05NTAgaG92ZXI6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIGZvbnQtYm9sZCB0ZXh0LWNlbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAg8J+TsSBRUiBDb2RlXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVBcHBseVByZXNldFNlY3Rpb24oJ3NpZ25hdHVyZScpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC1sZyBiZy1zbGF0ZS05NTAgaG92ZXI6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIGZvbnQtYm9sZCB0ZXh0LWNlbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAg4pyN77iPIFNpZ25hdHVyZVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogTG9jYWwgR3JhZGluZyBTbGlkZXJzIChTaG93biB3aGVuIHNlY3Rpb24gaXMgc2VsZWN0ZWQpICovfVxuICAgICAgICAgICAge2FjdGl2ZUNhcmRTZWN0aW9uID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMyBwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAvODAgYW5pbWF0ZS1pbiBmYWRlLWluXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1jeWFuLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICA8U2xpZGVycyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkdyYWRpbmcgU2VsZWN0ZWQgUmVnaW9uIE9ubHk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNsZWFyU2VjdGlvbn1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1yb3NlLTQwMCBob3Zlcjp1bmRlcmxpbmUgZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgQ2xlYXIgQm94XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBTZWN0aW9uIEJyaWdodG5lc3MgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNsYXRlLTMwMCBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1hbWJlci0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8U3VuIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gU2VjdGlvbiBCcmlnaHRuZXNzXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtd2hpdGVcIj57c2VjdGlvbkJyaWdodG5lc3MgPiAwID8gYCske3NlY3Rpb25CcmlnaHRuZXNzfWAgOiBzZWN0aW9uQnJpZ2h0bmVzc30lPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgICAgbWluPVwiLTUwXCJcbiAgICAgICAgICAgICAgICAgICAgbWF4PVwiNTBcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VjdGlvbkJyaWdodG5lc3N9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VjdGlvbkJyaWdodG5lc3MoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBhY2NlbnQtYW1iZXItNTAwIGgtMS41IGJnLXNsYXRlLTgwMCByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5EYXJrZW4gLTUwJTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+MDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+QnJpZ2h0ZW4gKzUwJTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIFNlY3Rpb24gQ29udHJhc3QgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNsYXRlLTMwMCBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1za3ktMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPENvbnRyYXN0IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gU2VjdGlvbiBDb250cmFzdCAmIFNoYXJwbmVzc1xuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXdoaXRlXCI+e3NlY3Rpb25Db250cmFzdCA+IDAgPyBgKyR7c2VjdGlvbkNvbnRyYXN0fWAgOiBzZWN0aW9uQ29udHJhc3R9JTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYW5nZVwiXG4gICAgICAgICAgICAgICAgICAgIG1pbj1cIi01MFwiXG4gICAgICAgICAgICAgICAgICAgIG1heD1cIjUwXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlY3Rpb25Db250cmFzdH1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWN0aW9uQ29udHJhc3QoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBhY2NlbnQtc2t5LTUwMCBoLTEuNSBiZy1zbGF0ZS04MDAgcm91bmRlZC1sZyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+U29mdDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+MDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+RGVlcCBDb250cmFzdCArNTAlPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogU2VjdGlvbiBTYXR1cmF0aW9uICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS0zMDAgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtcGluay0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8RHJvcGxldHMgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiBTZWN0aW9uIFNhdHVyYXRpb25cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC13aGl0ZVwiPntzZWN0aW9uU2F0dXJhdGlvbiA+IDAgPyBgKyR7c2VjdGlvblNhdHVyYXRpb259YCA6IHNlY3Rpb25TYXR1cmF0aW9ufSU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICAgICAgICBtaW49XCItNTBcIlxuICAgICAgICAgICAgICAgICAgICBtYXg9XCI1MFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWN0aW9uU2F0dXJhdGlvbn1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWN0aW9uU2F0dXJhdGlvbihOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGFjY2VudC1waW5rLTUwMCBoLTEuNSBiZy1zbGF0ZS04MDAgcm91bmRlZC1sZyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIFNlY3Rpb24gV2FybXRoIC8gVG9uZSAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtMzAwIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LW9yYW5nZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8RmxhbWUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiBTZWN0aW9uIFdhcm10aCAvIFRvbmVcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC13aGl0ZVwiPntzZWN0aW9uV2FybXRoID4gMCA/IGArJHtzZWN0aW9uV2FybXRofWAgOiBzZWN0aW9uV2FybXRofTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYW5nZVwiXG4gICAgICAgICAgICAgICAgICAgIG1pbj1cIi01MFwiXG4gICAgICAgICAgICAgICAgICAgIG1heD1cIjUwXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlY3Rpb25XYXJtdGh9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VjdGlvbldhcm10aChOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGFjY2VudC1vcmFuZ2UtNTAwIGgtMS41IGJnLXNsYXRlLTgwMCByb3VuZGVkLWxnIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Db29sIEJsdWU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPk5ldXRyYWw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPldhcm0gR2xvdzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIEJha2UgQWRqdXN0bWVudCBCdXR0b24gKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVCYWtlU2VjdGlvbkdyYWRpbmd9XG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc1Byb2Nlc3Npbmd9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweS0yIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1lbWVyYWxkLTYwMCB0by10ZWFsLTYwMCBob3Zlcjpmcm9tLWVtZXJhbGQtNTAwIGhvdmVyOnRvLXRlYWwtNTAwIHRleHQtd2hpdGUgZm9udC1leHRyYWJvbGQgdGV4dC14cyByb3VuZGVkLXhsIHNoYWRvdy1tZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+QXBwbHkgLyBCYWtlIHRvIENhcmQgSW1hZ2U8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2xlYXJTZWN0aW9ufVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTIgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTc1MCB0ZXh0LXNsYXRlLTMwMCB0ZXh0LXhzIGZvbnQtYm9sZCByb3VuZGVkLXhsXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgQ2FuY2VsXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyByb3VuZGVkLXhsIGJnLXNsYXRlLTk1MC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC84MCB0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMCBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDAgYmxvY2tcIj7wn5KhIEhvdyB0byBTZWxlY3Q6PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuPkNsaWNrIDxiPlwiU2VsZWN0IFNlY3Rpb24gVG9vbFwiPC9iPiBhYm92ZSwgdGhlbiBkcmFnIGEgcmVjdGFuZ2xlIG92ZXIgdGhlIGRhcmsgcGhvdG8gb3IgdGV4dCBhcmVhIGRpcmVjdGx5IG9uIHRoZSBjYXJkIHByZXZpZXchPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogV2hvbGUgQ2FyZCBHbG9iYWwgRW5oYW5jZW1lbnRzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzkwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNCBzaGFkb3ctbWQgc3BhY2UteS0zXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgYmxvY2tcIj5cbiAgICAgICAgICAgICAgV2hvbGUgQ2FyZCBFeHBvc3VyZSAmIEN1dHRpbmcgR3VpZGVzXG4gICAgICAgICAgICA8L3NwYW4+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtNDAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj48U3VuIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYW1iZXItNDAwXCIgLz4gV2hvbGUgQ2FyZCBCcmlnaHRuZXNzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtc2xhdGUtMjAwXCI+e2JyaWdodG5lc3MgPiAwID8gYCske2JyaWdodG5lc3N9YCA6IGJyaWdodG5lc3N9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgIG1pbj1cIi0zMFwiXG4gICAgICAgICAgICAgICAgICBtYXg9XCIzMFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17YnJpZ2h0bmVzc31cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QnJpZ2h0bmVzcyhwYXJzZUludChlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGFjY2VudC1hbWJlci01MDAgaC0xLjUgYmctc2xhdGUtODAwIHJvdW5kZWQtbGcgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNsYXRlLTQwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+PENvbnRyYXN0IGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtc2t5LTQwMFwiIC8+IFdob2xlIENhcmQgQ29udHJhc3Q8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1zbGF0ZS0yMDBcIj57Y29udHJhc3QgPiAwID8gYCske2NvbnRyYXN0fWAgOiBjb250cmFzdH08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICAgICAgbWluPVwiLTMwXCJcbiAgICAgICAgICAgICAgICAgIG1heD1cIjMwXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtjb250cmFzdH1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q29udHJhc3QocGFyc2VJbnQoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBhY2NlbnQtc2t5LTUwMCBoLTEuNSBiZy1zbGF0ZS04MDAgcm91bmRlZC1sZyBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAgZ3JpZCBncmlkLWNvbHMtMiBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBjdXJzb3ItcG9pbnRlciB0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3Nob3dDdXRNYXJrc31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTaG93Q3V0TWFya3MoZS50YXJnZXQuY2hlY2tlZCl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQgYWNjZW50LWJsdWUtNjAwXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj7inIIgQ2VudGVyIEN1dCBMaW5lPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXIgdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtyb3VuZGVkQ29ybmVyc31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRSb3VuZGVkQ29ybmVycyhlLnRhcmdldC5jaGVja2VkKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZCBhY2NlbnQtYmx1ZS02MDBcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPlJvdW5kZWQgQ1I4MCBDb3JuZXI8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cblxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBjdXJzb3ItcG9pbnRlciB0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e2JvcmRlclN0cm9rZX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRCb3JkZXJTdHJva2UoZS50YXJnZXQuY2hlY2tlZCl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQgYWNjZW50LWJsdWUtNjAwXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5DYXJkIE91dGxpbmUgQm9yZGVyPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBSaWdodCBTaWRlOiBMaXZlIEludGVyYWN0aXZlIDMwMCBEUEkgQ2FudmFzIFByZXZpZXcgKDcgY29sdW1ucykgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNyBzcGFjZS15LTNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTQgc2hhZG93LXhsXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtYi0zIHRleHQteHMgZmxleC13cmFwIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIHRleHQtc21cIj40w5c2IGluY2ggUG9ydHJhaXQgU2hlZXQgUHJldmlldzwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTUwMC8yMCB0ZXh0LWVtZXJhbGQtNDAwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgdGV4dC1bMTBweF0gcHgtMiBweS0wLjUgcm91bmRlZCBmb250LW1vbm8gZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICBFeGFjdCA1LjUgY20gw5cgOC41IGNtXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPjEyMDDDlzE4MDAgcHggQCAzMDAgRFBJPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogTW9kZSBpbmRpY2F0b3IgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SW50ZXJhY3Rpb25Nb2RlKGludGVyYWN0aW9uTW9kZSA9PT0gJ21vdmUnID8gJ3NlY3Rpb25fc2VsZWN0JyA6ICdtb3ZlJyl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0yLjUgcHktMSByb3VuZGVkLWxnIHRleHQteHMgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGJvcmRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICBpbnRlcmFjdGlvbk1vZGUgPT09ICdzZWN0aW9uX3NlbGVjdCdcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1jeWFuLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1jeWFuLTQwMCBzaGFkb3cnXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIGJvcmRlci1zbGF0ZS03MDAnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7aW50ZXJhY3Rpb25Nb2RlID09PSAnc2VjdGlvbl9zZWxlY3QnID8gPFNxdWFyZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWN5YW4tMjAwXCIgLz4gOiA8TW92ZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+fVxuICAgICAgICAgICAgICAgICAgPHNwYW4+e2ludGVyYWN0aW9uTW9kZSA9PT0gJ3NlY3Rpb25fc2VsZWN0JyA/ICdUb29sOiBEcmFnIFNlbGVjdGlvbiBCb3gnIDogJ1Rvb2w6IERyYWcgdG8gTW92ZSd9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQ2FudmFzIENvbnRhaW5lciAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgYmctc2xhdGUtOTUwIHAtMiBzbTpwLTQgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBvdmVyZmxvdy1oaWRkZW4gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgc2hhZG93LWlubmVyXCI+XG4gICAgICAgICAgICAgIDxjYW52YXNcbiAgICAgICAgICAgICAgICByZWY9e2NhbnZhc1JlZn1cbiAgICAgICAgICAgICAgICB3aWR0aD17Q0FOVkFTX1dJRFRIfVxuICAgICAgICAgICAgICAgIGhlaWdodD17Q0FOVkFTX0hFSUdIVH1cbiAgICAgICAgICAgICAgICBvbk1vdXNlRG93bj17aGFuZGxlTW91c2VEb3dufVxuICAgICAgICAgICAgICAgIG9uTW91c2VNb3ZlPXtoYW5kbGVNb3VzZU1vdmV9XG4gICAgICAgICAgICAgICAgb25Nb3VzZVVwPXtoYW5kbGVNb3VzZVVwfVxuICAgICAgICAgICAgICAgIG9uTW91c2VMZWF2ZT17aGFuZGxlTW91c2VVcH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BtYXgtdy1mdWxsIGgtYXV0byBiZy13aGl0ZSByb3VuZGVkLWxnIHNoYWRvdy0yeGwgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgIGludGVyYWN0aW9uTW9kZSA9PT0gJ3NlY3Rpb25fc2VsZWN0JyA/ICdjdXJzb3ItY3Jvc3NoYWlyJyA6ICdjdXJzb3ItbW92ZSdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICBzdHlsZT17eyBtYXhIZWlnaHQ6ICc3MjBweCcgfX1cbiAgICAgICAgICAgICAgLz5cblxuICAgICAgICAgICAgICB7LyogSGVscGVyIGJhZGdlICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS02IGxlZnQtNiByaWdodC02IGJnLXNsYXRlLTk1MC84NSBiYWNrZHJvcC1ibHVyLW1kIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHAtMiByb3VuZGVkLXhsIHRleHQtWzExcHhdIHRleHQtc2xhdGUtMzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMiBzaGFkb3ctbGcgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLWN5YW4tNDAwXCI+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+e2ludGVyYWN0aW9uTW9kZSA9PT0gJ3NlY3Rpb25fc2VsZWN0JyA/ICdEcmFnIG92ZXIgZGFyayBwaG90byBvciB0ZXh0IHRvIGNvbG9yIGdyYWRlIG9ubHkgdGhhdCBzZWN0aW9uJyA6ICdEcmFnIENhcmQgMSBvciBDYXJkIDIgdG8gYWxpZ24nfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1jeWFuLTMwMCBmb250LWJvbGRcIj5DUi04MDogNS41IGNtIMOXIDguNSBjbTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=