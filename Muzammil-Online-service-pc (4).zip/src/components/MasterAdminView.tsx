const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { ShieldCheck, Lock, Unlock, Smartphone, Laptop, RotateCcw, UserPlus, Trash2, Download, CheckCircle2, AlertCircle, Clock, Key, FileCode, Check, Archive, RefreshCw, Cpu, Monitor, ClipboardList, Sparkles, Circle, Activity, Radio, Power, MessageSquare, Send, Calendar, Copy, Terminal, ExternalLink } from "/node_modules/.vite/deps/lucide-react.js?v=090625a0";
import { getRegisteredOperators, resetOperatorPcBinding, resetOperatorMobileBinding, resetOperatorAllBindings, toggleOperatorLock, addNewOperator, deleteOperator, getSecurityAuditLogs, getHardwareDeviceId, getHardwareDeviceName, isMobileDevice, renewOperatorLicense, calculateRemainingDays, getLiveOperatorSessions, forceDisconnectOperator, sendOperatorBroadcastMessage } from "/src/utils/deviceSecurity.ts";
import { generateProjectZip, triggerDownloadZip } from "/src/utils/projectZip.ts";
var _jsxFileName = "/app/applet/src/components/MasterAdminView.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
const MASTER_WORKFLOW_STEPS = [
	{
		stepNumber: 1,
		title: "Customer Intake & Service Identification",
		description: "Welcome citizen, verify Aadhaar linked mobile, check document prerequisites, and quote transparent rates.",
		toolsUsed: [
			"Dashboard",
			"50+ Govt Portals Hub",
			"AI Assistant"
		],
		checklist: [
			"Check customer Aadhaar & active mobile OTP availability",
			"Inform customer of official portal charges + service fee",
			"Record customer name & WhatsApp number in CRM",
			"Issue physical or digital queue token"
		],
		tips: "Aadhaar mein active mobile number hona PM-KISAN, Ladki Bahin, aur Mahadbt schemes ke liye anivarya hai."
	},
	{
		stepNumber: 2,
		title: "Official Portal Filing & Document Submission",
		description: "Log into central/state portal (Aaple Sarkar, Sarathi, Mahadbt), complete form entry, and submit.",
		toolsUsed: ["50+ Govt Portals Directory", "PDF to HD JPG Converter"],
		checklist: [
			"Enter applicant details matching Aadhaar letter by letter",
			"If portal requires JPG under 100KB, use PDF to JPG tool to compress documents",
			"Verify uploaded certificate previews before final submission",
			"Download and save official acknowledgement PDF"
		],
		tips: "Acknowledgement Receipt Token Number hamesha download karke Customer CRM mein note karein."
	},
	{
		stepNumber: 3,
		title: "Studio Photo & PVC Smart Card Processing",
		description: "Produce high-precision CR-80 PVC cards or 35x45mm passport photo sheets.",
		toolsUsed: ["PVC Smart Card Maker", "Passport Photo Studio Pro"],
		checklist: [
			"Passport Photo: Select 4×6 Landscape (8 Copies @ 300 DPI) or A4 Landscape",
			"Background: Use Connected Magic Wand or Pen Tool to cut out person and set White/Studio Blue BG",
			"Auto Beauty: Apply AI Face Smoothing to brighten skin tones and reduce camera shadows",
			"Exam Strip: Add Candidate Name & Date stamp for SSC GD, Police Bharti, or Railway forms",
			"PVC Card: Align Front & Back cards to standard CR-80 (85.6×54mm) with center cut guide line"
		],
		tips: "PVC Card print karte waqt printer properties mein \"High Quality Glossy Photo Paper\" select karein."
	},
	{
		stepNumber: 4,
		title: "300 DPI Physical Printing & Thermal Lamination",
		description: "Execute in-app borderless printing on photo paper, cut cards, and laminate.",
		toolsUsed: ["In-App Direct Print Engine (Ctrl + P)"],
		checklist: [
			"Load 4×6 inch (10×15 cm) Glossy Photo Paper into printer",
			"Press \"🖨️ Direct Print Sheet (Ctrl + P)\" directly inside studio",
			"Cut along pre-aligned guide marks",
			"For PVC Smart Cards: Pass through thermal laminator for durable waterproof finish"
		],
		tips: "In-app direct print zero popup blocker ke saath seedha connected printer par 300 DPI job bhejta hai."
	},
	{
		stepNumber: 5,
		title: "POS Billing & Thermal Receipt Generation",
		description: "Generate itemized tax invoice or 58mm/80mm thermal slip with dynamic UPI QR code.",
		toolsUsed: ["Fast Billing Desk POS"],
		checklist: [
			"Select service package (e.g. PVC Card ₹70, Passport Photo 8-copies ₹50, Online Form ₹100)",
			"Display dynamic UPI QR code on screen for instant customer payment",
			"Print 58mm thermal receipt or A4 official tax invoice for customer records",
			"Update payment status as \"Paid\" in ledger"
		],
		tips: "Thermal receipt par shop ka authorized signature aur non-refundable portal terms automatic aate hain."
	},
	{
		stepNumber: 6,
		title: "Customer Handover & Daily Cash Reconciliation",
		description: "Hand over laminated cards, passport photos in sleeve, and portal acknowledgement.",
		toolsUsed: ["Customer CRM & Job Tracker"],
		checklist: [
			"Hand over laminated cards, passport photos in sleeve, and portal acknowledgement",
			"Send WhatsApp confirmation with status update",
			"Mark job as \"Delivered\" in CRM Tracker",
			"Daily reconciliation: Check total cash + UPI collections in Billing Desk Summary"
		],
		tips: "Din ke end par Daily Ledger Summary se cash counter balance match karein."
	}
];
export const MasterAdminView = ({ settings, onUpdateSettings, onNavigateToWorkflow }) => {
	const [operators, setOperators] = useState([]);
	const [auditLogs, setAuditLogs] = useState([]);
	const [activeSubTab, setActiveSubTab] = useState("live_monitor");
	// Live Monitoring State
	const [liveSessions, setLiveSessions] = useState([]);
	const [isAutoRefreshing, setIsAutoRefreshing] = useState(true);
	const [lastRefreshedAt, setLastRefreshedAt] = useState("");
	// Renewal Modal State
	const [selectedOpForRenew, setSelectedOpForRenew] = useState(null);
	const [renewDaysCount, setRenewDaysCount] = useState(30);
	// Broadcast Alert Modal
	const [broadcastTargetUsername, setBroadcastTargetUsername] = useState(null);
	const [broadcastMessageText, setBroadcastMessageText] = useState("");
	// New Operator Modal State
	const [showAddModal, setShowAddModal] = useState(false);
	const [newUsername, setNewUsername] = useState("");
	const [newPassword, setNewPassword] = useState("");
	const [newDisplayName, setNewDisplayName] = useState("");
	const [newPhone, setNewPhone] = useState("");
	const [addError, setAddError] = useState("");
	// Project ZIP Export State
	const [isExportingZip, setIsExportingZip] = useState(false);
	const [zipProgress, setZipProgress] = useState({
		percent: 0,
		file: ""
	});
	// 3 Files Hub - Copy feedback & Modal viewers
	const [copiedWorkflow, setCopiedWorkflow] = useState(false);
	const [copiedPcBatch, setCopiedPcBatch] = useState(false);
	const [copiedExeBatch, setCopiedExeBatch] = useState(false);
	const [expandedFileCard, setExpandedFileCard] = useState(null);
	// Notifications
	const [alertMessage, setAlertMessage] = useState(null);
	// Shop Settings Form
	const [shopForm, setShopForm] = useState(settings);
	// Workflow Checklist state inside Master Admin
	const [completedSteps, setCompletedSteps] = useState({});
	const currentDeviceId = getHardwareDeviceId();
	const currentDeviceName = getHardwareDeviceName();
	const currentIsMobile = isMobileDevice();
	const loadData = () => {
		setOperators(getRegisteredOperators());
		setAuditLogs(getSecurityAuditLogs());
	};
	const refreshLiveSessions = async () => {
		try {
			const sessions = await getLiveOperatorSessions();
			setLiveSessions(sessions);
			setLastRefreshedAt(new Date().toLocaleTimeString());
		} catch (e) {
			console.error(e);
		}
	};
	useEffect(() => {
		loadData();
		refreshLiveSessions();
	}, []);
	// Real-Time 3.5s Live Polling Heartbeat
	useEffect(() => {
		if (!isAutoRefreshing) return;
		const interval = setInterval(() => {
			refreshLiveSessions();
		}, 3500);
		return () => clearInterval(interval);
	}, [isAutoRefreshing]);
	// Handle License / Access Renewal
	const handleExecuteRenewal = () => {
		if (!selectedOpForRenew) return;
		const result = renewOperatorLicense(selectedOpForRenew.id, renewDaysCount);
		if (result.success) {
			loadData();
			refreshLiveSessions();
			setAlertMessage(`✅ Access Renewed for "${selectedOpForRenew.displayName}"! Valid until ${result.newExpiry} (${result.daysLeft} days remaining)`);
			setSelectedOpForRenew(null);
			setTimeout(() => setAlertMessage(null), 5e3);
		}
	};
	// Handle Force Disconnect Live Session
	const handleForceDisconnect = async (username, deviceId) => {
		if (window.confirm(`Force terminate active session for @${username}? Operator will be immediately logged out.`)) {
			await forceDisconnectOperator(username, deviceId);
			refreshLiveSessions();
			setAlertMessage(`🚨 Session for @${username} has been forcefully terminated.`);
			setTimeout(() => setAlertMessage(null), 4e3);
		}
	};
	// Handle Send In-App Broadcast Alert
	const handleSendBroadcast = async () => {
		if (!broadcastTargetUsername || !broadcastMessageText.trim()) return;
		await sendOperatorBroadcastMessage(broadcastTargetUsername, broadcastMessageText.trim());
		setAlertMessage(`📢 Alert message sent to @${broadcastTargetUsername}!`);
		setBroadcastTargetUsername(null);
		setBroadcastMessageText("");
		setTimeout(() => setAlertMessage(null), 4e3);
	};
	// Handle Reset PC Binding
	const handleResetPc = (operatorId, username) => {
		if (window.confirm(`Reset PC Device Binding for "${username}"? Operator can now log in on a new PC/Laptop.`)) {
			resetOperatorPcBinding(operatorId);
			loadData();
			refreshLiveSessions();
			setAlertMessage(`✅ PC device binding cleared for ${username}. Operator can bind a new PC.`);
			setTimeout(() => setAlertMessage(null), 4e3);
		}
	};
	// Handle Reset Mobile Binding
	const handleResetMobile = (operatorId, username) => {
		if (window.confirm(`Reset Mobile Device Binding for "${username}"? Operator can now log in on a new Smartphone.`)) {
			resetOperatorMobileBinding(operatorId);
			loadData();
			refreshLiveSessions();
			setAlertMessage(`✅ Mobile device binding cleared for ${username}. Operator can bind a new phone.`);
			setTimeout(() => setAlertMessage(null), 4e3);
		}
	};
	// Handle Reset All Devices (PC + Mobile)
	const handleResetAllDevices = (operatorId, username) => {
		if (window.confirm(`Reset BOTH PC & Mobile bindings for "${username}"?`)) {
			resetOperatorAllBindings(operatorId);
			loadData();
			refreshLiveSessions();
			setAlertMessage(`✅ All device bindings (PC & Mobile) cleared for ${username}.`);
			setTimeout(() => setAlertMessage(null), 4e3);
		}
	};
	// Handle Toggle Lock
	const handleToggleLock = (operatorId, username) => {
		toggleOperatorLock(operatorId);
		loadData();
		refreshLiveSessions();
		setAlertMessage(`Lock status updated for ${username}`);
		setTimeout(() => setAlertMessage(null), 3e3);
	};
	// Handle Delete Operator
	const handleDeleteOperator = (operatorId, username) => {
		if (window.confirm(`Permanently delete operator account "${username}"?`)) {
			deleteOperator(operatorId);
			loadData();
			refreshLiveSessions();
			setAlertMessage(`Operator ${username} deleted`);
			setTimeout(() => setAlertMessage(null), 3e3);
		}
	};
	// Handle Add Operator
	const handleCreateOperator = (e) => {
		e.preventDefault();
		setAddError("");
		if (!newUsername.trim() || !newPassword.trim() || !newDisplayName.trim()) {
			setAddError("Please fill all required fields");
			return;
		}
		const success = addNewOperator({
			username: newUsername.trim().toLowerCase(),
			password: newPassword.trim(),
			displayName: newDisplayName.trim(),
			role: "operator",
			phone: newPhone.trim() || "9561460313"
		});
		if (success) {
			setShowAddModal(false);
			setNewUsername("");
			setNewPassword("");
			setNewDisplayName("");
			setNewPhone("");
			loadData();
			refreshLiveSessions();
			setAlertMessage("✅ New Operator ID created! Permitted on 1 Authorized PC + 1 Authorized Mobile.");
			setTimeout(() => setAlertMessage(null), 4e3);
		} else {
			setAddError("Username already exists. Please choose another username.");
		}
	};
	// Handle Download Project ZIP
	const handleDownloadZip = async () => {
		setIsExportingZip(true);
		setZipProgress({
			percent: 10,
			file: "Gathering project source files..."
		});
		try {
			const zipBlob = await generateProjectZip((percent, file) => {
				setZipProgress({
					percent,
					file
				});
			});
			triggerDownloadZip(zipBlob, `Muzammil-Online-service-pc.zip`);
			setAlertMessage("📦 Complete original project source code (.ZIP) downloaded successfully!");
			setTimeout(() => setAlertMessage(null), 4e3);
		} catch (e) {
			console.error(e);
			window.location.href = "/api/download-zip";
		} finally {
			setIsExportingZip(false);
		}
	};
	const WORKFLOW_YAML_CODE = `name: Build Windows Desktop EXE Setup

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:
  release:
    types: [ published ]

jobs:
  build-windows:
    runs-on: windows-latest

    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Setup Node.js 20
        uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'npm'

      - name: Install Dependencies
        run: |
          npm install
          npm install --save-dev electron electron-packager

      - name: Build Web Application Assets
        run: npm run build

      - name: Package Windows .EXE Application
        run: |
          npx electron-packager . "Muzammil Online service pc" --platform=win32 --arch=x64 --out=dist-exe --overwrite --icon=public/favicon.ico

      - name: Compress Executable Folder to ZIP
        run: |
          Compress-Archive -Path "dist-exe\\Muzammil Online service pc-win32-x64\\*" -DestinationPath "Muzammil-Online-Service-Windows-x64.zip"

      - name: Upload Windows EXE Artifact
        uses: actions/upload-artifact@v4
        with:
          name: Muzammil-Online-Service-Windows-x64
          path: Muzammil-Online-Service-Windows-x64.zip
          retention-days: 30`;
	const PC_LAUNCHER_BAT_CODE = `@echo off
title Muzammil Online service pc
color 0b
echo ========================================================
echo   MUZAMMIL ONLINE SERVICE PC - WORKSTATION v98.0
echo   Starting Local Server and Launching App...
echo ========================================================

:: Check if node_modules exists
if not exist node_modules (
    echo [INFO] First time setup detected! Installing dependencies...
    call npm install
)

:: Launch browser in background after 3 seconds
start "" cmd /c "timeout /t 3 >nul && start http://localhost:3000"

:: Start the application
call npm run dev
pause`;
	const PC_EXE_BUILDER_BAT_CODE = `@echo off
title Muzammil Online service pc - Professional .EXE Setup Builder
color 0a

echo ========================================================
echo   MUZAMMIL ONLINE SERVICE PC - PROFESSIONAL .EXE BUILDER
echo   Building Desktop Application and Windows Installer...
echo ========================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed!
    echo Please install Node.js from https://nodejs.org
    pause
    exit /b
)

echo [1/4] Installing necessary build packages...
call npm install
call npm install --save-dev electron electron-packager electron-builder

echo [2/4] Building high-performance production assets...
call npm run build

echo [3/4] Packaging standalone Windows Executable (.exe)...
call npx electron-packager . "Muzammil Online service pc" --platform=win32 --arch=x64 --out=dist-exe --overwrite --icon=public/favicon.ico

echo.
echo ========================================================
echo   SUCCESS! Windows Desktop Software is Ready!
echo   Folder: dist-exe\\Muzammil Online service pc-win32-x64\\
echo   Executable: "Muzammil Online service pc.exe"
echo ========================================================
echo.
explorer "dist-exe\\Muzammil Online service pc-win32-x64"
pause`;
	// Download Workflow YML
	const handleDownloadWorkflowYml = () => {
		const blob = new Blob([WORKFLOW_YAML_CODE], { type: "text/yaml" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "build-windows-exe.yml";
		a.click();
		URL.revokeObjectURL(url);
		setAlertMessage("⚡ GitHub Actions workflow file \"build-windows-exe.yml\" downloaded!");
		setTimeout(() => setAlertMessage(null), 3e3);
	};
	// Download PC Launcher BAT
	const handleDownloadPcLauncher = () => {
		const blob = new Blob([PC_LAUNCHER_BAT_CODE], { type: "application/x-bat" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "START-WORKSTATION.bat";
		a.click();
		URL.revokeObjectURL(url);
		setAlertMessage("💻 PC Launcher file \"START-WORKSTATION.bat\" downloaded!");
		setTimeout(() => setAlertMessage(null), 3e3);
	};
	// Download PC EXE Builder BAT
	const handleDownloadExeBuilder = () => {
		const blob = new Blob([PC_EXE_BUILDER_BAT_CODE], { type: "application/x-bat" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = "CREATE-EXE-SETUP.bat";
		a.click();
		URL.revokeObjectURL(url);
		setAlertMessage("🛠️ PC EXE Setup Builder file \"CREATE-EXE-SETUP.bat\" downloaded!");
		setTimeout(() => setAlertMessage(null), 3e3);
	};
	// Copy to clipboard helpers
	const handleCopyWorkflowCode = () => {
		navigator.clipboard.writeText(WORKFLOW_YAML_CODE);
		setCopiedWorkflow(true);
		setAlertMessage("📋 GitHub Actions Workflow YAML code copied to clipboard!");
		setTimeout(() => {
			setCopiedWorkflow(false);
			setAlertMessage(null);
		}, 3e3);
	};
	const handleCopyPcBatchCode = () => {
		navigator.clipboard.writeText(PC_LAUNCHER_BAT_CODE);
		setCopiedPcBatch(true);
		setAlertMessage("📋 PC 1-Click Launcher (START-WORKSTATION.bat) code copied to clipboard!");
		setTimeout(() => {
			setCopiedPcBatch(false);
			setAlertMessage(null);
		}, 3e3);
	};
	const handleCopyExeBuilderCode = () => {
		navigator.clipboard.writeText(PC_EXE_BUILDER_BAT_CODE);
		setCopiedExeBatch(true);
		setAlertMessage("📋 PC EXE Setup Builder (CREATE-EXE-SETUP.bat) code copied to clipboard!");
		setTimeout(() => {
			setCopiedExeBatch(false);
			setAlertMessage(null);
		}, 3e3);
	};
	// Handle Save Shop Settings
	const handleSaveSettings = (e) => {
		e.preventDefault();
		onUpdateSettings(shopForm);
		setAlertMessage("✅ Shop details and configuration saved!");
		setTimeout(() => setAlertMessage(null), 3e3);
	};
	const completedWorkflowCount = Object.values(completedSteps).filter(Boolean).length;
	const onlineCount = liveSessions.filter((s) => s.isOnline).length;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 flex-wrap",
					children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl font-extrabold text-white flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-6 h-6 text-blue-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 575,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Master Admin Control & Live Monitoring Hub" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 576,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 574,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs px-2.5 py-0.5 rounded-full font-mono font-bold flex items-center gap-1.5",
						children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-emerald-400 animate-pulse" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 579,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
							"Live: ",
							onlineCount,
							" Active Online"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 580,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 578,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 573,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400 mt-1",
					children: "Real-Time Operator Activity Monitor • License Renewals • Dual-Device PC & Mobile Security • Central Setup"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 583,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 572,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 flex-wrap",
					children: /* @__PURE__ */ _jsxDEV("button", {
						onClick: handleDownloadZip,
						disabled: isExportingZip,
						className: "flex items-center gap-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-emerald-600/20 transition-all hover:scale-105 disabled:opacity-50",
						title: "Download full project source code archive (.zip)",
						children: [/* @__PURE__ */ _jsxDEV(Archive, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 596,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: isExportingZip ? "Packing ZIP..." : "📦 Download Project .ZIP" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 597,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 590,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 589,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 571,
				columnNumber: 7
			}, this),
			alertMessage && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center justify-between animate-in fade-in",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-400 flex-shrink-0" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 606,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: alertMessage }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 607,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 605,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setAlertMessage(null),
					className: "text-emerald-400 hover:text-white",
					children: "✕"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 609,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 604,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-1.5 bg-slate-900 border border-slate-800 p-1.5 rounded-xl text-xs font-bold overflow-x-auto",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveSubTab("live_monitor"),
						className: `flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${activeSubTab === "live_monitor" ? "bg-rose-600 text-white shadow" : "text-slate-400 hover:text-white"}`,
						children: [/* @__PURE__ */ _jsxDEV(Radio, { className: "w-3.5 h-3.5 text-white animate-pulse" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 623,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
							"🔴 Live Operator Monitor (",
							onlineCount,
							")"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 624,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 615,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveSubTab("operators"),
						className: `flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${activeSubTab === "operators" ? "bg-blue-600 text-white shadow" : "text-slate-400 hover:text-white"}`,
						children: [/* @__PURE__ */ _jsxDEV(Monitor, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 635,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
							"Operator IDs & Locks (",
							operators.length,
							")"
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 636,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 627,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveSubTab("workflow"),
						className: `flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${activeSubTab === "workflow" ? "bg-blue-600 text-white shadow" : "text-slate-400 hover:text-white"}`,
						children: [/* @__PURE__ */ _jsxDEV(ClipboardList, { className: "w-3.5 h-3.5 text-amber-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 647,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Cyber Cafe Workflow & SOP" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 648,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 639,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveSubTab("zip_download"),
						className: `flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${activeSubTab === "zip_download" ? "bg-blue-600 text-white shadow" : "text-slate-400 hover:text-white"}`,
						children: [/* @__PURE__ */ _jsxDEV(Archive, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 659,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "3 Files Hub (GitHub ZIP • Workflow • PC Files)" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 660,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 651,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveSubTab("logs"),
						className: `flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${activeSubTab === "logs" ? "bg-blue-600 text-white shadow" : "text-slate-400 hover:text-white"}`,
						children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 671,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Security & Device Logs" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 672,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 663,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveSubTab("settings"),
						className: `flex items-center gap-1.5 px-4 py-2 rounded-lg transition-all ${activeSubTab === "settings" ? "bg-blue-600 text-white shadow" : "text-slate-400 hover:text-white"}`,
						children: [/* @__PURE__ */ _jsxDEV(Key, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 683,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Master Setup Center" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 684,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 675,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 614,
				columnNumber: 7
			}, this),
			activeSubTab === "live_monitor" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base font-extrabold text-white flex items-center gap-2",
							children: [
								/* @__PURE__ */ _jsxDEV(Radio, { className: "w-4 h-4 text-rose-500 animate-pulse" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 694,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "Live Operator Activity & Real-Time Pulse" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 695,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 font-mono",
									children: "3.5s Live Ping"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 696,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 693,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400 mt-0.5",
							children: "See exactly which operator is working on what studio in real-time, their active PC/Mobile, and renew access."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 700,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 692,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setIsAutoRefreshing(!isAutoRefreshing),
								className: `px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors flex items-center gap-1.5 ${isAutoRefreshing ? "bg-emerald-500/10 text-emerald-300 border-emerald-500/30" : "bg-slate-800 text-slate-400 border-slate-700"}`,
								children: [/* @__PURE__ */ _jsxDEV(Activity, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 714,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: isAutoRefreshing ? "Auto-Update: ON" : "Paused" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 715,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 706,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: refreshLiveSessions,
								className: "p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs",
								title: "Refresh Live Data",
								children: /* @__PURE__ */ _jsxDEV(RefreshCw, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 723,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 718,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 705,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 691,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400 block text-[11px]",
										children: "Active Staff Online"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 731,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-2xl font-extrabold text-white font-mono flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 733,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: onlineCount }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 734,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 732,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-emerald-400 font-mono",
										children: "Live WebSocket Pulse"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 736,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 730,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400 block text-[11px]",
										children: "PC Workstations Active"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 740,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-2xl font-extrabold text-blue-400 font-mono flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV(Laptop, { className: "w-5 h-5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 742,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: liveSessions.filter((s) => s.deviceType === "pc" && s.isOnline).length }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 743,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 741,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400",
										children: "Desktop Workstations"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 745,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 739,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400 block text-[11px]",
										children: "Mobile Handsets Active"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 749,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-2xl font-extrabold text-purple-400 font-mono flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV(Smartphone, { className: "w-5 h-5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 751,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: liveSessions.filter((s) => s.deviceType === "mobile" && s.isOnline).length }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 752,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 750,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400",
										children: "Operator Handsets"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 754,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 748,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400 block text-[11px]",
										children: "Last Pulse Update"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 758,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-sm font-bold text-white font-mono mt-1",
										children: lastRefreshedAt || "Connecting..."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 759,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-500",
										children: "Auto Heartbeat"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 762,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 757,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 729,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ _jsxDEV("table", {
							className: "w-full text-left text-xs",
							children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
								className: "border-b border-slate-800 text-slate-400 uppercase tracking-wider font-semibold",
								children: [
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Live Status"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 771,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Operator Name"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 772,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Device / Machine"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 773,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Active Studio / Task"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 774,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "License Validity"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 775,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3 text-right",
										children: "Admin Control"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 776,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 770,
								columnNumber: 17
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 769,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("tbody", {
								className: "divide-y divide-slate-800/60 font-sans",
								children: liveSessions.map((session) => {
									const daysLeft = calculateRemainingDays(session.validityExpiresAt);
									const isExpiring = daysLeft < 15;
									return /* @__PURE__ */ _jsxDEV("tr", {
										className: "hover:bg-slate-950/40 transition-colors",
										children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ _jsxDEV("span", { className: `w-2.5 h-2.5 rounded-full ${session.isOnline ? "bg-emerald-400 animate-pulse" : "bg-slate-600"}` }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 789,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: `text-[11px] font-bold ${session.isOnline ? "text-emerald-400" : "text-slate-500"}`,
														children: session.isOnline ? "Active Now" : `${session.lastActiveSecondsAgo || 30}s ago`
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 792,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 788,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 787,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-extrabold text-white text-sm",
													children: session.displayName
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 802,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "text-[11px] text-slate-400 font-mono",
													children: [
														"@",
														session.username,
														" • ",
														session.phone || "9561460313"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 803,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 801,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center gap-1.5 font-bold text-slate-300",
													children: [session.deviceType === "mobile" ? /* @__PURE__ */ _jsxDEV(Smartphone, { className: "w-3.5 h-3.5 text-purple-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 810,
														columnNumber: 29
													}, this) : /* @__PURE__ */ _jsxDEV(Laptop, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 812,
														columnNumber: 29
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "font-mono text-[11px]",
														children: session.deviceId
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 814,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 808,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "text-[10px] text-slate-400",
													children: session.deviceName
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 816,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 807,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: /* @__PURE__ */ _jsxDEV("span", {
													className: "px-2.5 py-1 rounded-lg bg-blue-500/10 text-blue-300 border border-blue-500/20 font-bold text-[11px] inline-flex items-center gap-1",
													children: [/* @__PURE__ */ _jsxDEV(Activity, { className: "w-3 h-3 text-blue-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 822,
														columnNumber: 27
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: session.currentTab || "Workstation Hub" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 823,
														columnNumber: 27
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 821,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 820,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: session.role === "admin" || session.username === "admin" ? /* @__PURE__ */ _jsxDEV("div", {
													className: "space-y-0.5",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "font-extrabold font-mono text-[11px] text-amber-300 flex items-center gap-1",
														children: /* @__PURE__ */ _jsxDEV("span", { children: "👑 Lifetime Access" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 832,
															columnNumber: 31
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 831,
														columnNumber: 29
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "text-[10px] text-emerald-400 font-bold",
														children: "Never Expires (Permanent)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 834,
														columnNumber: 29
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 830,
													columnNumber: 27
												}, this) : /* @__PURE__ */ _jsxDEV("div", {
													className: "space-y-0.5",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: `font-bold font-mono text-[11px] ${isExpiring ? "text-rose-400" : "text-emerald-400"}`,
														children: daysLeft > 0 ? `${daysLeft} Days Left` : "Expired"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 838,
														columnNumber: 29
													}, this), /* @__PURE__ */ _jsxDEV("div", {
														className: "text-[10px] text-slate-500",
														children: ["Exp: ", session.validityExpiresAt || "2026-12-31"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 843,
														columnNumber: 29
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 837,
													columnNumber: 27
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 828,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3 text-right",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center justify-end gap-1.5",
													children: [
														/* @__PURE__ */ _jsxDEV("button", {
															onClick: () => {
																const found = operators.find((o) => o.username === session.username);
																if (found) setSelectedOpForRenew(found);
															},
															className: "px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/20 font-bold text-[10px] flex items-center gap-1 transition-colors",
															title: "Renew License Access",
															children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-3 h-3" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 860,
																columnNumber: 29
															}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Renew" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 861,
																columnNumber: 29
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 852,
															columnNumber: 27
														}, this),
														/* @__PURE__ */ _jsxDEV("button", {
															onClick: () => {
																setBroadcastTargetUsername(session.username);
																setBroadcastMessageText("");
															},
															className: "p-1 rounded-lg bg-slate-800 text-slate-300 border border-slate-700 hover:text-white",
															title: "Send In-App Toast Message",
															children: /* @__PURE__ */ _jsxDEV(MessageSquare, { className: "w-3 h-3" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 873,
																columnNumber: 29
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 865,
															columnNumber: 27
														}, this),
														/* @__PURE__ */ _jsxDEV("button", {
															onClick: () => handleForceDisconnect(session.username, session.deviceId),
															className: "p-1 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/30 hover:bg-rose-500/20",
															title: "Force Disconnect Session",
															children: /* @__PURE__ */ _jsxDEV(Power, { className: "w-3 h-3" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 882,
																columnNumber: 29
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 877,
															columnNumber: 27
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 850,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 849,
												columnNumber: 23
											}, this)
										]
									}, session.sessionId || `${session.username}-${session.deviceId}`, true, {
										fileName: _jsxFileName,
										lineNumber: 785,
										columnNumber: 21
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 779,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 768,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 767,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 690,
				columnNumber: 9
			}, this),
			activeSubTab === "operators" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base font-extrabold text-white flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "Authorized Operators (PC + Mobile Binding)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 901,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20 font-mono",
								children: "1 PC + 1 Mobile Per ID"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 902,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 900,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400 mt-0.5",
							children: [
								"Each operator ID can work on ",
								/* @__PURE__ */ _jsxDEV("b", { children: "1 authorized PC" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 907,
									columnNumber: 46
								}, this),
								" AND ",
								/* @__PURE__ */ _jsxDEV("b", { children: "1 authorized Mobile" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 907,
									columnNumber: 73
								}, this),
								" at the same time. Third-party devices are blocked automatically."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 906,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 899,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowAddModal(true),
							className: "flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow transition-all self-start sm:self-auto",
							children: [/* @__PURE__ */ _jsxDEV(UserPlus, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 915,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Register New Operator ID" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 916,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 911,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 898,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs flex items-center justify-between flex-wrap gap-2 text-slate-300",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ _jsxDEV(Cpu, { className: "w-4 h-4 text-blue-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 923,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: [
									"Your Current Machine (",
									currentIsMobile ? "📱 Mobile" : "💻 PC",
									"):"
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 924,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("code", {
									className: "text-white font-mono font-bold bg-slate-900 px-2 py-0.5 rounded border border-slate-700",
									children: currentDeviceId
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 925,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 922,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-slate-400 font-mono text-[11px]",
							children: currentDeviceName
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 929,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 921,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ _jsxDEV("table", {
							className: "w-full text-left text-xs",
							children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", {
								className: "border-b border-slate-800 text-slate-400 uppercase tracking-wider font-semibold",
								children: [
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Operator / Username"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 937,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Role"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 938,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Authorized PC (1 Max)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 939,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "Authorized Mobile (1 Max)"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 940,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3",
										children: "License Status"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 941,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("th", {
										className: "py-3 px-3 text-right",
										children: "Device & Renew Actions"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 942,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 936,
								columnNumber: 17
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 935,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("tbody", {
								className: "divide-y divide-slate-800/60",
								children: operators.map((op) => {
									const daysLeft = calculateRemainingDays(op.validityExpiresAt);
									return /* @__PURE__ */ _jsxDEV("tr", {
										className: "hover:bg-slate-950/40 transition-colors",
										children: [
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-bold text-white text-sm",
													children: op.displayName
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 953,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "text-slate-400 font-mono text-[11px]",
													children: [
														"@",
														op.username,
														" • ",
														op.phone
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 954,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 952,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: /* @__PURE__ */ _jsxDEV("span", {
													className: `px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono ${op.role === "admin" ? "bg-purple-500/20 text-purple-300 border border-purple-500/30" : "bg-blue-500/20 text-blue-300 border border-blue-500/30"}`,
													children: op.role === "admin" ? "Master Admin" : "Operator"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 959,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 958,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: op.boundPcDeviceId ? /* @__PURE__ */ _jsxDEV("div", {
													className: "space-y-0.5",
													children: [
														/* @__PURE__ */ _jsxDEV("div", {
															className: "flex items-center gap-1.5 font-bold text-blue-400",
															children: [/* @__PURE__ */ _jsxDEV(Laptop, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 973,
																columnNumber: 31
															}, this), /* @__PURE__ */ _jsxDEV("span", {
																className: "font-mono text-[11px]",
																children: op.boundPcDeviceId
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 974,
																columnNumber: 31
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 972,
															columnNumber: 29
														}, this),
														/* @__PURE__ */ _jsxDEV("div", {
															className: "text-[10px] text-slate-400 truncate max-w-[160px]",
															children: op.boundPcDeviceName || "PC Workstation"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 976,
															columnNumber: 29
														}, this),
														/* @__PURE__ */ _jsxDEV("button", {
															onClick: () => handleResetPc(op.id, op.username),
															className: "text-[10px] text-amber-400 hover:underline flex items-center gap-0.5 font-bold pt-0.5",
															children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-2.5 h-2.5" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 981,
																columnNumber: 31
															}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Reset PC Binding" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 982,
																columnNumber: 31
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 977,
															columnNumber: 29
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 971,
													columnNumber: 27
												}, this) : /* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 font-medium",
													children: "Unbound PC (Pending)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 986,
													columnNumber: 27
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 969,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: op.boundMobileDeviceId ? /* @__PURE__ */ _jsxDEV("div", {
													className: "space-y-0.5",
													children: [
														/* @__PURE__ */ _jsxDEV("div", {
															className: "flex items-center gap-1.5 font-bold text-purple-400",
															children: [/* @__PURE__ */ _jsxDEV(Smartphone, { className: "w-3.5 h-3.5 text-purple-400" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 997,
																columnNumber: 31
															}, this), /* @__PURE__ */ _jsxDEV("span", {
																className: "font-mono text-[11px]",
																children: op.boundMobileDeviceId
															}, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 998,
																columnNumber: 31
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 996,
															columnNumber: 29
														}, this),
														/* @__PURE__ */ _jsxDEV("div", {
															className: "text-[10px] text-slate-400 truncate max-w-[160px]",
															children: op.boundMobileDeviceName || "Smartphone"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1e3,
															columnNumber: 29
														}, this),
														/* @__PURE__ */ _jsxDEV("button", {
															onClick: () => handleResetMobile(op.id, op.username),
															className: "text-[10px] text-amber-400 hover:underline flex items-center gap-0.5 font-bold pt-0.5",
															children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-2.5 h-2.5" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1005,
																columnNumber: 31
															}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Reset Mobile Binding" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1006,
																columnNumber: 31
															}, this)]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1001,
															columnNumber: 29
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 995,
													columnNumber: 27
												}, this) : /* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 font-medium",
													children: "Unbound Mobile (Pending)"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1010,
													columnNumber: 27
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 993,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3",
												children: op.role === "admin" ? /* @__PURE__ */ _jsxDEV("div", {
													className: "space-y-0.5",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold text-[10px] font-mono flex items-center gap-1 w-fit",
														children: /* @__PURE__ */ _jsxDEV("span", { children: "👑 Lifetime (Never Expires)" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1021,
															columnNumber: 31
														}, this)
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1020,
														columnNumber: 29
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "text-[10px] text-emerald-400 font-bold block",
														children: "Permanent Access"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1023,
														columnNumber: 29
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1019,
													columnNumber: 27
												}, this) : /* @__PURE__ */ _jsxDEV("div", {
													className: "space-y-1",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold text-[10px] font-mono flex items-center gap-1 w-fit",
														children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-3 h-3 text-emerald-400" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1028,
															columnNumber: 31
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: [daysLeft, " Days Left"] }, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 1029,
															columnNumber: 31
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 1027,
														columnNumber: 29
													}, this), /* @__PURE__ */ _jsxDEV("button", {
														onClick: () => setSelectedOpForRenew(op),
														className: "text-[10px] text-sky-400 hover:underline font-bold block",
														children: "+ Renew Access"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 1031,
														columnNumber: 29
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1026,
													columnNumber: 27
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1017,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("td", {
												className: "py-3 px-3 text-right",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center justify-end gap-1.5 flex-wrap",
													children: [
														(op.boundPcDeviceId || op.boundMobileDeviceId) && /* @__PURE__ */ _jsxDEV("button", {
															onClick: () => handleResetAllDevices(op.id, op.username),
															className: "px-2 py-1 rounded-lg bg-amber-500/10 text-amber-300 border border-amber-500/30 hover:bg-amber-500/20 font-bold text-[10px] transition-colors",
															title: "Reset both PC and Mobile bindings",
															children: "Reset All"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1046,
															columnNumber: 29
														}, this),
														op.role !== "admin" && /* @__PURE__ */ _jsxDEV("button", {
															onClick: () => handleToggleLock(op.id, op.username),
															className: `p-1.5 rounded-lg border text-xs ${op.isLocked ? "bg-emerald-500/10 text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/20" : "bg-slate-800 text-slate-400 border-slate-700 hover:text-white"}`,
															title: op.isLocked ? "Unlock Operator" : "Suspend Operator",
															children: op.isLocked ? /* @__PURE__ */ _jsxDEV(Unlock, { className: "w-3.5 h-3.5" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1066,
																columnNumber: 46
															}, this) : /* @__PURE__ */ _jsxDEV(Lock, { className: "w-3.5 h-3.5" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1066,
																columnNumber: 83
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1057,
															columnNumber: 29
														}, this),
														op.role !== "admin" && /* @__PURE__ */ _jsxDEV("button", {
															onClick: () => handleDeleteOperator(op.id, op.username),
															className: "p-1.5 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/20 hover:bg-rose-500/20 text-xs",
															title: "Delete Operator",
															children: /* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
																fileName: _jsxFileName,
																lineNumber: 1077,
																columnNumber: 31
															}, this)
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 1072,
															columnNumber: 29
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1043,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1042,
												columnNumber: 23
											}, this)
										]
									}, op.id, true, {
										fileName: _jsxFileName,
										lineNumber: 950,
										columnNumber: 21
									}, this);
								})
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 945,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 934,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 933,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 897,
				columnNumber: 9
			}, this),
			activeSubTab === "workflow" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-base font-extrabold text-white flex items-center gap-2",
						children: [
							/* @__PURE__ */ _jsxDEV(ClipboardList, { className: "w-5 h-5 text-amber-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1097,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "Cyber Cafe Standard Operating Procedure (SOP)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1098,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 font-mono",
								children: "Master Workflow"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1099,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1096,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400 mt-0.5",
						children: "Standardized 6-stage operational protocol for all CSC & Cyber Cafe services"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1103,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1095,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-xs font-mono text-slate-300",
						children: ["Checklist: ", /* @__PURE__ */ _jsxDEV("strong", {
							className: "text-emerald-400",
							children: [
								completedWorkflowCount,
								" / ",
								MASTER_WORKFLOW_STEPS.length,
								" Completed"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1109,
							columnNumber: 26
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1108,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1094,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-4",
					children: MASTER_WORKFLOW_STEPS.map((step) => {
						const isDone = !!completedSteps[step.stepNumber];
						return /* @__PURE__ */ _jsxDEV("div", {
							className: `p-4 rounded-xl border transition-all space-y-3 ${isDone ? "bg-slate-950/60 border-emerald-500/40" : "bg-slate-950 border-slate-800 hover:border-slate-700"}`,
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: `w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs font-mono ${isDone ? "bg-emerald-500 text-slate-950" : "bg-blue-600 text-white"}`,
											children: step.stepNumber
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1128,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("h3", {
											className: "font-extrabold text-white text-xs",
											children: step.title
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1133,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1127,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setCompletedSteps((prev) => ({
											...prev,
											[step.stepNumber]: !prev[step.stepNumber]
										})),
										className: `flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-md border ${isDone ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30" : "bg-slate-900 text-slate-400 border-slate-700"}`,
										children: [isDone ? /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1144,
											columnNumber: 33
										}, this) : /* @__PURE__ */ _jsxDEV(Circle, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1144,
											columnNumber: 93
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: isDone ? "Done" : "Mark" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1145,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1136,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1126,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-300 leading-snug",
									children: step.description
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1149,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1 pt-1 border-t border-slate-800/80",
									children: step.checklist.map((item, idx) => /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start gap-1.5 text-[11px] text-slate-400",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-blue-500",
											children: "•"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1154,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: item }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1155,
											columnNumber: 25
										}, this)]
									}, idx, true, {
										fileName: _jsxFileName,
										lineNumber: 1153,
										columnNumber: 23
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1151,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-2 rounded-lg bg-slate-900 text-[10px] text-amber-300/90 flex items-start gap-1.5",
									children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3 h-3 text-amber-400 flex-shrink-0 mt-0.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1161,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
										/* @__PURE__ */ _jsxDEV("b", { children: "Operator Note:" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1162,
											columnNumber: 27
										}, this),
										" ",
										step.tips
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1162,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1160,
									columnNumber: 19
								}, this)
							]
						}, step.stepNumber, true, {
							fileName: _jsxFileName,
							lineNumber: 1118,
							columnNumber: 17
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1114,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1093,
				columnNumber: 9
			}, this),
			activeSubTab === "zip_download" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-4 border-b border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-start gap-4",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-600/20 to-teal-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 flex-shrink-0 shadow-inner",
								children: /* @__PURE__ */ _jsxDEV(Archive, { className: "w-7 h-7" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1178,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1177,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ _jsxDEV("h2", {
									className: "text-lg font-extrabold text-white flex items-center gap-2 flex-wrap",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "3 Master Admin Download Files Hub" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1182,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded font-mono border border-emerald-500/30",
										children: "GitHub & PC Ready"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1183,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1181,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-300 leading-relaxed",
									children: "Yahan se aap (1) GitHub-Ready complete project .ZIP, (2) GitHub Actions workflow .YML code, aur (3) PC standalone launcher .BAT files direct 1-click mein download ya copy kar sakte hain."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1187,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1180,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1176,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[10px] text-slate-400 font-mono bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 self-start",
							children: "Workstation v98.0"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1193,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1175,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 lg:grid-cols-3 gap-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950 border border-emerald-500/30 rounded-2xl p-4 flex flex-col justify-between space-y-3 shadow-lg hover:border-emerald-500/50 transition-all",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm",
												children: "1"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1204,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] font-bold text-emerald-300 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20",
												children: "GitHub Ready ZIP"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1207,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1203,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("h3", {
											className: "font-extrabold text-white text-sm",
											children: "📦 Complete Project .ZIP Archive"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1212,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-slate-400 text-[11px] leading-relaxed",
											children: "Sabhi studios (PVC, Passport, Video Studio, Billing, CRM, 50+ Portals, Electron, GitHub Workflow) ka complete source code bundle."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1215,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-500 font-mono space-y-0.5 bg-slate-900/60 p-2 rounded-lg border border-slate-800",
											children: [
												/* @__PURE__ */ _jsxDEV("div", { children: ["File: ", /* @__PURE__ */ _jsxDEV("b", { children: "Muzammil-Online-service-pc.zip" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1220,
													columnNumber: 30
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1220,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", { children: ["Format: ", /* @__PURE__ */ _jsxDEV("b", { children: "ZIP (Deflate Lv9)" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1221,
													columnNumber: 32
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1221,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", { children: ["Dest: ", /* @__PURE__ */ _jsxDEV("b", { children: "GitHub / Local PC" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1222,
													columnNumber: 30
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1222,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1219,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1202,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2 pt-2",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										onClick: handleDownloadZip,
										disabled: isExportingZip,
										className: "w-full flex items-center justify-center gap-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-xs py-2.5 rounded-xl shadow transition-all disabled:opacity-50",
										children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1232,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: isExportingZip ? "Compressing ZIP..." : "Download Project .ZIP" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1233,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1227,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("a", {
										href: "/api/download-zip",
										download: "Muzammil-Online-service-pc.zip",
										className: "text-[11px] text-blue-400 hover:underline flex items-center justify-center gap-1 font-semibold",
										children: [/* @__PURE__ */ _jsxDEV(ExternalLink, { className: "w-3 h-3" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1241,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Direct Server Download Link" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1242,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1236,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1226,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1201,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950 border border-purple-500/30 rounded-2xl p-4 flex flex-col justify-between space-y-3 shadow-lg hover:border-purple-500/50 transition-all",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold text-sm",
												children: "2"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1251,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] font-bold text-purple-300 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/20",
												children: "GitHub Actions .YML"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1254,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1250,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("h3", {
											className: "font-extrabold text-white text-sm",
											children: "⚡ GitHub Workflow Code (.YML)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1259,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-slate-400 text-[11px] leading-relaxed",
											children: [
												"GitHub Cloud servers par bina kisi load ke automatic standalone Windows ",
												/* @__PURE__ */ _jsxDEV("b", { children: ".EXE" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1263,
													columnNumber: 91
												}, this),
												" setup file build karne ka automation script."
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1262,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-500 font-mono space-y-0.5 bg-slate-900/60 p-2 rounded-lg border border-slate-800",
											children: [
												/* @__PURE__ */ _jsxDEV("div", { children: ["File: ", /* @__PURE__ */ _jsxDEV("b", { children: "build-windows-exe.yml" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1267,
													columnNumber: 30
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1267,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", { children: ["Target: ", /* @__PURE__ */ _jsxDEV("b", { children: ".github/workflows/" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1268,
													columnNumber: 32
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1268,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", { children: ["Output: ", /* @__PURE__ */ _jsxDEV("b", { children: "Windows x64 .EXE" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1269,
													columnNumber: 32
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1269,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1266,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1249,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2 pt-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 gap-2",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											onClick: handleDownloadWorkflowYml,
											className: "flex items-center justify-center gap-1 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs py-2 rounded-xl shadow transition-colors",
											title: "Download build-windows-exe.yml",
											children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1280,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Download .YML" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1281,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1275,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: handleCopyWorkflowCode,
											className: `flex items-center justify-center gap-1 font-bold text-xs py-2 rounded-xl border transition-colors ${copiedWorkflow ? "bg-emerald-600 text-white border-emerald-400" : "bg-slate-900 hover:bg-slate-800 text-purple-300 border-purple-500/40 hover:text-white"}`,
											title: "Copy full YAML code to clipboard",
											children: [copiedWorkflow ? /* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1293,
												columnNumber: 39
											}, this) : /* @__PURE__ */ _jsxDEV(Copy, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1293,
												columnNumber: 75
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: copiedWorkflow ? "Copied!" : "Copy Code" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1294,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1284,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1274,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setExpandedFileCard(expandedFileCard === "workflow" ? null : "workflow"),
										className: "w-full text-[11px] text-slate-400 hover:text-purple-300 flex items-center justify-center gap-1 font-semibold pt-0.5",
										children: [/* @__PURE__ */ _jsxDEV(FileCode, { className: "w-3 h-3" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1302,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: expandedFileCard === "workflow" ? "Hide Workflow Code" : "View Workflow Code" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1303,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1298,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1273,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1248,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950 border border-blue-500/30 rounded-2xl p-4 flex flex-col justify-between space-y-3 shadow-lg hover:border-blue-500/50 transition-all",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "w-8 h-8 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-sm",
												children: "3"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1312,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] font-bold text-blue-300 bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20",
												children: "Windows PC .BAT"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1315,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1311,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("h3", {
											className: "font-extrabold text-white text-sm",
											children: "💻 PC 1-Click Launcher Files"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1320,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-slate-400 text-[11px] leading-relaxed",
											children: "PC par 1-click mein software start karne wali batch file aur local computer par .EXE file generate karne wala builder script."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1323,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-500 font-mono space-y-0.5 bg-slate-900/60 p-2 rounded-lg border border-slate-800",
											children: [
												/* @__PURE__ */ _jsxDEV("div", { children: ["File 1: ", /* @__PURE__ */ _jsxDEV("b", { children: "START-WORKSTATION.bat" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1328,
													columnNumber: 32
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1328,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", { children: ["File 2: ", /* @__PURE__ */ _jsxDEV("b", { children: "CREATE-EXE-SETUP.bat" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1329,
													columnNumber: 32
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1329,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", { children: ["Port: ", /* @__PURE__ */ _jsxDEV("b", { children: "3000 (Offline Ready)" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1330,
													columnNumber: 30
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 1330,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1327,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1310,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2 pt-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 gap-2",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											onClick: handleDownloadPcLauncher,
											className: "flex items-center justify-center gap-1 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs py-2 rounded-xl shadow transition-colors",
											title: "Download START-WORKSTATION.bat",
											children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1341,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Download .BAT" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1342,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1336,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: handleCopyPcBatchCode,
											className: `flex items-center justify-center gap-1 font-bold text-xs py-2 rounded-xl border transition-colors ${copiedPcBatch ? "bg-emerald-600 text-white border-emerald-400" : "bg-slate-900 hover:bg-slate-800 text-blue-300 border-blue-500/40 hover:text-white"}`,
											title: "Copy START-WORKSTATION.bat script",
											children: [copiedPcBatch ? /* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1354,
												columnNumber: 38
											}, this) : /* @__PURE__ */ _jsxDEV(Copy, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1354,
												columnNumber: 74
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: copiedPcBatch ? "Copied!" : "Copy .BAT" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1355,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1345,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1335,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between text-[11px] pt-0.5",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											onClick: handleDownloadExeBuilder,
											className: "text-amber-400 hover:underline flex items-center gap-1 font-semibold",
											title: "Download CREATE-EXE-SETUP.bat",
											children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-3 h-3" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1365,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Get .EXE Builder (.bat)" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1366,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1360,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setExpandedFileCard(expandedFileCard === "pc_batch" ? null : "pc_batch"),
											className: "text-slate-400 hover:text-blue-300 font-semibold",
											children: expandedFileCard === "pc_batch" ? "Hide Code" : "View Code"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1369,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1359,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1334,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1309,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1199,
						columnNumber: 11
					}, this),
					expandedFileCard && /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-2 animate-in fade-in",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between border-b border-slate-800 pb-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-mono text-xs text-white font-bold flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(Terminal, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1385,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: expandedFileCard === "workflow" ? ".github/workflows/build-windows-exe.yml" : "START-WORKSTATION.bat" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1386,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1384,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									onClick: expandedFileCard === "workflow" ? handleCopyWorkflowCode : handleCopyPcBatchCode,
									className: "px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white text-[11px] font-bold border border-slate-700 flex items-center gap-1",
									children: [/* @__PURE__ */ _jsxDEV(Copy, { className: "w-3 h-3" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1395,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Copy" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1396,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1391,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setExpandedFileCard(null),
									className: "text-slate-400 hover:text-white text-xs px-1",
									children: "✕"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1398,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1390,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1383,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("pre", {
							className: "text-[11px] font-mono text-slate-300 max-h-60 overflow-y-auto p-3 bg-slate-900/90 rounded-xl leading-relaxed select-all",
							children: expandedFileCard === "workflow" ? WORKFLOW_YAML_CODE : PC_LAUNCHER_BAT_CODE
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1406,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1382,
						columnNumber: 13
					}, this),
					isExportingZip && /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2 p-4 rounded-xl bg-slate-950 border border-emerald-500/30 animate-pulse",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-between text-xs text-emerald-400 font-bold",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: ["Packing ZIP Archive: ", zipProgress.file] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1416,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: [zipProgress.percent, "%"] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1417,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1415,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "w-full bg-slate-800 h-2 rounded-full overflow-hidden",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-emerald-500 h-full transition-all duration-200",
								style: { width: `${zipProgress.percent}%` }
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1420,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1419,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1414,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-4 text-xs",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-purple-400 font-extrabold pb-1 border-b border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV(FileCode, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1433,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "GitHub Actions Se .EXE Setup Kaise Banayein:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1434,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1432,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("ol", {
								className: "list-decimal list-inside space-y-1.5 text-slate-300 text-[11px] leading-relaxed",
								children: [
									/* @__PURE__ */ _jsxDEV("li", { children: [
										"GitHub par nayi repository banayein: ",
										/* @__PURE__ */ _jsxDEV("b", { children: "muzammil-online-service" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1437,
											columnNumber: 58
										}, this),
										"."
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1437,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("li", { children: "Downloaded ZIP ko extract karke saari files GitHub par upload karein." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1438,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("li", { children: [
										"GitHub ke ",
										/* @__PURE__ */ _jsxDEV("b", { children: "\"Actions\"" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1439,
											columnNumber: 31
										}, this),
										" tab mein jakar ",
										/* @__PURE__ */ _jsxDEV("b", { children: "\"Build Windows Desktop EXE Setup\"" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1439,
											columnNumber: 63
										}, this),
										" chunein."
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1439,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("li", { children: [
										"Right side mein ",
										/* @__PURE__ */ _jsxDEV("b", { children: "\"Run workflow\"" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1440,
											columnNumber: 37
										}, this),
										" dabayein — 2 minute mein ",
										/* @__PURE__ */ _jsxDEV("b", { children: ".EXE Artifact" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1440,
											columnNumber: 84
										}, this),
										" tayar ho jayegi!"
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1440,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1436,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1431,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-blue-400 font-extrabold pb-1 border-b border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV(Laptop, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1447,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Direct PC Par Software Kaise Chalayein:" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1448,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1446,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("ol", {
								className: "list-decimal list-inside space-y-1.5 text-slate-300 text-[11px] leading-relaxed",
								children: [
									/* @__PURE__ */ _jsxDEV("li", { children: [
										"ZIP ko computer ki kisi drive mein extract karein (e.g. ",
										/* @__PURE__ */ _jsxDEV("code", { children: "D:\\MuzammilOnlineService" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1451,
											columnNumber: 77
										}, this),
										")."
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1451,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("li", { children: [
										"Agar computer mein Node.js nahi hai, to ",
										/* @__PURE__ */ _jsxDEV("b", { children: "nodejs.org" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1452,
											columnNumber: 61
										}, this),
										" se 1-click install karein."
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1452,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("li", { children: [
										"Folder ke andar ",
										/* @__PURE__ */ _jsxDEV("b", { children: "START-WORKSTATION.bat" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1453,
											columnNumber: 37
										}, this),
										" par double-click karein!"
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1453,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("li", { children: [
										"Chrome/Edge browser mein ",
										/* @__PURE__ */ _jsxDEV("b", { children: "\"Install as App\"" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1454,
											columnNumber: 46
										}, this),
										" par click karke desktop shortcut bana lein."
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1454,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1450,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1445,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1429,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1173,
				columnNumber: 9
			}, this),
			activeSubTab === "logs" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between pb-3 border-b border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-base font-extrabold text-white",
						children: "Real-Time Security & Device Audit Log"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1466,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400",
						children: "Record of all authorized PC & Mobile logins, device locks, and blocked access attempts"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1467,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1465,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: loadData,
						className: "flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold",
						children: [/* @__PURE__ */ _jsxDEV(RefreshCw, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1473,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Refresh Logs" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1474,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1469,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1464,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "overflow-x-auto max-h-96",
					children: /* @__PURE__ */ _jsxDEV("table", {
						className: "w-full text-left text-xs",
						children: [/* @__PURE__ */ _jsxDEV("thead", {
							className: "sticky top-0 bg-slate-900 border-b border-slate-800 text-slate-400",
							children: /* @__PURE__ */ _jsxDEV("tr", { children: [
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Timestamp"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1482,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Action"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1483,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Operator"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1484,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Type"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1485,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Device ID"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1486,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("th", {
									className: "py-2.5 px-3",
									children: "Details"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1487,
									columnNumber: 19
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1481,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1480,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("tbody", {
							className: "divide-y divide-slate-800/60 font-mono text-[11px]",
							children: auditLogs.length > 0 ? auditLogs.map((log) => /* @__PURE__ */ _jsxDEV("tr", {
								className: "hover:bg-slate-950/40",
								children: [
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 text-slate-400",
										children: log.timestamp
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1494,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3",
										children: /* @__PURE__ */ _jsxDEV("span", {
											className: `px-2 py-0.5 rounded text-[10px] font-bold ${log.action === "LOGIN_SUCCESS" ? "bg-emerald-500/20 text-emerald-400" : log.action === "DEVICE_BLOCKED" ? "bg-rose-500/20 text-rose-400" : log.action === "DEVICE_BOUND" ? "bg-blue-500/20 text-blue-400" : "bg-amber-500/20 text-amber-400"}`,
											children: log.action
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1496,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1495,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 text-white font-bold",
										children: ["@", log.username]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1508,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 text-slate-400",
										children: log.deviceType === "mobile" ? "📱 Mobile" : "💻 PC"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1509,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 text-slate-300",
										children: log.deviceId
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1510,
										columnNumber: 23
									}, this),
									/* @__PURE__ */ _jsxDEV("td", {
										className: "py-2.5 px-3 text-slate-400 max-w-xs truncate font-sans",
										children: log.details
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1511,
										columnNumber: 23
									}, this)
								]
							}, log.id, true, {
								fileName: _jsxFileName,
								lineNumber: 1493,
								columnNumber: 21
							}, this)) : /* @__PURE__ */ _jsxDEV("tr", { children: /* @__PURE__ */ _jsxDEV("td", {
								colSpan: 6,
								className: "py-6 text-center text-slate-500",
								children: "No security audit logs recorded yet."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1516,
								columnNumber: 21
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1515,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1490,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1479,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1478,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1463,
				columnNumber: 9
			}, this),
			activeSubTab === "settings" && /* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base font-extrabold text-white flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Key, { className: "w-5 h-5 text-blue-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1533,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Master Admin Workstation Setup & Control Center" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1534,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1532,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400 mt-0.5",
							children: "Centralized management for Shop Details, POS Rates, Hardware Settings, and Staff Security"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1536,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1531,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "bg-rose-500/10 text-rose-300 border border-rose-500/30 text-xs px-3 py-1 rounded-full font-bold w-fit",
							children: "Staff & Operator Access Only"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1541,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1530,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 rounded-xl bg-gradient-to-r from-rose-950/40 to-slate-950 border border-rose-500/30 space-y-2",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-rose-400 font-extrabold text-xs",
							children: [/* @__PURE__ */ _jsxDEV(AlertCircle, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1549,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "ZERO CUSTOMER LOGIN ENFORCED (NO PUBLIC ACCESS)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1550,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1548,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-300 leading-relaxed",
							children: [
								"Is system mein ",
								/* @__PURE__ */ _jsxDEV("b", { children: "kisi bhi anjan customer ya public user ka login ya registration poori tarah band hai" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1553,
									columnNumber: 30
								}, this),
								". Sirf Master Admin ke dwara banaye gaye verified Staff Operator IDs hi login kar sakte hain. Sabhi citizen/customer details sirf shop ke internal ",
								/* @__PURE__ */ _jsxDEV("b", { children: "Customer CRM" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1555,
									columnNumber: 68
								}, this),
								" mein safe record ke taur par store hoti hain."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1552,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1547,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleSaveSettings,
						className: "space-y-6 text-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-extrabold text-white text-xs uppercase tracking-wider flex items-center gap-2 text-blue-400",
									children: /* @__PURE__ */ _jsxDEV("span", { children: "1. Shop Identity & Official Details" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1563,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1562,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-slate-400 block mb-1",
											children: "Shop / Center Name"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1568,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: shopForm.shopName,
											onChange: (e) => setShopForm({
												...shopForm,
												shopName: e.target.value
											}),
											className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1569,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1567,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-slate-400 block mb-1",
											children: "Owner Name"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1578,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: shopForm.ownerName,
											onChange: (e) => setShopForm({
												...shopForm,
												ownerName: e.target.value
											}),
											className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1579,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1577,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-slate-400 block mb-1",
											children: "WhatsApp / Contact Phone"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1588,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: shopForm.phone,
											onChange: (e) => setShopForm({
												...shopForm,
												phone: e.target.value
											}),
											className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1589,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1587,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "text-slate-400 block mb-1",
											children: "UPI ID for Dynamic POS QR"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1598,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: shopForm.upiId,
											onChange: (e) => setShopForm({
												...shopForm,
												upiId: e.target.value
											}),
											className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold font-mono"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1599,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1597,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "sm:col-span-2",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-slate-400 block mb-1",
												children: "Address (Printed on Tax Invoices & Thermal Slips)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1608,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												value: shopForm.address,
												onChange: (e) => setShopForm({
													...shopForm,
													address: e.target.value
												}),
												className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1609,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1607,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1566,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1561,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3 pt-3 border-t border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-extrabold text-white text-xs uppercase tracking-wider flex items-center gap-2 text-emerald-400",
									children: /* @__PURE__ */ _jsxDEV("span", { children: "2. Default POS Service Rates & Pricing (₹)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1622,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1621,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-2.5 rounded-xl border border-slate-800",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-slate-400 block text-[11px] mb-1",
												children: "PVC Smart Card"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1627,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1 font-bold text-emerald-400",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "₹" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1629,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "number",
													defaultValue: 0,
													placeholder: "0",
													className: "w-full bg-slate-900 border border-slate-700 rounded p-1 text-white font-mono text-xs"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1630,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1628,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1626,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-2.5 rounded-xl border border-slate-800",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-slate-400 block text-[11px] mb-1",
												children: "Passport Photo (8x)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1640,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1 font-bold text-emerald-400",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "₹" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1642,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "number",
													defaultValue: 0,
													placeholder: "0",
													className: "w-full bg-slate-900 border border-slate-700 rounded p-1 text-white font-mono text-xs"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1643,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1641,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1639,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-2.5 rounded-xl border border-slate-800",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-slate-400 block text-[11px] mb-1",
												children: "Online Scheme Form"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1653,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1 font-bold text-emerald-400",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "₹" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1655,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "number",
													defaultValue: 0,
													placeholder: "0",
													className: "w-full bg-slate-900 border border-slate-700 rounded p-1 text-white font-mono text-xs"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1656,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1654,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1652,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-2.5 rounded-xl border border-slate-800",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-slate-400 block text-[11px] mb-1",
												children: "Exam Form (Police)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1666,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1 font-bold text-emerald-400",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "₹" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1668,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "number",
													defaultValue: 0,
													placeholder: "0",
													className: "w-full bg-slate-900 border border-slate-700 rounded p-1 text-white font-mono text-xs"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1669,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1667,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1665,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-2.5 rounded-xl border border-slate-800",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-slate-400 block text-[11px] mb-1",
												children: "BioData / CV"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1679,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1 font-bold text-emerald-400",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "₹" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1681,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "number",
													defaultValue: 0,
													placeholder: "0",
													className: "w-full bg-slate-900 border border-slate-700 rounded p-1 text-white font-mono text-xs"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1682,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1680,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1678,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-2.5 rounded-xl border border-slate-800",
											children: [/* @__PURE__ */ _jsxDEV("label", {
												className: "text-slate-400 block text-[11px] mb-1",
												children: "Thermal Lamination"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 1692,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-1 font-bold text-emerald-400",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "₹" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1694,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "number",
													defaultValue: 0,
													placeholder: "0",
													className: "w-full bg-slate-900 border border-slate-700 rounded p-1 text-white font-mono text-xs"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1695,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 1693,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1691,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1625,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1620,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3 pt-3 border-t border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "font-extrabold text-white text-xs uppercase tracking-wider flex items-center gap-2 text-purple-400",
									children: /* @__PURE__ */ _jsxDEV("span", { children: "3. Hardware & Printing Standards" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1709,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1708,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1",
											children: [
												/* @__PURE__ */ _jsxDEV("label", {
													className: "text-slate-400 block font-bold",
													children: "PVC Card Resolution"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1714,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "text-white font-mono font-extrabold text-xs text-blue-400",
													children: "300 DPI Ultra HD"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1715,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-slate-500",
													children: "Optimized for Epson L805, L850 & Canon G-Series"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1716,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1713,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1",
											children: [
												/* @__PURE__ */ _jsxDEV("label", {
													className: "text-slate-400 block font-bold",
													children: "Photo Studio Layout"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1720,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "text-white font-mono font-extrabold text-xs text-purple-400",
													children: "4×6 Inch (10×15 cm) Glossy"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1721,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-slate-500",
													children: "8 pre-aligned passport photos with border guide lines"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1722,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1719,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1",
											children: [
												/* @__PURE__ */ _jsxDEV("label", {
													className: "text-slate-400 block font-bold",
													children: "POS Receipt Printer"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1726,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "text-white font-mono font-extrabold text-xs text-emerald-400",
													children: "58mm / 80mm Thermal ESC/POS"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1727,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("p", {
													className: "text-[10px] text-slate-500",
													children: "Zero-ink thermal paper with dynamic UPI QR code"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 1728,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 1725,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1712,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1707,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "pt-2 flex items-center gap-3",
								children: /* @__PURE__ */ _jsxDEV("button", {
									type: "submit",
									className: "px-6 py-3 bg-blue-600 hover:bg-blue-500 text-white font-extrabold rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-105",
									children: "Save Master Setup Configuration"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1735,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1734,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1559,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1529,
				columnNumber: 9
			}, this),
			selectedOpForRenew && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pb-2 border-b border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "font-extrabold text-white text-base flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-5 h-5 text-emerald-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1752,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Renew License & Access Validity" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1753,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1751,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setSelectedOpForRenew(null),
								className: "text-slate-400 hover:text-white",
								children: "✕"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1755,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1750,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs space-y-1",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-white font-bold",
									children: selectedOpForRenew.displayName
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1759,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-slate-400 font-mono",
									children: [
										"@",
										selectedOpForRenew.username,
										" • ",
										selectedOpForRenew.phone
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1760,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-emerald-400 font-bold pt-1",
									children: [
										"Current Remaining: ",
										calculateRemainingDays(selectedOpForRenew.validityExpiresAt),
										" Days"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1761,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1758,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2 text-xs",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "text-slate-300 font-bold block",
								children: "Select Extension Duration:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1767,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 gap-2",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setRenewDaysCount(30),
										className: `p-3 rounded-xl border font-bold text-center transition-all ${renewDaysCount === 30 ? "bg-blue-600 text-white border-blue-400 shadow" : "bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800"}`,
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "text-sm",
											children: "+30 Days"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1778,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-400",
											children: "1 Month Pass"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1779,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1769,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setRenewDaysCount(90),
										className: `p-3 rounded-xl border font-bold text-center transition-all ${renewDaysCount === 90 ? "bg-blue-600 text-white border-blue-400 shadow" : "bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800"}`,
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "text-sm",
											children: "+90 Days"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1791,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-400",
											children: "Quarterly Pass"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1792,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1782,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setRenewDaysCount(365),
										className: `p-3 rounded-xl border font-bold text-center transition-all ${renewDaysCount === 365 ? "bg-blue-600 text-white border-blue-400 shadow" : "bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800"}`,
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "text-sm",
											children: "+365 Days"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1804,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-400",
											children: "Annual License"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1805,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1795,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setRenewDaysCount(3650),
										className: `p-3 rounded-xl border font-bold text-center transition-all ${renewDaysCount === 3650 ? "bg-emerald-600 text-white border-emerald-400 shadow" : "bg-slate-950 border-slate-800 text-slate-300 hover:bg-slate-800"}`,
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "text-sm",
											children: "Lifetime"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1817,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-400",
											children: "Permanent Access"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1818,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1808,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1768,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1766,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "pt-2 flex items-center justify-end gap-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setSelectedOpForRenew(null),
								className: "px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl text-xs",
								children: "Cancel"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1824,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: handleExecuteRenewal,
								className: "px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold rounded-xl shadow text-xs flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1836,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Confirm & Apply Renewal" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1837,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1831,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1823,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1749,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1748,
				columnNumber: 9
			}, this),
			broadcastTargetUsername && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pb-2 border-b border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "font-extrabold text-white text-base flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(MessageSquare, { className: "w-5 h-5 text-sky-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1850,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["Send Alert to @", broadcastTargetUsername] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1851,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1849,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setBroadcastTargetUsername(null),
								className: "text-slate-400 hover:text-white",
								children: "✕"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1853,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1848,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-300",
							children: "This message will pop up immediately on the operator's computer or mobile screen."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1856,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("textarea", {
							rows: 3,
							value: broadcastMessageText,
							onChange: (e) => setBroadcastMessageText(e.target.value),
							placeholder: "e.g. Please check Ladki Bahin payment slip before handing over to customer.",
							className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white text-xs"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1860,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-end gap-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setBroadcastTargetUsername(null),
								className: "px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl text-xs",
								children: "Cancel"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1869,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: handleSendBroadcast,
								className: "px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl shadow text-xs flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Send, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1879,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Send Toast Alert" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1880,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1875,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1868,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1847,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1846,
				columnNumber: 9
			}, this),
			showAddModal && /* @__PURE__ */ _jsxDEV("div", {
				className: "fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between pb-2 border-b border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("h3", {
								className: "font-extrabold text-white text-base flex items-center gap-2",
								children: [/* @__PURE__ */ _jsxDEV(UserPlus, { className: "w-5 h-5 text-blue-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1893,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Register New Operator ID" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1894,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1892,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setShowAddModal(false),
								className: "text-slate-400 hover:text-white",
								children: "✕"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1896,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1891,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-300",
							children: [
								"This new operator ID will bind to ",
								/* @__PURE__ */ _jsxDEV("b", { children: "1 Authorized PC" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1900,
									columnNumber: 49
								}, this),
								" + ",
								/* @__PURE__ */ _jsxDEV("b", { children: "1 Authorized Mobile" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1900,
									columnNumber: 74
								}, this),
								" upon their first login from each device."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1899,
							columnNumber: 13
						}, this),
						addError && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs",
							children: addError
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1904,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("form", {
							onSubmit: handleCreateOperator,
							className: "space-y-3 text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-400 block mb-1",
									children: "Operator Full Name"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1911,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									required: true,
									placeholder: "e.g. Shaikh Sameer",
									value: newDisplayName,
									onChange: (e) => setNewDisplayName(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-bold"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1912,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1910,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-400 block mb-1",
									children: "Username (Login ID)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1923,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									required: true,
									placeholder: "e.g. operator3",
									value: newUsername,
									onChange: (e) => setNewUsername(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono font-bold"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1924,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1922,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-400 block mb-1",
									children: "Password"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1935,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "password",
									required: true,
									placeholder: "Create secure password",
									value: newPassword,
									onChange: (e) => setNewPassword(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1936,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1934,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-400 block mb-1",
									children: "Phone Number"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1947,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "tel",
									placeholder: "Mobile number",
									value: newPhone,
									onChange: (e) => setNewPhone(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1948,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1946,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pt-2 flex items-center justify-end gap-2",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setShowAddModal(false),
										className: "px-4 py-2 bg-slate-800 text-slate-300 font-bold rounded-xl",
										children: "Cancel"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1958,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "submit",
										className: "px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl shadow",
										children: "Register Operator"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1965,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1957,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1909,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1890,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1889,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 569,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQ0UsYUFDQSxNQUNBLFFBQ0EsWUFDQSxRQUNBLFdBQ0EsVUFDQSxRQUNBLFVBQ0EsY0FDQSxhQUNBLE9BQ0EsS0FDQSxVQUVBLE9BQ0EsU0FDQSxXQUNBLEtBQ0EsU0FDQSxlQUNBLFVBQ0EsUUFFQSxVQUNBLE9BQ0EsT0FDQSxlQUNBLE1BQ0EsVUFJQSxNQUNBLFVBQ0Esb0JBRUs7QUFFUCxTQUNFLHdCQUNBLHdCQUNBLDRCQUNBLDBCQUNBLG9CQUNBLGdCQUNBLGdCQUNBLHNCQUVBLHFCQUNBLHVCQUNBLGdCQUNBLHNCQUNBLHdCQUNBLHlCQUNBLHlCQUNBLG9DQUNLO0FBQ1AsU0FBUyxvQkFBb0IsMEJBQTBCOzs7QUFpQnZELE1BQU0sd0JBQXdDO0NBQzVDO0VBQ0UsWUFBWTtFQUNaLE9BQU87RUFDUCxhQUFhO0VBQ2IsV0FBVztHQUFDO0dBQWE7R0FBd0I7RUFBYztFQUMvRCxXQUFXO0dBQ1Q7R0FDQTtHQUNBO0dBQ0E7RUFDRjtFQUNBLE1BQU07Q0FDUjtDQUNBO0VBQ0UsWUFBWTtFQUNaLE9BQU87RUFDUCxhQUFhO0VBQ2IsV0FBVyxDQUFDLDhCQUE4Qix5QkFBeUI7RUFDbkUsV0FBVztHQUNUO0dBQ0E7R0FDQTtHQUNBO0VBQ0Y7RUFDQSxNQUFNO0NBQ1I7Q0FDQTtFQUNFLFlBQVk7RUFDWixPQUFPO0VBQ1AsYUFBYTtFQUNiLFdBQVcsQ0FBQyx3QkFBd0IsMkJBQTJCO0VBQy9ELFdBQVc7R0FDVDtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0Y7RUFDQSxNQUFNO0NBQ1I7Q0FDQTtFQUNFLFlBQVk7RUFDWixPQUFPO0VBQ1AsYUFBYTtFQUNiLFdBQVcsQ0FBQyx1Q0FBdUM7RUFDbkQsV0FBVztHQUNUO0dBQ0E7R0FDQTtHQUNBO0VBQ0Y7RUFDQSxNQUFNO0NBQ1I7Q0FDQTtFQUNFLFlBQVk7RUFDWixPQUFPO0VBQ1AsYUFBYTtFQUNiLFdBQVcsQ0FBQyx1QkFBdUI7RUFDbkMsV0FBVztHQUNUO0dBQ0E7R0FDQTtHQUNBO0VBQ0Y7RUFDQSxNQUFNO0NBQ1I7Q0FDQTtFQUNFLFlBQVk7RUFDWixPQUFPO0VBQ1AsYUFBYTtFQUNiLFdBQVcsQ0FBQyw0QkFBNEI7RUFDeEMsV0FBVztHQUNUO0dBQ0E7R0FDQTtHQUNBO0VBQ0Y7RUFDQSxNQUFNO0NBQ1I7QUFDRjtBQUVBLE9BQU8sTUFBTSxtQkFBbUQsRUFDOUQsVUFDQSxrQkFDQSwyQkFDSTtDQUNKLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUE0QixDQUFDLENBQUM7Q0FDaEUsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQTZCLENBQUMsQ0FBQztDQUNqRSxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBMkYsY0FBYzs7Q0FHakosTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQWdDLENBQUMsQ0FBQztDQUMxRSxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFrQixJQUFJO0NBQ3RFLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQWlCLEVBQUU7O0NBR2pFLE1BQU0sQ0FBQyxvQkFBb0IseUJBQXlCLFNBQWlDLElBQUk7Q0FDekYsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBaUIsRUFBRTs7Q0FHL0QsTUFBTSxDQUFDLHlCQUF5Qiw4QkFBOEIsU0FBd0IsSUFBSTtDQUMxRixNQUFNLENBQUMsc0JBQXNCLDJCQUEyQixTQUFpQixFQUFFOztDQUczRSxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBa0IsS0FBSztDQUMvRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBaUIsRUFBRTtDQUN6RCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBaUIsRUFBRTtDQUN6RCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFpQixFQUFFO0NBQy9ELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBaUIsRUFBRTtDQUNuRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQWlCLEVBQUU7O0NBR25ELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQWtCLEtBQUs7Q0FDbkUsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQTRDO0VBQUUsU0FBUztFQUFHLE1BQU07Q0FBRyxDQUFDOztDQUcxRyxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFrQixLQUFLO0NBQ25FLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFrQixLQUFLO0NBQ2pFLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQWtCLEtBQUs7Q0FDbkUsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBdUQsSUFBSTs7Q0FHM0csTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQXdCLElBQUk7O0NBR3BFLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBdUIsUUFBUTs7Q0FHL0QsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBa0MsQ0FBQyxDQUFDO0NBRWhGLE1BQU0sa0JBQWtCLG9CQUFvQjtDQUM1QyxNQUFNLG9CQUFvQixzQkFBc0I7Q0FDaEQsTUFBTSxrQkFBa0IsZUFBZTtDQUV2QyxNQUFNLGlCQUFpQjtFQUNyQixhQUFhLHVCQUF1QixDQUFDO0VBQ3JDLGFBQWEscUJBQXFCLENBQUM7Q0FDckM7Q0FFQSxNQUFNLHNCQUFzQixZQUFZO0VBQ3RDLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSx3QkFBd0I7R0FDL0MsZ0JBQWdCLFFBQVE7R0FDeEIsbUJBQW1CLElBQUksS0FBSyxDQUFDLENBQUMsbUJBQW1CLENBQUM7RUFDcEQsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7RUFDakI7Q0FDRjtDQUVBLGdCQUFnQjtFQUNkLFNBQVM7RUFDVCxvQkFBb0I7Q0FDdEIsR0FBRyxDQUFDLENBQUM7O0NBR0wsZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLGtCQUFrQjtFQUN2QixNQUFNLFdBQVcsa0JBQWtCO0dBQ2pDLG9CQUFvQjtFQUN0QixHQUFHLElBQUk7RUFDUCxhQUFhLGNBQWMsUUFBUTtDQUNyQyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7O0NBR3JCLE1BQU0sNkJBQTZCO0VBQ2pDLElBQUksQ0FBQyxvQkFBb0I7RUFDekIsTUFBTSxTQUFTLHFCQUFxQixtQkFBbUIsSUFBSSxjQUFjO0VBQ3pFLElBQUksT0FBTyxTQUFTO0dBQ2xCLFNBQVM7R0FDVCxvQkFBb0I7R0FDcEIsZ0JBQWdCLHlCQUF5QixtQkFBbUIsWUFBWSxpQkFBaUIsT0FBTyxVQUFVLElBQUksT0FBTyxTQUFTLGlCQUFpQjtHQUMvSSxzQkFBc0IsSUFBSTtHQUMxQixpQkFBaUIsZ0JBQWdCLElBQUksR0FBRyxHQUFJO0VBQzlDO0NBQ0Y7O0NBR0EsTUFBTSx3QkFBd0IsT0FBTyxVQUFrQixhQUFzQjtFQUMzRSxJQUFJLE9BQU8sUUFBUSx1Q0FBdUMsU0FBUywyQ0FBMkMsR0FBRztHQUMvRyxNQUFNLHdCQUF3QixVQUFVLFFBQVE7R0FDaEQsb0JBQW9CO0dBQ3BCLGdCQUFnQixtQkFBbUIsU0FBUyxpQ0FBaUM7R0FDN0UsaUJBQWlCLGdCQUFnQixJQUFJLEdBQUcsR0FBSTtFQUM5QztDQUNGOztDQUdBLE1BQU0sc0JBQXNCLFlBQVk7RUFDdEMsSUFBSSxDQUFDLDJCQUEyQixDQUFDLHFCQUFxQixLQUFLLEdBQUc7RUFDOUQsTUFBTSw2QkFBNkIseUJBQXlCLHFCQUFxQixLQUFLLENBQUM7RUFDdkYsZ0JBQWdCLDZCQUE2Qix3QkFBd0IsRUFBRTtFQUN2RSwyQkFBMkIsSUFBSTtFQUMvQix3QkFBd0IsRUFBRTtFQUMxQixpQkFBaUIsZ0JBQWdCLElBQUksR0FBRyxHQUFJO0NBQzlDOztDQUdBLE1BQU0saUJBQWlCLFlBQW9CLGFBQXFCO0VBQzlELElBQUksT0FBTyxRQUFRLGdDQUFnQyxTQUFTLCtDQUErQyxHQUFHO0dBQzVHLHVCQUF1QixVQUFVO0dBQ2pDLFNBQVM7R0FDVCxvQkFBb0I7R0FDcEIsZ0JBQWdCLG1DQUFtQyxTQUFTLDhCQUE4QjtHQUMxRixpQkFBaUIsZ0JBQWdCLElBQUksR0FBRyxHQUFJO0VBQzlDO0NBQ0Y7O0NBR0EsTUFBTSxxQkFBcUIsWUFBb0IsYUFBcUI7RUFDbEUsSUFBSSxPQUFPLFFBQVEsb0NBQW9DLFNBQVMsZ0RBQWdELEdBQUc7R0FDakgsMkJBQTJCLFVBQVU7R0FDckMsU0FBUztHQUNULG9CQUFvQjtHQUNwQixnQkFBZ0IsdUNBQXVDLFNBQVMsaUNBQWlDO0dBQ2pHLGlCQUFpQixnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7RUFDOUM7Q0FDRjs7Q0FHQSxNQUFNLHlCQUF5QixZQUFvQixhQUFxQjtFQUN0RSxJQUFJLE9BQU8sUUFBUSx3Q0FBd0MsU0FBUyxHQUFHLEdBQUc7R0FDeEUseUJBQXlCLFVBQVU7R0FDbkMsU0FBUztHQUNULG9CQUFvQjtHQUNwQixnQkFBZ0IsbURBQW1ELFNBQVMsRUFBRTtHQUM5RSxpQkFBaUIsZ0JBQWdCLElBQUksR0FBRyxHQUFJO0VBQzlDO0NBQ0Y7O0NBR0EsTUFBTSxvQkFBb0IsWUFBb0IsYUFBcUI7RUFDakUsbUJBQW1CLFVBQVU7RUFDN0IsU0FBUztFQUNULG9CQUFvQjtFQUNwQixnQkFBZ0IsMkJBQTJCLFVBQVU7RUFDckQsaUJBQWlCLGdCQUFnQixJQUFJLEdBQUcsR0FBSTtDQUM5Qzs7Q0FHQSxNQUFNLHdCQUF3QixZQUFvQixhQUFxQjtFQUNyRSxJQUFJLE9BQU8sUUFBUSx3Q0FBd0MsU0FBUyxHQUFHLEdBQUc7R0FDeEUsZUFBZSxVQUFVO0dBQ3pCLFNBQVM7R0FDVCxvQkFBb0I7R0FDcEIsZ0JBQWdCLFlBQVksU0FBUyxTQUFTO0dBQzlDLGlCQUFpQixnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7RUFDOUM7Q0FDRjs7Q0FHQSxNQUFNLHdCQUF3QixNQUF1QjtFQUNuRCxFQUFFLGVBQWU7RUFDakIsWUFBWSxFQUFFO0VBRWQsSUFBSSxDQUFDLFlBQVksS0FBSyxLQUFLLENBQUMsWUFBWSxLQUFLLEtBQUssQ0FBQyxlQUFlLEtBQUssR0FBRztHQUN4RSxZQUFZLGlDQUFpQztHQUM3QztFQUNGO0VBRUEsTUFBTSxVQUFVLGVBQWU7R0FDN0IsVUFBVSxZQUFZLEtBQUssQ0FBQyxDQUFDLFlBQVk7R0FDekMsVUFBVSxZQUFZLEtBQUs7R0FDM0IsYUFBYSxlQUFlLEtBQUs7R0FDakMsTUFBTTtHQUNOLE9BQU8sU0FBUyxLQUFLLEtBQUs7RUFDNUIsQ0FBQztFQUVELElBQUksU0FBUztHQUNYLGdCQUFnQixLQUFLO0dBQ3JCLGVBQWUsRUFBRTtHQUNqQixlQUFlLEVBQUU7R0FDakIsa0JBQWtCLEVBQUU7R0FDcEIsWUFBWSxFQUFFO0dBQ2QsU0FBUztHQUNULG9CQUFvQjtHQUNwQixnQkFBZ0IsZ0ZBQWdGO0dBQ2hHLGlCQUFpQixnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7RUFDOUMsT0FBTztHQUNMLFlBQVksMERBQTBEO0VBQ3hFO0NBQ0Y7O0NBR0EsTUFBTSxvQkFBb0IsWUFBWTtFQUNwQyxrQkFBa0IsSUFBSTtFQUN0QixlQUFlO0dBQUUsU0FBUztHQUFJLE1BQU07RUFBb0MsQ0FBQztFQUV6RSxJQUFJO0dBQ0YsTUFBTSxVQUFVLE1BQU0sb0JBQW9CLFNBQVMsU0FBUztJQUMxRCxlQUFlO0tBQUU7S0FBUztJQUFLLENBQUM7R0FDbEMsQ0FBQztHQUVELG1CQUFtQixTQUFTLGdDQUFnQztHQUM1RCxnQkFBZ0IsMEVBQTBFO0dBQzFGLGlCQUFpQixnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7RUFDOUMsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7R0FDZixPQUFPLFNBQVMsT0FBTztFQUN6QixVQUFVO0dBQ1Isa0JBQWtCLEtBQUs7RUFDekI7Q0FDRjtDQUVBLE1BQU0scUJBQXFCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0E4QzNCLE1BQU0sdUJBQXVCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXFCN0IsTUFBTSwwQkFBMEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBdUNoQyxNQUFNLGtDQUFrQztFQUN0QyxNQUFNLE9BQU8sSUFBSSxLQUFLLENBQUMsa0JBQWtCLEdBQUcsRUFBRSxNQUFNLFlBQVksQ0FBQztFQUNqRSxNQUFNLE1BQU0sSUFBSSxnQkFBZ0IsSUFBSTtFQUNwQyxNQUFNLElBQUksU0FBUyxjQUFjLEdBQUc7RUFDcEMsRUFBRSxPQUFPO0VBQ1QsRUFBRSxXQUFXO0VBQ2IsRUFBRSxNQUFNO0VBQ1IsSUFBSSxnQkFBZ0IsR0FBRztFQUN2QixnQkFBZ0Isc0VBQW9FO0VBQ3BGLGlCQUFpQixnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7Q0FDOUM7O0NBR0EsTUFBTSxpQ0FBaUM7RUFDckMsTUFBTSxPQUFPLElBQUksS0FBSyxDQUFDLG9CQUFvQixHQUFHLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztFQUMzRSxNQUFNLE1BQU0sSUFBSSxnQkFBZ0IsSUFBSTtFQUNwQyxNQUFNLElBQUksU0FBUyxjQUFjLEdBQUc7RUFDcEMsRUFBRSxPQUFPO0VBQ1QsRUFBRSxXQUFXO0VBQ2IsRUFBRSxNQUFNO0VBQ1IsSUFBSSxnQkFBZ0IsR0FBRztFQUN2QixnQkFBZ0IsMkRBQXlEO0VBQ3pFLGlCQUFpQixnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7Q0FDOUM7O0NBR0EsTUFBTSxpQ0FBaUM7RUFDckMsTUFBTSxPQUFPLElBQUksS0FBSyxDQUFDLHVCQUF1QixHQUFHLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztFQUM5RSxNQUFNLE1BQU0sSUFBSSxnQkFBZ0IsSUFBSTtFQUNwQyxNQUFNLElBQUksU0FBUyxjQUFjLEdBQUc7RUFDcEMsRUFBRSxPQUFPO0VBQ1QsRUFBRSxXQUFXO0VBQ2IsRUFBRSxNQUFNO0VBQ1IsSUFBSSxnQkFBZ0IsR0FBRztFQUN2QixnQkFBZ0Isb0VBQWtFO0VBQ2xGLGlCQUFpQixnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7Q0FDOUM7O0NBR0EsTUFBTSwrQkFBK0I7RUFDbkMsVUFBVSxVQUFVLFVBQVUsa0JBQWtCO0VBQ2hELGtCQUFrQixJQUFJO0VBQ3RCLGdCQUFnQiwyREFBMkQ7RUFDM0UsaUJBQWlCO0dBQ2Ysa0JBQWtCLEtBQUs7R0FDdkIsZ0JBQWdCLElBQUk7RUFDdEIsR0FBRyxHQUFJO0NBQ1Q7Q0FFQSxNQUFNLDhCQUE4QjtFQUNsQyxVQUFVLFVBQVUsVUFBVSxvQkFBb0I7RUFDbEQsaUJBQWlCLElBQUk7RUFDckIsZ0JBQWdCLDBFQUEwRTtFQUMxRixpQkFBaUI7R0FDZixpQkFBaUIsS0FBSztHQUN0QixnQkFBZ0IsSUFBSTtFQUN0QixHQUFHLEdBQUk7Q0FDVDtDQUVBLE1BQU0saUNBQWlDO0VBQ3JDLFVBQVUsVUFBVSxVQUFVLHVCQUF1QjtFQUNyRCxrQkFBa0IsSUFBSTtFQUN0QixnQkFBZ0IsMEVBQTBFO0VBQzFGLGlCQUFpQjtHQUNmLGtCQUFrQixLQUFLO0dBQ3ZCLGdCQUFnQixJQUFJO0VBQ3RCLEdBQUcsR0FBSTtDQUNUOztDQUdBLE1BQU0sc0JBQXNCLE1BQXVCO0VBQ2pELEVBQUUsZUFBZTtFQUNqQixpQkFBaUIsUUFBUTtFQUN6QixnQkFBZ0IseUNBQXlDO0VBQ3pELGlCQUFpQixnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7Q0FDOUM7Q0FFQSxNQUFNLHlCQUF5QixPQUFPLE9BQU8sY0FBYyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQztDQUM3RSxNQUFNLGNBQWMsYUFBYSxRQUFPLE1BQUssRUFBRSxRQUFRLENBQUMsQ0FBQztDQUV6RCxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZCxDQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLHdCQUF5Qjs7OztnQkFDaEQsd0JBQUMsUUFBRCxZQUFNLDZDQUFnRDs7OztjQUNwRDs7Ozs7ZUFDSix3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEIsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxvREFBMEQ7Ozs7Z0JBQzFFLHdCQUFDLFFBQUQ7T0FBTTtPQUFPO09BQVk7TUFBb0I7Ozs7Y0FDekM7Ozs7O2FBQ0g7Ozs7O2NBQ0wsd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBOEI7SUFFeEM7Ozs7WUFDQTs7OztjQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ2Isd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxVQUFVO01BQ1YsV0FBVTtNQUNWLE9BQU07Z0JBSlIsQ0FNRSx3QkFBQyxTQUFELEVBQVMsV0FBVSxVQUFXOzs7O2dCQUM5Qix3QkFBQyxRQUFELFlBQU8saUJBQWlCLG1CQUFtQiwyQkFBaUM7Ozs7Y0FDdEU7Ozs7OztJQUNMOzs7O1lBQ0Y7Ozs7OztHQUdKLGdCQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsY0FBRCxFQUFjLFdBQVUseUNBQTBDOzs7O2VBQ2xFLHdCQUFDLFFBQUQsWUFBTyxhQUFtQjs7OzthQUN2Qjs7Ozs7Y0FDTCx3QkFBQyxVQUFEO0tBQVEsZUFBZSxnQkFBZ0IsSUFBSTtLQUFHLFdBQVU7ZUFBb0M7SUFBUzs7OztZQUNsRzs7Ozs7O0dBSVAsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLGdCQUFnQixjQUFjO01BQzdDLFdBQVcsaUVBQ1QsaUJBQWlCLGlCQUNiLGtDQUNBO2dCQUxSLENBUUUsd0JBQUMsT0FBRCxFQUFPLFdBQVUsdUNBQXdDOzs7O2dCQUN6RCx3QkFBQyxRQUFEO09BQU07T0FBMkI7T0FBWTtNQUFPOzs7O2NBQzlDOzs7Ozs7S0FFUix3QkFBQyxVQUFEO01BQ0UsZUFBZSxnQkFBZ0IsV0FBVztNQUMxQyxXQUFXLGlFQUNULGlCQUFpQixjQUNiLGtDQUNBO2dCQUxSLENBUUUsd0JBQUMsU0FBRCxFQUFTLFdBQVUsY0FBZTs7OztnQkFDbEMsd0JBQUMsUUFBRDtPQUFNO09BQXVCLFVBQVU7T0FBTztNQUFPOzs7O2NBQy9DOzs7Ozs7S0FFUix3QkFBQyxVQUFEO01BQ0UsZUFBZSxnQkFBZ0IsVUFBVTtNQUN6QyxXQUFXLGlFQUNULGlCQUFpQixhQUNiLGtDQUNBO2dCQUxSLENBUUUsd0JBQUMsZUFBRCxFQUFlLFdBQVUsNkJBQThCOzs7O2dCQUN2RCx3QkFBQyxRQUFELFlBQU0sNEJBQStCOzs7O2NBQy9COzs7Ozs7S0FFUix3QkFBQyxVQUFEO01BQ0UsZUFBZSxnQkFBZ0IsY0FBYztNQUM3QyxXQUFXLGlFQUNULGlCQUFpQixpQkFDYixrQ0FDQTtnQkFMUixDQVFFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLCtCQUFnQzs7OztnQkFDbkQsd0JBQUMsUUFBRCxZQUFNLGlEQUFvRDs7OztjQUNwRDs7Ozs7O0tBRVIsd0JBQUMsVUFBRDtNQUNFLGVBQWUsZ0JBQWdCLE1BQU07TUFDckMsV0FBVyxpRUFDVCxpQkFBaUIsU0FDYixrQ0FDQTtnQkFMUixDQVFFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLGNBQWU7Ozs7Z0JBQ2hDLHdCQUFDLFFBQUQsWUFBTSx5QkFBNEI7Ozs7Y0FDNUI7Ozs7OztLQUVSLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLGdCQUFnQixVQUFVO01BQ3pDLFdBQVcsaUVBQ1QsaUJBQWlCLGFBQ2Isa0NBQ0E7Z0JBTFIsQ0FRRSx3QkFBQyxLQUFELEVBQUssV0FBVSxjQUFlOzs7O2dCQUM5Qix3QkFBQyxRQUFELFlBQU0sc0JBQXlCOzs7O2NBQ3pCOzs7Ozs7SUFDTDs7Ozs7O0dBR0osaUJBQWlCLGtCQUNoQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQ7UUFDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSxzQ0FBdUM7Ozs7O1FBQ3hELHdCQUFDLFFBQUQsWUFBTSwyQ0FBOEM7Ozs7O1FBQ3BELHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUF3RztRQUVsSDs7Ozs7T0FDSjs7Ozs7Z0JBQ0osd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWdDO01BRTFDOzs7O2NBQ0E7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1FBQ0UsZUFBZSxvQkFBb0IsQ0FBQyxnQkFBZ0I7UUFDcEQsV0FBVywrRkFDVCxtQkFDSSw2REFDQTtrQkFMUixDQVFFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLGNBQWU7Ozs7a0JBQ25DLHdCQUFDLFFBQUQsWUFBTyxtQkFBbUIsb0JBQW9CLFNBQWU7Ozs7Z0JBQ3ZEOzs7OztpQkFFUix3QkFBQyxVQUFEO1FBQ0UsU0FBUztRQUNULFdBQVU7UUFDVixPQUFNO2tCQUVOLHdCQUFDLFdBQUQsRUFBVyxXQUFVLGNBQWU7Ozs7O09BQzlCOzs7O2VBQ0w7Ozs7O2NBQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBbUM7U0FBeUI7Ozs7O1NBQzVFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsdURBQTZEOzs7O29CQUM3RSx3QkFBQyxRQUFELFlBQU8sWUFBa0I7Ozs7a0JBQ3RCOzs7Ozs7U0FDTCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBeUM7U0FBMEI7Ozs7O1FBQ2hGOzs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFtQztTQUE0Qjs7Ozs7U0FDL0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7O29CQUM3Qix3QkFBQyxRQUFELFlBQU8sYUFBYSxRQUFPLE1BQUssRUFBRSxlQUFlLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQyxPQUFhOzs7O2tCQUMvRTs7Ozs7O1NBQ0wsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTZCO1NBQTBCOzs7OztRQUNwRTs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBbUM7U0FBNEI7Ozs7O1NBQy9FLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsWUFBRCxFQUFZLFdBQVUsVUFBVzs7OztvQkFDakMsd0JBQUMsUUFBRCxZQUFPLGFBQWEsUUFBTyxNQUFLLEVBQUUsZUFBZSxZQUFZLEVBQUUsUUFBUSxDQUFDLENBQUMsT0FBYTs7OztrQkFDbkY7Ozs7OztTQUNMLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE2QjtTQUF1Qjs7Ozs7UUFDakU7Ozs7OztPQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQW1DO1NBQXVCOzs7OztTQUMxRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWixtQkFBbUI7U0FDakI7Ozs7O1NBQ0wsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTZCO1NBQW9COzs7OztRQUM5RDs7Ozs7O01BQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUFqQixDQUNFLHdCQUFDLFNBQUQsWUFDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZDtTQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFZO1NBQWU7Ozs7O1NBQ3pDLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFZO1NBQWlCOzs7OztTQUMzQyx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBWTtTQUFvQjs7Ozs7U0FDOUMsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQVk7U0FBd0I7Ozs7O1NBQ2xELHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFZO1NBQW9COzs7OztTQUM5Qyx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBdUI7U0FBaUI7Ozs7O1FBQ3BEOzs7OztnQkFDQzs7OztpQkFDUCx3QkFBQyxTQUFEO1FBQU8sV0FBVTtrQkFDZCxhQUFhLEtBQUssWUFBWTtTQUM3QixNQUFNLFdBQVcsdUJBQXVCLFFBQVEsaUJBQWlCO1NBQ2pFLE1BQU0sYUFBYSxXQUFXO1NBRTlCLE9BQ0Usd0JBQUMsTUFBRDtVQUF5RSxXQUFVO29CQUFuRjtXQUVFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUNaLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVcsNEJBQ2YsUUFBUSxXQUFXLGlDQUFpQyxpQkFDNUM7Ozs7dUJBQ1Ysd0JBQUMsUUFBRDtjQUFNLFdBQVcseUJBQ2YsUUFBUSxXQUFXLHFCQUFxQjt3QkFFdkMsUUFBUSxXQUFXLGVBQWUsR0FBRyxRQUFRLHdCQUF3QixHQUFHO2FBQ3JFOzs7O3FCQUNIOzs7Ozs7V0FDSDs7Ozs7V0FHSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBZCxDQUNFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFxQyxRQUFRO1lBQWlCOzs7O3NCQUM3RSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZjtjQUFzRDtjQUFFLFFBQVE7Y0FBUztjQUFJLFFBQVEsU0FBUzthQUFrQjs7Ozs7b0JBQzlHOzs7Ozs7V0FHSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBZCxDQUNFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0csUUFBUSxlQUFlLFdBQ3RCLHdCQUFDLFlBQUQsRUFBWSxXQUFVLDhCQUErQjs7Ozt3QkFFckQsd0JBQUMsUUFBRCxFQUFRLFdBQVUsNEJBQTZCOzs7O3VCQUVqRCx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBeUIsUUFBUTthQUFlOzs7O3FCQUM3RDs7Ozs7c0JBQ0wsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQThCLFFBQVE7WUFBZ0I7Ozs7b0JBQ25FOzs7Ozs7V0FHSix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBaEIsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSx3QkFBeUI7Ozs7dUJBQzdDLHdCQUFDLFFBQUQsWUFBTyxRQUFRLGNBQWMsa0JBQXdCOzs7O3FCQUNqRDs7Ozs7O1dBQ0o7Ozs7O1dBR0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1gsUUFBUSxTQUFTLFdBQVcsUUFBUSxhQUFhLFVBQ2hELHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQ2Isd0JBQUMsUUFBRCxZQUFNLHFCQUF3Qjs7Ozs7YUFDM0I7Ozs7dUJBQ0wsd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQXlDO2FBQThCOzs7O3FCQUNuRjs7Ozs7dUJBRUwsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FDRSx3QkFBQyxPQUFEO2NBQUssV0FBVyxtQ0FDZCxhQUFhLGtCQUFrQjt3QkFFOUIsV0FBVyxJQUFJLEdBQUcsU0FBUyxjQUFjO2FBQ3ZDOzs7O3VCQUNMLHdCQUFDLE9BQUQ7Y0FBSyxXQUFVO3dCQUFmLENBQTRDLFNBQU0sUUFBUSxxQkFBcUIsWUFBa0I7Ozs7O3FCQUM5Rjs7Ozs7O1dBRUw7Ozs7O1dBR0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1osd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWY7Y0FFRSx3QkFBQyxVQUFEO2VBQ0UsZUFBZTtnQkFDYixNQUFNLFFBQVEsVUFBVSxNQUFLLE1BQUssRUFBRSxhQUFhLFFBQVEsUUFBUTtnQkFDakUsSUFBSSxPQUFPLHNCQUFzQixLQUFLO2VBQ3hDO2VBQ0EsV0FBVTtlQUNWLE9BQU07eUJBTlIsQ0FRRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7O3lCQUMvQix3QkFBQyxRQUFELFlBQU0sUUFBVzs7Ozt1QkFDWDs7Ozs7O2NBR1Isd0JBQUMsVUFBRDtlQUNFLGVBQWU7Z0JBQ2IsMkJBQTJCLFFBQVEsUUFBUTtnQkFDM0Msd0JBQXdCLEVBQUU7ZUFDNUI7ZUFDQSxXQUFVO2VBQ1YsT0FBTTt5QkFFTix3QkFBQyxlQUFELEVBQWUsV0FBVSxVQUFXOzs7OztjQUM5Qjs7Ozs7Y0FHUix3QkFBQyxVQUFEO2VBQ0UsZUFBZSxzQkFBc0IsUUFBUSxVQUFVLFFBQVEsUUFBUTtlQUN2RSxXQUFVO2VBQ1YsT0FBTTt5QkFFTix3QkFBQyxPQUFELEVBQU8sV0FBVSxVQUFXOzs7OztjQUN0Qjs7Ozs7YUFDTDs7Ozs7O1dBQ0g7Ozs7O1VBQ0Y7WUFyR0ssUUFBUSxhQUFhLEdBQUcsUUFBUSxTQUFTLEdBQUcsUUFBUTs7OztnQkFxR3pEO1FBRVIsQ0FBQztPQUNJOzs7O2VBQ0Y7Ozs7OztLQUNKOzs7OztJQUNGOzs7Ozs7R0FJTixpQkFBaUIsZUFDaEIsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkLENBQ0Usd0JBQUMsUUFBRCxZQUFNLDZDQUFnRDs7OztpQkFDdEQsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXdHO09BRWxIOzs7O2VBQ0o7Ozs7O2dCQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFiO1FBQTZDO1FBQ2Qsd0JBQUMsS0FBRCxZQUFHLGtCQUFrQjs7Ozs7UUFBQztRQUFLLHdCQUFDLEtBQUQsWUFBRyxzQkFBc0I7Ozs7O1FBQUM7T0FDakY7Ozs7O2NBQ0E7Ozs7Z0JBRUwsd0JBQUMsVUFBRDtPQUNFLGVBQWUsZ0JBQWdCLElBQUk7T0FDbkMsV0FBVTtpQkFGWixDQUlFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFVBQVc7Ozs7aUJBQy9CLHdCQUFDLFFBQUQsWUFBTSwyQkFBOEI7Ozs7ZUFDOUI7Ozs7O2NBQ0w7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxLQUFELEVBQUssV0FBVSx3QkFBeUI7Ozs7O1FBQ3hDLHdCQUFDLFFBQUQ7U0FBTTtTQUF1QixrQkFBa0IsY0FBYztTQUFRO1FBQVE7Ozs7O1FBQzdFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNiO1FBQ0c7Ozs7O09BQ0g7Ozs7O2dCQUNMLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUF3QztNQUF3Qjs7OztjQUM3RTs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQWpCLENBQ0Usd0JBQUMsU0FBRCxZQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkO1NBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQVk7U0FBdUI7Ozs7O1NBQ2pELHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFZO1NBQVE7Ozs7O1NBQ2xDLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFZO1NBQXlCOzs7OztTQUNuRCx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBWTtTQUE2Qjs7Ozs7U0FDdkQsd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQVk7U0FBa0I7Ozs7O1NBQzVDLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUF1QjtTQUEwQjs7Ozs7UUFDN0Q7Ozs7O2dCQUNDOzs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO2tCQUNkLFVBQVUsS0FBSyxPQUFPO1NBQ3JCLE1BQU0sV0FBVyx1QkFBdUIsR0FBRyxpQkFBaUI7U0FFNUQsT0FDRSx3QkFBQyxNQUFEO1VBQWdCLFdBQVU7b0JBQTFCO1dBRUUsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWQsQ0FDRSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZ0MsR0FBRztZQUFpQjs7OztzQkFDbkUsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWY7Y0FBc0Q7Y0FBRSxHQUFHO2NBQVM7Y0FBSSxHQUFHO2FBQVc7Ozs7O29CQUNwRjs7Ozs7O1dBR0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1osd0JBQUMsUUFBRDthQUFNLFdBQVcsaUVBQ2YsR0FBRyxTQUFTLFVBQ1IsaUVBQ0E7dUJBRUgsR0FBRyxTQUFTLFVBQVUsaUJBQWlCO1lBQ3BDOzs7OztXQUNKOzs7OztXQUdKLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUNYLEdBQUcsa0JBQ0Ysd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWY7Y0FDRSx3QkFBQyxPQUFEO2VBQUssV0FBVTt5QkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDRCQUE2Qjs7Ozt5QkFDL0Msd0JBQUMsUUFBRDtnQkFBTSxXQUFVOzBCQUF5QixHQUFHO2VBQXNCOzs7O3VCQUMvRDs7Ozs7O2NBQ0wsd0JBQUMsT0FBRDtlQUFLLFdBQVU7eUJBQXFELEdBQUcscUJBQXFCO2NBQXNCOzs7OztjQUNsSCx3QkFBQyxVQUFEO2VBQ0UsZUFBZSxjQUFjLEdBQUcsSUFBSSxHQUFHLFFBQVE7ZUFDL0MsV0FBVTt5QkFGWixDQUlFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLGNBQWU7Ozs7eUJBQ3BDLHdCQUFDLFFBQUQsWUFBTSxtQkFBc0I7Ozs7dUJBQ3RCOzs7Ozs7YUFDTDs7Ozs7dUJBRUwsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQXdHO1lBRWxIOzs7OztXQUVOOzs7OztXQUdKLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUNYLEdBQUcsc0JBQ0Ysd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWY7Y0FDRSx3QkFBQyxPQUFEO2VBQUssV0FBVTt5QkFBZixDQUNFLHdCQUFDLFlBQUQsRUFBWSxXQUFVLDhCQUErQjs7Ozt5QkFDckQsd0JBQUMsUUFBRDtnQkFBTSxXQUFVOzBCQUF5QixHQUFHO2VBQTBCOzs7O3VCQUNuRTs7Ozs7O2NBQ0wsd0JBQUMsT0FBRDtlQUFLLFdBQVU7eUJBQXFELEdBQUcseUJBQXlCO2NBQWtCOzs7OztjQUNsSCx3QkFBQyxVQUFEO2VBQ0UsZUFBZSxrQkFBa0IsR0FBRyxJQUFJLEdBQUcsUUFBUTtlQUNuRCxXQUFVO3lCQUZaLENBSUUsd0JBQUMsV0FBRCxFQUFXLFdBQVUsY0FBZTs7Ozt5QkFDcEMsd0JBQUMsUUFBRCxZQUFNLHVCQUEwQjs7Ozt1QkFDMUI7Ozs7OzthQUNMOzs7Ozt1QkFFTCx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBd0c7WUFFbEg7Ozs7O1dBRU47Ozs7O1dBR0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQ1gsR0FBRyxTQUFTLFVBQ1gsd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FDRSx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFDZCx3QkFBQyxRQUFELFlBQU0sOEJBQWlDOzs7OzthQUNuQzs7Ozt1QkFDTix3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBK0M7YUFBc0I7Ozs7cUJBQ2xGOzs7Ozt1QkFFTCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNFLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFoQixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLDJCQUE0Qjs7Ozt3QkFDaEQsd0JBQUMsUUFBRCxhQUFPLFVBQVMsWUFBZ0I7Ozs7c0JBQzVCOzs7Ozt1QkFDTix3QkFBQyxVQUFEO2NBQ0UsZUFBZSxzQkFBc0IsRUFBRTtjQUN2QyxXQUFVO3dCQUNYO2FBRU87Ozs7cUJBQ0w7Ozs7OztXQUVMOzs7OztXQUdKLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUNaLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmO2VBRUksR0FBRyxtQkFBbUIsR0FBRyx3QkFDekIsd0JBQUMsVUFBRDtlQUNFLGVBQWUsc0JBQXNCLEdBQUcsSUFBSSxHQUFHLFFBQVE7ZUFDdkQsV0FBVTtlQUNWLE9BQU07eUJBQ1A7Y0FFTzs7Ozs7Y0FJVCxHQUFHLFNBQVMsV0FDWCx3QkFBQyxVQUFEO2VBQ0UsZUFBZSxpQkFBaUIsR0FBRyxJQUFJLEdBQUcsUUFBUTtlQUNsRCxXQUFXLG1DQUNULEdBQUcsV0FDQyxxRkFDQTtlQUVOLE9BQU8sR0FBRyxXQUFXLG9CQUFvQjt5QkFFeEMsR0FBRyxXQUFXLHdCQUFDLFFBQUQsRUFBUSxXQUFVLGNBQWU7Ozs7MEJBQUksd0JBQUMsTUFBRCxFQUFNLFdBQVUsY0FBZTs7Ozs7Y0FDN0U7Ozs7O2NBSVQsR0FBRyxTQUFTLFdBQ1gsd0JBQUMsVUFBRDtlQUNFLGVBQWUscUJBQXFCLEdBQUcsSUFBSSxHQUFHLFFBQVE7ZUFDdEQsV0FBVTtlQUNWLE9BQU07eUJBRU4sd0JBQUMsUUFBRCxFQUFRLFdBQVUsY0FBZTs7Ozs7Y0FDM0I7Ozs7O2FBRVA7Ozs7OztXQUNIOzs7OztVQUNGO1lBcElLLEdBQUc7Ozs7Z0JBb0lSO1FBRVIsQ0FBQztPQUNJOzs7O2VBQ0Y7Ozs7OztLQUNKOzs7OztJQUNGOzs7Ozs7R0FJTixpQkFBaUIsY0FDaEIsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWQ7T0FDRSx3QkFBQyxlQUFELEVBQWUsV0FBVSx5QkFBMEI7Ozs7O09BQ25ELHdCQUFDLFFBQUQsWUFBTSxnREFBbUQ7Ozs7O09BQ3pELHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFrRztPQUU1Rzs7Ozs7TUFDSjs7Ozs7ZUFDSix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBZ0M7S0FFMUM7Ozs7YUFDQTs7OztlQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQThHLGVBQ2pHLHdCQUFDLFVBQUQ7T0FBUSxXQUFVO2lCQUFsQjtRQUFzQztRQUF1QjtRQUFJLHNCQUFzQjtRQUFPO09BQWtCOzs7OztjQUN4SDs7Ozs7YUFDRjs7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLHNCQUFzQixLQUFLLFNBQVM7TUFDbkMsTUFBTSxTQUFTLENBQUMsQ0FBQyxlQUFlLEtBQUs7TUFDckMsT0FDRSx3QkFBQyxPQUFEO09BRUUsV0FBVyxrREFDVCxTQUNJLDBDQUNBO2lCQUxSO1FBUUUsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFXLG1GQUNmLFNBQVMsa0NBQWtDO3FCQUUxQyxLQUFLO1VBQ0Y7Ozs7b0JBQ04sd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQXFDLEtBQUs7VUFBVTs7OztrQkFDL0Q7Ozs7O21CQUVMLHdCQUFDLFVBQUQ7VUFDRSxlQUFlLG1CQUFrQixVQUFTO1dBQUUsR0FBRztZQUFPLEtBQUssYUFBYSxDQUFDLEtBQUssS0FBSztVQUFZLEVBQUU7VUFDakcsV0FBVywrRUFDVCxTQUNJLDZEQUNBO29CQUxSLENBUUcsU0FBUyx3QkFBQyxjQUFELEVBQWMsV0FBVSwrQkFBZ0M7Ozs7cUJBQUksd0JBQUMsUUFBRCxFQUFRLFdBQVUsY0FBZTs7OztvQkFDdkcsd0JBQUMsUUFBRCxZQUFPLFNBQVMsU0FBUyxPQUFhOzs7O2tCQUNoQzs7Ozs7aUJBQ0w7Ozs7OztRQUVMLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUEyQyxLQUFLO1FBQWU7Ozs7O1FBRTVFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaLEtBQUssVUFBVSxLQUFLLE1BQU0sUUFDekIsd0JBQUMsT0FBRDtVQUFlLFdBQVU7b0JBQXpCLENBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWdCO1VBQU87Ozs7b0JBQ3ZDLHdCQUFDLFFBQUQsWUFBTyxLQUFXOzs7O2tCQUNmO1lBSEs7Ozs7Z0JBR0wsQ0FDTjtRQUNFOzs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsOENBQStDOzs7O21CQUNuRSx3QkFBQyxRQUFEO1VBQU0sd0JBQUMsS0FBRCxZQUFHLGlCQUFpQjs7Ozs7VUFBQztVQUFFLEtBQUs7U0FBVzs7OztpQkFDMUM7Ozs7OztPQUNGO1NBN0NFLEtBQUs7Ozs7YUE2Q1A7S0FFVCxDQUFDO0lBQ0U7Ozs7WUFDRjs7Ozs7O0dBSU4saUJBQWlCLGtCQUNoQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7O09BQzNCOzs7O2lCQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWQsQ0FDRSx3QkFBQyxRQUFELFlBQU0sb0NBQXVDOzs7O21CQUM3Qyx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBc0g7U0FFaEk7Ozs7aUJBQ0o7Ozs7O2tCQUNKLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUF5QztRQUVuRDs7OztnQkFDQTs7Ozs7ZUFDRjs7Ozs7Z0JBRUwsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQThHO01BRXhIOzs7O2NBQ0g7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BRUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQTJHO1dBRXJIOzs7O3FCQUNOLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUE0RztXQUV0SDs7OzttQkFDSDs7Ozs7O1VBRUwsd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQW9DO1VBRTlDOzs7OztVQUNKLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUE2QztVQUV2RDs7Ozs7VUFFSCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNFLHdCQUFDLE9BQUQsYUFBSyxVQUFNLHdCQUFDLEtBQUQsWUFBRyxpQ0FBaUM7Ozs7b0JBQU07Ozs7O1lBQ3JELHdCQUFDLE9BQUQsYUFBSyxZQUFRLHdCQUFDLEtBQUQsWUFBRyxvQkFBb0I7Ozs7b0JBQU07Ozs7O1lBQzFDLHdCQUFDLE9BQUQsYUFBSyxVQUFNLHdCQUFDLEtBQUQsWUFBRyxvQkFBb0I7Ozs7b0JBQU07Ozs7O1dBQ3JDOzs7Ozs7U0FDRjs7Ozs7a0JBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1VBQ0UsU0FBUztVQUNULFVBQVU7VUFDVixXQUFVO29CQUhaLENBS0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OztvQkFDL0Isd0JBQUMsUUFBRCxZQUFPLGlCQUFpQix1QkFBdUIsd0JBQThCOzs7O2tCQUN2RTs7Ozs7bUJBRVIsd0JBQUMsS0FBRDtVQUNFLE1BQUs7VUFDTCxVQUFTO1VBQ1QsV0FBVTtvQkFIWixDQUtFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLFVBQVc7Ozs7b0JBQ25DLHdCQUFDLFFBQUQsWUFBTSw4QkFBaUM7Ozs7a0JBQ3RDOzs7OztpQkFDQTs7Ozs7Z0JBQ0Y7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUF5RztXQUVuSDs7OztxQkFDTix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBeUc7V0FFbkg7Ozs7bUJBQ0g7Ozs7OztVQUVMLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFvQztVQUU5Qzs7Ozs7VUFDSix3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBYjtZQUEwRDtZQUNnQix3QkFBQyxLQUFELFlBQUcsT0FBTzs7Ozs7WUFBQztXQUNsRjs7Ozs7O1VBRUgsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxPQUFELGFBQUssVUFBTSx3QkFBQyxLQUFELFlBQUcsd0JBQXdCOzs7O29CQUFNOzs7OztZQUM1Qyx3QkFBQyxPQUFELGFBQUssWUFBUSx3QkFBQyxLQUFELFlBQUcscUJBQXFCOzs7O29CQUFNOzs7OztZQUMzQyx3QkFBQyxPQUFELGFBQUssWUFBUSx3QkFBQyxLQUFELFlBQUcsbUJBQW1COzs7O29CQUFNOzs7OztXQUN0Qzs7Ozs7O1NBQ0Y7Ozs7O2tCQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1dBQ0UsU0FBUztXQUNULFdBQVU7V0FDVixPQUFNO3FCQUhSLENBS0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsY0FBZTs7OztxQkFDbkMsd0JBQUMsUUFBRCxZQUFNLGdCQUFtQjs7OzttQkFDbkI7Ozs7O29CQUVSLHdCQUFDLFVBQUQ7V0FDRSxTQUFTO1dBQ1QsV0FBVyxxR0FDVCxpQkFDSSxpREFDQTtXQUVOLE9BQU07cUJBUFIsQ0FTRyxpQkFBaUIsd0JBQUMsT0FBRCxFQUFPLFdBQVUsY0FBZTs7OztzQkFBSSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O3FCQUNyRix3QkFBQyxRQUFELFlBQU8saUJBQWlCLFlBQVksWUFBa0I7Ozs7bUJBQ2hEOzs7OztrQkFDTDs7Ozs7bUJBRUwsd0JBQUMsVUFBRDtVQUNFLGVBQWUsb0JBQW9CLHFCQUFxQixhQUFhLE9BQU8sVUFBVTtVQUN0RixXQUFVO29CQUZaLENBSUUsd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OztvQkFDL0Isd0JBQUMsUUFBRCxZQUFPLHFCQUFxQixhQUFhLHVCQUF1QixxQkFBMkI7Ozs7a0JBQ3JGOzs7OztpQkFDTDs7Ozs7Z0JBQ0Y7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFxRztXQUUvRzs7OztxQkFDTix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBbUc7V0FFN0c7Ozs7bUJBQ0g7Ozs7OztVQUVMLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUFvQztVQUU5Qzs7Ozs7VUFDSix3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFBNkM7VUFFdkQ7Ozs7O1VBRUgsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxPQUFELGFBQUssWUFBUSx3QkFBQyxLQUFELFlBQUcsd0JBQXdCOzs7O29CQUFNOzs7OztZQUM5Qyx3QkFBQyxPQUFELGFBQUssWUFBUSx3QkFBQyxLQUFELFlBQUcsdUJBQXVCOzs7O29CQUFNOzs7OztZQUM3Qyx3QkFBQyxPQUFELGFBQUssVUFBTSx3QkFBQyxLQUFELFlBQUcsdUJBQXVCOzs7O29CQUFNOzs7OztXQUN4Qzs7Ozs7O1NBQ0Y7Ozs7O2tCQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1dBQ0UsU0FBUztXQUNULFdBQVU7V0FDVixPQUFNO3FCQUhSLENBS0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsY0FBZTs7OztxQkFDbkMsd0JBQUMsUUFBRCxZQUFNLGdCQUFtQjs7OzttQkFDbkI7Ozs7O29CQUVSLHdCQUFDLFVBQUQ7V0FDRSxTQUFTO1dBQ1QsV0FBVyxxR0FDVCxnQkFDSSxpREFDQTtXQUVOLE9BQU07cUJBUFIsQ0FTRyxnQkFBZ0Isd0JBQUMsT0FBRCxFQUFPLFdBQVUsY0FBZTs7OztzQkFBSSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O3FCQUNwRix3QkFBQyxRQUFELFlBQU8sZ0JBQWdCLFlBQVksWUFBa0I7Ozs7bUJBQy9DOzs7OztrQkFDTDs7Ozs7bUJBRUwsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1dBQ0UsU0FBUztXQUNULFdBQVU7V0FDVixPQUFNO3FCQUhSLENBS0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OztxQkFDL0Isd0JBQUMsUUFBRCxZQUFNLDBCQUE2Qjs7OzttQkFDN0I7Ozs7O29CQUVSLHdCQUFDLFVBQUQ7V0FDRSxlQUFlLG9CQUFvQixxQkFBcUIsYUFBYSxPQUFPLFVBQVU7V0FDdEYsV0FBVTtxQkFFVCxxQkFBcUIsYUFBYSxjQUFjO1VBQzNDOzs7O2tCQUNMOzs7OztpQkFDRjs7Ozs7Z0JBQ0Y7Ozs7OztNQUNGOzs7Ozs7S0FHSixvQkFDQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsMkJBQTRCOzs7O2tCQUNoRCx3QkFBQyxRQUFELFlBQ0cscUJBQXFCLGFBQWEsNENBQTRDLHdCQUMzRTs7OztnQkFDRjs7Ozs7aUJBQ04sd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1NBQ0UsU0FBUyxxQkFBcUIsYUFBYSx5QkFBeUI7U0FDcEUsV0FBVTttQkFGWixDQUlFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7bUJBQzNCLHdCQUFDLFFBQUQsWUFBTSxPQUFVOzs7O2lCQUNWOzs7OztrQkFDUix3QkFBQyxVQUFEO1NBQ0UsZUFBZSxvQkFBb0IsSUFBSTtTQUN2QyxXQUFVO21CQUNYO1FBRU87Ozs7Z0JBQ0w7Ozs7O2VBQ0Y7Ozs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLHFCQUFxQixhQUFhLHFCQUFxQjtNQUNyRDs7OztjQUNGOzs7Ozs7S0FJTixrQkFDQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRCxhQUFNLHlCQUFzQixZQUFZLElBQVc7Ozs7aUJBQ25ELHdCQUFDLFFBQUQsYUFBTyxZQUFZLFNBQVEsR0FBTzs7OztlQUMvQjs7Ozs7Z0JBQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsT0FBRDtRQUNFLFdBQVU7UUFDVixPQUFPLEVBQUUsT0FBTyxHQUFHLFlBQVksUUFBUSxHQUFHO09BQzNDOzs7OztNQUNFOzs7O2NBQ0Y7Ozs7OztLQUlQLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFVBQVc7Ozs7a0JBQy9CLHdCQUFDLFFBQUQsWUFBTSwrQ0FBa0Q7Ozs7Z0JBQ3JEOzs7OztpQkFDTCx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZDtTQUNFLHdCQUFDLE1BQUQ7VUFBSTtVQUFxQyx3QkFBQyxLQUFELFlBQUcsMEJBQTBCOzs7OztVQUFDO1NBQUs7Ozs7O1NBQzVFLHdCQUFDLE1BQUQsWUFBSSx3RUFBeUU7Ozs7O1NBQzdFLHdCQUFDLE1BQUQ7VUFBSTtVQUFVLHdCQUFDLEtBQUQsWUFBRyxjQUFZOzs7OztVQUFDO1VBQWdCLHdCQUFDLEtBQUQsWUFBRyxzQ0FBb0M7Ozs7O1VBQUM7U0FBYTs7Ozs7U0FDbkcsd0JBQUMsTUFBRDtVQUFJO1VBQWdCLHdCQUFDLEtBQUQsWUFBRyxtQkFBaUI7Ozs7O1VBQUM7VUFBMEIsd0JBQUMsS0FBRCxZQUFHLGdCQUFnQjs7Ozs7VUFBQztTQUFxQjs7Ozs7UUFDMUc7Ozs7O2VBQ0Q7Ozs7O2dCQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7O2tCQUM3Qix3QkFBQyxRQUFELFlBQU0sMENBQTZDOzs7O2dCQUNoRDs7Ozs7aUJBQ0wsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQ7U0FDRSx3QkFBQyxNQUFEO1VBQUk7VUFBd0Qsd0JBQUMsUUFBRCxZQUFNLDRCQUE4Qjs7Ozs7VUFBQztTQUFNOzs7OztTQUN2Ryx3QkFBQyxNQUFEO1VBQUk7VUFBd0Msd0JBQUMsS0FBRCxZQUFHLGFBQWE7Ozs7O1VBQUM7U0FBK0I7Ozs7O1NBQzVGLHdCQUFDLE1BQUQ7VUFBSTtVQUFnQix3QkFBQyxLQUFELFlBQUcsd0JBQXdCOzs7OztVQUFDO1NBQTZCOzs7OztTQUM3RSx3QkFBQyxNQUFEO1VBQUk7VUFBeUIsd0JBQUMsS0FBRCxZQUFHLHFCQUFtQjs7Ozs7VUFBQztTQUFnRDs7Ozs7UUFDbEc7Ozs7O2VBQ0Q7Ozs7O2NBQ0Y7Ozs7OztJQUNGOzs7Ozs7R0FJTixpQkFBaUIsVUFDaEIsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQXNDO0tBQXlDOzs7O2VBQzdGLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUF5QjtLQUF5Rjs7OzthQUM1SDs7OztlQUNMLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFGWixDQUlFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLGNBQWU7Ozs7Z0JBQ3BDLHdCQUFDLFFBQUQsWUFBTSxlQUFrQjs7OztjQUNsQjs7Ozs7YUFDTDs7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFNBQUQ7TUFBTyxXQUFVO2dCQUFqQixDQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUNmLHdCQUFDLE1BQUQ7UUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFhOzs7OztRQUN6Qyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFVOzs7OztRQUN0Qyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFZOzs7OztRQUN4Qyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFROzs7OztRQUNwQyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFhOzs7OztRQUN6Qyx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBYztRQUFXOzs7OztPQUNyQzs7Ozs7TUFDQzs7OztnQkFDUCx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFDZCxVQUFVLFNBQVMsSUFDbEIsVUFBVSxLQUFLLFFBQ2Isd0JBQUMsTUFBRDtRQUFpQixXQUFVO2tCQUEzQjtTQUNFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUE4QixJQUFJO1NBQWM7Ozs7O1NBQzlELHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNaLHdCQUFDLFFBQUQ7V0FBTSxXQUFXLDZDQUNmLElBQUksV0FBVyxrQkFDWCx1Q0FDQSxJQUFJLFdBQVcsbUJBQ2YsaUNBQ0EsSUFBSSxXQUFXLGlCQUNmLGlDQUNBO3FCQUVILElBQUk7VUFDRDs7Ozs7U0FDSjs7Ozs7U0FDSix3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBZCxDQUFpRCxLQUFFLElBQUksUUFBYTs7Ozs7O1NBQ3BFLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUE4QixJQUFJLGVBQWUsV0FBVyxjQUFjO1NBQVk7Ozs7O1NBQ3BHLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUE4QixJQUFJO1NBQWE7Ozs7O1NBQzdELHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUEwRCxJQUFJO1NBQVk7Ozs7O1FBQ3RGO1VBbkJLLElBQUk7Ozs7Y0FtQlQsQ0FDTCxJQUVELHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxNQUFEO1FBQUksU0FBUztRQUFHLFdBQVU7a0JBQWtDO09BRXhEOzs7O2dCQUNGOzs7OztNQUVEOzs7O2NBQ0Y7Ozs7OztJQUNKOzs7O1lBQ0Y7Ozs7OztHQUlOLGlCQUFpQixjQUNoQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FDRSx3QkFBQyxLQUFELEVBQUssV0FBVSx3QkFBeUI7Ozs7aUJBQ3hDLHdCQUFDLFFBQUQsWUFBTSxrREFBcUQ7Ozs7ZUFDekQ7Ozs7O2dCQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFnQztNQUUxQzs7OztjQUNBOzs7O2dCQUVMLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUF3RztNQUVsSDs7OztjQUNIOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUsVUFBVzs7OztpQkFDbEMsd0JBQUMsUUFBRCxZQUFNLGtEQUFxRDs7OztlQUN4RDs7Ozs7Z0JBQ0wsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQWI7UUFBc0Q7UUFDckMsd0JBQUMsS0FBRCxZQUFHLHVGQUF1Rjs7Ozs7UUFBQztRQUVyRCx3QkFBQyxLQUFELFlBQUcsZUFBZTs7Ozs7UUFBQztPQUN2RTs7Ozs7Y0FDQTs7Ozs7O0tBRUwsd0JBQUMsUUFBRDtNQUFNLFVBQVU7TUFBb0IsV0FBVTtnQkFBOUM7T0FFRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNaLHdCQUFDLFFBQUQsWUFBTSxzQ0FBeUM7Ozs7O1FBQzdDOzs7O2tCQUVKLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUE0QjtVQUF5Qjs7OztvQkFDdEUsd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPLFNBQVM7V0FDaEIsV0FBVyxNQUFNLFlBQVk7WUFBRSxHQUFHO1lBQVUsVUFBVSxFQUFFLE9BQU87V0FBTSxDQUFDO1dBQ3RFLFdBQVU7VUFDWDs7OztrQkFDRTs7Ozs7VUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQTRCO1VBQWlCOzs7O29CQUM5RCx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMLE9BQU8sU0FBUztXQUNoQixXQUFXLE1BQU0sWUFBWTtZQUFFLEdBQUc7WUFBVSxXQUFXLEVBQUUsT0FBTztXQUFNLENBQUM7V0FDdkUsV0FBVTtVQUNYOzs7O2tCQUNFOzs7OztVQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBNEI7VUFBK0I7Ozs7b0JBQzVFLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0wsT0FBTyxTQUFTO1dBQ2hCLFdBQVcsTUFBTSxZQUFZO1lBQUUsR0FBRztZQUFVLE9BQU8sRUFBRSxPQUFPO1dBQU0sQ0FBQztXQUNuRSxXQUFVO1VBQ1g7Ozs7a0JBQ0U7Ozs7O1VBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUE0QjtVQUFnQzs7OztvQkFDN0Usd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPLFNBQVM7V0FDaEIsV0FBVyxNQUFNLFlBQVk7WUFBRSxHQUFHO1lBQVUsT0FBTyxFQUFFLE9BQU87V0FBTSxDQUFDO1dBQ25FLFdBQVU7VUFDWDs7OztrQkFDRTs7Ozs7VUFFTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUE0QjtXQUF3RDs7OztxQkFDckcsd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxPQUFPLFNBQVM7WUFDaEIsV0FBVyxNQUFNLFlBQVk7YUFBRSxHQUFHO2FBQVUsU0FBUyxFQUFFLE9BQU87WUFBTSxDQUFDO1lBQ3JFLFdBQVU7V0FDWDs7OzttQkFDRTs7Ozs7O1NBQ0Y7Ozs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNaLHdCQUFDLFFBQUQsWUFBTSw2Q0FBZ0Q7Ozs7O1FBQ3BEOzs7O2tCQUVKLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFBd0M7V0FBcUI7Ozs7cUJBQzlFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7c0JBQ2Isd0JBQUMsU0FBRDthQUNFLE1BQUs7YUFDTCxjQUFjO2FBQ2QsYUFBWTthQUNaLFdBQVU7WUFDWDs7OztvQkFDRTs7Ozs7bUJBQ0Y7Ozs7OztVQUVMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQXdDO1dBQTBCOzs7O3FCQUNuRix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7O3NCQUNiLHdCQUFDLFNBQUQ7YUFDRSxNQUFLO2FBQ0wsY0FBYzthQUNkLGFBQVk7YUFDWixXQUFVO1lBQ1g7Ozs7b0JBQ0U7Ozs7O21CQUNGOzs7Ozs7VUFFTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUF3QztXQUF5Qjs7OztxQkFDbEYsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sSUFBTzs7OztzQkFDYix3QkFBQyxTQUFEO2FBQ0UsTUFBSzthQUNMLGNBQWM7YUFDZCxhQUFZO2FBQ1osV0FBVTtZQUNYOzs7O29CQUNFOzs7OzttQkFDRjs7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1lBQU8sV0FBVTtzQkFBd0M7V0FBeUI7Ozs7cUJBQ2xGLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7c0JBQ2Isd0JBQUMsU0FBRDthQUNFLE1BQUs7YUFDTCxjQUFjO2FBQ2QsYUFBWTthQUNaLFdBQVU7WUFDWDs7OztvQkFDRTs7Ozs7bUJBQ0Y7Ozs7OztVQUVMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsU0FBRDtZQUFPLFdBQVU7c0JBQXdDO1dBQW1COzs7O3FCQUM1RSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxJQUFPOzs7O3NCQUNiLHdCQUFDLFNBQUQ7YUFDRSxNQUFLO2FBQ0wsY0FBYzthQUNkLGFBQVk7YUFDWixXQUFVO1lBQ1g7Ozs7b0JBQ0U7Ozs7O21CQUNGOzs7Ozs7VUFFTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFNBQUQ7WUFBTyxXQUFVO3NCQUF3QztXQUF5Qjs7OztxQkFDbEYsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sSUFBTzs7OztzQkFDYix3QkFBQyxTQUFEO2FBQ0UsTUFBSzthQUNMLGNBQWM7YUFDZCxhQUFZO2FBQ1osV0FBVTtZQUNYOzs7O29CQUNFOzs7OzttQkFDRjs7Ozs7O1NBQ0Y7Ozs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNaLHdCQUFDLFFBQUQsWUFBTSxtQ0FBc0M7Ozs7O1FBQzFDOzs7O2tCQUVKLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBaUM7WUFBMEI7Ozs7O1lBQzVFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUE0RDtZQUFxQjs7Ozs7WUFDaEcsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQTZCO1lBQWtEOzs7OztXQUN6Rjs7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBaUM7WUFBMEI7Ozs7O1lBQzVFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUE4RDtZQUErQjs7Ozs7WUFDNUcsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQTZCO1lBQXdEOzs7OztXQUMvRjs7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWY7WUFDRSx3QkFBQyxTQUFEO2FBQU8sV0FBVTt1QkFBaUM7WUFBMEI7Ozs7O1lBQzVFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUErRDtZQUFnQzs7Ozs7WUFDOUcsd0JBQUMsS0FBRDthQUFHLFdBQVU7dUJBQTZCO1lBQWtEOzs7OztXQUN6Rjs7Ozs7O1NBQ0Y7Ozs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFdBQVU7bUJBQ1g7UUFFTzs7Ozs7T0FDTDs7Ozs7TUFDRDs7Ozs7O0lBQ0g7Ozs7OztHQUlOLHNCQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSwyQkFBNEI7Ozs7a0JBQ2hELHdCQUFDLFFBQUQsWUFBTSxrQ0FBcUM7Ozs7Z0JBQ3pDOzs7OztpQkFDSix3QkFBQyxVQUFEO1FBQVEsZUFBZSxzQkFBc0IsSUFBSTtRQUFHLFdBQVU7a0JBQWtDO09BQVM7Ozs7ZUFDdEc7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQXdCLG1CQUFtQjtRQUFpQjs7Ozs7UUFDM0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFBMEM7VUFBRSxtQkFBbUI7VUFBUztVQUFJLG1CQUFtQjtTQUFXOzs7Ozs7UUFDMUcsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFBaUQ7VUFDM0IsdUJBQXVCLG1CQUFtQixpQkFBaUI7VUFBRTtTQUM5RTs7Ozs7O09BQ0Y7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWlDO09BQWlDOzs7O2lCQUNuRix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsZUFBZSxrQkFBa0IsRUFBRTtVQUNuQyxXQUFXLDhEQUNULG1CQUFtQixLQUNmLGtEQUNBO29CQU5SLENBU0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQVU7VUFBYTs7OztvQkFDdEMsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQTZCO1VBQWlCOzs7O2tCQUN2RDs7Ozs7O1NBRVIsd0JBQUMsVUFBRDtVQUNFLE1BQUs7VUFDTCxlQUFlLGtCQUFrQixFQUFFO1VBQ25DLFdBQVcsOERBQ1QsbUJBQW1CLEtBQ2Ysa0RBQ0E7b0JBTlIsQ0FTRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBVTtVQUFhOzs7O29CQUN0Qyx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBNkI7VUFBbUI7Ozs7a0JBQ3pEOzs7Ozs7U0FFUix3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLGVBQWUsa0JBQWtCLEdBQUc7VUFDcEMsV0FBVyw4REFDVCxtQkFBbUIsTUFDZixrREFDQTtvQkFOUixDQVNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFVO1VBQWM7Ozs7b0JBQ3ZDLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUE2QjtVQUFtQjs7OztrQkFDekQ7Ozs7OztTQUVSLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsZUFBZSxrQkFBa0IsSUFBSTtVQUNyQyxXQUFXLDhEQUNULG1CQUFtQixPQUNmLHdEQUNBO29CQU5SLENBU0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQVU7VUFBYTs7OztvQkFDdEMsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQTZCO1VBQXFCOzs7O2tCQUMzRDs7Ozs7O1FBQ0w7Ozs7O2VBQ0Y7Ozs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxlQUFlLHNCQUFzQixJQUFJO1FBQ3pDLFdBQVU7a0JBQ1g7T0FFTzs7OztpQkFDUix3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLFNBQVM7UUFDVCxXQUFVO2tCQUhaLENBS0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsVUFBVzs7OztrQkFDNUIsd0JBQUMsUUFBRCxZQUFNLDBCQUE2Qjs7OztnQkFDN0I7Ozs7O2VBQ0w7Ozs7OztLQUNGOzs7Ozs7R0FDRjs7Ozs7R0FJTiwyQkFDQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFkLENBQ0Usd0JBQUMsZUFBRCxFQUFlLFdBQVUsdUJBQXdCOzs7O2tCQUNqRCx3QkFBQyxRQUFELGFBQU0sbUJBQWdCLHVCQUE4Qjs7OztnQkFDbEQ7Ozs7O2lCQUNKLHdCQUFDLFVBQUQ7UUFBUSxlQUFlLDJCQUEyQixJQUFJO1FBQUcsV0FBVTtrQkFBa0M7T0FBUzs7OztlQUMzRzs7Ozs7O01BRUwsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXlCO01BRW5DOzs7OztNQUVILHdCQUFDLFlBQUQ7T0FDRSxNQUFNO09BQ04sT0FBTztPQUNQLFdBQVcsTUFBTSx3QkFBd0IsRUFBRSxPQUFPLEtBQUs7T0FDdkQsYUFBWTtPQUNaLFdBQVU7TUFDWDs7Ozs7TUFFRCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLDJCQUEyQixJQUFJO1FBQzlDLFdBQVU7a0JBQ1g7T0FFTzs7OztpQkFDUix3QkFBQyxVQUFEO1FBQ0UsU0FBUztRQUNULFdBQVU7a0JBRlosQ0FJRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O2tCQUMvQix3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7O2dCQUN0Qjs7Ozs7ZUFDTDs7Ozs7O0tBQ0Y7Ozs7OztHQUNGOzs7OztHQUlOLGdCQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQWQsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSx3QkFBeUI7Ozs7a0JBQzdDLHdCQUFDLFFBQUQsWUFBTSwyQkFBOEI7Ozs7Z0JBQ2xDOzs7OztpQkFDSix3QkFBQyxVQUFEO1FBQVEsZUFBZSxnQkFBZ0IsS0FBSztRQUFHLFdBQVU7a0JBQWtDO09BQVM7Ozs7ZUFDakc7Ozs7OztNQUVMLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFiO1FBQXNDO1FBQ0Ysd0JBQUMsS0FBRCxZQUFHLGtCQUFrQjs7Ozs7UUFBQztRQUFHLHdCQUFDLEtBQUQsWUFBRyxzQkFBc0I7Ozs7O1FBQUM7T0FDcEY7Ozs7OztNQUVGLFlBQ0Msd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1o7TUFDRTs7Ozs7TUFHUCx3QkFBQyxRQUFEO09BQU0sVUFBVTtPQUFzQixXQUFVO2lCQUFoRDtRQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBNEI7UUFBeUI7Ozs7a0JBQ3RFLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0w7U0FDQSxhQUFZO1NBQ1osT0FBTztTQUNQLFdBQVcsTUFBTSxrQkFBa0IsRUFBRSxPQUFPLEtBQUs7U0FDakQsV0FBVTtRQUNYOzs7O2dCQUNFOzs7OztRQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBNEI7UUFBMEI7Ozs7a0JBQ3ZFLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0w7U0FDQSxhQUFZO1NBQ1osT0FBTztTQUNQLFdBQVcsTUFBTSxlQUFlLEVBQUUsT0FBTyxLQUFLO1NBQzlDLFdBQVU7UUFDWDs7OztnQkFDRTs7Ozs7UUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTRCO1FBQWU7Ozs7a0JBQzVELHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0w7U0FDQSxhQUFZO1NBQ1osT0FBTztTQUNQLFdBQVcsTUFBTSxlQUFlLEVBQUUsT0FBTyxLQUFLO1NBQzlDLFdBQVU7UUFDWDs7OztnQkFDRTs7Ozs7UUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTRCO1FBQW1COzs7O2tCQUNoRSx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLGFBQVk7U0FDWixPQUFPO1NBQ1AsV0FBVyxNQUFNLFlBQVksRUFBRSxPQUFPLEtBQUs7U0FDM0MsV0FBVTtRQUNYOzs7O2dCQUNFOzs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsVUFBRDtVQUNFLE1BQUs7VUFDTCxlQUFlLGdCQUFnQixLQUFLO1VBQ3BDLFdBQVU7b0JBQ1g7U0FFTzs7OzttQkFDUix3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLFdBQVU7b0JBQ1g7U0FFTzs7OztpQkFDTDs7Ozs7O09BQ0Q7Ozs7OztLQUNIOzs7Ozs7R0FDRjs7Ozs7RUFFSjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTWFzdGVyQWRtaW5WaWV3LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICBTaGllbGRDaGVjaywgXG4gIExvY2ssIFxuICBVbmxvY2ssIFxuICBTbWFydHBob25lLCBcbiAgTGFwdG9wLCBcbiAgUm90YXRlQ2N3LCBcbiAgVXNlclBsdXMsIFxuICBUcmFzaDIsIFxuICBEb3dubG9hZCwgXG4gIENoZWNrQ2lyY2xlMiwgXG4gIEFsZXJ0Q2lyY2xlLCBcbiAgQ2xvY2ssIFxuICBLZXksIFxuICBGaWxlQ29kZSwgXG4gIExheWVycywgXG4gIENoZWNrLCBcbiAgQXJjaGl2ZSxcbiAgUmVmcmVzaEN3LFxuICBDcHUsXG4gIE1vbml0b3IsXG4gIENsaXBib2FyZExpc3QsXG4gIFNwYXJrbGVzLFxuICBDaXJjbGUsXG4gIEhlbHBDaXJjbGUsXG4gIEFjdGl2aXR5LFxuICBSYWRpbyxcbiAgUG93ZXIsXG4gIE1lc3NhZ2VTcXVhcmUsXG4gIFNlbmQsXG4gIENhbGVuZGFyLFxuICBBbGVydFRyaWFuZ2xlLFxuICBXaWZpLFxuICBHbG9iZSxcbiAgQ29weSxcbiAgVGVybWluYWwsXG4gIEV4dGVybmFsTGluayxcbiAgRmlsZVRleHRcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IE9wZXJhdG9yQWNjb3VudCwgU2hvcFNldHRpbmdzLCBMaXZlT3BlcmF0b3JTZXNzaW9uIH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHsgXG4gIGdldFJlZ2lzdGVyZWRPcGVyYXRvcnMsIFxuICByZXNldE9wZXJhdG9yUGNCaW5kaW5nLFxuICByZXNldE9wZXJhdG9yTW9iaWxlQmluZGluZyxcbiAgcmVzZXRPcGVyYXRvckFsbEJpbmRpbmdzLFxuICB0b2dnbGVPcGVyYXRvckxvY2ssIFxuICBhZGROZXdPcGVyYXRvciwgXG4gIGRlbGV0ZU9wZXJhdG9yLFxuICBnZXRTZWN1cml0eUF1ZGl0TG9ncyxcbiAgU2VjdXJpdHlBdWRpdExvZyxcbiAgZ2V0SGFyZHdhcmVEZXZpY2VJZCxcbiAgZ2V0SGFyZHdhcmVEZXZpY2VOYW1lLFxuICBpc01vYmlsZURldmljZSxcbiAgcmVuZXdPcGVyYXRvckxpY2Vuc2UsXG4gIGNhbGN1bGF0ZVJlbWFpbmluZ0RheXMsXG4gIGdldExpdmVPcGVyYXRvclNlc3Npb25zLFxuICBmb3JjZURpc2Nvbm5lY3RPcGVyYXRvcixcbiAgc2VuZE9wZXJhdG9yQnJvYWRjYXN0TWVzc2FnZVxufSBmcm9tICcuLi91dGlscy9kZXZpY2VTZWN1cml0eSc7XG5pbXBvcnQgeyBnZW5lcmF0ZVByb2plY3RaaXAsIHRyaWdnZXJEb3dubG9hZFppcCB9IGZyb20gJy4uL3V0aWxzL3Byb2plY3RaaXAnO1xuXG5pbnRlcmZhY2UgTWFzdGVyQWRtaW5WaWV3UHJvcHMge1xuICBzZXR0aW5nczogU2hvcFNldHRpbmdzO1xuICBvblVwZGF0ZVNldHRpbmdzOiAoc2V0dGluZ3M6IFNob3BTZXR0aW5ncykgPT4gdm9pZDtcbiAgb25OYXZpZ2F0ZVRvV29ya2Zsb3c/OiAoKSA9PiB2b2lkO1xufVxuXG5pbnRlcmZhY2UgV29ya2Zsb3dTdGVwIHtcbiAgc3RlcE51bWJlcjogbnVtYmVyO1xuICB0aXRsZTogc3RyaW5nO1xuICBkZXNjcmlwdGlvbjogc3RyaW5nO1xuICB0b29sc1VzZWQ6IHN0cmluZ1tdO1xuICBjaGVja2xpc3Q6IHN0cmluZ1tdO1xuICB0aXBzOiBzdHJpbmc7XG59XG5cbmNvbnN0IE1BU1RFUl9XT1JLRkxPV19TVEVQUzogV29ya2Zsb3dTdGVwW10gPSBbXG4gIHtcbiAgICBzdGVwTnVtYmVyOiAxLFxuICAgIHRpdGxlOiAnQ3VzdG9tZXIgSW50YWtlICYgU2VydmljZSBJZGVudGlmaWNhdGlvbicsXG4gICAgZGVzY3JpcHRpb246ICdXZWxjb21lIGNpdGl6ZW4sIHZlcmlmeSBBYWRoYWFyIGxpbmtlZCBtb2JpbGUsIGNoZWNrIGRvY3VtZW50IHByZXJlcXVpc2l0ZXMsIGFuZCBxdW90ZSB0cmFuc3BhcmVudCByYXRlcy4nLFxuICAgIHRvb2xzVXNlZDogWydEYXNoYm9hcmQnLCAnNTArIEdvdnQgUG9ydGFscyBIdWInLCAnQUkgQXNzaXN0YW50J10sXG4gICAgY2hlY2tsaXN0OiBbXG4gICAgICAnQ2hlY2sgY3VzdG9tZXIgQWFkaGFhciAmIGFjdGl2ZSBtb2JpbGUgT1RQIGF2YWlsYWJpbGl0eScsXG4gICAgICAnSW5mb3JtIGN1c3RvbWVyIG9mIG9mZmljaWFsIHBvcnRhbCBjaGFyZ2VzICsgc2VydmljZSBmZWUnLFxuICAgICAgJ1JlY29yZCBjdXN0b21lciBuYW1lICYgV2hhdHNBcHAgbnVtYmVyIGluIENSTScsXG4gICAgICAnSXNzdWUgcGh5c2ljYWwgb3IgZGlnaXRhbCBxdWV1ZSB0b2tlbidcbiAgICBdLFxuICAgIHRpcHM6ICdBYWRoYWFyIG1laW4gYWN0aXZlIG1vYmlsZSBudW1iZXIgaG9uYSBQTS1LSVNBTiwgTGFka2kgQmFoaW4sIGF1ciBNYWhhZGJ0IHNjaGVtZXMga2UgbGl5ZSBhbml2YXJ5YSBoYWkuJ1xuICB9LFxuICB7XG4gICAgc3RlcE51bWJlcjogMixcbiAgICB0aXRsZTogJ09mZmljaWFsIFBvcnRhbCBGaWxpbmcgJiBEb2N1bWVudCBTdWJtaXNzaW9uJyxcbiAgICBkZXNjcmlwdGlvbjogJ0xvZyBpbnRvIGNlbnRyYWwvc3RhdGUgcG9ydGFsIChBYXBsZSBTYXJrYXIsIFNhcmF0aGksIE1haGFkYnQpLCBjb21wbGV0ZSBmb3JtIGVudHJ5LCBhbmQgc3VibWl0LicsXG4gICAgdG9vbHNVc2VkOiBbJzUwKyBHb3Z0IFBvcnRhbHMgRGlyZWN0b3J5JywgJ1BERiB0byBIRCBKUEcgQ29udmVydGVyJ10sXG4gICAgY2hlY2tsaXN0OiBbXG4gICAgICAnRW50ZXIgYXBwbGljYW50IGRldGFpbHMgbWF0Y2hpbmcgQWFkaGFhciBsZXR0ZXIgYnkgbGV0dGVyJyxcbiAgICAgICdJZiBwb3J0YWwgcmVxdWlyZXMgSlBHIHVuZGVyIDEwMEtCLCB1c2UgUERGIHRvIEpQRyB0b29sIHRvIGNvbXByZXNzIGRvY3VtZW50cycsXG4gICAgICAnVmVyaWZ5IHVwbG9hZGVkIGNlcnRpZmljYXRlIHByZXZpZXdzIGJlZm9yZSBmaW5hbCBzdWJtaXNzaW9uJyxcbiAgICAgICdEb3dubG9hZCBhbmQgc2F2ZSBvZmZpY2lhbCBhY2tub3dsZWRnZW1lbnQgUERGJ1xuICAgIF0sXG4gICAgdGlwczogJ0Fja25vd2xlZGdlbWVudCBSZWNlaXB0IFRva2VuIE51bWJlciBoYW1lc2hhIGRvd25sb2FkIGthcmtlIEN1c3RvbWVyIENSTSBtZWluIG5vdGUga2FyZWluLidcbiAgfSxcbiAge1xuICAgIHN0ZXBOdW1iZXI6IDMsXG4gICAgdGl0bGU6ICdTdHVkaW8gUGhvdG8gJiBQVkMgU21hcnQgQ2FyZCBQcm9jZXNzaW5nJyxcbiAgICBkZXNjcmlwdGlvbjogJ1Byb2R1Y2UgaGlnaC1wcmVjaXNpb24gQ1ItODAgUFZDIGNhcmRzIG9yIDM1eDQ1bW0gcGFzc3BvcnQgcGhvdG8gc2hlZXRzLicsXG4gICAgdG9vbHNVc2VkOiBbJ1BWQyBTbWFydCBDYXJkIE1ha2VyJywgJ1Bhc3Nwb3J0IFBob3RvIFN0dWRpbyBQcm8nXSxcbiAgICBjaGVja2xpc3Q6IFtcbiAgICAgICdQYXNzcG9ydCBQaG90bzogU2VsZWN0IDTDlzYgTGFuZHNjYXBlICg4IENvcGllcyBAIDMwMCBEUEkpIG9yIEE0IExhbmRzY2FwZScsXG4gICAgICAnQmFja2dyb3VuZDogVXNlIENvbm5lY3RlZCBNYWdpYyBXYW5kIG9yIFBlbiBUb29sIHRvIGN1dCBvdXQgcGVyc29uIGFuZCBzZXQgV2hpdGUvU3R1ZGlvIEJsdWUgQkcnLFxuICAgICAgJ0F1dG8gQmVhdXR5OiBBcHBseSBBSSBGYWNlIFNtb290aGluZyB0byBicmlnaHRlbiBza2luIHRvbmVzIGFuZCByZWR1Y2UgY2FtZXJhIHNoYWRvd3MnLFxuICAgICAgJ0V4YW0gU3RyaXA6IEFkZCBDYW5kaWRhdGUgTmFtZSAmIERhdGUgc3RhbXAgZm9yIFNTQyBHRCwgUG9saWNlIEJoYXJ0aSwgb3IgUmFpbHdheSBmb3JtcycsXG4gICAgICAnUFZDIENhcmQ6IEFsaWduIEZyb250ICYgQmFjayBjYXJkcyB0byBzdGFuZGFyZCBDUi04MCAoODUuNsOXNTRtbSkgd2l0aCBjZW50ZXIgY3V0IGd1aWRlIGxpbmUnXG4gICAgXSxcbiAgICB0aXBzOiAnUFZDIENhcmQgcHJpbnQga2FydGUgd2FxdCBwcmludGVyIHByb3BlcnRpZXMgbWVpbiBcIkhpZ2ggUXVhbGl0eSBHbG9zc3kgUGhvdG8gUGFwZXJcIiBzZWxlY3Qga2FyZWluLidcbiAgfSxcbiAge1xuICAgIHN0ZXBOdW1iZXI6IDQsXG4gICAgdGl0bGU6ICczMDAgRFBJIFBoeXNpY2FsIFByaW50aW5nICYgVGhlcm1hbCBMYW1pbmF0aW9uJyxcbiAgICBkZXNjcmlwdGlvbjogJ0V4ZWN1dGUgaW4tYXBwIGJvcmRlcmxlc3MgcHJpbnRpbmcgb24gcGhvdG8gcGFwZXIsIGN1dCBjYXJkcywgYW5kIGxhbWluYXRlLicsXG4gICAgdG9vbHNVc2VkOiBbJ0luLUFwcCBEaXJlY3QgUHJpbnQgRW5naW5lIChDdHJsICsgUCknXSxcbiAgICBjaGVja2xpc3Q6IFtcbiAgICAgICdMb2FkIDTDlzYgaW5jaCAoMTDDlzE1IGNtKSBHbG9zc3kgUGhvdG8gUGFwZXIgaW50byBwcmludGVyJyxcbiAgICAgICdQcmVzcyBcIvCflqjvuI8gRGlyZWN0IFByaW50IFNoZWV0IChDdHJsICsgUClcIiBkaXJlY3RseSBpbnNpZGUgc3R1ZGlvJyxcbiAgICAgICdDdXQgYWxvbmcgcHJlLWFsaWduZWQgZ3VpZGUgbWFya3MnLFxuICAgICAgJ0ZvciBQVkMgU21hcnQgQ2FyZHM6IFBhc3MgdGhyb3VnaCB0aGVybWFsIGxhbWluYXRvciBmb3IgZHVyYWJsZSB3YXRlcnByb29mIGZpbmlzaCdcbiAgICBdLFxuICAgIHRpcHM6ICdJbi1hcHAgZGlyZWN0IHByaW50IHplcm8gcG9wdXAgYmxvY2tlciBrZSBzYWF0aCBzZWVkaGEgY29ubmVjdGVkIHByaW50ZXIgcGFyIDMwMCBEUEkgam9iIGJoZWp0YSBoYWkuJ1xuICB9LFxuICB7XG4gICAgc3RlcE51bWJlcjogNSxcbiAgICB0aXRsZTogJ1BPUyBCaWxsaW5nICYgVGhlcm1hbCBSZWNlaXB0IEdlbmVyYXRpb24nLFxuICAgIGRlc2NyaXB0aW9uOiAnR2VuZXJhdGUgaXRlbWl6ZWQgdGF4IGludm9pY2Ugb3IgNThtbS84MG1tIHRoZXJtYWwgc2xpcCB3aXRoIGR5bmFtaWMgVVBJIFFSIGNvZGUuJyxcbiAgICB0b29sc1VzZWQ6IFsnRmFzdCBCaWxsaW5nIERlc2sgUE9TJ10sXG4gICAgY2hlY2tsaXN0OiBbXG4gICAgICAnU2VsZWN0IHNlcnZpY2UgcGFja2FnZSAoZS5nLiBQVkMgQ2FyZCDigrk3MCwgUGFzc3BvcnQgUGhvdG8gOC1jb3BpZXMg4oK5NTAsIE9ubGluZSBGb3JtIOKCuTEwMCknLFxuICAgICAgJ0Rpc3BsYXkgZHluYW1pYyBVUEkgUVIgY29kZSBvbiBzY3JlZW4gZm9yIGluc3RhbnQgY3VzdG9tZXIgcGF5bWVudCcsXG4gICAgICAnUHJpbnQgNThtbSB0aGVybWFsIHJlY2VpcHQgb3IgQTQgb2ZmaWNpYWwgdGF4IGludm9pY2UgZm9yIGN1c3RvbWVyIHJlY29yZHMnLFxuICAgICAgJ1VwZGF0ZSBwYXltZW50IHN0YXR1cyBhcyBcIlBhaWRcIiBpbiBsZWRnZXInXG4gICAgXSxcbiAgICB0aXBzOiAnVGhlcm1hbCByZWNlaXB0IHBhciBzaG9wIGthIGF1dGhvcml6ZWQgc2lnbmF0dXJlIGF1ciBub24tcmVmdW5kYWJsZSBwb3J0YWwgdGVybXMgYXV0b21hdGljIGFhdGUgaGFpbi4nXG4gIH0sXG4gIHtcbiAgICBzdGVwTnVtYmVyOiA2LFxuICAgIHRpdGxlOiAnQ3VzdG9tZXIgSGFuZG92ZXIgJiBEYWlseSBDYXNoIFJlY29uY2lsaWF0aW9uJyxcbiAgICBkZXNjcmlwdGlvbjogJ0hhbmQgb3ZlciBsYW1pbmF0ZWQgY2FyZHMsIHBhc3Nwb3J0IHBob3RvcyBpbiBzbGVldmUsIGFuZCBwb3J0YWwgYWNrbm93bGVkZ2VtZW50LicsXG4gICAgdG9vbHNVc2VkOiBbJ0N1c3RvbWVyIENSTSAmIEpvYiBUcmFja2VyJ10sXG4gICAgY2hlY2tsaXN0OiBbXG4gICAgICAnSGFuZCBvdmVyIGxhbWluYXRlZCBjYXJkcywgcGFzc3BvcnQgcGhvdG9zIGluIHNsZWV2ZSwgYW5kIHBvcnRhbCBhY2tub3dsZWRnZW1lbnQnLFxuICAgICAgJ1NlbmQgV2hhdHNBcHAgY29uZmlybWF0aW9uIHdpdGggc3RhdHVzIHVwZGF0ZScsXG4gICAgICAnTWFyayBqb2IgYXMgXCJEZWxpdmVyZWRcIiBpbiBDUk0gVHJhY2tlcicsXG4gICAgICAnRGFpbHkgcmVjb25jaWxpYXRpb246IENoZWNrIHRvdGFsIGNhc2ggKyBVUEkgY29sbGVjdGlvbnMgaW4gQmlsbGluZyBEZXNrIFN1bW1hcnknXG4gICAgXSxcbiAgICB0aXBzOiAnRGluIGtlIGVuZCBwYXIgRGFpbHkgTGVkZ2VyIFN1bW1hcnkgc2UgY2FzaCBjb3VudGVyIGJhbGFuY2UgbWF0Y2gga2FyZWluLidcbiAgfVxuXTtcblxuZXhwb3J0IGNvbnN0IE1hc3RlckFkbWluVmlldzogUmVhY3QuRkM8TWFzdGVyQWRtaW5WaWV3UHJvcHM+ID0gKHtcbiAgc2V0dGluZ3MsXG4gIG9uVXBkYXRlU2V0dGluZ3MsXG4gIG9uTmF2aWdhdGVUb1dvcmtmbG93XG59KSA9PiB7XG4gIGNvbnN0IFtvcGVyYXRvcnMsIHNldE9wZXJhdG9yc10gPSB1c2VTdGF0ZTxPcGVyYXRvckFjY291bnRbXT4oW10pO1xuICBjb25zdCBbYXVkaXRMb2dzLCBzZXRBdWRpdExvZ3NdID0gdXNlU3RhdGU8U2VjdXJpdHlBdWRpdExvZ1tdPihbXSk7XG4gIGNvbnN0IFthY3RpdmVTdWJUYWIsIHNldEFjdGl2ZVN1YlRhYl0gPSB1c2VTdGF0ZTwnbGl2ZV9tb25pdG9yJyB8ICdvcGVyYXRvcnMnIHwgJ3dvcmtmbG93JyB8ICd6aXBfZG93bmxvYWQnIHwgJ2xvZ3MnIHwgJ3NldHRpbmdzJz4oJ2xpdmVfbW9uaXRvcicpO1xuXG4gIC8vIExpdmUgTW9uaXRvcmluZyBTdGF0ZVxuICBjb25zdCBbbGl2ZVNlc3Npb25zLCBzZXRMaXZlU2Vzc2lvbnNdID0gdXNlU3RhdGU8TGl2ZU9wZXJhdG9yU2Vzc2lvbltdPihbXSk7XG4gIGNvbnN0IFtpc0F1dG9SZWZyZXNoaW5nLCBzZXRJc0F1dG9SZWZyZXNoaW5nXSA9IHVzZVN0YXRlPGJvb2xlYW4+KHRydWUpO1xuICBjb25zdCBbbGFzdFJlZnJlc2hlZEF0LCBzZXRMYXN0UmVmcmVzaGVkQXRdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG5cbiAgLy8gUmVuZXdhbCBNb2RhbCBTdGF0ZVxuICBjb25zdCBbc2VsZWN0ZWRPcEZvclJlbmV3LCBzZXRTZWxlY3RlZE9wRm9yUmVuZXddID0gdXNlU3RhdGU8T3BlcmF0b3JBY2NvdW50IHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtyZW5ld0RheXNDb3VudCwgc2V0UmVuZXdEYXlzQ291bnRdID0gdXNlU3RhdGU8bnVtYmVyPigzMCk7XG5cbiAgLy8gQnJvYWRjYXN0IEFsZXJ0IE1vZGFsXG4gIGNvbnN0IFticm9hZGNhc3RUYXJnZXRVc2VybmFtZSwgc2V0QnJvYWRjYXN0VGFyZ2V0VXNlcm5hbWVdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFticm9hZGNhc3RNZXNzYWdlVGV4dCwgc2V0QnJvYWRjYXN0TWVzc2FnZVRleHRdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG5cbiAgLy8gTmV3IE9wZXJhdG9yIE1vZGFsIFN0YXRlXG4gIGNvbnN0IFtzaG93QWRkTW9kYWwsIHNldFNob3dBZGRNb2RhbF0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG4gIGNvbnN0IFtuZXdVc2VybmFtZSwgc2V0TmV3VXNlcm5hbWVdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG4gIGNvbnN0IFtuZXdQYXNzd29yZCwgc2V0TmV3UGFzc3dvcmRdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG4gIGNvbnN0IFtuZXdEaXNwbGF5TmFtZSwgc2V0TmV3RGlzcGxheU5hbWVdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG4gIGNvbnN0IFtuZXdQaG9uZSwgc2V0TmV3UGhvbmVdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG4gIGNvbnN0IFthZGRFcnJvciwgc2V0QWRkRXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nPignJyk7XG5cbiAgLy8gUHJvamVjdCBaSVAgRXhwb3J0IFN0YXRlXG4gIGNvbnN0IFtpc0V4cG9ydGluZ1ppcCwgc2V0SXNFeHBvcnRpbmdaaXBdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbemlwUHJvZ3Jlc3MsIHNldFppcFByb2dyZXNzXSA9IHVzZVN0YXRlPHsgcGVyY2VudDogbnVtYmVyOyBmaWxlOiBzdHJpbmcgfT4oeyBwZXJjZW50OiAwLCBmaWxlOiAnJyB9KTtcblxuICAvLyAzIEZpbGVzIEh1YiAtIENvcHkgZmVlZGJhY2sgJiBNb2RhbCB2aWV3ZXJzXG4gIGNvbnN0IFtjb3BpZWRXb3JrZmxvdywgc2V0Q29waWVkV29ya2Zsb3ddID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbY29waWVkUGNCYXRjaCwgc2V0Q29waWVkUGNCYXRjaF0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG4gIGNvbnN0IFtjb3BpZWRFeGVCYXRjaCwgc2V0Q29waWVkRXhlQmF0Y2hdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbZXhwYW5kZWRGaWxlQ2FyZCwgc2V0RXhwYW5kZWRGaWxlQ2FyZF0gPSB1c2VTdGF0ZTwnd29ya2Zsb3cnIHwgJ3BjX2JhdGNoJyB8ICdleGVfYmF0Y2gnIHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gTm90aWZpY2F0aW9uc1xuICBjb25zdCBbYWxlcnRNZXNzYWdlLCBzZXRBbGVydE1lc3NhZ2VdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gU2hvcCBTZXR0aW5ncyBGb3JtXG4gIGNvbnN0IFtzaG9wRm9ybSwgc2V0U2hvcEZvcm1dID0gdXNlU3RhdGU8U2hvcFNldHRpbmdzPihzZXR0aW5ncyk7XG5cbiAgLy8gV29ya2Zsb3cgQ2hlY2tsaXN0IHN0YXRlIGluc2lkZSBNYXN0ZXIgQWRtaW5cbiAgY29uc3QgW2NvbXBsZXRlZFN0ZXBzLCBzZXRDb21wbGV0ZWRTdGVwc10gPSB1c2VTdGF0ZTxSZWNvcmQ8bnVtYmVyLCBib29sZWFuPj4oe30pO1xuXG4gIGNvbnN0IGN1cnJlbnREZXZpY2VJZCA9IGdldEhhcmR3YXJlRGV2aWNlSWQoKTtcbiAgY29uc3QgY3VycmVudERldmljZU5hbWUgPSBnZXRIYXJkd2FyZURldmljZU5hbWUoKTtcbiAgY29uc3QgY3VycmVudElzTW9iaWxlID0gaXNNb2JpbGVEZXZpY2UoKTtcblxuICBjb25zdCBsb2FkRGF0YSA9ICgpID0+IHtcbiAgICBzZXRPcGVyYXRvcnMoZ2V0UmVnaXN0ZXJlZE9wZXJhdG9ycygpKTtcbiAgICBzZXRBdWRpdExvZ3MoZ2V0U2VjdXJpdHlBdWRpdExvZ3MoKSk7XG4gIH07XG5cbiAgY29uc3QgcmVmcmVzaExpdmVTZXNzaW9ucyA9IGFzeW5jICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3Qgc2Vzc2lvbnMgPSBhd2FpdCBnZXRMaXZlT3BlcmF0b3JTZXNzaW9ucygpO1xuICAgICAgc2V0TGl2ZVNlc3Npb25zKHNlc3Npb25zKTtcbiAgICAgIHNldExhc3RSZWZyZXNoZWRBdChuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZygpKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgIH1cbiAgfTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGxvYWREYXRhKCk7XG4gICAgcmVmcmVzaExpdmVTZXNzaW9ucygpO1xuICB9LCBbXSk7XG5cbiAgLy8gUmVhbC1UaW1lIDMuNXMgTGl2ZSBQb2xsaW5nIEhlYXJ0YmVhdFxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghaXNBdXRvUmVmcmVzaGluZykgcmV0dXJuO1xuICAgIGNvbnN0IGludGVydmFsID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgcmVmcmVzaExpdmVTZXNzaW9ucygpO1xuICAgIH0sIDM1MDApO1xuICAgIHJldHVybiAoKSA9PiBjbGVhckludGVydmFsKGludGVydmFsKTtcbiAgfSwgW2lzQXV0b1JlZnJlc2hpbmddKTtcblxuICAvLyBIYW5kbGUgTGljZW5zZSAvIEFjY2VzcyBSZW5ld2FsXG4gIGNvbnN0IGhhbmRsZUV4ZWN1dGVSZW5ld2FsID0gKCkgPT4ge1xuICAgIGlmICghc2VsZWN0ZWRPcEZvclJlbmV3KSByZXR1cm47XG4gICAgY29uc3QgcmVzdWx0ID0gcmVuZXdPcGVyYXRvckxpY2Vuc2Uoc2VsZWN0ZWRPcEZvclJlbmV3LmlkLCByZW5ld0RheXNDb3VudCk7XG4gICAgaWYgKHJlc3VsdC5zdWNjZXNzKSB7XG4gICAgICBsb2FkRGF0YSgpO1xuICAgICAgcmVmcmVzaExpdmVTZXNzaW9ucygpO1xuICAgICAgc2V0QWxlcnRNZXNzYWdlKGDinIUgQWNjZXNzIFJlbmV3ZWQgZm9yIFwiJHtzZWxlY3RlZE9wRm9yUmVuZXcuZGlzcGxheU5hbWV9XCIhIFZhbGlkIHVudGlsICR7cmVzdWx0Lm5ld0V4cGlyeX0gKCR7cmVzdWx0LmRheXNMZWZ0fSBkYXlzIHJlbWFpbmluZylgKTtcbiAgICAgIHNldFNlbGVjdGVkT3BGb3JSZW5ldyhudWxsKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0QWxlcnRNZXNzYWdlKG51bGwpLCA1MDAwKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gSGFuZGxlIEZvcmNlIERpc2Nvbm5lY3QgTGl2ZSBTZXNzaW9uXG4gIGNvbnN0IGhhbmRsZUZvcmNlRGlzY29ubmVjdCA9IGFzeW5jICh1c2VybmFtZTogc3RyaW5nLCBkZXZpY2VJZD86IHN0cmluZykgPT4ge1xuICAgIGlmICh3aW5kb3cuY29uZmlybShgRm9yY2UgdGVybWluYXRlIGFjdGl2ZSBzZXNzaW9uIGZvciBAJHt1c2VybmFtZX0/IE9wZXJhdG9yIHdpbGwgYmUgaW1tZWRpYXRlbHkgbG9nZ2VkIG91dC5gKSkge1xuICAgICAgYXdhaXQgZm9yY2VEaXNjb25uZWN0T3BlcmF0b3IodXNlcm5hbWUsIGRldmljZUlkKTtcbiAgICAgIHJlZnJlc2hMaXZlU2Vzc2lvbnMoKTtcbiAgICAgIHNldEFsZXJ0TWVzc2FnZShg8J+aqCBTZXNzaW9uIGZvciBAJHt1c2VybmFtZX0gaGFzIGJlZW4gZm9yY2VmdWxseSB0ZXJtaW5hdGVkLmApO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRBbGVydE1lc3NhZ2UobnVsbCksIDQwMDApO1xuICAgIH1cbiAgfTtcblxuICAvLyBIYW5kbGUgU2VuZCBJbi1BcHAgQnJvYWRjYXN0IEFsZXJ0XG4gIGNvbnN0IGhhbmRsZVNlbmRCcm9hZGNhc3QgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFicm9hZGNhc3RUYXJnZXRVc2VybmFtZSB8fCAhYnJvYWRjYXN0TWVzc2FnZVRleHQudHJpbSgpKSByZXR1cm47XG4gICAgYXdhaXQgc2VuZE9wZXJhdG9yQnJvYWRjYXN0TWVzc2FnZShicm9hZGNhc3RUYXJnZXRVc2VybmFtZSwgYnJvYWRjYXN0TWVzc2FnZVRleHQudHJpbSgpKTtcbiAgICBzZXRBbGVydE1lc3NhZ2UoYPCfk6IgQWxlcnQgbWVzc2FnZSBzZW50IHRvIEAke2Jyb2FkY2FzdFRhcmdldFVzZXJuYW1lfSFgKTtcbiAgICBzZXRCcm9hZGNhc3RUYXJnZXRVc2VybmFtZShudWxsKTtcbiAgICBzZXRCcm9hZGNhc3RNZXNzYWdlVGV4dCgnJyk7XG4gICAgc2V0VGltZW91dCgoKSA9PiBzZXRBbGVydE1lc3NhZ2UobnVsbCksIDQwMDApO1xuICB9O1xuXG4gIC8vIEhhbmRsZSBSZXNldCBQQyBCaW5kaW5nXG4gIGNvbnN0IGhhbmRsZVJlc2V0UGMgPSAob3BlcmF0b3JJZDogc3RyaW5nLCB1c2VybmFtZTogc3RyaW5nKSA9PiB7XG4gICAgaWYgKHdpbmRvdy5jb25maXJtKGBSZXNldCBQQyBEZXZpY2UgQmluZGluZyBmb3IgXCIke3VzZXJuYW1lfVwiPyBPcGVyYXRvciBjYW4gbm93IGxvZyBpbiBvbiBhIG5ldyBQQy9MYXB0b3AuYCkpIHtcbiAgICAgIHJlc2V0T3BlcmF0b3JQY0JpbmRpbmcob3BlcmF0b3JJZCk7XG4gICAgICBsb2FkRGF0YSgpO1xuICAgICAgcmVmcmVzaExpdmVTZXNzaW9ucygpO1xuICAgICAgc2V0QWxlcnRNZXNzYWdlKGDinIUgUEMgZGV2aWNlIGJpbmRpbmcgY2xlYXJlZCBmb3IgJHt1c2VybmFtZX0uIE9wZXJhdG9yIGNhbiBiaW5kIGEgbmV3IFBDLmApO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRBbGVydE1lc3NhZ2UobnVsbCksIDQwMDApO1xuICAgIH1cbiAgfTtcblxuICAvLyBIYW5kbGUgUmVzZXQgTW9iaWxlIEJpbmRpbmdcbiAgY29uc3QgaGFuZGxlUmVzZXRNb2JpbGUgPSAob3BlcmF0b3JJZDogc3RyaW5nLCB1c2VybmFtZTogc3RyaW5nKSA9PiB7XG4gICAgaWYgKHdpbmRvdy5jb25maXJtKGBSZXNldCBNb2JpbGUgRGV2aWNlIEJpbmRpbmcgZm9yIFwiJHt1c2VybmFtZX1cIj8gT3BlcmF0b3IgY2FuIG5vdyBsb2cgaW4gb24gYSBuZXcgU21hcnRwaG9uZS5gKSkge1xuICAgICAgcmVzZXRPcGVyYXRvck1vYmlsZUJpbmRpbmcob3BlcmF0b3JJZCk7XG4gICAgICBsb2FkRGF0YSgpO1xuICAgICAgcmVmcmVzaExpdmVTZXNzaW9ucygpO1xuICAgICAgc2V0QWxlcnRNZXNzYWdlKGDinIUgTW9iaWxlIGRldmljZSBiaW5kaW5nIGNsZWFyZWQgZm9yICR7dXNlcm5hbWV9LiBPcGVyYXRvciBjYW4gYmluZCBhIG5ldyBwaG9uZS5gKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0QWxlcnRNZXNzYWdlKG51bGwpLCA0MDAwKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gSGFuZGxlIFJlc2V0IEFsbCBEZXZpY2VzIChQQyArIE1vYmlsZSlcbiAgY29uc3QgaGFuZGxlUmVzZXRBbGxEZXZpY2VzID0gKG9wZXJhdG9ySWQ6IHN0cmluZywgdXNlcm5hbWU6IHN0cmluZykgPT4ge1xuICAgIGlmICh3aW5kb3cuY29uZmlybShgUmVzZXQgQk9USCBQQyAmIE1vYmlsZSBiaW5kaW5ncyBmb3IgXCIke3VzZXJuYW1lfVwiP2ApKSB7XG4gICAgICByZXNldE9wZXJhdG9yQWxsQmluZGluZ3Mob3BlcmF0b3JJZCk7XG4gICAgICBsb2FkRGF0YSgpO1xuICAgICAgcmVmcmVzaExpdmVTZXNzaW9ucygpO1xuICAgICAgc2V0QWxlcnRNZXNzYWdlKGDinIUgQWxsIGRldmljZSBiaW5kaW5ncyAoUEMgJiBNb2JpbGUpIGNsZWFyZWQgZm9yICR7dXNlcm5hbWV9LmApO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRBbGVydE1lc3NhZ2UobnVsbCksIDQwMDApO1xuICAgIH1cbiAgfTtcblxuICAvLyBIYW5kbGUgVG9nZ2xlIExvY2tcbiAgY29uc3QgaGFuZGxlVG9nZ2xlTG9jayA9IChvcGVyYXRvcklkOiBzdHJpbmcsIHVzZXJuYW1lOiBzdHJpbmcpID0+IHtcbiAgICB0b2dnbGVPcGVyYXRvckxvY2sob3BlcmF0b3JJZCk7XG4gICAgbG9hZERhdGEoKTtcbiAgICByZWZyZXNoTGl2ZVNlc3Npb25zKCk7XG4gICAgc2V0QWxlcnRNZXNzYWdlKGBMb2NrIHN0YXR1cyB1cGRhdGVkIGZvciAke3VzZXJuYW1lfWApO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0QWxlcnRNZXNzYWdlKG51bGwpLCAzMDAwKTtcbiAgfTtcblxuICAvLyBIYW5kbGUgRGVsZXRlIE9wZXJhdG9yXG4gIGNvbnN0IGhhbmRsZURlbGV0ZU9wZXJhdG9yID0gKG9wZXJhdG9ySWQ6IHN0cmluZywgdXNlcm5hbWU6IHN0cmluZykgPT4ge1xuICAgIGlmICh3aW5kb3cuY29uZmlybShgUGVybWFuZW50bHkgZGVsZXRlIG9wZXJhdG9yIGFjY291bnQgXCIke3VzZXJuYW1lfVwiP2ApKSB7XG4gICAgICBkZWxldGVPcGVyYXRvcihvcGVyYXRvcklkKTtcbiAgICAgIGxvYWREYXRhKCk7XG4gICAgICByZWZyZXNoTGl2ZVNlc3Npb25zKCk7XG4gICAgICBzZXRBbGVydE1lc3NhZ2UoYE9wZXJhdG9yICR7dXNlcm5hbWV9IGRlbGV0ZWRgKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0QWxlcnRNZXNzYWdlKG51bGwpLCAzMDAwKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gSGFuZGxlIEFkZCBPcGVyYXRvclxuICBjb25zdCBoYW5kbGVDcmVhdGVPcGVyYXRvciA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc2V0QWRkRXJyb3IoJycpO1xuXG4gICAgaWYgKCFuZXdVc2VybmFtZS50cmltKCkgfHwgIW5ld1Bhc3N3b3JkLnRyaW0oKSB8fCAhbmV3RGlzcGxheU5hbWUudHJpbSgpKSB7XG4gICAgICBzZXRBZGRFcnJvcignUGxlYXNlIGZpbGwgYWxsIHJlcXVpcmVkIGZpZWxkcycpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IHN1Y2Nlc3MgPSBhZGROZXdPcGVyYXRvcih7XG4gICAgICB1c2VybmFtZTogbmV3VXNlcm5hbWUudHJpbSgpLnRvTG93ZXJDYXNlKCksXG4gICAgICBwYXNzd29yZDogbmV3UGFzc3dvcmQudHJpbSgpLFxuICAgICAgZGlzcGxheU5hbWU6IG5ld0Rpc3BsYXlOYW1lLnRyaW0oKSxcbiAgICAgIHJvbGU6ICdvcGVyYXRvcicsXG4gICAgICBwaG9uZTogbmV3UGhvbmUudHJpbSgpIHx8ICc5NTYxNDYwMzEzJ1xuICAgIH0pO1xuXG4gICAgaWYgKHN1Y2Nlc3MpIHtcbiAgICAgIHNldFNob3dBZGRNb2RhbChmYWxzZSk7XG4gICAgICBzZXROZXdVc2VybmFtZSgnJyk7XG4gICAgICBzZXROZXdQYXNzd29yZCgnJyk7XG4gICAgICBzZXROZXdEaXNwbGF5TmFtZSgnJyk7XG4gICAgICBzZXROZXdQaG9uZSgnJyk7XG4gICAgICBsb2FkRGF0YSgpO1xuICAgICAgcmVmcmVzaExpdmVTZXNzaW9ucygpO1xuICAgICAgc2V0QWxlcnRNZXNzYWdlKCfinIUgTmV3IE9wZXJhdG9yIElEIGNyZWF0ZWQhIFBlcm1pdHRlZCBvbiAxIEF1dGhvcml6ZWQgUEMgKyAxIEF1dGhvcml6ZWQgTW9iaWxlLicpO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRBbGVydE1lc3NhZ2UobnVsbCksIDQwMDApO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRBZGRFcnJvcignVXNlcm5hbWUgYWxyZWFkeSBleGlzdHMuIFBsZWFzZSBjaG9vc2UgYW5vdGhlciB1c2VybmFtZS4nKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gSGFuZGxlIERvd25sb2FkIFByb2plY3QgWklQXG4gIGNvbnN0IGhhbmRsZURvd25sb2FkWmlwID0gYXN5bmMgKCkgPT4ge1xuICAgIHNldElzRXhwb3J0aW5nWmlwKHRydWUpO1xuICAgIHNldFppcFByb2dyZXNzKHsgcGVyY2VudDogMTAsIGZpbGU6ICdHYXRoZXJpbmcgcHJvamVjdCBzb3VyY2UgZmlsZXMuLi4nIH0pO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHppcEJsb2IgPSBhd2FpdCBnZW5lcmF0ZVByb2plY3RaaXAoKHBlcmNlbnQsIGZpbGUpID0+IHtcbiAgICAgICAgc2V0WmlwUHJvZ3Jlc3MoeyBwZXJjZW50LCBmaWxlIH0pO1xuICAgICAgfSk7XG5cbiAgICAgIHRyaWdnZXJEb3dubG9hZFppcCh6aXBCbG9iLCBgTXV6YW1taWwtT25saW5lLXNlcnZpY2UtcGMuemlwYCk7XG4gICAgICBzZXRBbGVydE1lc3NhZ2UoJ/Cfk6YgQ29tcGxldGUgb3JpZ2luYWwgcHJvamVjdCBzb3VyY2UgY29kZSAoLlpJUCkgZG93bmxvYWRlZCBzdWNjZXNzZnVsbHkhJyk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldEFsZXJ0TWVzc2FnZShudWxsKSwgNDAwMCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gJy9hcGkvZG93bmxvYWQtemlwJztcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNFeHBvcnRpbmdaaXAoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBXT1JLRkxPV19ZQU1MX0NPREUgPSBgbmFtZTogQnVpbGQgV2luZG93cyBEZXNrdG9wIEVYRSBTZXR1cFxuXG5vbjpcbiAgcHVzaDpcbiAgICBicmFuY2hlczogWyBtYWluLCBtYXN0ZXIgXVxuICB3b3JrZmxvd19kaXNwYXRjaDpcbiAgcmVsZWFzZTpcbiAgICB0eXBlczogWyBwdWJsaXNoZWQgXVxuXG5qb2JzOlxuICBidWlsZC13aW5kb3dzOlxuICAgIHJ1bnMtb246IHdpbmRvd3MtbGF0ZXN0XG5cbiAgICBzdGVwczpcbiAgICAgIC0gbmFtZTogQ2hlY2tvdXQgQ29kZVxuICAgICAgICB1c2VzOiBhY3Rpb25zL2NoZWNrb3V0QHY0XG5cbiAgICAgIC0gbmFtZTogU2V0dXAgTm9kZS5qcyAyMFxuICAgICAgICB1c2VzOiBhY3Rpb25zL3NldHVwLW5vZGVAdjRcbiAgICAgICAgd2l0aDpcbiAgICAgICAgICBub2RlLXZlcnNpb246IDIwXG4gICAgICAgICAgY2FjaGU6ICducG0nXG5cbiAgICAgIC0gbmFtZTogSW5zdGFsbCBEZXBlbmRlbmNpZXNcbiAgICAgICAgcnVuOiB8XG4gICAgICAgICAgbnBtIGluc3RhbGxcbiAgICAgICAgICBucG0gaW5zdGFsbCAtLXNhdmUtZGV2IGVsZWN0cm9uIGVsZWN0cm9uLXBhY2thZ2VyXG5cbiAgICAgIC0gbmFtZTogQnVpbGQgV2ViIEFwcGxpY2F0aW9uIEFzc2V0c1xuICAgICAgICBydW46IG5wbSBydW4gYnVpbGRcblxuICAgICAgLSBuYW1lOiBQYWNrYWdlIFdpbmRvd3MgLkVYRSBBcHBsaWNhdGlvblxuICAgICAgICBydW46IHxcbiAgICAgICAgICBucHggZWxlY3Ryb24tcGFja2FnZXIgLiBcIk11emFtbWlsIE9ubGluZSBzZXJ2aWNlIHBjXCIgLS1wbGF0Zm9ybT13aW4zMiAtLWFyY2g9eDY0IC0tb3V0PWRpc3QtZXhlIC0tb3ZlcndyaXRlIC0taWNvbj1wdWJsaWMvZmF2aWNvbi5pY29cblxuICAgICAgLSBuYW1lOiBDb21wcmVzcyBFeGVjdXRhYmxlIEZvbGRlciB0byBaSVBcbiAgICAgICAgcnVuOiB8XG4gICAgICAgICAgQ29tcHJlc3MtQXJjaGl2ZSAtUGF0aCBcImRpc3QtZXhlXFxcXE11emFtbWlsIE9ubGluZSBzZXJ2aWNlIHBjLXdpbjMyLXg2NFxcXFwqXCIgLURlc3RpbmF0aW9uUGF0aCBcIk11emFtbWlsLU9ubGluZS1TZXJ2aWNlLVdpbmRvd3MteDY0LnppcFwiXG5cbiAgICAgIC0gbmFtZTogVXBsb2FkIFdpbmRvd3MgRVhFIEFydGlmYWN0XG4gICAgICAgIHVzZXM6IGFjdGlvbnMvdXBsb2FkLWFydGlmYWN0QHY0XG4gICAgICAgIHdpdGg6XG4gICAgICAgICAgbmFtZTogTXV6YW1taWwtT25saW5lLVNlcnZpY2UtV2luZG93cy14NjRcbiAgICAgICAgICBwYXRoOiBNdXphbW1pbC1PbmxpbmUtU2VydmljZS1XaW5kb3dzLXg2NC56aXBcbiAgICAgICAgICByZXRlbnRpb24tZGF5czogMzBgO1xuXG4gIGNvbnN0IFBDX0xBVU5DSEVSX0JBVF9DT0RFID0gYEBlY2hvIG9mZlxudGl0bGUgTXV6YW1taWwgT25saW5lIHNlcnZpY2UgcGNcbmNvbG9yIDBiXG5lY2hvID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XG5lY2hvICAgTVVaQU1NSUwgT05MSU5FIFNFUlZJQ0UgUEMgLSBXT1JLU1RBVElPTiB2OTguMFxuZWNobyAgIFN0YXJ0aW5nIExvY2FsIFNlcnZlciBhbmQgTGF1bmNoaW5nIEFwcC4uLlxuZWNobyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuXG46OiBDaGVjayBpZiBub2RlX21vZHVsZXMgZXhpc3RzXG5pZiBub3QgZXhpc3Qgbm9kZV9tb2R1bGVzIChcbiAgICBlY2hvIFtJTkZPXSBGaXJzdCB0aW1lIHNldHVwIGRldGVjdGVkISBJbnN0YWxsaW5nIGRlcGVuZGVuY2llcy4uLlxuICAgIGNhbGwgbnBtIGluc3RhbGxcbilcblxuOjogTGF1bmNoIGJyb3dzZXIgaW4gYmFja2dyb3VuZCBhZnRlciAzIHNlY29uZHNcbnN0YXJ0IFwiXCIgY21kIC9jIFwidGltZW91dCAvdCAzID5udWwgJiYgc3RhcnQgaHR0cDovL2xvY2FsaG9zdDozMDAwXCJcblxuOjogU3RhcnQgdGhlIGFwcGxpY2F0aW9uXG5jYWxsIG5wbSBydW4gZGV2XG5wYXVzZWA7XG5cbiAgY29uc3QgUENfRVhFX0JVSUxERVJfQkFUX0NPREUgPSBgQGVjaG8gb2ZmXG50aXRsZSBNdXphbW1pbCBPbmxpbmUgc2VydmljZSBwYyAtIFByb2Zlc3Npb25hbCAuRVhFIFNldHVwIEJ1aWxkZXJcbmNvbG9yIDBhXG5cbmVjaG8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbmVjaG8gICBNVVpBTU1JTCBPTkxJTkUgU0VSVklDRSBQQyAtIFBST0ZFU1NJT05BTCAuRVhFIEJVSUxERVJcbmVjaG8gICBCdWlsZGluZyBEZXNrdG9wIEFwcGxpY2F0aW9uIGFuZCBXaW5kb3dzIEluc3RhbGxlci4uLlxuZWNobyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuZWNoby5cblxud2hlcmUgbm9kZSA+bnVsIDI+bnVsXG5pZiAlZXJyb3JsZXZlbCUgbmVxIDAgKFxuICAgIGVjaG8gW0VSUk9SXSBOb2RlLmpzIGlzIG5vdCBpbnN0YWxsZWQhXG4gICAgZWNobyBQbGVhc2UgaW5zdGFsbCBOb2RlLmpzIGZyb20gaHR0cHM6Ly9ub2RlanMub3JnXG4gICAgcGF1c2VcbiAgICBleGl0IC9iXG4pXG5cbmVjaG8gWzEvNF0gSW5zdGFsbGluZyBuZWNlc3NhcnkgYnVpbGQgcGFja2FnZXMuLi5cbmNhbGwgbnBtIGluc3RhbGxcbmNhbGwgbnBtIGluc3RhbGwgLS1zYXZlLWRldiBlbGVjdHJvbiBlbGVjdHJvbi1wYWNrYWdlciBlbGVjdHJvbi1idWlsZGVyXG5cbmVjaG8gWzIvNF0gQnVpbGRpbmcgaGlnaC1wZXJmb3JtYW5jZSBwcm9kdWN0aW9uIGFzc2V0cy4uLlxuY2FsbCBucG0gcnVuIGJ1aWxkXG5cbmVjaG8gWzMvNF0gUGFja2FnaW5nIHN0YW5kYWxvbmUgV2luZG93cyBFeGVjdXRhYmxlICguZXhlKS4uLlxuY2FsbCBucHggZWxlY3Ryb24tcGFja2FnZXIgLiBcIk11emFtbWlsIE9ubGluZSBzZXJ2aWNlIHBjXCIgLS1wbGF0Zm9ybT13aW4zMiAtLWFyY2g9eDY0IC0tb3V0PWRpc3QtZXhlIC0tb3ZlcndyaXRlIC0taWNvbj1wdWJsaWMvZmF2aWNvbi5pY29cblxuZWNoby5cbmVjaG8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbmVjaG8gICBTVUNDRVNTISBXaW5kb3dzIERlc2t0b3AgU29mdHdhcmUgaXMgUmVhZHkhXG5lY2hvICAgRm9sZGVyOiBkaXN0LWV4ZVxcXFxNdXphbW1pbCBPbmxpbmUgc2VydmljZSBwYy13aW4zMi14NjRcXFxcXG5lY2hvICAgRXhlY3V0YWJsZTogXCJNdXphbW1pbCBPbmxpbmUgc2VydmljZSBwYy5leGVcIlxuZWNobyA9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PVxuZWNoby5cbmV4cGxvcmVyIFwiZGlzdC1leGVcXFxcTXV6YW1taWwgT25saW5lIHNlcnZpY2UgcGMtd2luMzIteDY0XCJcbnBhdXNlYDtcblxuICAvLyBEb3dubG9hZCBXb3JrZmxvdyBZTUxcbiAgY29uc3QgaGFuZGxlRG93bmxvYWRXb3JrZmxvd1ltbCA9ICgpID0+IHtcbiAgICBjb25zdCBibG9iID0gbmV3IEJsb2IoW1dPUktGTE9XX1lBTUxfQ09ERV0sIHsgdHlwZTogJ3RleHQveWFtbCcgfSk7XG4gICAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcbiAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgIGEuaHJlZiA9IHVybDtcbiAgICBhLmRvd25sb2FkID0gJ2J1aWxkLXdpbmRvd3MtZXhlLnltbCc7XG4gICAgYS5jbGljaygpO1xuICAgIFVSTC5yZXZva2VPYmplY3RVUkwodXJsKTtcbiAgICBzZXRBbGVydE1lc3NhZ2UoJ+KaoSBHaXRIdWIgQWN0aW9ucyB3b3JrZmxvdyBmaWxlIFwiYnVpbGQtd2luZG93cy1leGUueW1sXCIgZG93bmxvYWRlZCEnKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldEFsZXJ0TWVzc2FnZShudWxsKSwgMzAwMCk7XG4gIH07XG5cbiAgLy8gRG93bmxvYWQgUEMgTGF1bmNoZXIgQkFUXG4gIGNvbnN0IGhhbmRsZURvd25sb2FkUGNMYXVuY2hlciA9ICgpID0+IHtcbiAgICBjb25zdCBibG9iID0gbmV3IEJsb2IoW1BDX0xBVU5DSEVSX0JBVF9DT0RFXSwgeyB0eXBlOiAnYXBwbGljYXRpb24veC1iYXQnIH0pO1xuICAgIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XG4gICAgY29uc3QgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcbiAgICBhLmhyZWYgPSB1cmw7XG4gICAgYS5kb3dubG9hZCA9ICdTVEFSVC1XT1JLU1RBVElPTi5iYXQnO1xuICAgIGEuY2xpY2soKTtcbiAgICBVUkwucmV2b2tlT2JqZWN0VVJMKHVybCk7XG4gICAgc2V0QWxlcnRNZXNzYWdlKCfwn5K7IFBDIExhdW5jaGVyIGZpbGUgXCJTVEFSVC1XT1JLU1RBVElPTi5iYXRcIiBkb3dubG9hZGVkIScpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0QWxlcnRNZXNzYWdlKG51bGwpLCAzMDAwKTtcbiAgfTtcblxuICAvLyBEb3dubG9hZCBQQyBFWEUgQnVpbGRlciBCQVRcbiAgY29uc3QgaGFuZGxlRG93bmxvYWRFeGVCdWlsZGVyID0gKCkgPT4ge1xuICAgIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbUENfRVhFX0JVSUxERVJfQkFUX0NPREVdLCB7IHR5cGU6ICdhcHBsaWNhdGlvbi94LWJhdCcgfSk7XG4gICAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcbiAgICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgIGEuaHJlZiA9IHVybDtcbiAgICBhLmRvd25sb2FkID0gJ0NSRUFURS1FWEUtU0VUVVAuYmF0JztcbiAgICBhLmNsaWNrKCk7XG4gICAgVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpO1xuICAgIHNldEFsZXJ0TWVzc2FnZSgn8J+boO+4jyBQQyBFWEUgU2V0dXAgQnVpbGRlciBmaWxlIFwiQ1JFQVRFLUVYRS1TRVRVUC5iYXRcIiBkb3dubG9hZGVkIScpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0QWxlcnRNZXNzYWdlKG51bGwpLCAzMDAwKTtcbiAgfTtcblxuICAvLyBDb3B5IHRvIGNsaXBib2FyZCBoZWxwZXJzXG4gIGNvbnN0IGhhbmRsZUNvcHlXb3JrZmxvd0NvZGUgPSAoKSA9PiB7XG4gICAgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQoV09SS0ZMT1dfWUFNTF9DT0RFKTtcbiAgICBzZXRDb3BpZWRXb3JrZmxvdyh0cnVlKTtcbiAgICBzZXRBbGVydE1lc3NhZ2UoJ/Cfk4sgR2l0SHViIEFjdGlvbnMgV29ya2Zsb3cgWUFNTCBjb2RlIGNvcGllZCB0byBjbGlwYm9hcmQhJyk7XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBzZXRDb3BpZWRXb3JrZmxvdyhmYWxzZSk7XG4gICAgICBzZXRBbGVydE1lc3NhZ2UobnVsbCk7XG4gICAgfSwgMzAwMCk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ29weVBjQmF0Y2hDb2RlID0gKCkgPT4ge1xuICAgIG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KFBDX0xBVU5DSEVSX0JBVF9DT0RFKTtcbiAgICBzZXRDb3BpZWRQY0JhdGNoKHRydWUpO1xuICAgIHNldEFsZXJ0TWVzc2FnZSgn8J+TiyBQQyAxLUNsaWNrIExhdW5jaGVyIChTVEFSVC1XT1JLU1RBVElPTi5iYXQpIGNvZGUgY29waWVkIHRvIGNsaXBib2FyZCEnKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHNldENvcGllZFBjQmF0Y2goZmFsc2UpO1xuICAgICAgc2V0QWxlcnRNZXNzYWdlKG51bGwpO1xuICAgIH0sIDMwMDApO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNvcHlFeGVCdWlsZGVyQ29kZSA9ICgpID0+IHtcbiAgICBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dChQQ19FWEVfQlVJTERFUl9CQVRfQ09ERSk7XG4gICAgc2V0Q29waWVkRXhlQmF0Y2godHJ1ZSk7XG4gICAgc2V0QWxlcnRNZXNzYWdlKCfwn5OLIFBDIEVYRSBTZXR1cCBCdWlsZGVyIChDUkVBVEUtRVhFLVNFVFVQLmJhdCkgY29kZSBjb3BpZWQgdG8gY2xpcGJvYXJkIScpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgc2V0Q29waWVkRXhlQmF0Y2goZmFsc2UpO1xuICAgICAgc2V0QWxlcnRNZXNzYWdlKG51bGwpO1xuICAgIH0sIDMwMDApO1xuICB9O1xuXG4gIC8vIEhhbmRsZSBTYXZlIFNob3AgU2V0dGluZ3NcbiAgY29uc3QgaGFuZGxlU2F2ZVNldHRpbmdzID0gKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBvblVwZGF0ZVNldHRpbmdzKHNob3BGb3JtKTtcbiAgICBzZXRBbGVydE1lc3NhZ2UoJ+KchSBTaG9wIGRldGFpbHMgYW5kIGNvbmZpZ3VyYXRpb24gc2F2ZWQhJyk7XG4gICAgc2V0VGltZW91dCgoKSA9PiBzZXRBbGVydE1lc3NhZ2UobnVsbCksIDMwMDApO1xuICB9O1xuXG4gIGNvbnN0IGNvbXBsZXRlZFdvcmtmbG93Q291bnQgPSBPYmplY3QudmFsdWVzKGNvbXBsZXRlZFN0ZXBzKS5maWx0ZXIoQm9vbGVhbikubGVuZ3RoO1xuICBjb25zdCBvbmxpbmVDb3VudCA9IGxpdmVTZXNzaW9ucy5maWx0ZXIocyA9PiBzLmlzT25saW5lKS5sZW5ndGg7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgey8qIFRvcCBCYW5uZXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBwLTUgcm91bmRlZC0yeGwgc2hhZG93LW1kIGZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgZmxleC13cmFwXCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxTaGllbGRDaGVjayBjbGFzc05hbWU9XCJ3LTYgaC02IHRleHQtYmx1ZS00MDBcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj5NYXN0ZXIgQWRtaW4gQ29udHJvbCAmIExpdmUgTW9uaXRvcmluZyBIdWI8L3NwYW4+XG4gICAgICAgICAgICA8L2gxPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTMwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIHRleHQteHMgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgZm9udC1tb25vIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtNDAwIGFuaW1hdGUtcHVsc2VcIj48L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuPkxpdmU6IHtvbmxpbmVDb3VudH0gQWN0aXZlIE9ubGluZTwvc3Bhbj5cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTFcIj5cbiAgICAgICAgICAgIFJlYWwtVGltZSBPcGVyYXRvciBBY3Rpdml0eSBNb25pdG9yIOKAoiBMaWNlbnNlIFJlbmV3YWxzIOKAoiBEdWFsLURldmljZSBQQyAmIE1vYmlsZSBTZWN1cml0eSDigKIgQ2VudHJhbCBTZXR1cFxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEFjdGlvbiBCdXR0b25zICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGZsZXgtd3JhcFwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURvd25sb2FkWmlwfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzRXhwb3J0aW5nWmlwfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctZ3JhZGllbnQtdG8tciBmcm9tLWVtZXJhbGQtNjAwIHRvLXRlYWwtNjAwIGhvdmVyOmZyb20tZW1lcmFsZC01MDAgaG92ZXI6dG8tdGVhbC01MDAgdGV4dC13aGl0ZSBmb250LWV4dHJhYm9sZCB0ZXh0LXhzIHB4LTQgcHktMi41IHJvdW5kZWQteGwgc2hhZG93LWxnIHNoYWRvdy1lbWVyYWxkLTYwMC8yMCB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzY2FsZS0xMDUgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICB0aXRsZT1cIkRvd25sb2FkIGZ1bGwgcHJvamVjdCBzb3VyY2UgY29kZSBhcmNoaXZlICguemlwKVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEFyY2hpdmUgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj57aXNFeHBvcnRpbmdaaXAgPyAnUGFja2luZyBaSVAuLi4nIDogJ/Cfk6YgRG93bmxvYWQgUHJvamVjdCAuWklQJ308L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBOb3RpZmljYXRpb25zICovfVxuICAgICAge2FsZXJ0TWVzc2FnZSAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgcm91bmRlZC14bCBiZy1lbWVyYWxkLTUwMC8xMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIHRleHQtZW1lcmFsZC00MDAgdGV4dC14cyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYW5pbWF0ZS1pbiBmYWRlLWluXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC00MDAgZmxleC1zaHJpbmstMFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj57YWxlcnRNZXNzYWdlfTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldEFsZXJ0TWVzc2FnZShudWxsKX0gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTQwMCBob3Zlcjp0ZXh0LXdoaXRlXCI+4pyVPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFN1Yi1OYXZpZ2F0aW9uIFRhYnMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHAtMS41IHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgb3ZlcmZsb3cteC1hdXRvXCI+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTdWJUYWIoJ2xpdmVfbW9uaXRvcicpfVxuICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtNCBweS0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgIGFjdGl2ZVN1YlRhYiA9PT0gJ2xpdmVfbW9uaXRvcidcbiAgICAgICAgICAgICAgPyAnYmctcm9zZS02MDAgdGV4dC13aGl0ZSBzaGFkb3cnXG4gICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgfWB9XG4gICAgICAgID5cbiAgICAgICAgICA8UmFkaW8gY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC13aGl0ZSBhbmltYXRlLXB1bHNlXCIgLz5cbiAgICAgICAgICA8c3Bhbj7wn5S0IExpdmUgT3BlcmF0b3IgTW9uaXRvciAoe29ubGluZUNvdW50fSk8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTdWJUYWIoJ29wZXJhdG9ycycpfVxuICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtNCBweS0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgIGFjdGl2ZVN1YlRhYiA9PT0gJ29wZXJhdG9ycydcbiAgICAgICAgICAgICAgPyAnYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBzaGFkb3cnXG4gICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgfWB9XG4gICAgICAgID5cbiAgICAgICAgICA8TW9uaXRvciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgPHNwYW4+T3BlcmF0b3IgSURzICYgTG9ja3MgKHtvcGVyYXRvcnMubGVuZ3RofSk8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTdWJUYWIoJ3dvcmtmbG93Jyl9XG4gICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC00IHB5LTIgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgYWN0aXZlU3ViVGFiID09PSAnd29ya2Zsb3cnXG4gICAgICAgICAgICAgID8gJ2JnLWJsdWUtNjAwIHRleHQtd2hpdGUgc2hhZG93J1xuICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgIH1gfVxuICAgICAgICA+XG4gICAgICAgICAgPENsaXBib2FyZExpc3QgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1hbWJlci00MDBcIiAvPlxuICAgICAgICAgIDxzcGFuPkN5YmVyIENhZmUgV29ya2Zsb3cgJiBTT1A8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVTdWJUYWIoJ3ppcF9kb3dubG9hZCcpfVxuICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtNCBweS0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgIGFjdGl2ZVN1YlRhYiA9PT0gJ3ppcF9kb3dubG9hZCdcbiAgICAgICAgICAgICAgPyAnYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBzaGFkb3cnXG4gICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgfWB9XG4gICAgICAgID5cbiAgICAgICAgICA8QXJjaGl2ZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICA8c3Bhbj4zIEZpbGVzIEh1YiAoR2l0SHViIFpJUCDigKIgV29ya2Zsb3cg4oCiIFBDIEZpbGVzKTwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVN1YlRhYignbG9ncycpfVxuICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtNCBweS0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgIGFjdGl2ZVN1YlRhYiA9PT0gJ2xvZ3MnXG4gICAgICAgICAgICAgID8gJ2JnLWJsdWUtNjAwIHRleHQtd2hpdGUgc2hhZG93J1xuICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgIH1gfVxuICAgICAgICA+XG4gICAgICAgICAgPENsb2NrIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICA8c3Bhbj5TZWN1cml0eSAmIERldmljZSBMb2dzPC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlU3ViVGFiKCdzZXR0aW5ncycpfVxuICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtNCBweS0yIHJvdW5kZWQtbGcgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgIGFjdGl2ZVN1YlRhYiA9PT0gJ3NldHRpbmdzJ1xuICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdydcbiAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICB9YH1cbiAgICAgICAgPlxuICAgICAgICAgIDxLZXkgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgIDxzcGFuPk1hc3RlciBTZXR1cCBDZW50ZXI8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBUQUIgMDogTElWRSBVU0VSIE1PTklUT1JJTkcgJiBSRU5FV0FMIERFQ0sgKi99XG4gICAgICB7YWN0aXZlU3ViVGFiID09PSAnbGl2ZV9tb25pdG9yJyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNSBzaGFkb3cteGwgc3BhY2UteS00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgcGItMyBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8UmFkaW8gY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXJvc2UtNTAwIGFuaW1hdGUtcHVsc2VcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkxpdmUgT3BlcmF0b3IgQWN0aXZpdHkgJiBSZWFsLVRpbWUgUHVsc2U8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWVtZXJhbGQtNDAwIGJnLWVtZXJhbGQtNTAwLzEwIHB4LTIgcHktMC41IHJvdW5kZWQgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8yMCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgIDMuNXMgTGl2ZSBQaW5nXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgIFNlZSBleGFjdGx5IHdoaWNoIG9wZXJhdG9yIGlzIHdvcmtpbmcgb24gd2hhdCBzdHVkaW8gaW4gcmVhbC10aW1lLCB0aGVpciBhY3RpdmUgUEMvTW9iaWxlLCBhbmQgcmVuZXcgYWNjZXNzLlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNBdXRvUmVmcmVzaGluZyghaXNBdXRvUmVmcmVzaGluZyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMyBweS0xLjUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBib3JkZXIgdHJhbnNpdGlvbi1jb2xvcnMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSAke1xuICAgICAgICAgICAgICAgICAgaXNBdXRvUmVmcmVzaGluZyBcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MDAvMTAgdGV4dC1lbWVyYWxkLTMwMCBib3JkZXItZW1lcmFsZC01MDAvMzAnIFxuICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS00MDAgYm9yZGVyLXNsYXRlLTcwMCdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxBY3Rpdml0eSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+e2lzQXV0b1JlZnJlc2hpbmcgPyAnQXV0by1VcGRhdGU6IE9OJyA6ICdQYXVzZWQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3JlZnJlc2hMaXZlU2Vzc2lvbnN9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC14bCBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMzAwIGhvdmVyOnRleHQtd2hpdGUgdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJSZWZyZXNoIExpdmUgRGF0YVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8UmVmcmVzaEN3IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBMaXZlIE1ldHJpYyBDYXJkcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTQgZ2FwLTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgcC0zLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgdGV4dC1bMTFweF1cIj5BY3RpdmUgU3RhZmYgT25saW5lPC9zcGFuPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgZm9udC1tb25vIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yLjUgaC0yLjUgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtNDAwIGFuaW1hdGUtcGluZ1wiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3Bhbj57b25saW5lQ291bnR9PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1lbWVyYWxkLTQwMCBmb250LW1vbm9cIj5MaXZlIFdlYlNvY2tldCBQdWxzZTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBwLTMuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayB0ZXh0LVsxMXB4XVwiPlBDIFdvcmtzdGF0aW9ucyBBY3RpdmU8L3NwYW4+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1leHRyYWJvbGQgdGV4dC1ibHVlLTQwMCBmb250LW1vbm8gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8TGFwdG9wIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPntsaXZlU2Vzc2lvbnMuZmlsdGVyKHMgPT4gcy5kZXZpY2VUeXBlID09PSAncGMnICYmIHMuaXNPbmxpbmUpLmxlbmd0aH08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPkRlc2t0b3AgV29ya3N0YXRpb25zPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHAtMy41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIHRleHQtWzExcHhdXCI+TW9iaWxlIEhhbmRzZXRzIEFjdGl2ZTwvc3Bhbj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWV4dHJhYm9sZCB0ZXh0LXB1cnBsZS00MDAgZm9udC1tb25vIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPFNtYXJ0cGhvbmUgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+e2xpdmVTZXNzaW9ucy5maWx0ZXIocyA9PiBzLmRldmljZVR5cGUgPT09ICdtb2JpbGUnICYmIHMuaXNPbmxpbmUpLmxlbmd0aH08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPk9wZXJhdG9yIEhhbmRzZXRzPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHAtMy41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIHRleHQtWzExcHhdXCI+TGFzdCBQdWxzZSBVcGRhdGU8L3NwYW4+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdGV4dC13aGl0ZSBmb250LW1vbm8gbXQtMVwiPlxuICAgICAgICAgICAgICAgIHtsYXN0UmVmcmVzaGVkQXQgfHwgJ0Nvbm5lY3RpbmcuLi4nfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDBcIj5BdXRvIEhlYXJ0YmVhdDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIExpdmUgU2Vzc2lvbnMgVGFibGUgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvdmVyZmxvdy14LWF1dG9cIj5cbiAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1sZWZ0IHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPHRoZWFkPlxuICAgICAgICAgICAgICAgIDx0ciBjbGFzc05hbWU9XCJib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMyBweC0zXCI+TGl2ZSBTdGF0dXM8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPk9wZXJhdG9yIE5hbWU8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPkRldmljZSAvIE1hY2hpbmU8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPkFjdGl2ZSBTdHVkaW8gLyBUYXNrPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5MaWNlbnNlIFZhbGlkaXR5PC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1yaWdodFwiPkFkbWluIENvbnRyb2w8L3RoPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtODAwLzYwIGZvbnQtc2Fuc1wiPlxuICAgICAgICAgICAgICAgIHtsaXZlU2Vzc2lvbnMubWFwKChzZXNzaW9uKSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBkYXlzTGVmdCA9IGNhbGN1bGF0ZVJlbWFpbmluZ0RheXMoc2Vzc2lvbi52YWxpZGl0eUV4cGlyZXNBdCk7XG4gICAgICAgICAgICAgICAgICBjb25zdCBpc0V4cGlyaW5nID0gZGF5c0xlZnQgPCAxNTtcblxuICAgICAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICAgICAgPHRyIGtleT17c2Vzc2lvbi5zZXNzaW9uSWQgfHwgYCR7c2Vzc2lvbi51c2VybmFtZX0tJHtzZXNzaW9uLmRldmljZUlkfWB9IGNsYXNzTmFtZT1cImhvdmVyOmJnLXNsYXRlLTk1MC80MCB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBMaXZlIFB1bHNlIFN0YXR1cyAqL31cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT17YHctMi41IGgtMi41IHJvdW5kZWQtZnVsbCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlc3Npb24uaXNPbmxpbmUgPyAnYmctZW1lcmFsZC00MDAgYW5pbWF0ZS1wdWxzZScgOiAnYmctc2xhdGUtNjAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B0ZXh0LVsxMXB4XSBmb250LWJvbGQgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXNzaW9uLmlzT25saW5lID8gJ3RleHQtZW1lcmFsZC00MDAnIDogJ3RleHQtc2xhdGUtNTAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nlc3Npb24uaXNPbmxpbmUgPyAnQWN0aXZlIE5vdycgOiBgJHtzZXNzaW9uLmxhc3RBY3RpdmVTZWNvbmRzQWdvIHx8IDMwfXMgYWdvYH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBPcGVyYXRvciBEZXRhaWxzICovfVxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSB0ZXh0LXNtXCI+e3Nlc3Npb24uZGlzcGxheU5hbWV9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPkB7c2Vzc2lvbi51c2VybmFtZX0g4oCiIHtzZXNzaW9uLnBob25lIHx8ICc5NTYxNDYwMzEzJ308L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuXG4gICAgICAgICAgICAgICAgICAgICAgey8qIERldmljZSAmIEhhcmR3YXJlICovfVxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3Nlc3Npb24uZGV2aWNlVHlwZSA9PT0gJ21vYmlsZScgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNtYXJ0cGhvbmUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1wdXJwbGUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGFwdG9wIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYmx1ZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1bMTFweF1cIj57c2Vzc2lvbi5kZXZpY2VJZH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDBcIj57c2Vzc2lvbi5kZXZpY2VOYW1lfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogQ3VycmVudCBBY3RpdmUgU3R1ZGlvICovfVxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIuNSBweS0xIHJvdW5kZWQtbGcgYmctYmx1ZS01MDAvMTAgdGV4dC1ibHVlLTMwMCBib3JkZXIgYm9yZGVyLWJsdWUtNTAwLzIwIGZvbnQtYm9sZCB0ZXh0LVsxMXB4XSBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPEFjdGl2aXR5IGNsYXNzTmFtZT1cInctMyBoLTMgdGV4dC1ibHVlLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntzZXNzaW9uLmN1cnJlbnRUYWIgfHwgJ1dvcmtzdGF0aW9uIEh1Yid9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogTGljZW5zZSBWYWxpZGl0eSAmIFJlbmV3YWwgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3Nlc3Npb24ucm9sZSA9PT0gJ2FkbWluJyB8fCBzZXNzaW9uLnVzZXJuYW1lID09PSAnYWRtaW4nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCBmb250LW1vbm8gdGV4dC1bMTFweF0gdGV4dC1hbWJlci0zMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPvCfkZEgTGlmZXRpbWUgQWNjZXNzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1lbWVyYWxkLTQwMCBmb250LWJvbGRcIj5OZXZlciBFeHBpcmVzIChQZXJtYW5lbnQpPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgZm9udC1ib2xkIGZvbnQtbW9ubyB0ZXh0LVsxMXB4XSAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNFeHBpcmluZyA/ICd0ZXh0LXJvc2UtNDAwJyA6ICd0ZXh0LWVtZXJhbGQtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtkYXlzTGVmdCA+IDAgPyBgJHtkYXlzTGVmdH0gRGF5cyBMZWZ0YCA6ICdFeHBpcmVkJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwXCI+RXhwOiB7c2Vzc2lvbi52YWxpZGl0eUV4cGlyZXNBdCB8fCAnMjAyNi0xMi0zMSd9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEFjdGlvbiBidXR0b25zICovfVxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSZW5ldyBCdXR0b24gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmb3VuZCA9IG9wZXJhdG9ycy5maW5kKG8gPT4gby51c2VybmFtZSA9PT0gc2Vzc2lvbi51c2VybmFtZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZm91bmQpIHNldFNlbGVjdGVkT3BGb3JSZW5ldyhmb3VuZCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMSByb3VuZGVkLWxnIGJnLWVtZXJhbGQtNTAwLzEwIHRleHQtZW1lcmFsZC0zMDAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCBob3ZlcjpiZy1lbWVyYWxkLTUwMC8yMCBmb250LWJvbGQgdGV4dC1bMTBweF0gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUmVuZXcgTGljZW5zZSBBY2Nlc3NcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPENhbGVuZGFyIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlJlbmV3PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogU2VuZCBNZXNzYWdlICovfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QnJvYWRjYXN0VGFyZ2V0VXNlcm5hbWUoc2Vzc2lvbi51c2VybmFtZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRCcm9hZGNhc3RNZXNzYWdlVGV4dCgnJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgcm91bmRlZC1sZyBiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgaG92ZXI6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJTZW5kIEluLUFwcCBUb2FzdCBNZXNzYWdlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNZXNzYWdlU3F1YXJlIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogRm9yY2UgRGlzY29ubmVjdCAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUZvcmNlRGlzY29ubmVjdChzZXNzaW9uLnVzZXJuYW1lLCBzZXNzaW9uLmRldmljZUlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgcm91bmRlZC1sZyBiZy1yb3NlLTUwMC8xMCB0ZXh0LXJvc2UtNDAwIGJvcmRlciBib3JkZXItcm9zZS01MDAvMzAgaG92ZXI6Ymctcm9zZS01MDAvMjBcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRm9yY2UgRGlzY29ubmVjdCBTZXNzaW9uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQb3dlciBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFRBQiAxOiBPUEVSQVRPUiBJRFMgJiBEVUFMLURFVklDRSAoUEMgKyBNT0JJTEUpIFRBQkxFICovfVxuICAgICAge2FjdGl2ZVN1YlRhYiA9PT0gJ29wZXJhdG9ycycgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTUgc2hhZG93LXhsIHNwYWNlLXktNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHBiLTMgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+QXV0aG9yaXplZCBPcGVyYXRvcnMgKFBDICsgTW9iaWxlIEJpbmRpbmcpPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1lbWVyYWxkLTQwMCBiZy1lbWVyYWxkLTUwMC8xMCBweC0yIHB5LTAuNSByb3VuZGVkIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMjAgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICAxIFBDICsgMSBNb2JpbGUgUGVyIElEXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgIEVhY2ggb3BlcmF0b3IgSUQgY2FuIHdvcmsgb24gPGI+MSBhdXRob3JpemVkIFBDPC9iPiBBTkQgPGI+MSBhdXRob3JpemVkIE1vYmlsZTwvYj4gYXQgdGhlIHNhbWUgdGltZS4gVGhpcmQtcGFydHkgZGV2aWNlcyBhcmUgYmxvY2tlZCBhdXRvbWF0aWNhbGx5LlxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QWRkTW9kYWwodHJ1ZSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYmctYmx1ZS02MDAgaG92ZXI6YmctYmx1ZS01MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14cyBweC0zLjUgcHktMiByb3VuZGVkLXhsIHNoYWRvdyB0cmFuc2l0aW9uLWFsbCBzZWxmLXN0YXJ0IHNtOnNlbGYtYXV0b1wiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxVc2VyUGx1cyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+UmVnaXN0ZXIgTmV3IE9wZXJhdG9yIElEPC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQ3VycmVudCBEZXZpY2UgQ2FsbG91dCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMy41IHJvdW5kZWQteGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGZsZXgtd3JhcCBnYXAtMiB0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8Q3B1IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ibHVlLTQwMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPllvdXIgQ3VycmVudCBNYWNoaW5lICh7Y3VycmVudElzTW9iaWxlID8gJ/Cfk7EgTW9iaWxlJyA6ICfwn5K7IFBDJ30pOjwvc3Bhbj5cbiAgICAgICAgICAgICAgPGNvZGUgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LW1vbm8gZm9udC1ib2xkIGJnLXNsYXRlLTkwMCBweC0yIHB5LTAuNSByb3VuZGVkIGJvcmRlciBib3JkZXItc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgICAge2N1cnJlbnREZXZpY2VJZH1cbiAgICAgICAgICAgICAgPC9jb2RlPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBmb250LW1vbm8gdGV4dC1bMTFweF1cIj57Y3VycmVudERldmljZU5hbWV9PC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIE9wZXJhdG9ycyBUYWJsZSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXgtYXV0b1wiPlxuICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWxlZnQgdGV4dC14c1wiPlxuICAgICAgICAgICAgICA8dGhlYWQ+XG4gICAgICAgICAgICAgICAgPHRyIGNsYXNzTmFtZT1cImJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5PcGVyYXRvciAvIFVzZXJuYW1lPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5Sb2xlPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5BdXRob3JpemVkIFBDICgxIE1heCk8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPkF1dGhvcml6ZWQgTW9iaWxlICgxIE1heCk8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPkxpY2Vuc2UgU3RhdHVzPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0zIHB4LTMgdGV4dC1yaWdodFwiPkRldmljZSAmIFJlbmV3IEFjdGlvbnM8L3RoPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtODAwLzYwXCI+XG4gICAgICAgICAgICAgICAge29wZXJhdG9ycy5tYXAoKG9wKSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBkYXlzTGVmdCA9IGNhbGN1bGF0ZVJlbWFpbmluZ0RheXMob3AudmFsaWRpdHlFeHBpcmVzQXQpO1xuXG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtvcC5pZH0gY2xhc3NOYW1lPVwiaG92ZXI6Ymctc2xhdGUtOTUwLzQwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICAgICAgey8qIE9wZXJhdG9yIE5hbWUgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC13aGl0ZSB0ZXh0LXNtXCI+e29wLmRpc3BsYXlOYW1lfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBmb250LW1vbm8gdGV4dC1bMTFweF1cIj5Ae29wLnVzZXJuYW1lfSDigKIge29wLnBob25lfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogUm9sZSAqL31cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIHB5LTAuNSByb3VuZGVkIHRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgZm9udC1tb25vICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9wLnJvbGUgPT09ICdhZG1pbidcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1wdXJwbGUtNTAwLzIwIHRleHQtcHVycGxlLTMwMCBib3JkZXIgYm9yZGVyLXB1cnBsZS01MDAvMzAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctYmx1ZS01MDAvMjAgdGV4dC1ibHVlLTMwMCBib3JkZXIgYm9yZGVyLWJsdWUtNTAwLzMwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7b3Aucm9sZSA9PT0gJ2FkbWluJyA/ICdNYXN0ZXIgQWRtaW4nIDogJ09wZXJhdG9yJ31cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuXG4gICAgICAgICAgICAgICAgICAgICAgey8qIEF1dGhvcml6ZWQgUEMgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAge29wLmJvdW5kUGNEZXZpY2VJZCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBmb250LWJvbGQgdGV4dC1ibHVlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExhcHRvcCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWJsdWUtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LVsxMXB4XVwiPntvcC5ib3VuZFBjRGV2aWNlSWR9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgdHJ1bmNhdGUgbWF4LXctWzE2MHB4XVwiPntvcC5ib3VuZFBjRGV2aWNlTmFtZSB8fCAnUEMgV29ya3N0YXRpb24nfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlc2V0UGMob3AuaWQsIG9wLnVzZXJuYW1lKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtYW1iZXItNDAwIGhvdmVyOnVuZGVybGluZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMC41IGZvbnQtYm9sZCBwdC0wLjVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSb3RhdGVDY3cgY2xhc3NOYW1lPVwidy0yLjUgaC0yLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+UmVzZXQgUEMgQmluZGluZzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWFtYmVyLTQwMCBiZy1hbWJlci01MDAvMTAgcHgtMiBweS0wLjUgcm91bmRlZCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8yMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFVuYm91bmQgUEMgKFBlbmRpbmcpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBBdXRob3JpemVkIE1vYmlsZSAqL31cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMyBweC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7b3AuYm91bmRNb2JpbGVEZXZpY2VJZCA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBmb250LWJvbGQgdGV4dC1wdXJwbGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8U21hcnRwaG9uZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXB1cnBsZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtWzExcHhdXCI+e29wLmJvdW5kTW9iaWxlRGV2aWNlSWR9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDAgdHJ1bmNhdGUgbWF4LXctWzE2MHB4XVwiPntvcC5ib3VuZE1vYmlsZURldmljZU5hbWUgfHwgJ1NtYXJ0cGhvbmUnfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVJlc2V0TW9iaWxlKG9wLmlkLCBvcC51c2VybmFtZSl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWFtYmVyLTQwMCBob3Zlcjp1bmRlcmxpbmUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTAuNSBmb250LWJvbGQgcHQtMC41XCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Um90YXRlQ2N3IGNsYXNzTmFtZT1cInctMi41IGgtMi41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlJlc2V0IE1vYmlsZSBCaW5kaW5nPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtYW1iZXItNDAwIGJnLWFtYmVyLTUwMC8xMCBweC0yIHB5LTAuNSByb3VuZGVkIGJvcmRlciBib3JkZXItYW1iZXItNTAwLzIwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVW5ib3VuZCBNb2JpbGUgKFBlbmRpbmcpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cblxuICAgICAgICAgICAgICAgICAgICAgIHsvKiBMaWNlbnNlIFZhbGlkaXR5ICovfVxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0zIHB4LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtvcC5yb2xlID09PSAnYWRtaW4nID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgcm91bmRlZCBiZy1hbWJlci01MDAvMjAgdGV4dC1hbWJlci0zMDAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgZm9udC1ib2xkIHRleHQtWzEwcHhdIGZvbnQtbW9ubyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB3LWZpdFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+8J+RkSBMaWZldGltZSAoTmV2ZXIgRXhwaXJlcyk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtZW1lcmFsZC00MDAgZm9udC1ib2xkIGJsb2NrXCI+UGVybWFuZW50IEFjY2Vzczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IHJvdW5kZWQgYmctZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTMwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIGZvbnQtYm9sZCB0ZXh0LVsxMHB4XSBmb250LW1vbm8gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdy1maXRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDYWxlbmRhciBjbGFzc05hbWU9XCJ3LTMgaC0zIHRleHQtZW1lcmFsZC00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2RheXNMZWZ0fSBEYXlzIExlZnQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkT3BGb3JSZW5ldyhvcCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNreS00MDAgaG92ZXI6dW5kZXJsaW5lIGZvbnQtYm9sZCBibG9ja1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKyBSZW5ldyBBY2Nlc3NcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7LyogQWN0aW9uIGJ1dHRvbnMgKi99XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTMgcHgtMyB0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0xLjUgZmxleC13cmFwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBSZXNldCBBbGwgRGV2aWNlcyBCdXR0b24gKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsob3AuYm91bmRQY0RldmljZUlkIHx8IG9wLmJvdW5kTW9iaWxlRGV2aWNlSWQpICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVSZXNldEFsbERldmljZXMob3AuaWQsIG9wLnVzZXJuYW1lKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktMSByb3VuZGVkLWxnIGJnLWFtYmVyLTUwMC8xMCB0ZXh0LWFtYmVyLTMwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8zMCBob3ZlcjpiZy1hbWJlci01MDAvMjAgZm9udC1ib2xkIHRleHQtWzEwcHhdIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiUmVzZXQgYm90aCBQQyBhbmQgTW9iaWxlIGJpbmRpbmdzXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZXNldCBBbGxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgICAgICB7LyogTG9jayAvIFVubG9jayAqL31cbiAgICAgICAgICAgICAgICAgICAgICAgICAge29wLnJvbGUgIT09ICdhZG1pbicgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVRvZ2dsZUxvY2sob3AuaWQsIG9wLnVzZXJuYW1lKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMS41IHJvdW5kZWQtbGcgYm9yZGVyIHRleHQteHMgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3AuaXNMb2NrZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTUwMC8xMCB0ZXh0LWVtZXJhbGQtMzAwIGJvcmRlci1lbWVyYWxkLTUwMC8zMCBob3ZlcjpiZy1lbWVyYWxkLTUwMC8yMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS00MDAgYm9yZGVyLXNsYXRlLTcwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17b3AuaXNMb2NrZWQgPyAnVW5sb2NrIE9wZXJhdG9yJyA6ICdTdXNwZW5kIE9wZXJhdG9yJ31cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7b3AuaXNMb2NrZWQgPyA8VW5sb2NrIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gOiA8TG9jayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHsvKiBEZWxldGUgT3BlcmF0b3IgKi99XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtvcC5yb2xlICE9PSAnYWRtaW4nICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVEZWxldGVPcGVyYXRvcihvcC5pZCwgb3AudXNlcm5hbWUpfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC1sZyBiZy1yb3NlLTUwMC8xMCB0ZXh0LXJvc2UtNDAwIGJvcmRlciBib3JkZXItcm9zZS01MDAvMjAgaG92ZXI6Ymctcm9zZS01MDAvMjAgdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkRlbGV0ZSBPcGVyYXRvclwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9KX1cbiAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFRBQiAyOiBDWUJFUiBDQUZFIFdPUktGTE9XICYgU09QICovfVxuICAgICAge2FjdGl2ZVN1YlRhYiA9PT0gJ3dvcmtmbG93JyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNSBzaGFkb3cteGwgc3BhY2UteS00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgcGItMyBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8Q2xpcGJvYXJkTGlzdCBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5DeWJlciBDYWZlIFN0YW5kYXJkIE9wZXJhdGluZyBQcm9jZWR1cmUgKFNPUCk8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LWFtYmVyLTQwMCBiZy1hbWJlci01MDAvMTAgcHgtMiBweS0wLjUgcm91bmRlZCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC8yMCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgIE1hc3RlciBXb3JrZmxvd1xuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0wLjVcIj5cbiAgICAgICAgICAgICAgICBTdGFuZGFyZGl6ZWQgNi1zdGFnZSBvcGVyYXRpb25hbCBwcm90b2NvbCBmb3IgYWxsIENTQyAmIEN5YmVyIENhZmUgc2VydmljZXNcbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHB4LTMgcHktMS41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdGV4dC14cyBmb250LW1vbm8gdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgQ2hlY2tsaXN0OiA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC00MDBcIj57Y29tcGxldGVkV29ya2Zsb3dDb3VudH0gLyB7TUFTVEVSX1dPUktGTE9XX1NURVBTLmxlbmd0aH0gQ29tcGxldGVkPC9zdHJvbmc+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBXb3JrZmxvdyBTdGVwcyBHcmlkICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBnYXAtNFwiPlxuICAgICAgICAgICAge01BU1RFUl9XT1JLRkxPV19TVEVQUy5tYXAoKHN0ZXApID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgaXNEb25lID0gISFjb21wbGV0ZWRTdGVwc1tzdGVwLnN0ZXBOdW1iZXJdO1xuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgIGtleT17c3RlcC5zdGVwTnVtYmVyfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC00IHJvdW5kZWQteGwgYm9yZGVyIHRyYW5zaXRpb24tYWxsIHNwYWNlLXktMyAke1xuICAgICAgICAgICAgICAgICAgICBpc0RvbmUgXG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctc2xhdGUtOTUwLzYwIGJvcmRlci1lbWVyYWxkLTUwMC80MCcgXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTUwIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2B3LTYgaC02IHJvdW5kZWQtbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9udC1ib2xkIHRleHQteHMgZm9udC1tb25vICR7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc0RvbmUgPyAnYmctZW1lcmFsZC01MDAgdGV4dC1zbGF0ZS05NTAnIDogJ2JnLWJsdWUtNjAwIHRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICAgICAgfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAge3N0ZXAuc3RlcE51bWJlcn1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdGV4dC14c1wiPntzdGVwLnRpdGxlfTwvaDM+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRDb21wbGV0ZWRTdGVwcyhwcmV2ID0+ICh7IC4uLnByZXYsIFtzdGVwLnN0ZXBOdW1iZXJdOiAhcHJldltzdGVwLnN0ZXBOdW1iZXJdIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LVsxMXB4XSBmb250LWJvbGQgcHgtMiBweS0wLjUgcm91bmRlZC1tZCBib3JkZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzRG9uZSBcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTMwMCBib3JkZXItZW1lcmFsZC01MDAvMzAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTkwMCB0ZXh0LXNsYXRlLTQwMCBib3JkZXItc2xhdGUtNzAwJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge2lzRG9uZSA/IDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1lbWVyYWxkLTQwMFwiIC8+IDogPENpcmNsZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+fVxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntpc0RvbmUgPyAnRG9uZScgOiAnTWFyayd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTMwMCBsZWFkaW5nLXNudWdcIj57c3RlcC5kZXNjcmlwdGlvbn08L3A+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xIHB0LTEgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMC84MFwiPlxuICAgICAgICAgICAgICAgICAgICB7c3RlcC5jaGVja2xpc3QubWFwKChpdGVtLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGtleT17aWR4fSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0xLjUgdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYmx1ZS01MDBcIj7igKI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aXRlbX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQtbGcgYmctc2xhdGUtOTAwIHRleHQtWzEwcHhdIHRleHQtYW1iZXItMzAwLzkwIGZsZXggaXRlbXMtc3RhcnQgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWFtYmVyLTQwMCBmbGV4LXNocmluay0wIG10LTAuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPjxiPk9wZXJhdG9yIE5vdGU6PC9iPiB7c3RlcC50aXBzfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFRBQiAzOiAzIE1BU1RFUiBBRE1JTiBGSUxFUyBIVUIgKEdJVEhVQiBaSVAg4oCiIFdPUktGTE9XIENPREUg4oCiIFBDIEZJTEVTKSAqL31cbiAgICAgIHthY3RpdmVTdWJUYWIgPT09ICd6aXBfZG93bmxvYWQnICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC02IHNoYWRvdy14bCBzcGFjZS15LTZcIj5cbiAgICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgcGItNCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE0IGgtMTQgcm91bmRlZC0yeGwgYmctZ3JhZGllbnQtdG8tdHIgZnJvbS1lbWVyYWxkLTYwMC8yMCB0by10ZWFsLTUwMC8yMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtZW1lcmFsZC00MDAgZmxleC1zaHJpbmstMCBzaGFkb3ctaW5uZXJcIj5cbiAgICAgICAgICAgICAgICA8QXJjaGl2ZSBjbGFzc05hbWU9XCJ3LTcgaC03XCIgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBmbGV4LXdyYXBcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPjMgTWFzdGVyIEFkbWluIERvd25sb2FkIEZpbGVzIEh1Yjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGJnLWVtZXJhbGQtNTAwLzIwIHRleHQtZW1lcmFsZC0zMDAgZm9udC1ib2xkIHB4LTIgcHktMC41IHJvdW5kZWQgZm9udC1tb25vIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzBcIj5cbiAgICAgICAgICAgICAgICAgICAgR2l0SHViICYgUEMgUmVhZHlcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS0zMDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgICAgICAgICBZYWhhbiBzZSBhYXAgKDEpIEdpdEh1Yi1SZWFkeSBjb21wbGV0ZSBwcm9qZWN0IC5aSVAsICgyKSBHaXRIdWIgQWN0aW9ucyB3b3JrZmxvdyAuWU1MIGNvZGUsIGF1ciAoMykgUEMgc3RhbmRhbG9uZSBsYXVuY2hlciAuQkFUIGZpbGVzIGRpcmVjdCAxLWNsaWNrIG1laW4gZG93bmxvYWQgeWEgY29weSBrYXIgc2FrdGUgaGFpbi5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ubyBiZy1zbGF0ZS05NTAgcHgtMyBweS0xLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzZWxmLXN0YXJ0XCI+XG4gICAgICAgICAgICAgIFdvcmtzdGF0aW9uIHY5OC4wXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogMyBERURJQ0FURUQgRklMRSBDQVJEUyBHUklEICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMyBnYXAtNFwiPlxuICAgICAgICAgICAgey8qIEZJTEUgMTogR0lUSFVCIFJFQURZIFBST0pFQ1QgLlpJUCBBUkNISVZFICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCByb3VuZGVkLTJ4bCBwLTQgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteS0zIHNoYWRvdy1sZyBob3Zlcjpib3JkZXItZW1lcmFsZC01MDAvNTAgdHJhbnNpdGlvbi1hbGxcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLXhsIGJnLWVtZXJhbGQtNTAwLzIwIHRleHQtZW1lcmFsZC00MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9udC1ib2xkIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgMVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtZW1lcmFsZC0zMDAgYmctZW1lcmFsZC01MDAvMTAgcHgtMiBweS0wLjUgcm91bmRlZCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzIwXCI+XG4gICAgICAgICAgICAgICAgICAgIEdpdEh1YiBSZWFkeSBaSVBcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgIPCfk6YgQ29tcGxldGUgUHJvamVjdCAuWklQIEFyY2hpdmVcbiAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQtWzExcHhdIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgU2FiaGkgc3R1ZGlvcyAoUFZDLCBQYXNzcG9ydCwgVmlkZW8gU3R1ZGlvLCBCaWxsaW5nLCBDUk0sIDUwKyBQb3J0YWxzLCBFbGVjdHJvbiwgR2l0SHViIFdvcmtmbG93KSBrYSBjb21wbGV0ZSBzb3VyY2UgY29kZSBidW5kbGUuXG4gICAgICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LW1vbm8gc3BhY2UteS0wLjUgYmctc2xhdGUtOTAwLzYwIHAtMiByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2PkZpbGU6IDxiPk11emFtbWlsLU9ubGluZS1zZXJ2aWNlLXBjLnppcDwvYj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+Rm9ybWF0OiA8Yj5aSVAgKERlZmxhdGUgTHY5KTwvYj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+RGVzdDogPGI+R2l0SHViIC8gTG9jYWwgUEM8L2I+PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIHB0LTJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVEb3dubG9hZFppcH1cbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtpc0V4cG9ydGluZ1ppcH1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IGJnLWdyYWRpZW50LXRvLXIgZnJvbS1lbWVyYWxkLTYwMCB0by10ZWFsLTYwMCBob3Zlcjpmcm9tLWVtZXJhbGQtNTAwIGhvdmVyOnRvLXRlYWwtNTAwIHRleHQtd2hpdGUgZm9udC1leHRyYWJvbGQgdGV4dC14cyBweS0yLjUgcm91bmRlZC14bCBzaGFkb3cgdHJhbnNpdGlvbi1hbGwgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+e2lzRXhwb3J0aW5nWmlwID8gJ0NvbXByZXNzaW5nIFpJUC4uLicgOiAnRG93bmxvYWQgUHJvamVjdCAuWklQJ308L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgaHJlZj1cIi9hcGkvZG93bmxvYWQtemlwXCJcbiAgICAgICAgICAgICAgICAgIGRvd25sb2FkPVwiTXV6YW1taWwtT25saW5lLXNlcnZpY2UtcGMuemlwXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtYmx1ZS00MDAgaG92ZXI6dW5kZXJsaW5lIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xIGZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxFeHRlcm5hbExpbmsgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5EaXJlY3QgU2VydmVyIERvd25sb2FkIExpbms8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogRklMRSAyOiBHSVRIVUIgQUNUSU9OUyBXT1JLRkxPVyBDT0RFICguWU1MKSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItcHVycGxlLTUwMC8zMCByb3VuZGVkLTJ4bCBwLTQgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteS0zIHNoYWRvdy1sZyBob3Zlcjpib3JkZXItcHVycGxlLTUwMC81MCB0cmFuc2l0aW9uLWFsbFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQteGwgYmctcHVycGxlLTUwMC8yMCB0ZXh0LXB1cnBsZS00MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9udC1ib2xkIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgMlxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtcHVycGxlLTMwMCBiZy1wdXJwbGUtNTAwLzEwIHB4LTIgcHktMC41IHJvdW5kZWQgYm9yZGVyIGJvcmRlci1wdXJwbGUtNTAwLzIwXCI+XG4gICAgICAgICAgICAgICAgICAgIEdpdEh1YiBBY3Rpb25zIC5ZTUxcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgIOKaoSBHaXRIdWIgV29ya2Zsb3cgQ29kZSAoLllNTClcbiAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQtWzExcHhdIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgR2l0SHViIENsb3VkIHNlcnZlcnMgcGFyIGJpbmEga2lzaSBsb2FkIGtlIGF1dG9tYXRpYyBzdGFuZGFsb25lIFdpbmRvd3MgPGI+LkVYRTwvYj4gc2V0dXAgZmlsZSBidWlsZCBrYXJuZSBrYSBhdXRvbWF0aW9uIHNjcmlwdC5cbiAgICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIGZvbnQtbW9ubyBzcGFjZS15LTAuNSBiZy1zbGF0ZS05MDAvNjAgcC0yIHJvdW5kZWQtbGcgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+RmlsZTogPGI+YnVpbGQtd2luZG93cy1leGUueW1sPC9iPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5UYXJnZXQ6IDxiPi5naXRodWIvd29ya2Zsb3dzLzwvYj48L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXY+T3V0cHV0OiA8Yj5XaW5kb3dzIHg2NCAuRVhFPC9iPjwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMiBwdC0yXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURvd25sb2FkV29ya2Zsb3dZbWx9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xIGJnLXB1cnBsZS02MDAgaG92ZXI6YmctcHVycGxlLTUwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXhzIHB5LTIgcm91bmRlZC14bCBzaGFkb3cgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkRvd25sb2FkIGJ1aWxkLXdpbmRvd3MtZXhlLnltbFwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkRvd25sb2FkIC5ZTUw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDb3B5V29ya2Zsb3dDb2RlfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMSBmb250LWJvbGQgdGV4dC14cyBweS0yIHJvdW5kZWQteGwgYm9yZGVyIHRyYW5zaXRpb24tY29sb3JzICR7XG4gICAgICAgICAgICAgICAgICAgICAgY29waWVkV29ya2Zsb3cgXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1lbWVyYWxkLTQwMCcgXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05MDAgaG92ZXI6Ymctc2xhdGUtODAwIHRleHQtcHVycGxlLTMwMCBib3JkZXItcHVycGxlLTUwMC80MCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJDb3B5IGZ1bGwgWUFNTCBjb2RlIHRvIGNsaXBib2FyZFwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtjb3BpZWRXb3JrZmxvdyA/IDxDaGVjayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+IDogPENvcHkgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPn1cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2NvcGllZFdvcmtmbG93ID8gJ0NvcGllZCEnIDogJ0NvcHkgQ29kZSd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRFeHBhbmRlZEZpbGVDYXJkKGV4cGFuZGVkRmlsZUNhcmQgPT09ICd3b3JrZmxvdycgPyBudWxsIDogJ3dvcmtmbG93Jyl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1wdXJwbGUtMzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xIGZvbnQtc2VtaWJvbGQgcHQtMC41XCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8RmlsZUNvZGUgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj57ZXhwYW5kZWRGaWxlQ2FyZCA9PT0gJ3dvcmtmbG93JyA/ICdIaWRlIFdvcmtmbG93IENvZGUnIDogJ1ZpZXcgV29ya2Zsb3cgQ29kZSd9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogRklMRSAzOiBXSU5ET1dTIFBDIExBVU5DSEVSICYgRVhFIEJVSUxERVIgKC5CQVQpICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1ibHVlLTUwMC8zMCByb3VuZGVkLTJ4bCBwLTQgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gc3BhY2UteS0zIHNoYWRvdy1sZyBob3Zlcjpib3JkZXItYmx1ZS01MDAvNTAgdHJhbnNpdGlvbi1hbGxcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLXhsIGJnLWJsdWUtNTAwLzIwIHRleHQtYmx1ZS00MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9udC1ib2xkIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgICAgICAgM1xuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtYmx1ZS0zMDAgYmctYmx1ZS01MDAvMTAgcHgtMiBweS0wLjUgcm91bmRlZCBib3JkZXIgYm9yZGVyLWJsdWUtNTAwLzIwXCI+XG4gICAgICAgICAgICAgICAgICAgIFdpbmRvd3MgUEMgLkJBVFxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdGV4dC1zbVwiPlxuICAgICAgICAgICAgICAgICAg8J+SuyBQQyAxLUNsaWNrIExhdW5jaGVyIEZpbGVzXG4gICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LVsxMXB4XSBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICAgIFBDIHBhciAxLWNsaWNrIG1laW4gc29mdHdhcmUgc3RhcnQga2FybmUgd2FsaSBiYXRjaCBmaWxlIGF1ciBsb2NhbCBjb21wdXRlciBwYXIgLkVYRSBmaWxlIGdlbmVyYXRlIGthcm5lIHdhbGEgYnVpbGRlciBzY3JpcHQuXG4gICAgICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LW1vbm8gc3BhY2UteS0wLjUgYmctc2xhdGUtOTAwLzYwIHAtMiByb3VuZGVkLWxnIGJvcmRlciBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2PkZpbGUgMTogPGI+U1RBUlQtV09SS1NUQVRJT04uYmF0PC9iPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5GaWxlIDI6IDxiPkNSRUFURS1FWEUtU0VUVVAuYmF0PC9iPjwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5Qb3J0OiA8Yj4zMDAwIChPZmZsaW5lIFJlYWR5KTwvYj48L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgcHQtMlwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVEb3dubG9hZFBjTGF1bmNoZXJ9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xIGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcHktMiByb3VuZGVkLXhsIHNoYWRvdyB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiRG93bmxvYWQgU1RBUlQtV09SS1NUQVRJT04uYmF0XCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+RG93bmxvYWQgLkJBVDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUNvcHlQY0JhdGNoQ29kZX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEgZm9udC1ib2xkIHRleHQteHMgcHktMiByb3VuZGVkLXhsIGJvcmRlciB0cmFuc2l0aW9uLWNvbG9ycyAke1xuICAgICAgICAgICAgICAgICAgICAgIGNvcGllZFBjQmF0Y2ggXG4gICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1lbWVyYWxkLTQwMCcgXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05MDAgaG92ZXI6Ymctc2xhdGUtODAwIHRleHQtYmx1ZS0zMDAgYm9yZGVyLWJsdWUtNTAwLzQwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkNvcHkgU1RBUlQtV09SS1NUQVRJT04uYmF0IHNjcmlwdFwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtjb3BpZWRQY0JhdGNoID8gPENoZWNrIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gOiA8Q29weSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+fVxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj57Y29waWVkUGNCYXRjaCA/ICdDb3BpZWQhJyA6ICdDb3B5IC5CQVQnfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bMTFweF0gcHQtMC41XCI+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURvd25sb2FkRXhlQnVpbGRlcn1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1hbWJlci00MDAgaG92ZXI6dW5kZXJsaW5lIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGZvbnQtc2VtaWJvbGRcIlxuICAgICAgICAgICAgICAgICAgICB0aXRsZT1cIkRvd25sb2FkIENSRUFURS1FWEUtU0VUVVAuYmF0XCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5HZXQgLkVYRSBCdWlsZGVyICguYmF0KTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEV4cGFuZGVkRmlsZUNhcmQoZXhwYW5kZWRGaWxlQ2FyZCA9PT0gJ3BjX2JhdGNoJyA/IG51bGwgOiAncGNfYmF0Y2gnKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1ibHVlLTMwMCBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge2V4cGFuZGVkRmlsZUNhcmQgPT09ICdwY19iYXRjaCcgPyAnSGlkZSBDb2RlJyA6ICdWaWV3IENvZGUnfVxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQ09ERSBQUkVWSUVXIE1PREFMIC8gRVhQQU5EQUJMRSBCT1ggKi99XG4gICAgICAgICAge2V4cGFuZGVkRmlsZUNhcmQgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC00IHNwYWNlLXktMiBhbmltYXRlLWluIGZhZGUtaW5cIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwYi0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQteHMgdGV4dC13aGl0ZSBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxUZXJtaW5hbCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgIHtleHBhbmRlZEZpbGVDYXJkID09PSAnd29ya2Zsb3cnID8gJy5naXRodWIvd29ya2Zsb3dzL2J1aWxkLXdpbmRvd3MtZXhlLnltbCcgOiAnU1RBUlQtV09SS1NUQVRJT04uYmF0J31cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtleHBhbmRlZEZpbGVDYXJkID09PSAnd29ya2Zsb3cnID8gaGFuZGxlQ29weVdvcmtmbG93Q29kZSA6IGhhbmRsZUNvcHlQY0JhdGNoQ29kZX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMi41IHB5LTEgcm91bmRlZCBiZy1zbGF0ZS05MDAgaG92ZXI6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIGhvdmVyOnRleHQtd2hpdGUgdGV4dC1bMTFweF0gZm9udC1ib2xkIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPENvcHkgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkNvcHk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0RXhwYW5kZWRGaWxlQ2FyZChudWxsKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSB0ZXh0LXhzIHB4LTFcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICDinJVcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPHByZSBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8gdGV4dC1zbGF0ZS0zMDAgbWF4LWgtNjAgb3ZlcmZsb3cteS1hdXRvIHAtMyBiZy1zbGF0ZS05MDAvOTAgcm91bmRlZC14bCBsZWFkaW5nLXJlbGF4ZWQgc2VsZWN0LWFsbFwiPlxuICAgICAgICAgICAgICAgIHtleHBhbmRlZEZpbGVDYXJkID09PSAnd29ya2Zsb3cnID8gV09SS0ZMT1dfWUFNTF9DT0RFIDogUENfTEFVTkNIRVJfQkFUX0NPREV9XG4gICAgICAgICAgICAgIDwvcHJlPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBEb3dubG9hZCBQcm9ncmVzcyBCYXIgKi99XG4gICAgICAgICAge2lzRXhwb3J0aW5nWmlwICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIHAtNCByb3VuZGVkLXhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIGFuaW1hdGUtcHVsc2VcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIHRleHQtZW1lcmFsZC00MDAgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+UGFja2luZyBaSVAgQXJjaGl2ZToge3ppcFByb2dyZXNzLmZpbGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuPnt6aXBQcm9ncmVzcy5wZXJjZW50fSU8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS04MDAgaC0yIHJvdW5kZWQtZnVsbCBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgICAgICA8ZGl2IFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctZW1lcmFsZC01MDAgaC1mdWxsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTIwMFwiIFxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IGAke3ppcFByb2dyZXNzLnBlcmNlbnR9JWAgfX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogU1RFUC1CWS1TVEVQIEdVSURFUyBGT1IgR0lUSFVCICYgUEMgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGdhcC00IHRleHQteHNcIj5cbiAgICAgICAgICAgIHsvKiBHdWlkZSBBOiBHaXRIdWIgQWN0aW9ucyBTZSAuRVhFIEJhbmFuYSAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHAtNCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXB1cnBsZS00MDAgZm9udC1leHRyYWJvbGQgcGItMSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgPEZpbGVDb2RlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkdpdEh1YiBBY3Rpb25zIFNlIC5FWEUgU2V0dXAgS2Fpc2UgQmFuYXllaW46PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPG9sIGNsYXNzTmFtZT1cImxpc3QtZGVjaW1hbCBsaXN0LWluc2lkZSBzcGFjZS15LTEuNSB0ZXh0LXNsYXRlLTMwMCB0ZXh0LVsxMXB4XSBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgICA8bGk+R2l0SHViIHBhciBuYXlpIHJlcG9zaXRvcnkgYmFuYXllaW46IDxiPm11emFtbWlsLW9ubGluZS1zZXJ2aWNlPC9iPi48L2xpPlxuICAgICAgICAgICAgICAgIDxsaT5Eb3dubG9hZGVkIFpJUCBrbyBleHRyYWN0IGthcmtlIHNhYXJpIGZpbGVzIEdpdEh1YiBwYXIgdXBsb2FkIGthcmVpbi48L2xpPlxuICAgICAgICAgICAgICAgIDxsaT5HaXRIdWIga2UgPGI+XCJBY3Rpb25zXCI8L2I+IHRhYiBtZWluIGpha2FyIDxiPlwiQnVpbGQgV2luZG93cyBEZXNrdG9wIEVYRSBTZXR1cFwiPC9iPiBjaHVuZWluLjwvbGk+XG4gICAgICAgICAgICAgICAgPGxpPlJpZ2h0IHNpZGUgbWVpbiA8Yj5cIlJ1biB3b3JrZmxvd1wiPC9iPiBkYWJheWVpbiDigJQgMiBtaW51dGUgbWVpbiA8Yj4uRVhFIEFydGlmYWN0PC9iPiB0YXlhciBobyBqYXllZ2khPC9saT5cbiAgICAgICAgICAgICAgPC9vbD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogR3VpZGUgQjogRGlyZWN0IFBDIFBhciBDaGFsYW5hICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgcC00IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtYmx1ZS00MDAgZm9udC1leHRyYWJvbGQgcGItMSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgPExhcHRvcCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5EaXJlY3QgUEMgUGFyIFNvZnR3YXJlIEthaXNlIENoYWxheWVpbjo8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8b2wgY2xhc3NOYW1lPVwibGlzdC1kZWNpbWFsIGxpc3QtaW5zaWRlIHNwYWNlLXktMS41IHRleHQtc2xhdGUtMzAwIHRleHQtWzExcHhdIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgIDxsaT5aSVAga28gY29tcHV0ZXIga2kga2lzaSBkcml2ZSBtZWluIGV4dHJhY3Qga2FyZWluIChlLmcuIDxjb2RlPkQ6XFxNdXphbW1pbE9ubGluZVNlcnZpY2U8L2NvZGU+KS48L2xpPlxuICAgICAgICAgICAgICAgIDxsaT5BZ2FyIGNvbXB1dGVyIG1laW4gTm9kZS5qcyBuYWhpIGhhaSwgdG8gPGI+bm9kZWpzLm9yZzwvYj4gc2UgMS1jbGljayBpbnN0YWxsIGthcmVpbi48L2xpPlxuICAgICAgICAgICAgICAgIDxsaT5Gb2xkZXIga2UgYW5kYXIgPGI+U1RBUlQtV09SS1NUQVRJT04uYmF0PC9iPiBwYXIgZG91YmxlLWNsaWNrIGthcmVpbiE8L2xpPlxuICAgICAgICAgICAgICAgIDxsaT5DaHJvbWUvRWRnZSBicm93c2VyIG1laW4gPGI+XCJJbnN0YWxsIGFzIEFwcFwiPC9iPiBwYXIgY2xpY2sga2Fya2UgZGVza3RvcCBzaG9ydGN1dCBiYW5hIGxlaW4uPC9saT5cbiAgICAgICAgICAgICAgPC9vbD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBUQUIgNDogU0VDVVJJVFkgQVVESVQgJiBBQ0NFU1MgTE9HUyAqL31cbiAgICAgIHthY3RpdmVTdWJUYWIgPT09ICdsb2dzJyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNSBzaGFkb3cteGwgc3BhY2UteS00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMyBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGVcIj5SZWFsLVRpbWUgU2VjdXJpdHkgJiBEZXZpY2UgQXVkaXQgTG9nPC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlJlY29yZCBvZiBhbGwgYXV0aG9yaXplZCBQQyAmIE1vYmlsZSBsb2dpbnMsIGRldmljZSBsb2NrcywgYW5kIGJsb2NrZWQgYWNjZXNzIGF0dGVtcHRzPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2xvYWREYXRhfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBweC0zIHB5LTEuNSByb3VuZGVkLWxnIGJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTMwMCBob3Zlcjp0ZXh0LXdoaXRlIHRleHQteHMgZm9udC1zZW1pYm9sZFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxSZWZyZXNoQ3cgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj5SZWZyZXNoIExvZ3M8L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteC1hdXRvIG1heC1oLTk2XCI+XG4gICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtbGVmdCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJzdGlja3kgdG9wLTAgYmctc2xhdGUtOTAwIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgICA8dGggY2xhc3NOYW1lPVwicHktMi41IHB4LTNcIj5UaW1lc3RhbXA8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zXCI+QWN0aW9uPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPk9wZXJhdG9yPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPlR5cGU8L3RoPlxuICAgICAgICAgICAgICAgICAgPHRoIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zXCI+RGV2aWNlIElEPC90aD5cbiAgICAgICAgICAgICAgICAgIDx0aCBjbGFzc05hbWU9XCJweS0yLjUgcHgtM1wiPkRldGFpbHM8L3RoPlxuICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDwvdGhlYWQ+XG4gICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJkaXZpZGUteSBkaXZpZGUtc2xhdGUtODAwLzYwIGZvbnQtbW9ubyB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICAgIHthdWRpdExvZ3MubGVuZ3RoID4gMCA/IChcbiAgICAgICAgICAgICAgICAgIGF1ZGl0TG9ncy5tYXAoKGxvZykgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8dHIga2V5PXtsb2cuaWR9IGNsYXNzTmFtZT1cImhvdmVyOmJnLXNsYXRlLTk1MC80MFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMyB0ZXh0LXNsYXRlLTQwMFwiPntsb2cudGltZXN0YW1wfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2BweC0yIHB5LTAuNSByb3VuZGVkIHRleHQtWzEwcHhdIGZvbnQtYm9sZCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICBsb2cuYWN0aW9uID09PSAnTE9HSU5fU1VDQ0VTUycgXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MDAvMjAgdGV4dC1lbWVyYWxkLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGxvZy5hY3Rpb24gPT09ICdERVZJQ0VfQkxPQ0tFRCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1yb3NlLTUwMC8yMCB0ZXh0LXJvc2UtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogbG9nLmFjdGlvbiA9PT0gJ0RFVklDRV9CT1VORCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTUwMC8yMCB0ZXh0LWJsdWUtNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLWFtYmVyLTUwMC8yMCB0ZXh0LWFtYmVyLTQwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2xvZy5hY3Rpb259XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHktMi41IHB4LTMgdGV4dC13aGl0ZSBmb250LWJvbGRcIj5Ae2xvZy51c2VybmFtZX08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMyB0ZXh0LXNsYXRlLTQwMFwiPntsb2cuZGV2aWNlVHlwZSA9PT0gJ21vYmlsZScgPyAn8J+TsSBNb2JpbGUnIDogJ/CfkrsgUEMnfTwvdGQ+XG4gICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB5LTIuNSBweC0zIHRleHQtc2xhdGUtMzAwXCI+e2xvZy5kZXZpY2VJZH08L3RkPlxuICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweS0yLjUgcHgtMyB0ZXh0LXNsYXRlLTQwMCBtYXgtdy14cyB0cnVuY2F0ZSBmb250LXNhbnNcIj57bG9nLmRldGFpbHN9PC90ZD5cbiAgICAgICAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgICAgICAgICkpXG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICAgICAgPHRkIGNvbFNwYW49ezZ9IGNsYXNzTmFtZT1cInB5LTYgdGV4dC1jZW50ZXIgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICBObyBzZWN1cml0eSBhdWRpdCBsb2dzIHJlY29yZGVkIHlldC5cbiAgICAgICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC90Ym9keT5cbiAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFRBQiA1OiBNQVNURVIgU0VUVVAgJiBDT05UUk9MIENFTlRFUiAqL31cbiAgICAgIHthY3RpdmVTdWJUYWIgPT09ICdzZXR0aW5ncycgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTYgc2hhZG93LXhsIHNwYWNlLXktNlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHBiLTMgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPEtleSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYmx1ZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPk1hc3RlciBBZG1pbiBXb3Jrc3RhdGlvbiBTZXR1cCAmIENvbnRyb2wgQ2VudGVyPC9zcGFuPlxuICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgIENlbnRyYWxpemVkIG1hbmFnZW1lbnQgZm9yIFNob3AgRGV0YWlscywgUE9TIFJhdGVzLCBIYXJkd2FyZSBTZXR0aW5ncywgYW5kIFN0YWZmIFNlY3VyaXR5XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1yb3NlLTUwMC8xMCB0ZXh0LXJvc2UtMzAwIGJvcmRlciBib3JkZXItcm9zZS01MDAvMzAgdGV4dC14cyBweC0zIHB5LTEgcm91bmRlZC1mdWxsIGZvbnQtYm9sZCB3LWZpdFwiPlxuICAgICAgICAgICAgICBTdGFmZiAmIE9wZXJhdG9yIEFjY2VzcyBPbmx5XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogU1RSSUNUIENVU1RPTUVSIEFDQ0VTUyBQT0xJQ1kgQkFOTkVSICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLXJvc2UtOTUwLzQwIHRvLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXJvc2UtNTAwLzMwIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXJvc2UtNDAwIGZvbnQtZXh0cmFib2xkIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPEFsZXJ0Q2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj5aRVJPIENVU1RPTUVSIExPR0lOIEVORk9SQ0VEIChOTyBQVUJMSUMgQUNDRVNTKTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTMwMCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAgSXMgc3lzdGVtIG1laW4gPGI+a2lzaSBiaGkgYW5qYW4gY3VzdG9tZXIgeWEgcHVibGljIHVzZXIga2EgbG9naW4geWEgcmVnaXN0cmF0aW9uIHBvb3JpIHRhcmFoIGJhbmQgaGFpPC9iPi4gXG4gICAgICAgICAgICAgIFNpcmYgTWFzdGVyIEFkbWluIGtlIGR3YXJhIGJhbmF5ZSBnYXllIHZlcmlmaWVkIFN0YWZmIE9wZXJhdG9yIElEcyBoaSBsb2dpbiBrYXIgc2FrdGUgaGFpbi4gXG4gICAgICAgICAgICAgIFNhYmhpIGNpdGl6ZW4vY3VzdG9tZXIgZGV0YWlscyBzaXJmIHNob3Aga2UgaW50ZXJuYWwgPGI+Q3VzdG9tZXIgQ1JNPC9iPiBtZWluIHNhZmUgcmVjb3JkIGtlIHRhdXIgcGFyIHN0b3JlIGhvdGkgaGFpbi5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTYXZlU2V0dGluZ3N9IGNsYXNzTmFtZT1cInNwYWNlLXktNiB0ZXh0LXhzXCI+XG4gICAgICAgICAgICB7LyogU2VjdGlvbiAxOiBTaG9wICYgQnVzaW5lc3MgSWRlbnRpdHkgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktM1wiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LWJsdWUtNDAwXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+MS4gU2hvcCBJZGVudGl0eSAmIE9mZmljaWFsIERldGFpbHM8L3NwYW4+XG4gICAgICAgICAgICAgIDwvaDM+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+U2hvcCAvIENlbnRlciBOYW1lPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzaG9wRm9ybS5zaG9wTmFtZX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTaG9wRm9ybSh7IC4uLnNob3BGb3JtLCBzaG9wTmFtZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBwLTIuNSB0ZXh0LXdoaXRlIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+T3duZXIgTmFtZTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2hvcEZvcm0ub3duZXJOYW1lfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNob3BGb3JtKHsgLi4uc2hvcEZvcm0sIG93bmVyTmFtZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBwLTIuNSB0ZXh0LXdoaXRlIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+V2hhdHNBcHAgLyBDb250YWN0IFBob25lPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzaG9wRm9ybS5waG9uZX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTaG9wRm9ybSh7IC4uLnNob3BGb3JtLCBwaG9uZTogZS50YXJnZXQudmFsdWUgfSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBwLTIuNSB0ZXh0LXdoaXRlIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+VVBJIElEIGZvciBEeW5hbWljIFBPUyBRUjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2hvcEZvcm0udXBpSWR9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2hvcEZvcm0oeyAuLi5zaG9wRm9ybSwgdXBpSWQ6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcC0yLjUgdGV4dC13aGl0ZSBmb250LWJvbGQgZm9udC1tb25vXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmNvbC1zcGFuLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+QWRkcmVzcyAoUHJpbnRlZCBvbiBUYXggSW52b2ljZXMgJiBUaGVybWFsIFNsaXBzKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2hvcEZvcm0uYWRkcmVzc31cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTaG9wRm9ybSh7IC4uLnNob3BGb3JtLCBhZGRyZXNzOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHAtMi41IHRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFNlY3Rpb24gMjogRGVmYXVsdCBQT1MgUmF0ZXMgU2V0dXAgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMyBwdC0zIGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgdGV4dC14cyB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC1lbWVyYWxkLTQwMFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuPjIuIERlZmF1bHQgUE9TIFNlcnZpY2UgUmF0ZXMgJiBQcmljaW5nICjigrkpPC9zcGFuPlxuICAgICAgICAgICAgICA8L2gzPlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBzbTpncmlkLWNvbHMtMyBsZzpncmlkLWNvbHMtNiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHAtMi41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayB0ZXh0LVsxMXB4XSBtYi0xXCI+UFZDIFNtYXJ0IENhcmQ8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj7igrk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT17MH1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBwLTEgdGV4dC13aGl0ZSBmb250LW1vbm8gdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHAtMi41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayB0ZXh0LVsxMXB4XSBtYi0xXCI+UGFzc3BvcnQgUGhvdG8gKDh4KTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPuKCuTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlPXswfVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMFwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHAtMSB0ZXh0LXdoaXRlIGZvbnQtbW9ubyB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgcC0yLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIHRleHQtWzExcHhdIG1iLTFcIj5PbmxpbmUgU2NoZW1lIEZvcm08L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj7igrk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT17MH1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBwLTEgdGV4dC13aGl0ZSBmb250LW1vbm8gdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHAtMi41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayB0ZXh0LVsxMXB4XSBtYi0xXCI+RXhhbSBGb3JtIChQb2xpY2UpPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgZm9udC1ib2xkIHRleHQtZW1lcmFsZC00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+4oK5PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwibnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWU9ezB9XG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIwXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQgcC0xIHRleHQtd2hpdGUgZm9udC1tb25vIHRleHQteHNcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBwLTIuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgdGV4dC1bMTFweF0gbWItMVwiPkJpb0RhdGEgLyBDVjwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPuKCuTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXG4gICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlPXswfVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiMFwiXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHAtMSB0ZXh0LXdoaXRlIGZvbnQtbW9ubyB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAgcC0yLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIHRleHQtWzExcHhdIG1iLTFcIj5UaGVybWFsIExhbWluYXRpb248L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj7igrk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxuICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRWYWx1ZT17MH1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIjBcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBwLTEgdGV4dC13aGl0ZSBmb250LW1vbm8gdGV4dC14c1wiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFNlY3Rpb24gMzogSGFyZHdhcmUgJiBQcmludGVyIFN0YW5kYXJkcyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zIHB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXB1cnBsZS00MDBcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj4zLiBIYXJkd2FyZSAmIFByaW50aW5nIFN0YW5kYXJkczwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9oMz5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTMgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBwLTMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBmb250LWJvbGRcIj5QVkMgQ2FyZCBSZXNvbHV0aW9uPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LW1vbm8gZm9udC1leHRyYWJvbGQgdGV4dC14cyB0ZXh0LWJsdWUtNDAwXCI+MzAwIERQSSBVbHRyYSBIRDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDBcIj5PcHRpbWl6ZWQgZm9yIEVwc29uIEw4MDUsIEw4NTAgJiBDYW5vbiBHLVNlcmllczwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwIHAtMyByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIGZvbnQtYm9sZFwiPlBob3RvIFN0dWRpbyBMYXlvdXQ8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIGZvbnQtbW9ubyBmb250LWV4dHJhYm9sZCB0ZXh0LXhzIHRleHQtcHVycGxlLTQwMFwiPjTDlzYgSW5jaCAoMTDDlzE1IGNtKSBHbG9zc3k8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwXCI+OCBwcmUtYWxpZ25lZCBwYXNzcG9ydCBwaG90b3Mgd2l0aCBib3JkZXIgZ3VpZGUgbGluZXM8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MCBwLTMgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBmb250LWJvbGRcIj5QT1MgUmVjZWlwdCBQcmludGVyPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LW1vbm8gZm9udC1leHRyYWJvbGQgdGV4dC14cyB0ZXh0LWVtZXJhbGQtNDAwXCI+NThtbSAvIDgwbW0gVGhlcm1hbCBFU0MvUE9TPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMFwiPlplcm8taW5rIHRoZXJtYWwgcGFwZXIgd2l0aCBkeW5hbWljIFVQSSBRUiBjb2RlPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogU2F2ZSBCdXR0b24gKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTYgcHktMyBiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTUwMCB0ZXh0LXdoaXRlIGZvbnQtZXh0cmFib2xkIHJvdW5kZWQteGwgc2hhZG93LWxnIHNoYWRvdy1ibHVlLTYwMC8zMCB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzY2FsZS0xMDVcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgU2F2ZSBNYXN0ZXIgU2V0dXAgQ29uZmlndXJhdGlvblxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogUkVORVcgQUNDRVNTIE1PREFMICovfVxuICAgICAge3NlbGVjdGVkT3BGb3JSZW5ldyAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjay84NSBiYWNrZHJvcC1ibHVyLXNtIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgbWF4LXctbWQgdy1mdWxsIHAtNiBzaGFkb3ctMnhsIHNwYWNlLXktNCBhbmltYXRlLWluIGZhZGUtaW4gem9vbS1pbi05NVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMiBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIHRleHQtYmFzZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxDYWxlbmRhciBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtZW1lcmFsZC00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPlJlbmV3IExpY2Vuc2UgJiBBY2Nlc3MgVmFsaWRpdHk8L3NwYW4+XG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRPcEZvclJlbmV3KG51bGwpfSBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlXCI+4pyVPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctc2xhdGUtOTUwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdGV4dC14cyBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIGZvbnQtYm9sZFwiPntzZWxlY3RlZE9wRm9yUmVuZXcuZGlzcGxheU5hbWV9PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgZm9udC1tb25vXCI+QHtzZWxlY3RlZE9wRm9yUmVuZXcudXNlcm5hbWV9IOKAoiB7c2VsZWN0ZWRPcEZvclJlbmV3LnBob25lfTwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC00MDAgZm9udC1ib2xkIHB0LTFcIj5cbiAgICAgICAgICAgICAgICBDdXJyZW50IFJlbWFpbmluZzoge2NhbGN1bGF0ZVJlbWFpbmluZ0RheXMoc2VsZWN0ZWRPcEZvclJlbmV3LnZhbGlkaXR5RXhwaXJlc0F0KX0gRGF5c1xuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMiB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTMwMCBmb250LWJvbGQgYmxvY2tcIj5TZWxlY3QgRXh0ZW5zaW9uIER1cmF0aW9uOjwvbGFiZWw+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UmVuZXdEYXlzQ291bnQoMzApfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0zIHJvdW5kZWQteGwgYm9yZGVyIGZvbnQtYm9sZCB0ZXh0LWNlbnRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICByZW5ld0RheXNDb3VudCA9PT0gMzBcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1ibHVlLTQwMCBzaGFkb3cnXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTUwIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtODAwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+KzMwIERheXM8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDBcIj4xIE1vbnRoIFBhc3M8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UmVuZXdEYXlzQ291bnQoOTApfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0zIHJvdW5kZWQteGwgYm9yZGVyIGZvbnQtYm9sZCB0ZXh0LWNlbnRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICByZW5ld0RheXNDb3VudCA9PT0gOTBcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1ibHVlLTQwMCBzaGFkb3cnXG4gICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTUwIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtODAwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXNtXCI+KzkwIERheXM8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDBcIj5RdWFydGVybHkgUGFzczwvZGl2PlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRSZW5ld0RheXNDb3VudCgzNjUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0zIHJvdW5kZWQteGwgYm9yZGVyIGZvbnQtYm9sZCB0ZXh0LWNlbnRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICByZW5ld0RheXNDb3VudCA9PT0gMzY1XG4gICAgICAgICAgICAgICAgICAgICAgPyAnYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBib3JkZXItYmx1ZS00MDAgc2hhZG93J1xuICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTk1MCBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIGhvdmVyOmJnLXNsYXRlLTgwMCdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbVwiPiszNjUgRGF5czwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPkFubnVhbCBMaWNlbnNlPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJlbmV3RGF5c0NvdW50KDM2NTApfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0zIHJvdW5kZWQteGwgYm9yZGVyIGZvbnQtYm9sZCB0ZXh0LWNlbnRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICByZW5ld0RheXNDb3VudCA9PT0gMzY1MFxuICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNjAwIHRleHQtd2hpdGUgYm9yZGVyLWVtZXJhbGQtNDAwIHNoYWRvdydcbiAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05NTAgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTMwMCBob3ZlcjpiZy1zbGF0ZS04MDAnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc21cIj5MaWZldGltZTwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPlBlcm1hbmVudCBBY2Nlc3M8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZE9wRm9yUmVuZXcobnVsbCl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTMwMCBmb250LWJvbGQgcm91bmRlZC14bCB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUV4ZWN1dGVSZW5ld2FsfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMi41IGJnLWVtZXJhbGQtNjAwIGhvdmVyOmJnLWVtZXJhbGQtNTAwIHRleHQtd2hpdGUgZm9udC1leHRyYWJvbGQgcm91bmRlZC14bCBzaGFkb3cgdGV4dC14cyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxDaGVjayBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5Db25maXJtICYgQXBwbHkgUmVuZXdhbDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogU0VORCBCUk9BRENBU1QgTU9EQUwgKi99XG4gICAgICB7YnJvYWRjYXN0VGFyZ2V0VXNlcm5hbWUgJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgYmctYmxhY2svODUgYmFja2Ryb3AtYmx1ci1zbSB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtM3hsIG1heC13LW1kIHctZnVsbCBwLTYgc2hhZG93LTJ4bCBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSB0ZXh0LWJhc2UgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8TWVzc2FnZVNxdWFyZSBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtc2t5LTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+U2VuZCBBbGVydCB0byBAe2Jyb2FkY2FzdFRhcmdldFVzZXJuYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRCcm9hZGNhc3RUYXJnZXRVc2VybmFtZShudWxsKX0gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZVwiPuKclTwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgVGhpcyBtZXNzYWdlIHdpbGwgcG9wIHVwIGltbWVkaWF0ZWx5IG9uIHRoZSBvcGVyYXRvcidzIGNvbXB1dGVyIG9yIG1vYmlsZSBzY3JlZW4uXG4gICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgICAgICByb3dzPXszfVxuICAgICAgICAgICAgICB2YWx1ZT17YnJvYWRjYXN0TWVzc2FnZVRleHR9XG4gICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QnJvYWRjYXN0TWVzc2FnZVRleHQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gUGxlYXNlIGNoZWNrIExhZGtpIEJhaGluIHBheW1lbnQgc2xpcCBiZWZvcmUgaGFuZGluZyBvdmVyIHRvIGN1c3RvbWVyLlwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBwLTMgdGV4dC13aGl0ZSB0ZXh0LXhzXCJcbiAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWVuZCBnYXAtMlwiPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QnJvYWRjYXN0VGFyZ2V0VXNlcm5hbWUobnVsbCl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0yIGJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTMwMCBmb250LWJvbGQgcm91bmRlZC14bCB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVNlbmRCcm9hZGNhc3R9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yIGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHJvdW5kZWQteGwgc2hhZG93IHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8U2VuZCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+U2VuZCBUb2FzdCBBbGVydDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuXG4gICAgICB7LyogUkVHSVNURVIgTkVXIE9QRVJBVE9SIE1PREFMICovfVxuICAgICAge3Nob3dBZGRNb2RhbCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCBiZy1ibGFjay84MCBiYWNrZHJvcC1ibHVyLXNtIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0zeGwgbWF4LXctbWQgdy1mdWxsIHAtNiBzaGFkb3ctMnhsIHNwYWNlLXktNCBhbmltYXRlLWluIGZhZGUtaW4gem9vbS1pbi05NVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMiBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIHRleHQtYmFzZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxVc2VyUGx1cyBjbGFzc05hbWU9XCJ3LTUgaC01IHRleHQtYmx1ZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPlJlZ2lzdGVyIE5ldyBPcGVyYXRvciBJRDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93QWRkTW9kYWwoZmFsc2UpfSBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlXCI+4pyVPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICBUaGlzIG5ldyBvcGVyYXRvciBJRCB3aWxsIGJpbmQgdG8gPGI+MSBBdXRob3JpemVkIFBDPC9iPiArIDxiPjEgQXV0aG9yaXplZCBNb2JpbGU8L2I+IHVwb24gdGhlaXIgZmlyc3QgbG9naW4gZnJvbSBlYWNoIGRldmljZS5cbiAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAge2FkZEVycm9yICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC14bCBiZy1yb3NlLTUwMC8xMCBib3JkZXIgYm9yZGVyLXJvc2UtNTAwLzMwIHRleHQtcm9zZS00MDAgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgIHthZGRFcnJvcn1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlQ3JlYXRlT3BlcmF0b3J9IGNsYXNzTmFtZT1cInNwYWNlLXktMyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIG1iLTFcIj5PcGVyYXRvciBGdWxsIE5hbWU8L2xhYmVsPlxuICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBTaGFpa2ggU2FtZWVyXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdEaXNwbGF5TmFtZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmV3RGlzcGxheU5hbWUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHAtMi41IHRleHQtd2hpdGUgZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+VXNlcm5hbWUgKExvZ2luIElEKTwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIG9wZXJhdG9yM1wiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3VXNlcm5hbWV9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld1VzZXJuYW1lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBwLTIuNSB0ZXh0LXdoaXRlIGZvbnQtbW9ubyBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIG1iLTFcIj5QYXNzd29yZDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQ3JlYXRlIHNlY3VyZSBwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3UGFzc3dvcmR9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld1Bhc3N3b3JkKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBwLTIuNSB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBtYi0xXCI+UGhvbmUgTnVtYmVyPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZWxcIlxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJNb2JpbGUgbnVtYmVyXCJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtuZXdQaG9uZX1cbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmV3UGhvbmUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHAtMi41IHRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0FkZE1vZGFsKGZhbHNlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgZm9udC1ib2xkIHJvdW5kZWQteGxcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yIGJnLWJsdWUtNjAwIGhvdmVyOmJnLWJsdWUtNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHJvdW5kZWQteGwgc2hhZG93XCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBSZWdpc3RlciBPcGVyYXRvclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==