const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { Store, QrCode, Save, Database, Download, Upload, Check } from "/node_modules/.vite/deps/lucide-react.js?v=090625a0";
import { exportAllData, importDataFromJSON } from "/src/utils/storage.ts";
var _jsxFileName = "/app/applet/src/components/SettingsView.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
export const SettingsView = ({ settings, onSaveSettings }) => {
	const [formData, setFormData] = useState({ ...settings });
	const [savedSuccess, setSavedSuccess] = useState(false);
	const handleChange = (field, val) => {
		setFormData((prev) => ({
			...prev,
			[field]: val
		}));
	};
	const handleSubmit = (e) => {
		e.preventDefault();
		onSaveSettings(formData);
		setSavedSuccess(true);
		setTimeout(() => setSavedSuccess(false), 2500);
	};
	const handleImportFile = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		const reader = new FileReader();
		reader.onload = (event) => {
			const text = event.target?.result;
			const success = importDataFromJSON(text);
			if (success) {
				alert("Data backup successfully restored! Reloading...");
				window.location.reload();
			} else {
				alert("Invalid backup JSON file.");
			}
		};
		reader.readAsText(file);
		e.target.value = "";
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-5 max-w-4xl mx-auto",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl font-extrabold text-white",
						children: "Cyber Cafe & Shop Settings"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "bg-blue-500/20 text-blue-400 border border-blue-500/30 text-xs px-2 py-0.5 rounded-full font-mono font-bold",
						children: "Station Config"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400 mt-0.5",
					children: "Configure shop branding, UPI ID for QR code receipts, printer defaults, and local data backup"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 9
				}, this), savedSuccess && /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-1.5 text-xs text-emerald-400 font-bold bg-emerald-500/10 border border-emerald-500/30 px-3 py-1.5 rounded-xl",
					children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Settings Saved!" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 63,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit,
				className: "space-y-5",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md space-y-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-white font-bold text-sm border-b border-slate-800 pb-3",
							children: [/* @__PURE__ */ _jsxDEV(Store, { className: "w-4 h-4 text-blue-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 88,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Shop Profile & Bill Header" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-300 font-semibold block mb-1",
									children: "Shop / Center Name *"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 94,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									required: true,
									value: formData.shopName,
									onChange: (e) => handleChange("shopName", e.target.value),
									placeholder: "e.g. Muzammil Online Service",
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold text-sm focus:outline-none focus:border-blue-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 95,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 93,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-300 font-semibold block mb-1",
									children: "Tagline / Subheading"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 106,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: formData.tagline,
									onChange: (e) => handleChange("tagline", e.target.value),
									placeholder: "e.g. Digital Citizen Services Hub",
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-blue-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 107,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 105,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-300 font-semibold block mb-1",
									children: "Owner / Operator Name"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 117,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: formData.ownerName,
									onChange: (e) => handleChange("ownerName", e.target.value),
									placeholder: "e.g. Imran Khan",
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-blue-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 118,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 116,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-300 font-semibold block mb-1",
									children: "Contact Phone / WhatsApp *"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 128,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "tel",
									required: true,
									value: formData.phone,
									onChange: (e) => handleChange("phone", e.target.value),
									placeholder: "e.g. 9561460313",
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-blue-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 129,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 127,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "sm:col-span-2",
									children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "text-slate-300 font-semibold block mb-1",
										children: "Shop Address"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 140,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: formData.address,
										onChange: (e) => handleChange("address", e.target.value),
										placeholder: "e.g. Naya Munshi Shaban Nagar, Main Road",
										className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-blue-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 141,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 139,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 92,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md space-y-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 text-white font-bold text-sm border-b border-slate-800 pb-3",
							children: [/* @__PURE__ */ _jsxDEV(QrCode, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 155,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "UPI Payments & POS Thermal Printer" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 156,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 154,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("label", {
										className: "text-slate-300 font-semibold block mb-1",
										children: "UPI ID for Dynamic Payment QR Code"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 161,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										type: "text",
										value: formData.upiId,
										onChange: (e) => handleChange("upiId", e.target.value),
										placeholder: "e.g. 9561460313@ybl or imran@okaxis",
										className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-emerald-500"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 162,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] text-slate-500 mt-1 block",
										children: "This UPI ID generates the scannable Google Pay/PhonePe QR code on all bills!"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 169,
										columnNumber: 15
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 160,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-300 font-semibold block mb-1",
									children: "POS Thermal Receipt Width"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 175,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-2 mt-1",
									children: ["58mm", "80mm"].map((width) => /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setFormData((prev) => ({
											...prev,
											thermalWidth: width
										})),
										className: `py-2 px-3 rounded-xl font-bold border transition-all text-xs ${formData.thermalWidth === width ? "bg-blue-600 text-white border-blue-500 shadow-sm" : "bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800"}`,
										children: [width, " POS Printer"]
									}, width, true, {
										fileName: _jsxFileName,
										lineNumber: 178,
										columnNumber: 19
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 176,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 174,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "text-slate-300 font-semibold block mb-1",
									children: "GSTIN / Shop Reg No. (Optional)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 195,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									value: formData.gstNo || "",
									onChange: (e) => handleChange("gstNo", e.target.value),
									placeholder: "e.g. 27AAAAA0000A1Z5",
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-blue-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 196,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 194,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 159,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 153,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "submit",
						className: "w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 rounded-xl shadow-lg shadow-blue-600/30 transition-transform active:scale-[0.99]",
						children: [/* @__PURE__ */ _jsxDEV(Save, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 212,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Save Shop Profile & Settings" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 213,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 208,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 84,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-md space-y-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 text-white font-bold text-sm border-b border-slate-800 pb-3",
						children: [/* @__PURE__ */ _jsxDEV(Database, { className: "w-4 h-4 text-purple-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 220,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Data Backup & Restore for PC" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 221,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 219,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-300 leading-relaxed",
						children: "Export your entire customer database, billing ledger, and shop settings into a single secure JSON backup file. You can restore it on any PC or laptop at any time."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 224,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-wrap items-center gap-3 pt-1",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: exportAllData,
							className: "flex items-center gap-2 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-md transition-colors",
							children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 234,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Export Complete Backup (JSON)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 235,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 229,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("label", {
							className: "flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold px-4 py-2.5 rounded-xl border border-slate-700 cursor-pointer transition-colors",
							children: [
								/* @__PURE__ */ _jsxDEV(Upload, { className: "w-4 h-4 text-blue-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 239,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { children: "Restore Backup File" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 240,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "file",
									accept: ".json",
									onChange: handleImportFile,
									className: "hidden"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 241,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 238,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 228,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 218,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 61,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUVFLE9BQ0EsUUFFQSxNQUNBLFVBQ0EsVUFDQSxRQUNBLGFBR0s7QUFFUCxTQUFTLGVBQWUsMEJBQTBCOzs7QUFPbEQsT0FBTyxNQUFNLGdCQUE2QyxFQUN4RCxVQUNBLHFCQUNJO0NBQ0osTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUF1QixFQUFFLEdBQUcsU0FBUyxDQUFDO0NBQ3RFLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEtBQUs7Q0FFdEQsTUFBTSxnQkFBZ0IsT0FBMkIsUUFBZ0I7RUFDL0QsYUFBWSxVQUFTO0dBQUUsR0FBRztJQUFPLFFBQVE7RUFBSSxFQUFFO0NBQ2pEO0NBRUEsTUFBTSxnQkFBZ0IsTUFBdUI7RUFDM0MsRUFBRSxlQUFlO0VBQ2pCLGVBQWUsUUFBUTtFQUN2QixnQkFBZ0IsSUFBSTtFQUNwQixpQkFBaUIsZ0JBQWdCLEtBQUssR0FBRyxJQUFJO0NBQy9DO0NBRUEsTUFBTSxvQkFBb0IsTUFBMkM7RUFDbkUsTUFBTSxPQUFPLEVBQUUsT0FBTyxRQUFRO0VBQzlCLElBQUksQ0FBQyxNQUFNO0VBRVgsTUFBTSxTQUFTLElBQUksV0FBVztFQUM5QixPQUFPLFVBQVUsVUFBVTtHQUN6QixNQUFNLE9BQU8sTUFBTSxRQUFRO0dBQzNCLE1BQU0sVUFBVSxtQkFBbUIsSUFBSTtHQUN2QyxJQUFJLFNBQVM7SUFDWCxNQUFNLGlEQUFpRDtJQUN2RCxPQUFPLFNBQVMsT0FBTztHQUN6QixPQUFPO0lBQ0wsTUFBTSwyQkFBMkI7R0FDbkM7RUFDRjtFQUNBLE9BQU8sV0FBVyxJQUFJO0VBQ3RCLEVBQUUsT0FBTyxRQUFRO0NBQ25CO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQW9DO0tBQThCOzs7O2VBQ2hGLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUE4RztLQUV4SDs7OzthQUNIOzs7OztjQUNMLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQWdDO0lBRTFDOzs7O1lBQ0E7Ozs7Y0FFSixnQkFDQyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsVUFBVzs7OztlQUM1Qix3QkFBQyxRQUFELFlBQU0sa0JBQXFCOzs7O2FBQ3hCOzs7OztZQUVKOzs7Ozs7R0FFTCx3QkFBQyxRQUFEO0lBQU0sVUFBVTtJQUFjLFdBQVU7Y0FBeEM7S0FFRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsd0JBQXlCOzs7O2lCQUMxQyx3QkFBQyxRQUFELFlBQU0sNkJBQWdDOzs7O2VBQ25DOzs7OztnQkFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBMEM7UUFBMkI7Ozs7a0JBQ3RGLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0w7U0FDQSxPQUFPLFNBQVM7U0FDaEIsV0FBVyxNQUFNLGFBQWEsWUFBWSxFQUFFLE9BQU8sS0FBSztTQUN4RCxhQUFZO1NBQ1osV0FBVTtRQUNYOzs7O2dCQUNFOzs7OztRQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBMEM7UUFBMkI7Ozs7a0JBQ3RGLHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsT0FBTyxTQUFTO1NBQ2hCLFdBQVcsTUFBTSxhQUFhLFdBQVcsRUFBRSxPQUFPLEtBQUs7U0FDdkQsYUFBWTtTQUNaLFdBQVU7UUFDWDs7OztnQkFDRTs7Ozs7UUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTBDO1FBQTRCOzs7O2tCQUN2Rix3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLE9BQU8sU0FBUztTQUNoQixXQUFXLE1BQU0sYUFBYSxhQUFhLEVBQUUsT0FBTyxLQUFLO1NBQ3pELGFBQVk7U0FDWixXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O1FBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUEwQztRQUFpQzs7OztrQkFDNUYsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTDtTQUNBLE9BQU8sU0FBUztTQUNoQixXQUFXLE1BQU0sYUFBYSxTQUFTLEVBQUUsT0FBTyxLQUFLO1NBQ3JELGFBQVk7U0FDWixXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1VBQU8sV0FBVTtvQkFBMEM7U0FBbUI7Ozs7bUJBQzlFLHdCQUFDLFNBQUQ7VUFDRSxNQUFLO1VBQ0wsT0FBTyxTQUFTO1VBQ2hCLFdBQVcsTUFBTSxhQUFhLFdBQVcsRUFBRSxPQUFPLEtBQUs7VUFDdkQsYUFBWTtVQUNaLFdBQVU7U0FDWDs7OztpQkFDRTs7Ozs7O09BQ0Y7Ozs7O2NBQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSwyQkFBNEI7Ozs7aUJBQzlDLHdCQUFDLFFBQUQsWUFBTSxxQ0FBd0M7Ozs7ZUFDM0M7Ozs7O2dCQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUNFLHdCQUFDLFNBQUQ7VUFBTyxXQUFVO29CQUEwQztTQUF5Qzs7Ozs7U0FDcEcsd0JBQUMsU0FBRDtVQUNFLE1BQUs7VUFDTCxPQUFPLFNBQVM7VUFDaEIsV0FBVyxNQUFNLGFBQWEsU0FBUyxFQUFFLE9BQU8sS0FBSztVQUNyRCxhQUFZO1VBQ1osV0FBVTtTQUNYOzs7OztTQUNELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUF3QztTQUVsRDs7Ozs7UUFDSDs7Ozs7UUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQTBDO1FBQWdDOzs7O2tCQUMzRix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWCxDQUFDLFFBQVEsTUFBTSxDQUFDLENBQVcsS0FBSyxVQUNoQyx3QkFBQyxVQUFEO1VBRUUsTUFBSztVQUNMLGVBQWUsYUFBWSxVQUFTO1dBQUUsR0FBRztXQUFNLGNBQWM7VUFBTSxFQUFFO1VBQ3JFLFdBQVcsZ0VBQ1QsU0FBUyxpQkFBaUIsUUFDdEIscURBQ0E7b0JBUFIsQ0FVRyxPQUFNLGNBQ0Q7WUFWRDs7OztnQkFVQyxDQUNUO1FBQ0U7Ozs7Z0JBQ0Y7Ozs7O1FBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7U0FBTyxXQUFVO21CQUEwQztRQUFzQzs7OztrQkFDakcsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxPQUFPLFNBQVMsU0FBUztTQUN6QixXQUFXLE1BQU0sYUFBYSxTQUFTLEVBQUUsT0FBTyxLQUFLO1NBQ3JELGFBQVk7U0FDWixXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O09BQ0Y7Ozs7O2NBQ0Y7Ozs7OztLQUdMLHdCQUFDLFVBQUQ7TUFDRSxNQUFLO01BQ0wsV0FBVTtnQkFGWixDQUlFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7Z0JBQzNCLHdCQUFDLFFBQUQsWUFBTSwrQkFBa0M7Ozs7Y0FDbEM7Ozs7OztJQUNKOzs7Ozs7R0FHTix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSwwQkFBMkI7Ozs7Z0JBQy9DLHdCQUFDLFFBQUQsWUFBTSwrQkFBa0M7Ozs7Y0FDckM7Ozs7OztLQUVMLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUF5QztLQUVuRDs7Ozs7S0FFSCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsU0FBUztPQUNULFdBQVU7aUJBSFosQ0FLRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7O2lCQUMvQix3QkFBQyxRQUFELFlBQU0sZ0NBQW1DOzs7O2VBQ25DOzs7OztnQkFFUix3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBakI7UUFDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSx3QkFBeUI7Ozs7O1FBQzNDLHdCQUFDLFFBQUQsWUFBTSxzQkFBeUI7Ozs7O1FBQy9CLHdCQUFDLFNBQUQ7U0FBTyxNQUFLO1NBQU8sUUFBTztTQUFRLFVBQVU7U0FBa0IsV0FBVTtRQUFVOzs7OztPQUM3RTs7Ozs7Y0FDSjs7Ozs7O0lBQ0Y7Ozs7OztFQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTZXR0aW5nc1ZpZXcudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFxuICBTZXR0aW5ncywgXG4gIFN0b3JlLCBcbiAgUXJDb2RlLCBcbiAgUHJpbnRlciwgXG4gIFNhdmUsIFxuICBEYXRhYmFzZSwgXG4gIERvd25sb2FkLCBcbiAgVXBsb2FkLCBcbiAgQ2hlY2ssIFxuICBIZWxwQ2lyY2xlLFxuICBTaGllbGRBbGVydFxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgU2hvcFNldHRpbmdzIH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHsgZXhwb3J0QWxsRGF0YSwgaW1wb3J0RGF0YUZyb21KU09OIH0gZnJvbSAnLi4vdXRpbHMvc3RvcmFnZSc7XG5cbmludGVyZmFjZSBTZXR0aW5nc1ZpZXdQcm9wcyB7XG4gIHNldHRpbmdzOiBTaG9wU2V0dGluZ3M7XG4gIG9uU2F2ZVNldHRpbmdzOiAoc2V0dGluZ3M6IFNob3BTZXR0aW5ncykgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IFNldHRpbmdzVmlldzogUmVhY3QuRkM8U2V0dGluZ3NWaWV3UHJvcHM+ID0gKHtcbiAgc2V0dGluZ3MsXG4gIG9uU2F2ZVNldHRpbmdzXG59KSA9PiB7XG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGU8U2hvcFNldHRpbmdzPih7IC4uLnNldHRpbmdzIH0pO1xuICBjb25zdCBbc2F2ZWRTdWNjZXNzLCBzZXRTYXZlZFN1Y2Nlc3NdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChmaWVsZDoga2V5b2YgU2hvcFNldHRpbmdzLCB2YWw6IHN0cmluZykgPT4ge1xuICAgIHNldEZvcm1EYXRhKHByZXYgPT4gKHsgLi4ucHJldiwgW2ZpZWxkXTogdmFsIH0pKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIG9uU2F2ZVNldHRpbmdzKGZvcm1EYXRhKTtcbiAgICBzZXRTYXZlZFN1Y2Nlc3ModHJ1ZSk7XG4gICAgc2V0VGltZW91dCgoKSA9PiBzZXRTYXZlZFN1Y2Nlc3MoZmFsc2UpLCAyNTAwKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVJbXBvcnRGaWxlID0gKGU6IFJlYWN0LkNoYW5nZUV2ZW50PEhUTUxJbnB1dEVsZW1lbnQ+KSA9PiB7XG4gICAgY29uc3QgZmlsZSA9IGUudGFyZ2V0LmZpbGVzPy5bMF07XG4gICAgaWYgKCFmaWxlKSByZXR1cm47XG5cbiAgICBjb25zdCByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpO1xuICAgIHJlYWRlci5vbmxvYWQgPSAoZXZlbnQpID0+IHtcbiAgICAgIGNvbnN0IHRleHQgPSBldmVudC50YXJnZXQ/LnJlc3VsdCBhcyBzdHJpbmc7XG4gICAgICBjb25zdCBzdWNjZXNzID0gaW1wb3J0RGF0YUZyb21KU09OKHRleHQpO1xuICAgICAgaWYgKHN1Y2Nlc3MpIHtcbiAgICAgICAgYWxlcnQoJ0RhdGEgYmFja3VwIHN1Y2Nlc3NmdWxseSByZXN0b3JlZCEgUmVsb2FkaW5nLi4uJyk7XG4gICAgICAgIHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGFsZXJ0KCdJbnZhbGlkIGJhY2t1cCBKU09OIGZpbGUuJyk7XG4gICAgICB9XG4gICAgfTtcbiAgICByZWFkZXIucmVhZEFzVGV4dChmaWxlKTtcbiAgICBlLnRhcmdldC52YWx1ZSA9ICcnO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTUgbWF4LXctNHhsIG14LWF1dG9cIj5cbiAgICAgIHsvKiBIZWFkZXIgYmFyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHAtNCByb3VuZGVkLTJ4bCBzaGFkb3ctbWRcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlXCI+Q3liZXIgQ2FmZSAmIFNob3AgU2V0dGluZ3M8L2gxPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmctYmx1ZS01MDAvMjAgdGV4dC1ibHVlLTQwMCBib3JkZXIgYm9yZGVyLWJsdWUtNTAwLzMwIHRleHQteHMgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIGZvbnQtbW9ubyBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgU3RhdGlvbiBDb25maWdcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTAuNVwiPlxuICAgICAgICAgICAgQ29uZmlndXJlIHNob3AgYnJhbmRpbmcsIFVQSSBJRCBmb3IgUVIgY29kZSByZWNlaXB0cywgcHJpbnRlciBkZWZhdWx0cywgYW5kIGxvY2FsIGRhdGEgYmFja3VwXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7c2F2ZWRTdWNjZXNzICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC14cyB0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtYm9sZCBiZy1lbWVyYWxkLTUwMC8xMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzMwIHB4LTMgcHktMS41IHJvdW5kZWQteGxcIj5cbiAgICAgICAgICAgIDxDaGVjayBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgIDxzcGFuPlNldHRpbmdzIFNhdmVkITwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fSBjbGFzc05hbWU9XCJzcGFjZS15LTVcIj5cbiAgICAgICAgey8qIFNob3AgQnJhbmRpbmcgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNSBzaGFkb3ctbWQgc3BhY2UteS00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXNtIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcGItM1wiPlxuICAgICAgICAgICAgPFN0b3JlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1ibHVlLTQwMFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5TaG9wIFByb2ZpbGUgJiBCaWxsIEhlYWRlcjwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtNCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDAgZm9udC1zZW1pYm9sZCBibG9jayBtYi0xXCI+U2hvcCAvIENlbnRlciBOYW1lICo8L2xhYmVsPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEuc2hvcE5hbWV9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBoYW5kbGVDaGFuZ2UoJ3Nob3BOYW1lJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBNdXphbW1pbCBPbmxpbmUgU2VydmljZVwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXdoaXRlIGZvbnQtYm9sZCB0ZXh0LXNtIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYmx1ZS01MDBcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTMwMCBmb250LXNlbWlib2xkIGJsb2NrIG1iLTFcIj5UYWdsaW5lIC8gU3ViaGVhZGluZzwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEudGFnbGluZX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUNoYW5nZSgndGFnbGluZScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gRGlnaXRhbCBDaXRpemVuIFNlcnZpY2VzIEh1YlwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXdoaXRlIHRleHQteHMgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1ibHVlLTUwMFwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwIGZvbnQtc2VtaWJvbGQgYmxvY2sgbWItMVwiPk93bmVyIC8gT3BlcmF0b3IgTmFtZTwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17Zm9ybURhdGEub3duZXJOYW1lfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2hhbmdlKCdvd25lck5hbWUnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIEltcmFuIEtoYW5cIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC13aGl0ZSB0ZXh0LXhzIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYmx1ZS01MDBcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTMwMCBmb250LXNlbWlib2xkIGJsb2NrIG1iLTFcIj5Db250YWN0IFBob25lIC8gV2hhdHNBcHAgKjwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZWxcIlxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnBob25lfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2hhbmdlKCdwaG9uZScsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gOTU2MTQ2MDMxM1wiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXdoaXRlIGZvbnQtbW9ubyB0ZXh0LXhzIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYmx1ZS01MDBcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206Y29sLXNwYW4tMlwiPlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDAgZm9udC1zZW1pYm9sZCBibG9jayBtYi0xXCI+U2hvcCBBZGRyZXNzPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5hZGRyZXNzfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gaGFuZGxlQ2hhbmdlKCdhZGRyZXNzJywgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBOYXlhIE11bnNoaSBTaGFiYW4gTmFnYXIsIE1haW4gUm9hZFwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXdoaXRlIHRleHQteHMgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1ibHVlLTUwMFwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFVQSSBQYXltZW50cyAmIFRoZXJtYWwgUHJpbnRlciBTZXR0aW5ncyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC01IHNoYWRvdy1tZCBzcGFjZS15LTRcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQtc20gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwYi0zXCI+XG4gICAgICAgICAgICA8UXJDb2RlIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTQwMFwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5VUEkgUGF5bWVudHMgJiBQT1MgVGhlcm1hbCBQcmludGVyPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC00IHRleHQteHNcIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTMwMCBmb250LXNlbWlib2xkIGJsb2NrIG1iLTFcIj5VUEkgSUQgZm9yIER5bmFtaWMgUGF5bWVudCBRUiBDb2RlPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS51cGlJZH1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUNoYW5nZSgndXBpSWQnLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIDk1NjE0NjAzMTNAeWJsIG9yIGltcmFuQG9rYXhpc1wiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXdoaXRlIGZvbnQtbW9ubyB0ZXh0LXhzIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItZW1lcmFsZC01MDBcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBtdC0xIGJsb2NrXCI+XG4gICAgICAgICAgICAgICAgVGhpcyBVUEkgSUQgZ2VuZXJhdGVzIHRoZSBzY2FubmFibGUgR29vZ2xlIFBheS9QaG9uZVBlIFFSIGNvZGUgb24gYWxsIGJpbGxzIVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwIGZvbnQtc2VtaWJvbGQgYmxvY2sgbWItMVwiPlBPUyBUaGVybWFsIFJlY2VpcHQgV2lkdGg8L2xhYmVsPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTIgbXQtMVwiPlxuICAgICAgICAgICAgICAgIHsoWyc1OG1tJywgJzgwbW0nXSBhcyBjb25zdCkubWFwKCh3aWR0aCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBrZXk9e3dpZHRofVxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Rm9ybURhdGEocHJldiA9PiAoeyAuLi5wcmV2LCB0aGVybWFsV2lkdGg6IHdpZHRoIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHktMiBweC0zIHJvdW5kZWQteGwgZm9udC1ib2xkIGJvcmRlciB0cmFuc2l0aW9uLWFsbCB0ZXh0LXhzICR7XG4gICAgICAgICAgICAgICAgICAgICAgZm9ybURhdGEudGhlcm1hbFdpZHRoID09PSB3aWR0aFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctYmx1ZS02MDAgdGV4dC13aGl0ZSBib3JkZXItYmx1ZS01MDAgc2hhZG93LXNtJ1xuICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTUwIHRleHQtc2xhdGUtNDAwIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtODAwJ1xuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge3dpZHRofSBQT1MgUHJpbnRlclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTMwMCBmb250LXNlbWlib2xkIGJsb2NrIG1iLTFcIj5HU1RJTiAvIFNob3AgUmVnIE5vLiAoT3B0aW9uYWwpPC9sYWJlbD5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5nc3RObyB8fCAnJ31cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGhhbmRsZUNoYW5nZSgnZ3N0Tm8nLCBlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIDI3QUFBQUEwMDAwQTFaNVwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXdoaXRlIGZvbnQtbW9ubyB0ZXh0LXhzIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYmx1ZS01MDBcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBTYXZlIEJ1dHRvbiAqL31cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBiZy1ibHVlLTYwMCBob3ZlcjpiZy1ibHVlLTUwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCBweS0zIHJvdW5kZWQteGwgc2hhZG93LWxnIHNoYWRvdy1ibHVlLTYwMC8zMCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBhY3RpdmU6c2NhbGUtWzAuOTldXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxTYXZlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgIDxzcGFuPlNhdmUgU2hvcCBQcm9maWxlICYgU2V0dGluZ3M8L3NwYW4+XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9mb3JtPlxuXG4gICAgICB7LyogQmFja3VwICYgUmVzdG9yZSBQYW5lbCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtNSBzaGFkb3ctbWQgc3BhY2UteS00XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC1zbSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHBiLTNcIj5cbiAgICAgICAgICA8RGF0YWJhc2UgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXB1cnBsZS00MDBcIiAvPlxuICAgICAgICAgIDxzcGFuPkRhdGEgQmFja3VwICYgUmVzdG9yZSBmb3IgUEM8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS0zMDAgbGVhZGluZy1yZWxheGVkXCI+XG4gICAgICAgICAgRXhwb3J0IHlvdXIgZW50aXJlIGN1c3RvbWVyIGRhdGFiYXNlLCBiaWxsaW5nIGxlZGdlciwgYW5kIHNob3Agc2V0dGluZ3MgaW50byBhIHNpbmdsZSBzZWN1cmUgSlNPTiBiYWNrdXAgZmlsZS4gWW91IGNhbiByZXN0b3JlIGl0IG9uIGFueSBQQyBvciBsYXB0b3AgYXQgYW55IHRpbWUuXG4gICAgICAgIDwvcD5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMyBwdC0xXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXtleHBvcnRBbGxEYXRhfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgYmctcHVycGxlLTYwMCBob3ZlcjpiZy1wdXJwbGUtNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgcHgtNCBweS0yLjUgcm91bmRlZC14bCBzaGFkb3ctbWQgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxEb3dubG9hZCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgIDxzcGFuPkV4cG9ydCBDb21wbGV0ZSBCYWNrdXAgKEpTT04pPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0yMDAgdGV4dC14cyBmb250LWJvbGQgcHgtNCBweS0yLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBjdXJzb3ItcG9pbnRlciB0cmFuc2l0aW9uLWNvbG9yc1wiPlxuICAgICAgICAgICAgPFVwbG9hZCBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtYmx1ZS00MDBcIiAvPlxuICAgICAgICAgICAgPHNwYW4+UmVzdG9yZSBCYWNrdXAgRmlsZTwvc3Bhbj5cbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cIi5qc29uXCIgb25DaGFuZ2U9e2hhbmRsZUltcG9ydEZpbGV9IGNsYXNzTmFtZT1cImhpZGRlblwiIC8+XG4gICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=