const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useRef = __vite__cjsImport0_react["useRef"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { Upload, Printer, Sparkles, Sun, Contrast, CheckCircle2, Sliders, Flame, Droplets, Check, Undo2, Redo2, Layers, Minimize2 } from "/node_modules/.vite/deps/lucide-react.js?v=090625a0";
import { jsPDF } from "/node_modules/.vite/deps/jspdf.js?v=090625a0";
import { addDownloadRecord } from "/src/utils/storage.ts";
import { printImageSheet } from "/src/utils/printer.ts";
var _jsxFileName = "/app/applet/src/components/PassportStudioView.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
const BEAUTY_PRESETS = [
	{
		id: "auto_beauty",
		name: "Auto Studio Beauty",
		icon: "✨",
		desc: "Smooth skin & radiant facial lighting",
		settings: {
			brightness: 8,
			contrast: 6,
			saturation: 12,
			warmth: 8,
			tint: 4,
			skinSmooth: 20,
			faceGlow: 25,
			shadowLift: 15,
			isGrayscale: false
		}
	},
	{
		id: "indian_warm",
		name: "Indian Studio Tone",
		icon: "📸",
		desc: "Golden warm glow, removes camera pale tone",
		settings: {
			brightness: 6,
			contrast: 8,
			saturation: 15,
			warmth: 18,
			tint: 2,
			skinSmooth: 16,
			faceGlow: 20,
			shadowLift: 12,
			isGrayscale: false
		}
	},
	{
		id: "glamour_soft",
		name: "Soft Glamour Glow",
		icon: "🌟",
		desc: "Airbrushed porcelain skin with soft highlights",
		settings: {
			brightness: 12,
			contrast: 4,
			saturation: 8,
			warmth: 10,
			tint: 6,
			skinSmooth: 32,
			faceGlow: 35,
			shadowLift: 20,
			isGrayscale: false
		}
	},
	{
		id: "crisp_formal",
		name: "Sharp Formal ID",
		icon: "💼",
		desc: "Neutral white balance & crisp facial edges",
		settings: {
			brightness: 4,
			contrast: 12,
			saturation: 5,
			warmth: 0,
			tint: 0,
			skinSmooth: 8,
			faceGlow: 10,
			shadowLift: 8,
			isGrayscale: false
		}
	},
	{
		id: "cool_clean",
		name: "Cool White Balance",
		icon: "❄️",
		desc: "Removes yellow/orange lighting cast",
		settings: {
			brightness: 8,
			contrast: 8,
			saturation: 4,
			warmth: -14,
			tint: -2,
			skinSmooth: 14,
			faceGlow: 15,
			shadowLift: 10,
			isGrayscale: false
		}
	},
	{
		id: "bw_formal",
		name: "B&W Official Exam",
		icon: "🖤",
		desc: "High contrast monochrome for SSC/UPSC",
		settings: {
			brightness: 6,
			contrast: 16,
			saturation: 0,
			warmth: 0,
			tint: 0,
			skinSmooth: 12,
			faceGlow: 10,
			shadowLift: 10,
			isGrayscale: true
		}
	}
];
export const PassportStudioView = () => {
	// Main Sheet Canvas (Hidden or rendered for 4x6 / A4 sheet calculation)
	const fullSheetCanvasRef = useRef(null);
	// Photoshop-Style Editing Canvas (Primary interactive workspace)
	const editorCanvasRef = useRef(null);
	// Mini Preview Canvas (Compact Sheet Preview widget)
	const miniPreviewCanvasRef = useRef(null);
	// Active Tool Selection (Photoshop Toolbar)
	const [activeTool, setActiveTool] = useState("select");
	// Photo Source & History Stack for Undo / Redo
	const [photoSrc, setPhotoSrc] = useState(null);
	const [originalPhotoSrc, setOriginalPhotoSrc] = useState(null);
	const [historyStack, setHistoryStack] = useState([]);
	const [historyIndex, setHistoryIndex] = useState(-1);
	const photoImgRef = useRef(null);
	// Paper & Layout settings: Default is 4x6 LANDSCAPE with 8 COPIES
	const [paperFormat, setPaperFormat] = useState("4x6_landscape");
	const [copies, setCopies] = useState(8);
	// Studio background replacement color
	const [bgColor, setBgColor] = useState("#ffffff");
	// Mini Preview Visibility State (Collapsible / Expandable)
	const [showMiniPreview, setShowMiniPreview] = useState(true);
	// Auto Beauty Mode Toggle
	const [autoBeauty, setAutoBeauty] = useState(true);
	const [activePreset, setActivePreset] = useState("auto_beauty");
	// Color Grading Parameters
	const [brightness, setBrightness] = useState(8);
	const [contrast, setContrast] = useState(6);
	const [saturation, setSaturation] = useState(12);
	const [warmth, setWarmth] = useState(8);
	const [tint, setTint] = useState(4);
	const [shadowLift, setShadowLift] = useState(15);
	const [skinSmooth, setSkinSmooth] = useState(20);
	const [faceGlow, setFaceGlow] = useState(25);
	const [isGrayscale, setIsGrayscale] = useState(false);
	// Canvas Viewport Pan & Zoom
	const [canvasZoom, setCanvasZoom] = useState(1);
	const [canvasPan, setCanvasPan] = useState({
		x: 0,
		y: 0
	});
	const [isSpacePressed, setIsSpacePressed] = useState(false);
	const [isPanning, setIsPanning] = useState(false);
	const [panStart, setPanStart] = useState({
		x: 0,
		y: 0
	});
	// Tool Specific States:
	// 1. Magic Wand / Magic Cut
	const [magicTolerance, setMagicTolerance] = useState(32);
	const [magicFeather, setMagicFeather] = useState(2);
	// 2. Pen Tool (Manual Vector Cutout)
	const [penPoints, setPenPoints] = useState([]);
	const [isPathClosed, setIsPathClosed] = useState(false);
	const [isNearStartPoint, setIsNearStartPoint] = useState(false);
	const [penFeather, setPenFeather] = useState(2);
	// 3. Brushes (Blemish, Beauty, Eye Brighten)
	const [brushSize, setBrushSize] = useState(24);
	const [isBrushing, setIsBrushing] = useState(false);
	// 4. Crop Tool
	const [cropBox, setCropBox] = useState(null);
	// 5. Section Selection & Local Color Grading State
	const [selectionBox, setSelectionBox] = useState(null);
	const [isSelectingBox, setIsSelectingBox] = useState(false);
	const [selectionStartNorm, setSelectionStartNorm] = useState(null);
	const [gradingScope, setGradingScope] = useState("full");
	// Local section color grading parameters
	const [secBrightness, setSecBrightness] = useState(15);
	const [secContrast, setSecContrast] = useState(12);
	const [secWarmth, setSecWarmth] = useState(0);
	const [secSaturation, setSecSaturation] = useState(0);
	const [secSmooth, setSecSmooth] = useState(15);
	const [secFeather, setSecFeather] = useState(8);
	// Exam Name & Date overlay (for SSC, Police Bharti, UPSC)
	const [showNameDate, setShowNameDate] = useState(false);
	const [candidateName, setCandidateName] = useState("CANDIDATE NAME");
	const [photoDate, setPhotoDate] = useState(new Date().toLocaleDateString("en-IN", {
		day: "2-digit",
		month: "2-digit",
		year: "numeric"
	}));
	const [isProcessing, setIsProcessing] = useState(false);
	const [printAlert, setPrintAlert] = useState(null);
	// 300 DPI Canvas Dimensions for full sheet
	let SHEET_WIDTH = 1800;
	let SHEET_HEIGHT = 1200;
	if (paperFormat === "4x6_landscape") {
		SHEET_WIDTH = 1800;
		SHEET_HEIGHT = 1200;
	} else if (paperFormat === "a4_landscape") {
		SHEET_WIDTH = 3508;
		SHEET_HEIGHT = 2480;
	} else if (paperFormat === "4x6_portrait") {
		SHEET_WIDTH = 1200;
		SHEET_HEIGHT = 1800;
	} else {
		SHEET_WIDTH = 2480;
		SHEET_HEIGHT = 3508;
	}
	// -------------------------------------------------------------
	// KEYBOARD SHORTCUTS LISTENER (Photoshop Standard: V, C, W, P, B, S, H, Z, Ctrl+Z, Ctrl+P)
	// -------------------------------------------------------------
	useEffect(() => {
		const handleKeyDown = (e) => {
			// Don't trigger if user is typing in text input
			if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") {
				return;
			}
			// Spacebar for temporary Hand Pan tool
			if (e.code === "Space" && !e.repeat) {
				setIsSpacePressed(true);
			}
			// Undo: Ctrl + Z
			if (e.ctrlKey && e.key.toLowerCase() === "z" && !e.shiftKey) {
				e.preventDefault();
				handleUndo();
			}
			// Redo: Ctrl + Y or Ctrl + Shift + Z
			if (e.ctrlKey && e.key.toLowerCase() === "y" || e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "z") {
				e.preventDefault();
				handleRedo();
			}
			// Tools Switcher Shortcuts:
			if (!e.ctrlKey && !e.altKey && !e.metaKey) {
				switch (e.key.toLowerCase()) {
					case "v":
						setActiveTool("select");
						break;
					case "q":
						setActiveTool("section_select");
						setGradingScope("selection");
						break;
					case "r":
						handleAutoBackgroundErase();
						break;
					case "c":
						setActiveTool("crop");
						initCropBox();
						break;
					case "w":
						setActiveTool("magic_wand");
						break;
					case "p":
						setActiveTool("pen_tool");
						break;
					case "b":
						setActiveTool("blemish_brush");
						break;
					case "s":
						setActiveTool("beauty_brush");
						break;
					case "e":
						setActiveTool("eye_brighten");
						break;
					case "h":
						setActiveTool("hand");
						break;
					case "z":
						setActiveTool("zoom");
						break;
					case "m":
						setShowMiniPreview((prev) => !prev);
						break;
					case "[":
						setBrushSize((prev) => Math.max(8, prev - 4));
						break;
					case "]":
						setBrushSize((prev) => Math.min(80, prev + 4));
						break;
					case "escape":
						if (activeTool === "pen_tool") {
							setPenPoints([]);
							setIsPathClosed(false);
						}
						if (activeTool === "crop") {
							setCropBox(null);
							setActiveTool("select");
						}
						break;
				}
			}
			// Zoom Shortcuts: Ctrl + '+' / Ctrl + '-' / Ctrl + '0'
			if (e.ctrlKey && (e.key === "=" || e.key === "+")) {
				e.preventDefault();
				setCanvasZoom((prev) => Math.min(4, prev + .25));
			}
			if (e.ctrlKey && (e.key === "-" || e.key === "_")) {
				e.preventDefault();
				setCanvasZoom((prev) => Math.max(.4, prev - .25));
			}
			if (e.ctrlKey && e.key === "0") {
				e.preventDefault();
				setCanvasZoom(1);
				setCanvasPan({
					x: 0,
					y: 0
				});
			}
		};
		const handleKeyUp = (e) => {
			if (e.code === "Space") {
				setIsSpacePressed(false);
				setIsPanning(false);
			}
		};
		window.addEventListener("keydown", handleKeyDown);
		window.addEventListener("keyup", handleKeyUp);
		return () => {
			window.removeEventListener("keydown", handleKeyDown);
			window.removeEventListener("keyup", handleKeyUp);
		};
	}, [
		activeTool,
		historyIndex,
		historyStack
	]);
	// Push new state to undo/redo history
	const pushToHistory = (newSrc) => {
		setHistoryStack((prev) => {
			const upToCurrent = prev.slice(0, historyIndex + 1);
			const updated = [...upToCurrent, newSrc];
			if (updated.length > 15) updated.shift();
			return updated;
		});
		setHistoryIndex((prev) => Math.min(14, prev + 1));
	};
	const handleUndo = () => {
		if (activeTool === "pen_tool" && penPoints.length > 0) {
			if (isPathClosed) {
				setIsPathClosed(false);
			} else {
				setPenPoints((prev) => prev.slice(0, -1));
			}
			return;
		}
		if (historyIndex > 0) {
			const nextIdx = historyIndex - 1;
			setHistoryIndex(nextIdx);
			setPhotoSrc(historyStack[nextIdx]);
		}
	};
	const handleRedo = () => {
		if (historyIndex < historyStack.length - 1) {
			const nextIdx = historyIndex + 1;
			setHistoryIndex(nextIdx);
			setPhotoSrc(historyStack[nextIdx]);
		}
	};
	// Load photo into Image object
	useEffect(() => {
		if (photoSrc) {
			const img = new Image();
			img.crossOrigin = "anonymous";
			img.onload = () => {
				photoImgRef.current = img;
				renderEditorCanvas();
				renderMiniPreview();
				renderFullSheet();
			};
			img.src = photoSrc;
		} else {
			photoImgRef.current = null;
			renderEditorCanvas();
			renderMiniPreview();
			renderFullSheet();
		}
	}, [photoSrc]);
	// Re-render when adjustments change
	useEffect(() => {
		renderEditorCanvas();
		renderMiniPreview();
		renderFullSheet();
	}, [
		photoSrc,
		activeTool,
		penPoints,
		isPathClosed,
		isNearStartPoint,
		cropBox,
		canvasZoom,
		canvasPan,
		bgColor,
		autoBeauty,
		brightness,
		contrast,
		saturation,
		warmth,
		tint,
		shadowLift,
		skinSmooth,
		faceGlow,
		isGrayscale,
		paperFormat,
		copies,
		showNameDate,
		candidateName,
		photoDate
	]);
	// Initialize crop box to 35:45 ratio
	const initCropBox = () => {
		const canvas = editorCanvasRef.current;
		if (!canvas) return;
		const w = Math.min(canvas.width * .7, canvas.height * .7 * (35 / 45));
		const h = w * (45 / 35);
		setCropBox({
			x: (canvas.width - w) / 2,
			y: (canvas.height - h) / 2,
			w,
			h
		});
	};
	// Apply Crop
	const handleApplyCrop = () => {
		const canvas = editorCanvasRef.current;
		const img = photoImgRef.current;
		if (!canvas || !img || !cropBox) return;
		try {
			const cropCanvas = document.createElement("canvas");
			cropCanvas.width = 700;
			cropCanvas.height = 900;
			const cCtx = cropCanvas.getContext("2d");
			if (!cCtx) return;
			// Extract cropped area from editor canvas
			cCtx.drawImage(canvas, cropBox.x, cropBox.y, cropBox.w, cropBox.h, 0, 0, cropCanvas.width, cropCanvas.height);
			const croppedUrl = cropCanvas.toDataURL("image/jpeg", .98);
			setPhotoSrc(croppedUrl);
			pushToHistory(croppedUrl);
			setCropBox(null);
			setActiveTool("select");
			setPrintAlert("✂️ Photo cropped to 35×45mm passport ratio!");
			setTimeout(() => setPrintAlert(null), 3e3);
		} catch (e) {
			console.error(e);
		}
	};
	// -------------------------------------------------------------
	// MAGIC WAND / MAGIC CUT (FIXED & HIGH-PRECISION FLOOD FILL)
	// -------------------------------------------------------------
	// BFS Connected Flood-Fill from clicked pixel
	const executeMagicWandCut = (clickX, clickY) => {
		const img = photoImgRef.current;
		if (!img) return;
		setIsProcessing(true);
		try {
			const workCanvas = document.createElement("canvas");
			workCanvas.width = img.width;
			workCanvas.height = img.height;
			const wCtx = workCanvas.getContext("2d");
			if (!wCtx) return;
			wCtx.drawImage(img, 0, 0);
			const imgData = wCtx.getImageData(0, 0, workCanvas.width, workCanvas.height);
			const data = imgData.data;
			const w = workCanvas.width;
			const h = workCanvas.height;
			// Scale clickX, clickY to original image pixels
			const startX = Math.floor(Math.max(0, Math.min(w - 1, clickX)));
			const startY = Math.floor(Math.max(0, Math.min(h - 1, clickY)));
			const startIndex = (startY * w + startX) * 4;
			const targetR = data[startIndex];
			const targetG = data[startIndex + 1];
			const targetB = data[startIndex + 2];
			// Parse target background color
			const dummy = document.createElement("div");
			dummy.style.color = bgColor;
			document.body.appendChild(dummy);
			const computed = window.getComputedStyle(dummy).color;
			document.body.removeChild(dummy);
			const rgb = computed.match(/\d+/g)?.map(Number) || [
				255,
				255,
				255
			];
			// Visited array to prevent infinite loop
			const visited = new Uint8Array(w * h);
			const queue = [startX + startY * w];
			visited[startX + startY * w] = 1;
			const tolSq = Math.pow(magicTolerance * 2.2, 2);
			// BFS flood fill
			let head = 0;
			while (head < queue.length) {
				const curr = queue[head++];
				const cx = curr % w;
				const cy = Math.floor(curr / w);
				const idx = curr * 4;
				// Replace pixel color with studio background
				data[idx] = rgb[0];
				data[idx + 1] = rgb[1];
				data[idx + 2] = rgb[2];
				data[idx + 3] = 255;
				// Check 4-directional neighbors
				const neighbors = [
					[cx + 1, cy],
					[cx - 1, cy],
					[cx, cy + 1],
					[cx, cy - 1]
				];
				for (let i = 0; i < 4; i++) {
					const nx = neighbors[i][0];
					const ny = neighbors[i][1];
					if (nx >= 0 && nx < w && ny >= 0 && ny < h) {
						const nPos = nx + ny * w;
						if (!visited[nPos]) {
							const nIdx = nPos * 4;
							const nr = data[nIdx];
							const ng = data[nIdx + 1];
							const nb = data[nIdx + 2];
							// Color distance from target
							const distSq = Math.pow(nr - targetR, 2) + Math.pow(ng - targetG, 2) + Math.pow(nb - targetB, 2);
							if (distSq <= tolSq) {
								visited[nPos] = 1;
								queue.push(nPos);
							}
						}
					}
				}
			}
			wCtx.putImageData(imgData, 0, 0);
			const resDataUrl = workCanvas.toDataURL("image/jpeg", .98);
			if (!originalPhotoSrc && photoSrc) {
				setOriginalPhotoSrc(photoSrc);
			}
			setPhotoSrc(resDataUrl);
			pushToHistory(resDataUrl);
			setPrintAlert(`🪄 Magic Wand erased connected background at (${startX}, ${startY})!`);
			setTimeout(() => setPrintAlert(null), 3e3);
		} catch (e) {
			console.error(e);
		} finally {
			setIsProcessing(false);
		}
	};
	// 1-Click Auto Background Eraser (Seeds flood fill from all 4 outer borders)
	const handleAutoBackgroundErase = () => {
		const img = photoImgRef.current;
		if (!img) return;
		setIsProcessing(true);
		try {
			const workCanvas = document.createElement("canvas");
			workCanvas.width = img.width;
			workCanvas.height = img.height;
			const wCtx = workCanvas.getContext("2d");
			if (!wCtx) return;
			wCtx.drawImage(img, 0, 0);
			const imgData = wCtx.getImageData(0, 0, workCanvas.width, workCanvas.height);
			const data = imgData.data;
			const w = workCanvas.width;
			const h = workCanvas.height;
			// Target background color parse
			const isTransparent = bgColor === "transparent";
			let rgb = [
				255,
				255,
				255
			];
			if (!isTransparent) {
				const dummy = document.createElement("div");
				dummy.style.color = bgColor;
				document.body.appendChild(dummy);
				const computed = window.getComputedStyle(dummy).color;
				document.body.removeChild(dummy);
				rgb = computed.match(/\d+/g)?.map(Number) || [
					255,
					255,
					255
				];
			}
			// Sample reference background color from top corners
			const cornerR = (data[0] + data[(w - 1) * 4]) / 2;
			const cornerG = (data[1] + data[(w - 1) * 4 + 1]) / 2;
			const cornerB = (data[2] + data[(w - 1) * 4 + 2]) / 2;
			const visited = new Uint8Array(w * h);
			const queue = [];
			// Seed all 4 outer borders
			for (let x = 0; x < w; x++) {
				queue.push(x);
				queue.push(x + (h - 1) * w);
				visited[x] = 1;
				visited[x + (h - 1) * w] = 1;
			}
			for (let y = 0; y < h; y++) {
				queue.push(y * w);
				queue.push(w - 1 + y * w);
				visited[y * w] = 1;
				visited[w - 1 + y * w] = 1;
			}
			const tolSq = Math.pow(magicTolerance * 2.2, 2);
			let head = 0;
			while (head < queue.length) {
				const curr = queue[head++];
				const cx = curr % w;
				const cy = Math.floor(curr / w);
				const idx = curr * 4;
				// Replace background pixel
				if (isTransparent) {
					data[idx + 3] = 0;
				} else {
					data[idx] = rgb[0];
					data[idx + 1] = rgb[1];
					data[idx + 2] = rgb[2];
					data[idx + 3] = 255;
				}
				const neighbors = [
					[cx + 1, cy],
					[cx - 1, cy],
					[cx, cy + 1],
					[cx, cy - 1]
				];
				for (let i = 0; i < 4; i++) {
					const nx = neighbors[i][0];
					const ny = neighbors[i][1];
					if (nx >= 0 && nx < w && ny >= 0 && ny < h) {
						const nPos = nx + ny * w;
						if (!visited[nPos]) {
							const nIdx = nPos * 4;
							const nr = data[nIdx];
							const ng = data[nIdx + 1];
							const nb = data[nIdx + 2];
							const distSq = Math.pow(nr - cornerR, 2) + Math.pow(ng - cornerG, 2) + Math.pow(nb - cornerB, 2);
							if (distSq <= tolSq) {
								visited[nPos] = 1;
								queue.push(nPos);
							}
						}
					}
				}
			}
			wCtx.putImageData(imgData, 0, 0);
			const resDataUrl = workCanvas.toDataURL(isTransparent ? "image/png" : "image/jpeg", .98);
			if (!originalPhotoSrc && photoSrc) {
				setOriginalPhotoSrc(photoSrc);
			}
			setPhotoSrc(resDataUrl);
			pushToHistory(resDataUrl);
			setPrintAlert(isTransparent ? "✨ 1-Click Transparent Background Cutout created!" : "✨ 1-Click Magic Auto Background successfully replaced!");
			setTimeout(() => setPrintAlert(null), 3e3);
		} catch (e) {
			console.error(e);
		} finally {
			setIsProcessing(false);
		}
	};
	// -------------------------------------------------------------
	// SPOT BLEMISH REMOVER & BEAUTY BRUSH
	// -------------------------------------------------------------
	const applyHealingBrush = (centerX, centerY, mode) => {
		const img = photoImgRef.current;
		if (!img) return;
		try {
			const workCanvas = document.createElement("canvas");
			workCanvas.width = img.width;
			workCanvas.height = img.height;
			const wCtx = workCanvas.getContext("2d");
			if (!wCtx) return;
			wCtx.drawImage(img, 0, 0);
			const rad = brushSize;
			const x = Math.max(0, Math.min(img.width, centerX));
			const y = Math.max(0, Math.min(img.height, centerY));
			if (mode === "blemish") {
				// Sample surrounding ring of skin pixels and blend into center
				const imgData = wCtx.getImageData(Math.max(0, x - rad), Math.max(0, y - rad), rad * 2, rad * 2);
				const data = imgData.data;
				// Average surrounding ring
				let rSum = 0, gSum = 0, bSum = 0, count = 0;
				for (let py = 0; py < rad * 2; py++) {
					for (let px = 0; px < rad * 2; px++) {
						const d = Math.hypot(px - rad, py - rad);
						if (d >= rad * .7 && d <= rad) {
							const i = (py * rad * 2 + px) * 4;
							rSum += data[i];
							gSum += data[i + 1];
							bSum += data[i + 2];
							count++;
						}
					}
				}
				if (count > 0) {
					const avgR = rSum / count;
					const avgG = gSum / count;
					const avgB = bSum / count;
					for (let py = 0; py < rad * 2; py++) {
						for (let px = 0; px < rad * 2; px++) {
							const d = Math.hypot(px - rad, py - rad);
							if (d < rad) {
								const i = (py * rad * 2 + px) * 4;
								const alphaWeight = 1 - d / rad;
								data[i] = data[i] * (1 - alphaWeight) + avgR * alphaWeight;
								data[i + 1] = data[i + 1] * (1 - alphaWeight) + avgG * alphaWeight;
								data[i + 2] = data[i + 2] * (1 - alphaWeight) + avgB * alphaWeight;
							}
						}
					}
					wCtx.putImageData(imgData, Math.max(0, x - rad), Math.max(0, y - rad));
				}
			} else if (mode === "beauty") {
				// Soft skin airbrush blur
				wCtx.save();
				wCtx.beginPath();
				wCtx.arc(x, y, rad, 0, Math.PI * 2);
				wCtx.clip();
				wCtx.filter = "blur(4px) brightness(105%)";
				wCtx.drawImage(img, 0, 0);
				wCtx.restore();
			} else {
				// Eye & Teeth Whitener
				wCtx.save();
				wCtx.beginPath();
				wCtx.arc(x, y, rad, 0, Math.PI * 2);
				wCtx.clip();
				wCtx.filter = "brightness(118%) contrast(106%) saturate(60%)";
				wCtx.drawImage(img, 0, 0);
				wCtx.restore();
			}
			const resDataUrl = workCanvas.toDataURL("image/jpeg", .98);
			setPhotoSrc(resDataUrl);
			pushToHistory(resDataUrl);
		} catch (e) {
			console.error(e);
		}
	};
	// -------------------------------------------------------------
	// PEN TOOL: APPLY VECTOR CUTOUT
	// -------------------------------------------------------------
	const handleApplyPenCutout = () => {
		const img = photoImgRef.current;
		if (!img || penPoints.length < 3) return;
		try {
			const workCanvas = document.createElement("canvas");
			workCanvas.width = img.width;
			workCanvas.height = img.height;
			const wCtx = workCanvas.getContext("2d");
			if (!wCtx) return;
			// 1. Fill studio background
			wCtx.fillStyle = bgColor;
			wCtx.fillRect(0, 0, workCanvas.width, workCanvas.height);
			// 2. Create offscreen person layer clipped to path
			const personCanvas = document.createElement("canvas");
			personCanvas.width = img.width;
			personCanvas.height = img.height;
			const pCtx = personCanvas.getContext("2d");
			if (pCtx) {
				pCtx.drawImage(img, 0, 0);
				const maskCanvas = document.createElement("canvas");
				maskCanvas.width = img.width;
				maskCanvas.height = img.height;
				const mCtx = maskCanvas.getContext("2d");
				if (mCtx) {
					if (penFeather > 0) {
						mCtx.filter = `blur(${penFeather}px)`;
					}
					mCtx.beginPath();
					mCtx.moveTo(penPoints[0].x * img.width, penPoints[0].y * img.height);
					for (let i = 1; i < penPoints.length; i++) {
						mCtx.lineTo(penPoints[i].x * img.width, penPoints[i].y * img.height);
					}
					mCtx.closePath();
					mCtx.fillStyle = "#000000";
					mCtx.fill();
					pCtx.globalCompositeOperation = "destination-in";
					pCtx.drawImage(maskCanvas, 0, 0);
				}
				wCtx.drawImage(personCanvas, 0, 0);
			}
			const resDataUrl = workCanvas.toDataURL("image/jpeg", .98);
			if (!originalPhotoSrc && photoSrc) {
				setOriginalPhotoSrc(photoSrc);
			}
			setPhotoSrc(resDataUrl);
			pushToHistory(resDataUrl);
			setPenPoints([]);
			setIsPathClosed(false);
			setActiveTool("select");
			setPrintAlert("🖊️ Pen Tool Cutout applied successfully!");
			setTimeout(() => setPrintAlert(null), 3e3);
		} catch (e) {
			console.error(e);
		}
	};
	// -------------------------------------------------------------
	// SECTION SELECTION & LOCAL COLOR GRADING HANDLERS
	// -------------------------------------------------------------
	const handleSelectPreset = (type) => {
		switch (type) {
			case "face":
				setSelectionBox({
					x: .18,
					y: .1,
					w: .64,
					h: .52
				});
				break;
			case "clothes":
				setSelectionBox({
					x: .05,
					y: .58,
					w: .9,
					h: .42
				});
				break;
			case "eyes":
				setSelectionBox({
					x: .22,
					y: .24,
					w: .56,
					h: .2
				});
				break;
			case "full":
				setSelectionBox({
					x: .02,
					y: .02,
					w: .96,
					h: .96
				});
				break;
		}
		setActiveTool("section_select");
		setGradingScope("selection");
	};
	const handleClearSelection = () => {
		setSelectionBox(null);
		setGradingScope("full");
	};
	const handleInvertSelection = () => {
		if (!selectionBox) return;
		// Invert selection box coordinates
		setSelectionBox({
			x: Math.max(0, 1 - (selectionBox.x + selectionBox.w)),
			y: selectionBox.y,
			w: selectionBox.w,
			h: selectionBox.h
		});
	};
	const handleBakeSectionAdjustment = () => {
		const img = photoImgRef.current;
		if (!img || !selectionBox) return;
		setIsProcessing(true);
		try {
			const workCanvas = document.createElement("canvas");
			workCanvas.width = img.width;
			workCanvas.height = img.height;
			const wCtx = workCanvas.getContext("2d");
			if (!wCtx) return;
			// 1. Draw base photo
			wCtx.drawImage(img, 0, 0);
			// 2. Draw section with local adjustments
			const secX = selectionBox.x * img.width;
			const secY = selectionBox.y * img.height;
			const secW = selectionBox.w * img.width;
			const secH = selectionBox.h * img.height;
			wCtx.save();
			wCtx.beginPath();
			wCtx.rect(secX, secY, secW, secH);
			wCtx.clip();
			const secEffBright = 100 + secBrightness;
			const secEffCont = 100 + secContrast;
			const secEffSat = 100 + secSaturation;
			wCtx.filter = `brightness(${secEffBright}%) contrast(${secEffCont}%) saturate(${secEffSat}%)`;
			wCtx.drawImage(img, 0, 0);
			if (secWarmth !== 0 && !isGrayscale) {
				wCtx.globalCompositeOperation = "color";
				wCtx.fillStyle = secWarmth > 0 ? `rgba(255, 175, 75, ${Math.min(.45, secWarmth / 100 * .5)})` : `rgba(80, 165, 255, ${Math.min(.45, Math.abs(secWarmth) / 100 * .5)})`;
				wCtx.fillRect(secX, secY, secW, secH);
			}
			wCtx.restore();
			const resDataUrl = workCanvas.toDataURL("image/jpeg", .98);
			if (!originalPhotoSrc && photoSrc) {
				setOriginalPhotoSrc(photoSrc);
			}
			setPhotoSrc(resDataUrl);
			pushToHistory(resDataUrl);
			setPrintAlert("✅ Section color grading permanently baked into photo!");
			setTimeout(() => setPrintAlert(null), 4e3);
		} catch (e) {
			console.error(e);
		} finally {
			setIsProcessing(false);
		}
	};
	// -------------------------------------------------------------
	// MAIN EDITOR CANVAS RENDER (Central Photoshop-Style Workspace)
	// -------------------------------------------------------------
	const renderEditorCanvas = () => {
		const canvas = editorCanvasRef.current;
		const img = photoImgRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		// Fixed internal size for sharp 2K editing canvas
		canvas.width = 900;
		canvas.height = 700;
		// Dark workspace checkered background
		ctx.fillStyle = "#090d16";
		ctx.fillRect(0, 0, canvas.width, canvas.height);
		if (!img) {
			// Empty state
			ctx.fillStyle = "#64748b";
			ctx.font = "bold 16px sans-serif";
			ctx.textAlign = "center";
			ctx.fillText("Upload or Drag Customer Photo to Edit", canvas.width / 2, canvas.height / 2 - 10);
			ctx.font = "12px sans-serif";
			ctx.fillText("Photoshop-style tools: Pen, Magic Wand, Blemish, Crop, Auto Beauty", canvas.width / 2, canvas.height / 2 + 15);
			return;
		}
		ctx.save();
		// Pan & Zoom transformations
		ctx.translate(canvas.width / 2 + canvasPan.x, canvas.height / 2 + canvasPan.y);
		ctx.scale(canvasZoom, canvasZoom);
		// Calculate dimensions maintaining aspect ratio
		const aspect = img.width / img.height;
		let renderW = 460;
		let renderH = 460 / aspect;
		if (renderH > 560) {
			renderH = 560;
			renderW = 560 * aspect;
		}
		const drawX = -renderW / 2;
		const drawY = -renderH / 2;
		// Apply color grading filters
		const effBrightness = 100 + brightness + (autoBeauty ? 6 : 0) + faceGlow * .12;
		const effContrast = 100 + contrast + (autoBeauty ? 4 : 0);
		const effSaturation = isGrayscale ? 0 : 100 + saturation + (autoBeauty ? 8 : 0);
		let filterStr = `brightness(${effBrightness}%) contrast(${effContrast}%) saturate(${effSaturation}%)`;
		if (isGrayscale) filterStr += " grayscale(100%)";
		ctx.filter = filterStr;
		ctx.drawImage(img, drawX, drawY, renderW, renderH);
		// Soft Beauty Layer (Soft-Light pass)
		const effSmooth = autoBeauty ? Math.max(skinSmooth, 16) : skinSmooth;
		const effGlow = autoBeauty ? Math.max(faceGlow, 20) : faceGlow;
		if (effSmooth > 0 || effGlow > 0) {
			ctx.save();
			ctx.globalCompositeOperation = "soft-light";
			ctx.globalAlpha = Math.min(.65, effSmooth * .012 + effGlow * .01);
			ctx.filter = `blur(${Math.max(2, effSmooth / 8)}px) brightness(120%)`;
			ctx.drawImage(img, drawX, drawY, renderW, renderH);
			ctx.restore();
		}
		// Warmth & Tint
		if (warmth !== 0 && !isGrayscale) {
			ctx.save();
			ctx.globalCompositeOperation = "color";
			ctx.fillStyle = warmth > 0 ? `rgba(255, 175, 75, ${Math.min(.35, warmth / 100 * .4)})` : `rgba(80, 165, 255, ${Math.min(.35, Math.abs(warmth) / 100 * .4)})`;
			ctx.fillRect(drawX, drawY, renderW, renderH);
			ctx.restore();
		}
		if (tint !== 0 && !isGrayscale) {
			ctx.save();
			ctx.globalCompositeOperation = "color";
			ctx.fillStyle = tint > 0 ? `rgba(255, 60, 180, ${Math.min(.25, tint / 100 * .3)})` : `rgba(60, 220, 100, ${Math.min(.25, Math.abs(tint) / 100 * .3)})`;
			ctx.fillRect(drawX, drawY, renderW, renderH);
			ctx.restore();
		}
		// -------------------------------------------------------------
		// LOCAL SECTION COLOR GRADING OVERLAY (Inside Photo Coordinates)
		// -------------------------------------------------------------
		if (selectionBox && selectionBox.w > .005 && selectionBox.h > .005) {
			const secX = drawX + selectionBox.x * renderW;
			const secY = drawY + selectionBox.y * renderH;
			const secW = selectionBox.w * renderW;
			const secH = selectionBox.h * renderH;
			ctx.save();
			ctx.beginPath();
			ctx.rect(secX, secY, secW, secH);
			ctx.clip();
			const secEffBright = effBrightness + secBrightness;
			const secEffCont = effContrast + secContrast;
			const secEffSat = isGrayscale ? 0 : effSaturation + secSaturation;
			ctx.filter = `brightness(${secEffBright}%) contrast(${secEffCont}%) saturate(${secEffSat}%)`;
			ctx.drawImage(img, drawX, drawY, renderW, renderH);
			// Local Soft Airbrush Pass
			if (secSmooth > 0) {
				ctx.save();
				ctx.globalCompositeOperation = "soft-light";
				ctx.globalAlpha = Math.min(.65, secSmooth * .015);
				ctx.filter = `blur(${Math.max(2, secSmooth / 7)}px) brightness(120%)`;
				ctx.drawImage(img, drawX, drawY, renderW, renderH);
				ctx.restore();
			}
			// Local Warmth
			if (secWarmth !== 0 && !isGrayscale) {
				ctx.save();
				ctx.globalCompositeOperation = "color";
				ctx.fillStyle = secWarmth > 0 ? `rgba(255, 175, 75, ${Math.min(.45, secWarmth / 100 * .5)})` : `rgba(80, 165, 255, ${Math.min(.45, Math.abs(secWarmth) / 100 * .5)})`;
				ctx.fillRect(secX, secY, secW, secH);
				ctx.restore();
			}
			ctx.restore();
			// Draw Animated Cyan Selection Marquee
			ctx.save();
			ctx.strokeStyle = "#06b6d4";
			ctx.lineWidth = 2.5;
			ctx.setLineDash([8, 6]);
			ctx.strokeRect(secX, secY, secW, secH);
			// Corner handles
			const handleSize = 8;
			ctx.fillStyle = "#ffffff";
			ctx.strokeStyle = "#0891b2";
			ctx.lineWidth = 1.5;
			ctx.setLineDash([]);
			[
				[secX, secY],
				[secX + secW, secY],
				[secX, secY + secH],
				[secX + secW, secY + secH]
			].forEach(([hx, hy]) => {
				ctx.fillRect(hx - handleSize / 2, hy - handleSize / 2, handleSize, handleSize);
				ctx.strokeRect(hx - handleSize / 2, hy - handleSize / 2, handleSize, handleSize);
			});
			// Section Badge
			ctx.fillStyle = "rgba(6, 182, 212, 0.95)";
			ctx.fillRect(secX, Math.max(drawY, secY - 24), 170, 22);
			ctx.fillStyle = "#ffffff";
			ctx.font = "bold 12px sans-serif";
			ctx.fillText(`🎯 Section (${secBrightness > 0 ? "+" : ""}${secBrightness}B / ${secContrast > 0 ? "+" : ""}${secContrast}C)`, secX + 6, Math.max(drawY, secY - 24) + 16);
			ctx.restore();
		}
		ctx.restore();
		// -------------------------------------------------------------
		// OVERLAYS: Pen Tool Path / Crop Box
		// -------------------------------------------------------------
		// Pen Tool Path
		if (activeTool === "pen_tool" && penPoints.length > 0) {
			ctx.save();
			ctx.translate(canvas.width / 2 + canvasPan.x, canvas.height / 2 + canvasPan.y);
			ctx.scale(canvasZoom, canvasZoom);
			ctx.beginPath();
			const firstX = drawX + penPoints[0].x * renderW;
			const firstY = drawY + penPoints[0].y * renderH;
			ctx.moveTo(firstX, firstY);
			for (let i = 1; i < penPoints.length; i++) {
				const px = drawX + penPoints[i].x * renderW;
				const py = drawY + penPoints[i].y * renderH;
				ctx.lineTo(px, py);
			}
			if (isPathClosed) {
				ctx.closePath();
				ctx.fillStyle = "rgba(14, 165, 233, 0.25)";
				ctx.fill();
			}
			ctx.strokeStyle = isPathClosed ? "#10b981" : "#38bdf8";
			ctx.lineWidth = 2 / canvasZoom;
			ctx.setLineDash(isPathClosed ? [] : [4, 4]);
			ctx.stroke();
			// Points
			penPoints.forEach((pt, idx) => {
				const px = drawX + pt.x * renderW;
				const py = drawY + pt.y * renderH;
				const isFirst = idx === 0;
				ctx.beginPath();
				ctx.arc(px, py, (isFirst ? 7 : 5) / canvasZoom, 0, Math.PI * 2);
				ctx.fillStyle = isFirst ? isNearStartPoint ? "#22c55e" : "#eab308" : "#38bdf8";
				ctx.strokeStyle = "#0f172a";
				ctx.lineWidth = 2 / canvasZoom;
				ctx.fill();
				ctx.stroke();
			});
			ctx.restore();
		}
		// Crop Tool Box Overlay
		if (activeTool === "crop" && cropBox) {
			ctx.save();
			// Dim outer area
			ctx.fillStyle = "rgba(0, 0, 0, 0.6)";
			ctx.fillRect(0, 0, canvas.width, cropBox.y);
			ctx.fillRect(0, cropBox.y + cropBox.h, canvas.width, canvas.height - (cropBox.y + cropBox.h));
			ctx.fillRect(0, cropBox.y, cropBox.x, cropBox.h);
			ctx.fillRect(cropBox.x + cropBox.w, cropBox.y, canvas.width - (cropBox.x + cropBox.w), cropBox.h);
			// Crop border
			ctx.strokeStyle = "#38bdf8";
			ctx.lineWidth = 2;
			ctx.strokeRect(cropBox.x, cropBox.y, cropBox.w, cropBox.h);
			// Rule of thirds lines
			ctx.strokeStyle = "rgba(255, 255, 255, 0.3)";
			ctx.lineWidth = 1;
			ctx.beginPath();
			ctx.moveTo(cropBox.x + cropBox.w / 3, cropBox.y);
			ctx.lineTo(cropBox.x + cropBox.w / 3, cropBox.y + cropBox.h);
			ctx.moveTo(cropBox.x + cropBox.w * 2 / 3, cropBox.y);
			ctx.lineTo(cropBox.x + cropBox.w * 2 / 3, cropBox.y + cropBox.h);
			ctx.moveTo(cropBox.x, cropBox.y + cropBox.h / 3);
			ctx.lineTo(cropBox.x + cropBox.w, cropBox.y + cropBox.h / 3);
			ctx.moveTo(cropBox.x, cropBox.y + cropBox.h * 2 / 3);
			ctx.lineTo(cropBox.x + cropBox.w, cropBox.y + cropBox.h * 2 / 3);
			ctx.stroke();
			ctx.restore();
		}
	};
	// Convert Editor Canvas Click to Image Coordinates
	const canvasToImageCoords = (clientX, clientY) => {
		const canvas = editorCanvasRef.current;
		const img = photoImgRef.current;
		if (!canvas || !img) return null;
		const rect = canvas.getBoundingClientRect();
		const scaleX = canvas.width / rect.width;
		const scaleY = canvas.height / rect.height;
		const clickX = (clientX - rect.left) * scaleX;
		const clickY = (clientY - rect.top) * scaleY;
		// Reverse Pan & Zoom
		const localX = (clickX - (canvas.width / 2 + canvasPan.x)) / canvasZoom;
		const localY = (clickY - (canvas.height / 2 + canvasPan.y)) / canvasZoom;
		const aspect = img.width / img.height;
		let renderW = 460;
		let renderH = 460 / aspect;
		if (renderH > 560) {
			renderH = 560;
			renderW = 560 * aspect;
		}
		const drawX = -renderW / 2;
		const drawY = -renderH / 2;
		const normX = (localX - drawX) / renderW;
		const normY = (localY - drawY) / renderH;
		const imgX = normX * img.width;
		const imgY = normY * img.height;
		return {
			normX,
			normY,
			imgX,
			imgY,
			isInside: normX >= 0 && normX <= 1 && normY >= 0 && normY <= 1
		};
	};
	// Canvas Mouse Down
	const handleEditorMouseDown = (e) => {
		if (isSpacePressed || activeTool === "hand" || e.button === 1) {
			setIsPanning(true);
			setPanStart({
				x: e.clientX - canvasPan.x,
				y: e.clientY - canvasPan.y
			});
			return;
		}
		const coords = canvasToImageCoords(e.clientX, e.clientY);
		if (!coords || !coords.isInside) return;
		// Tool actions
		if (activeTool === "section_select") {
			setIsSelectingBox(true);
			setSelectionStartNorm({
				x: coords.normX,
				y: coords.normY
			});
			setSelectionBox({
				x: coords.normX,
				y: coords.normY,
				w: .01,
				h: .01
			});
			setGradingScope("selection");
		} else if (activeTool === "magic_wand") {
			executeMagicWandCut(coords.imgX, coords.imgY);
		} else if (activeTool === "pen_tool") {
			if (penPoints.length >= 3 && !isPathClosed) {
				const first = penPoints[0];
				const dist = Math.hypot(coords.normX - first.x, coords.normY - first.y);
				if (dist < .05) {
					setIsPathClosed(true);
					return;
				}
			}
			if (!isPathClosed) {
				setPenPoints((prev) => [...prev, {
					x: coords.normX,
					y: coords.normY
				}]);
			}
		} else if (activeTool === "blemish_brush") {
			applyHealingBrush(coords.imgX, coords.imgY, "blemish");
		} else if (activeTool === "beauty_brush") {
			applyHealingBrush(coords.imgX, coords.imgY, "beauty");
		} else if (activeTool === "eye_brighten") {
			applyHealingBrush(coords.imgX, coords.imgY, "eye");
		} else if (activeTool === "zoom") {
			if (e.altKey) {
				setCanvasZoom((prev) => Math.max(.4, prev - .3));
			} else {
				setCanvasZoom((prev) => Math.min(4, prev + .3));
			}
		}
	};
	// Canvas Mouse Move
	const handleEditorMouseMove = (e) => {
		if (isPanning) {
			setCanvasPan({
				x: e.clientX - panStart.x,
				y: e.clientY - panStart.y
			});
			return;
		}
		if (isSelectingBox && selectionStartNorm && activeTool === "section_select") {
			const coords = canvasToImageCoords(e.clientX, e.clientY);
			if (coords) {
				const curX = Math.max(0, Math.min(1, coords.normX));
				const curY = Math.max(0, Math.min(1, coords.normY));
				const boxX = Math.min(selectionStartNorm.x, curX);
				const boxY = Math.min(selectionStartNorm.y, curY);
				const boxW = Math.max(.01, Math.abs(curX - selectionStartNorm.x));
				const boxH = Math.max(.01, Math.abs(curY - selectionStartNorm.y));
				setSelectionBox({
					x: boxX,
					y: boxY,
					w: boxW,
					h: boxH
				});
			}
			return;
		}
		if (activeTool === "pen_tool" && penPoints.length >= 3 && !isPathClosed) {
			const coords = canvasToImageCoords(e.clientX, e.clientY);
			if (coords) {
				const first = penPoints[0];
				const dist = Math.hypot(coords.normX - first.x, coords.normY - first.y);
				setIsNearStartPoint(dist < .05);
			}
		}
	};
	// Canvas Mouse Up
	const handleEditorMouseUp = () => {
		setIsPanning(false);
		setIsSelectingBox(false);
		setSelectionStartNorm(null);
	};
	// Canvas Mouse Wheel (Centered Zoom)
	const handleEditorWheel = (e) => {
		e.preventDefault();
		const zoomFactor = e.deltaY < 0 ? 1.15 : .88;
		setCanvasZoom((prev) => Math.max(.4, Math.min(4, prev * zoomFactor)));
	};
	// -------------------------------------------------------------
	// MINI PREVIEW CANVAS RENDER ("preview mini dikhna chaiye")
	// -------------------------------------------------------------
	const renderMiniPreview = () => {
		const canvas = miniPreviewCanvasRef.current;
		const img = photoImgRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		canvas.width = 240;
		canvas.height = 160;
		// Pure white photo paper
		ctx.fillStyle = "#ffffff";
		ctx.fillRect(0, 0, canvas.width, canvas.height);
		if (!img) {
			ctx.fillStyle = "#94a3b8";
			ctx.font = "10px sans-serif";
			ctx.textAlign = "center";
			ctx.fillText("Mini Sheet Preview", canvas.width / 2, canvas.height / 2);
			return;
		}
		// Draw miniature grid (4x6 landscape 8 copies or A4)
		const isA4 = paperFormat.startsWith("a4");
		const cols = paperFormat === "4x6_landscape" ? 4 : isA4 ? copies === 32 ? 8 : 4 : 2;
		const rows = paperFormat === "4x6_landscape" ? 2 : isA4 ? 4 : 4;
		const gap = 4;
		const margin = 8;
		const cellW = (canvas.width - margin * 2 - (cols - 1) * gap) / cols;
		const cellH = cellW * (45 / 35);
		let count = 0;
		for (let r = 0; r < rows; r++) {
			for (let c = 0; c < cols; c++) {
				if (count >= copies) break;
				const x = margin + c * (cellW + gap);
				const y = margin + r * (cellH + gap);
				// Fill background
				ctx.fillStyle = bgColor;
				ctx.fillRect(x, y, cellW, cellH);
				// Draw photo
				ctx.drawImage(img, x, y, cellW, cellH);
				// Cut mark
				ctx.strokeStyle = "#94a3b8";
				ctx.lineWidth = .5;
				ctx.strokeRect(x, y, cellW, cellH);
				count++;
			}
		}
	};
	// -------------------------------------------------------------
	// FULL SHEET 300 DPI RENDER (For Direct Printing & PDF / JPG Export)
	// -------------------------------------------------------------
	const renderFullSheet = () => {
		const canvas = fullSheetCanvasRef.current;
		const img = photoImgRef.current;
		if (!canvas || !img) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		canvas.width = SHEET_WIDTH;
		canvas.height = SHEET_HEIGHT;
		ctx.fillStyle = "#ffffff";
		ctx.fillRect(0, 0, SHEET_WIDTH, SHEET_HEIGHT);
		// Single photo canvas at 300 DPI
		const singleW = 350;
		const singleH = 450;
		const singleCanvas = document.createElement("canvas");
		singleCanvas.width = singleW;
		singleCanvas.height = singleH;
		const sCtx = singleCanvas.getContext("2d");
		if (sCtx) {
			sCtx.fillStyle = bgColor;
			sCtx.fillRect(0, 0, singleW, singleH);
			// Color filters
			const effBrightness = 100 + brightness + (autoBeauty ? 6 : 0) + faceGlow * .12;
			const effContrast = 100 + contrast + (autoBeauty ? 4 : 0);
			const effSaturation = isGrayscale ? 0 : 100 + saturation + (autoBeauty ? 8 : 0);
			let filterStr = `brightness(${effBrightness}%) contrast(${effContrast}%) saturate(${effSaturation}%)`;
			if (isGrayscale) filterStr += " grayscale(100%)";
			sCtx.filter = filterStr;
			const aspect = img.width / img.height;
			let dw = singleW;
			let dh = singleH;
			if (aspect > singleW / singleH) {
				dw = singleH * aspect;
			} else {
				dh = singleW / aspect;
			}
			sCtx.drawImage(img, (singleW - dw) / 2, (singleH - dh) / 2, dw, dh);
			// Local Section Color Grading pass on print sheet
			if (selectionBox && selectionBox.w > .005 && selectionBox.h > .005) {
				const secX = (singleW - dw) / 2 + selectionBox.x * dw;
				const secY = (singleH - dh) / 2 + selectionBox.y * dh;
				const secW = selectionBox.w * dw;
				const secH = selectionBox.h * dh;
				sCtx.save();
				sCtx.beginPath();
				sCtx.rect(secX, secY, secW, secH);
				sCtx.clip();
				const secEffBright = effBrightness + secBrightness;
				const secEffCont = effContrast + secContrast;
				const secEffSat = isGrayscale ? 0 : effSaturation + secSaturation;
				sCtx.filter = `brightness(${secEffBright}%) contrast(${secEffCont}%) saturate(${secEffSat}%)`;
				sCtx.drawImage(img, (singleW - dw) / 2, (singleH - dh) / 2, dw, dh);
				if (secWarmth !== 0 && !isGrayscale) {
					sCtx.globalCompositeOperation = "color";
					sCtx.fillStyle = secWarmth > 0 ? `rgba(255, 175, 75, ${Math.min(.45, secWarmth / 100 * .5)})` : `rgba(80, 165, 255, ${Math.min(.45, Math.abs(secWarmth) / 100 * .5)})`;
					sCtx.fillRect(secX, secY, secW, secH);
				}
				sCtx.restore();
			}
			// Soft light beauty pass
			const effSmooth = autoBeauty ? Math.max(skinSmooth, 16) : skinSmooth;
			const effGlow = autoBeauty ? Math.max(faceGlow, 20) : faceGlow;
			if (effSmooth > 0 || effGlow > 0) {
				sCtx.save();
				sCtx.globalCompositeOperation = "soft-light";
				sCtx.globalAlpha = Math.min(.65, effSmooth * .012 + effGlow * .01);
				sCtx.filter = `blur(${Math.max(2, effSmooth / 8)}px) brightness(120%)`;
				sCtx.drawImage(img, (singleW - dw) / 2, (singleH - dh) / 2, dw, dh);
				sCtx.restore();
			}
			// Candidate Name & Date Strip
			if (showNameDate) {
				const boxH = 58;
				sCtx.fillStyle = "#ffffff";
				sCtx.fillRect(0, singleH - boxH, singleW, boxH);
				sCtx.fillStyle = "#000000";
				sCtx.font = "bold 17px sans-serif";
				sCtx.textAlign = "center";
				sCtx.fillText(candidateName.toUpperCase(), singleW / 2, singleH - boxH + 22);
				sCtx.font = "bold 14px sans-serif";
				sCtx.fillText(`DATE: ${photoDate}`, singleW / 2, singleH - boxH + 45);
				sCtx.strokeStyle = "#000000";
				sCtx.lineWidth = 2;
				sCtx.beginPath();
				sCtx.moveTo(0, singleH - boxH);
				sCtx.lineTo(singleW, singleH - boxH);
				sCtx.stroke();
			}
			sCtx.strokeStyle = "#334155";
			sCtx.lineWidth = 2;
			sCtx.strokeRect(0, 0, singleW, singleH);
		}
		// Grid placement
		const cols = paperFormat === "4x6_landscape" ? 4 : paperFormat === "a4_landscape" ? copies === 32 ? 8 : 4 : 2;
		const rows = paperFormat === "4x6_landscape" ? 2 : 4;
		const isA4 = paperFormat.startsWith("a4");
		const marginX = isA4 ? 90 : 60;
		const marginY = isA4 ? 80 : 50;
		const availableW = SHEET_WIDTH - marginX * 2;
		const availableH = SHEET_HEIGHT - marginY * 2;
		const gap = isA4 ? 20 : 16;
		const targetW = (availableW - (cols - 1) * gap) / cols;
		let drawW = targetW;
		let drawH = targetW * (45 / 35);
		if (rows * drawH + (rows - 1) * gap > availableH) {
			drawH = (availableH - (rows - 1) * gap) / rows;
			drawW = drawH * (35 / 45);
		}
		const gapX = cols > 1 ? (availableW - cols * drawW) / (cols - 1) : 0;
		const gapY = rows > 1 ? (availableH - rows * drawH) / (rows - 1) : 0;
		let count = 0;
		for (let r = 0; r < rows; r++) {
			for (let c = 0; c < cols; c++) {
				if (count >= copies) break;
				const x = marginX + c * (drawW + gapX);
				const y = marginY + r * (drawH + gapY);
				ctx.drawImage(singleCanvas, x, y, drawW, drawH);
				ctx.strokeStyle = "#64748b";
				ctx.lineWidth = 1;
				ctx.strokeRect(x, y, drawW, drawH);
				count++;
			}
		}
		// Center cutting line
		ctx.save();
		ctx.strokeStyle = "#94a3b8";
		ctx.lineWidth = 1.5;
		ctx.setLineDash([6, 6]);
		ctx.beginPath();
		ctx.moveTo(30, SHEET_HEIGHT / 2);
		ctx.lineTo(SHEET_WIDTH - 30, SHEET_HEIGHT / 2);
		ctx.stroke();
		ctx.restore();
	};
	// Upload handler
	const handleUpload = (e) => {
		const file = e.target.files?.[0];
		if (!file) return;
		const reader = new FileReader();
		reader.onload = (event) => {
			const src = event.target?.result;
			setPhotoSrc(src);
			setOriginalPhotoSrc(src);
			setHistoryStack([src]);
			setHistoryIndex(0);
			setCanvasZoom(1);
			setCanvasPan({
				x: 0,
				y: 0
			});
			setPenPoints([]);
			setIsPathClosed(false);
			setAutoBeauty(true);
			setActivePreset("auto_beauty");
		};
		reader.readAsDataURL(file);
		e.target.value = "";
	};
	// Direct In-App Print
	const handleDirectPrint = () => {
		const canvas = fullSheetCanvasRef.current;
		if (!canvas) return;
		try {
			const dataUrl = canvas.toDataURL("image/jpeg", 1);
			printImageSheet(dataUrl, {
				paperFormat,
				title: `Passport_${paperFormat}_${copies}Copies`,
				copiesCount: copies
			});
			setPrintAlert(`🖨️ Print command sent to printer! (${paperFormat.replace("_", " ").toUpperCase()} • ${copies} Copies)`);
			setTimeout(() => setPrintAlert(null), 4e3);
		} catch (e) {
			console.error(e);
			window.print();
		}
	};
	// Download PDF
	const handleDownloadSheetPDF = () => {
		const canvas = fullSheetCanvasRef.current;
		if (!canvas) return;
		try {
			const dataUrl = canvas.toDataURL("image/jpeg", .98);
			const isLandscape = paperFormat.includes("landscape");
			const isA4 = paperFormat.startsWith("a4");
			const pdf = new jsPDF({
				orientation: isLandscape ? "landscape" : "portrait",
				unit: isA4 ? "mm" : "in",
				format: isA4 ? "a4" : [4, 6]
			});
			if (isA4) {
				pdf.addImage(dataUrl, "JPEG", 0, 0, isLandscape ? 297 : 210, isLandscape ? 210 : 297);
			} else {
				pdf.addImage(dataUrl, "JPEG", 0, 0, isLandscape ? 6 : 4, isLandscape ? 4 : 6);
			}
			const fileName = `Passport_${paperFormat}_${copies}_Copies_${Date.now()}.pdf`;
			pdf.save(fileName);
			addDownloadRecord({
				id: `pass-pdf-${Date.now()}`,
				title: fileName,
				type: "Passport Sheet PDF",
				size: `${paperFormat.replace("_", " ")} (${copies} Copies)`,
				timestamp: new Date().toLocaleTimeString("en-IN")
			});
		} catch (e) {
			console.error(e);
		}
	};
	// Download HD JPG
	const handleDownloadSheetJPG = () => {
		const canvas = fullSheetCanvasRef.current;
		if (!canvas) return;
		try {
			const dataUrl = canvas.toDataURL("image/jpeg", .98);
			const a = document.createElement("a");
			a.href = dataUrl;
			const fileName = `Passport_${paperFormat}_${copies}_Copies_300DPI_${Date.now()}.jpg`;
			a.download = fileName;
			a.click();
			addDownloadRecord({
				id: `pass-jpg-${Date.now()}`,
				title: fileName,
				type: "Passport Sheet JPG",
				size: `${paperFormat.replace("_", " ")} (${copies} Copies 300 DPI)`,
				timestamp: new Date().toLocaleTimeString("en-IN")
			});
		} catch (e) {
			console.error(e);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-3 select-none",
		children: [
			/* @__PURE__ */ _jsxDEV("canvas", {
				ref: fullSheetCanvasRef,
				className: "hidden"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 1732,
				columnNumber: 7
			}, this),
			printAlert && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center justify-between animate-in fade-in",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-400 flex-shrink-0" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1738,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: printAlert }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1739,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1737,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setPrintAlert(null),
					className: "text-emerald-400 hover:text-white",
					children: "✕"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1741,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1736,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl px-4 py-2.5 flex items-center justify-between gap-3 shadow-md flex-wrap text-xs",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-3 flex-wrap",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 pr-3 border-r border-slate-800",
							children: /* @__PURE__ */ _jsxDEV("span", {
								className: "font-extrabold text-white text-sm flex items-center gap-1.5",
								children: [
									activeTool === "select" && /* @__PURE__ */ _jsxDEV("span", { children: "↖️ Pointer (V)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1751,
										columnNumber: 43
									}, this),
									activeTool === "section_select" && /* @__PURE__ */ _jsxDEV("span", { children: "🔲 Section Select & Color Grading (Q)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1752,
										columnNumber: 51
									}, this),
									activeTool === "magic_wand" && /* @__PURE__ */ _jsxDEV("span", { children: "🪄 Magic Wand Cut (W)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1753,
										columnNumber: 47
									}, this),
									activeTool === "pen_tool" && /* @__PURE__ */ _jsxDEV("span", { children: "🖊️ Pen Tool (P)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1754,
										columnNumber: 45
									}, this),
									activeTool === "crop" && /* @__PURE__ */ _jsxDEV("span", { children: "✂️ Passport Crop (C)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1755,
										columnNumber: 41
									}, this),
									activeTool === "blemish_brush" && /* @__PURE__ */ _jsxDEV("span", { children: "🩹 Spot Healing (B)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1756,
										columnNumber: 50
									}, this),
									activeTool === "beauty_brush" && /* @__PURE__ */ _jsxDEV("span", { children: "✨ Beauty Airbrush (S)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1757,
										columnNumber: 49
									}, this),
									activeTool === "eye_brighten" && /* @__PURE__ */ _jsxDEV("span", { children: "👁️ Eye/Teeth Brighten (E)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1758,
										columnNumber: 49
									}, this),
									activeTool === "hand" && /* @__PURE__ */ _jsxDEV("span", { children: "✋ Hand Pan (H)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1759,
										columnNumber: 41
									}, this),
									activeTool === "zoom" && /* @__PURE__ */ _jsxDEV("span", { children: "🔍 Zoom (Z)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1760,
										columnNumber: 41
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1750,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1749,
							columnNumber: 11
						}, this),
						activeTool === "section_select" && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1.5 animate-in fade-in flex-wrap",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400 font-semibold text-[11px]",
									children: "Presets:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1767,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => handleSelectPreset("face"),
									className: "px-2 py-0.5 rounded-md bg-slate-950 hover:bg-slate-800 text-slate-200 border border-slate-700 font-bold text-[11px]",
									children: "👤 Face"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1768,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => handleSelectPreset("clothes"),
									className: "px-2 py-0.5 rounded-md bg-slate-950 hover:bg-slate-800 text-slate-200 border border-slate-700 font-bold text-[11px]",
									children: "👔 Clothes"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1775,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => handleSelectPreset("eyes"),
									className: "px-2 py-0.5 rounded-md bg-slate-950 hover:bg-slate-800 text-slate-200 border border-slate-700 font-bold text-[11px]",
									children: "👁️ Eyes"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1782,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => handleSelectPreset("full"),
									className: "px-2 py-0.5 rounded-md bg-slate-950 hover:bg-slate-800 text-slate-200 border border-slate-700 font-bold text-[11px]",
									children: "🔲 Full"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1789,
									columnNumber: 15
								}, this),
								selectionBox && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: handleInvertSelection,
										className: "px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 font-bold hover:text-white text-[11px]",
										title: "Invert Selection",
										children: "🔄 Invert"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1799,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: handleBakeSectionAdjustment,
										className: "flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[11px] shadow",
										title: "Bake local adjustments into photo",
										children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1813,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Bake Section" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 1814,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 1807,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: handleClearSelection,
										className: "px-2 py-0.5 rounded-md bg-slate-800 text-rose-300 hover:text-rose-200 font-bold text-[11px]",
										children: "Clear"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1816,
										columnNumber: 19
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1798,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1766,
							columnNumber: 13
						}, this),
						activeTool === "magic_wand" && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 animate-in fade-in",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400",
									children: "Tolerance:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1831,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "range",
									min: "10",
									max: "65",
									value: magicTolerance,
									onChange: (e) => setMagicTolerance(Number(e.target.value)),
									className: "w-20 accent-sky-400 cursor-pointer",
									title: "Color similarity distance (10-65)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1832,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-mono text-white font-bold",
									children: magicTolerance
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1841,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: handleAutoBackgroundErase,
									disabled: isProcessing || !photoSrc,
									className: "ml-2 flex items-center gap-1 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold px-3 py-1 rounded-lg shadow-sm",
									title: "1-Click Auto Erases borders inwards",
									children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1849,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "1-Click Auto Cut" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1850,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1843,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1830,
							columnNumber: 13
						}, this),
						activeTool === "pen_tool" && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 animate-in fade-in",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400 font-mono text-[11px]",
									children: [
										penPoints.length,
										" Points ",
										isPathClosed ? "• Path Closed" : ""
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1858,
									columnNumber: 15
								}, this),
								!isPathClosed && penPoints.length >= 3 && /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setIsPathClosed(true),
									className: "px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg",
									children: "Close Path"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1863,
									columnNumber: 17
								}, this),
								penPoints.length >= 3 && /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleApplyPenCutout,
									className: "flex items-center gap-1 px-3 py-1 bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold rounded-lg shadow-md",
									children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1876,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Apply Cutout" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 1877,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1872,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										setPenPoints([]);
										setIsPathClosed(false);
									},
									className: "px-2 py-1 bg-slate-800 text-rose-300 font-bold rounded-lg hover:bg-rose-900/30",
									children: "Clear"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1881,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1857,
							columnNumber: 13
						}, this),
						activeTool === "crop" && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 animate-in fade-in",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "bg-sky-500/20 text-sky-300 px-2 py-0.5 rounded font-mono font-bold",
									children: "Ratio: 35×45mm Standard"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1893,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: handleApplyCrop,
									className: "px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg shadow",
									children: "Apply Crop"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1896,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										setCropBox(null);
										setActiveTool("select");
									},
									className: "px-2 py-1 bg-slate-800 text-slate-300 font-bold rounded-lg",
									children: "Cancel"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1902,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1892,
							columnNumber: 13
						}, this),
						(activeTool === "blemish_brush" || activeTool === "beauty_brush" || activeTool === "eye_brighten") && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-2 animate-in fade-in",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400",
									children: "Brush Size:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1914,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "range",
									min: "8",
									max: "70",
									value: brushSize,
									onChange: (e) => setBrushSize(Number(e.target.value)),
									className: "w-20 accent-amber-400 cursor-pointer"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1915,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-mono text-white font-bold",
									children: [brushSize, "px"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 1923,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-500 text-[10px]",
									children: "Use [ and ] to resize"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1924,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1913,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: handleAutoBackgroundErase,
							disabled: isProcessing || !photoSrc,
							className: "flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-500 hover:from-purple-500 hover:to-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-md shadow-purple-600/30 transition-all hover:scale-105 active:scale-95 disabled:opacity-40",
							title: "1-Click Automatic Background Remove / Replace with selected studio color",
							children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3.5 h-3.5 text-amber-300" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1936,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "⚡ 1-Click Remove BG" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1937,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1929,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1.5 pl-3 border-l border-slate-800",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400",
								children: "BG:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1942,
								columnNumber: 13
							}, this), [
								{
									name: "White",
									color: "#ffffff"
								},
								{
									name: "Sky Blue",
									color: "#cce3f8"
								},
								{
									name: "Studio Blue",
									color: "#2563eb"
								},
								{
									name: "Grey",
									color: "#e2e8f0"
								},
								{
									name: "Red",
									color: "#dc2626"
								},
								{
									name: "Transparent Cutout",
									color: "transparent"
								}
							].map((c) => /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setBgColor(c.color),
								className: `w-5 h-5 rounded-full border shadow-sm transition-transform ${bgColor === c.color ? "scale-125 ring-2 ring-sky-400 border-white" : "border-slate-500 hover:scale-110"} ${c.color === "transparent" ? "bg-[linear-gradient(45deg,#ccc_25%,transparent_25%),linear-gradient(-45deg,#ccc_25%,transparent_25%),linear-gradient(45deg,transparent_75%,#ccc_75%),linear-gradient(-45deg,transparent_75%,#ccc_75%)] bg-[size:6px_6px] bg-white" : ""}`,
								style: c.color !== "transparent" ? { backgroundColor: c.color } : {},
								title: `Change studio background to ${c.name}`
							}, c.name, false, {
								fileName: _jsxFileName,
								lineNumber: 1951,
								columnNumber: 15
							}, this))]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1941,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1748,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center bg-slate-950 border border-slate-800 rounded-lg p-0.5",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: handleUndo,
								disabled: historyIndex <= 0 && penPoints.length === 0,
								className: "p-1.5 text-slate-300 hover:text-white disabled:opacity-30 disabled:hover:text-slate-300",
								title: "Undo (Ctrl + Z)",
								children: /* @__PURE__ */ _jsxDEV(Undo2, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1974,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1968,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: handleRedo,
								disabled: historyIndex >= historyStack.length - 1,
								className: "p-1.5 text-slate-300 hover:text-white disabled:opacity-30 disabled:hover:text-slate-300",
								title: "Redo (Ctrl + Y)",
								children: /* @__PURE__ */ _jsxDEV(Redo2, { className: "w-3.5 h-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 1982,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1976,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1967,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setShowMiniPreview((prev) => !prev),
							className: `flex items-center gap-1 px-2.5 py-1.5 rounded-lg border font-bold text-xs transition-colors ${showMiniPreview ? "bg-sky-600/20 text-sky-300 border-sky-500/40" : "bg-slate-800 text-slate-400 border-slate-700"}`,
							title: "Toggle Mini Sheet Preview (M)",
							children: [/* @__PURE__ */ _jsxDEV(Layers, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1994,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Mini Preview (M)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1995,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1987,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleDirectPrint,
							className: "flex items-center gap-1.5 bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold px-3.5 py-1.5 rounded-xl shadow-lg shadow-blue-600/30 transition-all hover:scale-105",
							title: "Direct Print Sheet (Ctrl + P)",
							children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5 text-white" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2004,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "🖨️ Print Sheet (Ctrl+P)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2005,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1999,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1965,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 1746,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 lg:grid-cols-12 gap-3 items-start min-h-[640px]",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "lg:col-span-1 bg-slate-900 border border-slate-800 rounded-2xl p-2 flex lg:flex-col items-center justify-center gap-2 shadow-lg",
						children: [
							[
								{
									id: "select",
									label: "Pointer / Move (V)",
									icon: "↖️"
								},
								{
									id: "section_select",
									label: "Section Selection Tool (Q)",
									icon: "🔲"
								},
								{
									id: "auto_bg",
									label: "1-Click Auto Remove BG (R)",
									icon: "⚡"
								},
								{
									id: "crop",
									label: "Passport Crop (C)",
									icon: "✂️"
								},
								{
									id: "magic_wand",
									label: "Magic Wand / Cut (W)",
									icon: "🪄"
								},
								{
									id: "pen_tool",
									label: "Pen Tool Cutout (P)",
									icon: "🖊️"
								},
								{
									id: "blemish_brush",
									label: "Spot Healing Brush (B)",
									icon: "🩹"
								},
								{
									id: "beauty_brush",
									label: "Skin Airbrush (S)",
									icon: "✨"
								},
								{
									id: "eye_brighten",
									label: "Eye/Teeth Whitener (E)",
									icon: "👁️"
								},
								{
									id: "hand",
									label: "Hand Tool Pan (H / Space)",
									icon: "✋"
								},
								{
									id: "zoom",
									label: "Zoom Tool (Z)",
									icon: "🔍"
								}
							].map((t) => {
								const isActive = activeTool === t.id;
								return /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										if (t.id === "auto_bg") {
											handleAutoBackgroundErase();
											return;
										}
										setActiveTool(t.id);
										if (t.id === "crop") initCropBox();
										if (t.id === "section_select") {
											setGradingScope("selection");
											if (!selectionBox) handleSelectPreset("face");
										}
									},
									className: `w-10 h-10 rounded-xl flex items-center justify-center text-lg transition-all ${isActive ? "bg-blue-600 text-white shadow-lg shadow-blue-600/40 ring-2 ring-blue-400 scale-105" : "bg-slate-950 text-slate-300 hover:bg-slate-800 border border-slate-800/80 hover:text-white"}`,
									title: t.label,
									children: /* @__PURE__ */ _jsxDEV("span", { children: t.icon }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2051,
										columnNumber: 17
									}, this)
								}, t.id, false, {
									fileName: _jsxFileName,
									lineNumber: 2030,
									columnNumber: 15
								}, this);
							}),
							/* @__PURE__ */ _jsxDEV("div", { className: "w-8 border-t border-slate-800 my-1 hidden lg:block" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2056,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								className: "w-10 h-10 rounded-xl bg-purple-600/20 border border-purple-500/40 text-purple-300 hover:bg-purple-600/30 flex items-center justify-center cursor-pointer transition-colors",
								title: "Upload Customer Photo",
								children: [/* @__PURE__ */ _jsxDEV(Upload, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2060,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "file",
									accept: "image/*",
									onChange: handleUpload,
									className: "hidden"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2061,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2059,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 2013,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: `${showMiniPreview ? "lg:col-span-8" : "lg:col-span-11"} relative bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col justify-between min-h-[640px]`,
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "absolute top-3 left-3 z-10 flex items-center gap-2 bg-slate-900/85 backdrop-blur-sm border border-slate-800 px-3 py-1.5 rounded-xl text-[11px] text-slate-300 pointer-events-none",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-white",
										children: "Photoshop Studio Canvas"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2069,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "•" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2070,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "font-mono text-sky-400 font-bold",
										children: [Math.round(canvasZoom * 100), "%"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2071,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "•" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2072,
										columnNumber: 13
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: "Hold Spacebar + Drag to Pan • Wheel to Zoom" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2073,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2068,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex-1 flex items-center justify-center p-2 overflow-hidden",
								children: /* @__PURE__ */ _jsxDEV("canvas", {
									ref: editorCanvasRef,
									onMouseDown: handleEditorMouseDown,
									onMouseMove: handleEditorMouseMove,
									onMouseUp: handleEditorMouseUp,
									onMouseLeave: handleEditorMouseUp,
									onWheel: handleEditorWheel,
									className: `max-w-full max-h-[580px] w-auto h-auto rounded-lg shadow-2xl ${isSpacePressed || activeTool === "hand" ? "cursor-grab active:cursor-grabbing" : activeTool === "magic_wand" || activeTool === "pen_tool" ? "cursor-crosshair" : activeTool === "blemish_brush" || activeTool === "beauty_brush" || activeTool === "eye_brighten" ? "cursor-cell" : "cursor-default"}`
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2078,
									columnNumber: 13
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 2077,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-900/80 border-t border-slate-800/80 px-4 py-2 flex items-center justify-between text-xs text-slate-400 flex-wrap gap-2",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: ["Tool: ", /* @__PURE__ */ _jsxDEV("strong", {
										className: "text-white uppercase",
										children: activeTool.replace("_", " ")
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2100,
										columnNumber: 27
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2100,
										columnNumber: 15
									}, this), photoSrc && /* @__PURE__ */ _jsxDEV("span", {
										className: "text-emerald-400 flex items-center gap-1 font-semibold",
										children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2103,
											columnNumber: 19
										}, this), " High-Resolution Photo Ready"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2102,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2099,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => {
												setCanvasZoom(1);
												setCanvasPan({
													x: 0,
													y: 0
												});
											},
											className: "px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] font-mono",
											children: "Fit Screen (Ctrl+0)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2109,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setCanvasZoom((prev) => Math.min(4, prev + .25)),
											className: "px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] font-mono",
											children: "+"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2115,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setCanvasZoom((prev) => Math.max(.4, prev - .25)),
											className: "px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] font-mono",
											children: "-"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2121,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2108,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2098,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 2066,
						columnNumber: 9
					}, this),
					showMiniPreview && /* @__PURE__ */ _jsxDEV("div", {
						className: "lg:col-span-3 space-y-3",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-900 border border-slate-800 rounded-2xl p-3 shadow-xl space-y-2.5",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between pb-1.5 border-b border-slate-800",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "font-extrabold text-white text-xs",
												children: "Mini Sheet Preview"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2138,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] font-mono bg-blue-500/20 text-blue-300 px-1.5 py-0.5 rounded font-bold",
												children: paperFormat === "4x6_landscape" ? "4×6 (8)" : "A4"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2139,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2137,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setShowMiniPreview(false),
											className: "p-1 text-slate-500 hover:text-white rounded",
											title: "Hide Mini Preview (M)",
											children: /* @__PURE__ */ _jsxDEV(Minimize2, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2148,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2143,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2136,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "relative flex justify-center bg-slate-950 p-2 rounded-xl border border-slate-800 overflow-hidden shadow-inner",
										children: /* @__PURE__ */ _jsxDEV("canvas", {
											ref: miniPreviewCanvasRef,
											width: 240,
											height: 160,
											className: "w-full h-auto bg-white rounded shadow-md border border-slate-700 pointer-events-none"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2154,
											columnNumber: 17
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2153,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => {
												setPaperFormat("4x6_landscape");
												setCopies(8);
											},
											className: `py-1.5 px-2 rounded-lg text-xs font-bold transition-all text-center ${paperFormat === "4x6_landscape" ? "bg-blue-600 text-white shadow" : "bg-slate-950 text-slate-400 hover:text-white"}`,
											children: "4×6 (8 Copies)"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2164,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => {
												setPaperFormat("a4_landscape");
												setCopies(32);
											},
											className: `py-1.5 px-2 rounded-lg text-xs font-bold transition-all text-center ${paperFormat === "a4_landscape" ? "bg-purple-600 text-white shadow" : "bg-slate-950 text-slate-400 hover:text-white"}`,
											children: "A4 Landscape"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2174,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2163,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: handleDirectPrint,
										className: "w-full flex items-center justify-center gap-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-extrabold text-xs py-2 rounded-xl shadow-md transition-all active:scale-95",
										children: [/* @__PURE__ */ _jsxDEV(Printer, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2191,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "🖨️ Print Sheet Now" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2192,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2187,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2135,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-900 border border-slate-800 rounded-2xl p-3.5 shadow-md space-y-2.5",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3.5 h-3.5 text-amber-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2200,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Auto Beauty Presets" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2201,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2199,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-amber-400 font-bold bg-amber-500/10 px-1.5 py-0.5 rounded",
										children: "1-Click"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 2203,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 2198,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-1.5",
									children: BEAUTY_PRESETS.map((p) => {
										const isSelected = activePreset === p.id && autoBeauty;
										return /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => {
												setActivePreset(p.id);
												setBrightness(p.settings.brightness);
												setContrast(p.settings.contrast);
												setSaturation(p.settings.saturation);
												setWarmth(p.settings.warmth);
												setTint(p.settings.tint);
												setSkinSmooth(p.settings.skinSmooth);
												setFaceGlow(p.settings.faceGlow);
												setShadowLift(p.settings.shadowLift);
												setIsGrayscale(p.settings.isGrayscale);
												setAutoBeauty(true);
											},
											className: `p-2 rounded-xl text-left border transition-all ${isSelected ? "bg-amber-500/10 border-amber-500/60 text-white ring-1 ring-amber-500/30" : "bg-slate-950 border-slate-800/80 text-slate-300 hover:bg-slate-800"}`,
											children: /* @__PURE__ */ _jsxDEV("div", {
												className: "text-xs font-bold truncate flex items-center gap-1",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: p.icon }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2234,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "truncate",
													children: p.name
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2235,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2233,
												columnNumber: 23
											}, this)
										}, p.id, false, {
											fileName: _jsxFileName,
											lineNumber: 2212,
											columnNumber: 21
										}, this);
									})
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 2208,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2197,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-900 border border-slate-800 rounded-2xl p-3.5 shadow-md space-y-3 text-xs",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between pb-1 border-b border-slate-800",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-white uppercase tracking-wider flex items-center gap-1.5",
											children: [/* @__PURE__ */ _jsxDEV(Sliders, { className: "w-3.5 h-3.5 text-blue-400" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2247,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Color Grading & Skin" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2248,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2246,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => {
												if (gradingScope === "selection") {
													setSecBrightness(0);
													setSecContrast(0);
													setSecSaturation(0);
													setSecWarmth(0);
													setSecSmooth(0);
												} else {
													setBrightness(0);
													setContrast(0);
													setSaturation(0);
													setWarmth(0);
													setTint(0);
													setSkinSmooth(0);
													setFaceGlow(0);
													setIsGrayscale(false);
												}
											},
											className: "text-[10px] text-slate-400 hover:text-white",
											children: "Reset"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2250,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2245,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800 text-[11px]",
										children: [/* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => setGradingScope("full"),
											className: `py-1.5 px-2 rounded-lg font-bold flex items-center justify-center gap-1 transition-all ${gradingScope === "full" ? "bg-blue-600 text-white shadow" : "text-slate-400 hover:text-white"}`,
											children: /* @__PURE__ */ _jsxDEV("span", { children: "🌐 Whole Photo" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2286,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2277,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											onClick: () => {
												setGradingScope("selection");
												if (!selectionBox) handleSelectPreset("face");
												setActiveTool("section_select");
											},
											className: `py-1.5 px-2 rounded-lg font-bold flex items-center justify-center gap-1 transition-all ${gradingScope === "selection" ? "bg-gradient-to-r from-cyan-600 to-blue-600 text-white shadow shadow-cyan-600/30" : "text-slate-400 hover:text-white"}`,
											children: /* @__PURE__ */ _jsxDEV("span", { children: "🔲 Section Only" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2301,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 2288,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2276,
										columnNumber: 15
									}, this),
									gradingScope === "selection" ? /* @__PURE__ */ _jsxDEV(
										"div",
										/* SECTION COLOR GRADING CONTROLS */
										{
											className: "space-y-2.5 pt-1 animate-in fade-in",
											children: [
												/* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center justify-between text-[11px] bg-cyan-950/40 p-2 rounded-lg border border-cyan-500/30",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "font-extrabold text-cyan-300",
														children: "🎯 Section Preset & Box:"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2310,
														columnNumber: 21
													}, this), selectionBox ? /* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: handleClearSelection,
														className: "text-rose-400 hover:underline text-[10px] font-bold",
														children: "Clear"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2314,
														columnNumber: 23
													}, this) : /* @__PURE__ */ _jsxDEV("span", {
														className: "text-amber-400 text-[10px]",
														children: "Draw box on photo"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2322,
														columnNumber: 23
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2309,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "grid grid-cols-4 gap-1 text-[10px]",
													children: [
														/* @__PURE__ */ _jsxDEV("button", {
															type: "button",
															onClick: () => handleSelectPreset("face"),
															className: "p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-center",
															children: "👤 Face"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2328,
															columnNumber: 21
														}, this),
														/* @__PURE__ */ _jsxDEV("button", {
															type: "button",
															onClick: () => handleSelectPreset("clothes"),
															className: "p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-center",
															children: "👔 Clothes"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2335,
															columnNumber: 21
														}, this),
														/* @__PURE__ */ _jsxDEV("button", {
															type: "button",
															onClick: () => handleSelectPreset("eyes"),
															className: "p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-center",
															children: "👁️ Eyes"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2342,
															columnNumber: 21
														}, this),
														/* @__PURE__ */ _jsxDEV("button", {
															type: "button",
															onClick: () => handleSelectPreset("full"),
															className: "p-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-300 font-bold text-center",
															children: "🔲 Full"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2349,
															columnNumber: 21
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2327,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "flex justify-between text-slate-300 mb-0.5 font-semibold",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "text-amber-300 flex items-center gap-1",
														children: [/* @__PURE__ */ _jsxDEV(Sun, { className: "w-3.5 h-3.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2362,
															columnNumber: 25
														}, this), " Section Brightness"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2361,
														columnNumber: 23
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "font-mono text-white",
														children: [secBrightness > 0 ? `+${secBrightness}` : secBrightness, "%"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2364,
														columnNumber: 23
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2360,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "range",
													min: "-40",
													max: "40",
													value: secBrightness,
													onChange: (e) => setSecBrightness(Number(e.target.value)),
													className: "w-full accent-amber-500 cursor-pointer h-1.5 bg-slate-800 rounded"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2366,
													columnNumber: 21
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2359,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "flex justify-between text-slate-300 mb-0.5 font-semibold",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "text-sky-300 flex items-center gap-1",
														children: [/* @__PURE__ */ _jsxDEV(Contrast, { className: "w-3.5 h-3.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2380,
															columnNumber: 25
														}, this), " Section Contrast"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2379,
														columnNumber: 23
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "font-mono text-white",
														children: [secContrast > 0 ? `+${secContrast}` : secContrast, "%"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2382,
														columnNumber: 23
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2378,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "range",
													min: "-40",
													max: "40",
													value: secContrast,
													onChange: (e) => setSecContrast(Number(e.target.value)),
													className: "w-full accent-sky-500 cursor-pointer h-1.5 bg-slate-800 rounded"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2384,
													columnNumber: 21
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2377,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "flex justify-between text-slate-300 mb-0.5 font-semibold",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "text-orange-300 flex items-center gap-1",
														children: [/* @__PURE__ */ _jsxDEV(Flame, { className: "w-3.5 h-3.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2398,
															columnNumber: 25
														}, this), " Section Warmth / Tone"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2397,
														columnNumber: 23
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "font-mono text-white",
														children: secWarmth > 0 ? `+${secWarmth}` : secWarmth
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2400,
														columnNumber: 23
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2396,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "range",
													min: "-40",
													max: "40",
													value: secWarmth,
													onChange: (e) => setSecWarmth(Number(e.target.value)),
													className: "w-full accent-orange-500 cursor-pointer h-1.5 bg-slate-800 rounded"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2402,
													columnNumber: 21
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2395,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "flex justify-between text-slate-300 mb-0.5 font-semibold",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "text-pink-300 flex items-center gap-1",
														children: [/* @__PURE__ */ _jsxDEV(Droplets, { className: "w-3.5 h-3.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2416,
															columnNumber: 25
														}, this), " Section Saturation"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2415,
														columnNumber: 23
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "font-mono text-white",
														children: [secSaturation > 0 ? `+${secSaturation}` : secSaturation, "%"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2418,
														columnNumber: 23
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2414,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "range",
													min: "-40",
													max: "40",
													value: secSaturation,
													onChange: (e) => setSecSaturation(Number(e.target.value)),
													className: "w-full accent-pink-500 cursor-pointer h-1.5 bg-slate-800 rounded"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2420,
													columnNumber: 21
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2413,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "flex justify-between text-slate-300 mb-0.5 font-semibold",
													children: [/* @__PURE__ */ _jsxDEV("span", {
														className: "text-emerald-300 flex items-center gap-1",
														children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3.5 h-3.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2434,
															columnNumber: 25
														}, this), " Section Smoothness"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2433,
														columnNumber: 23
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "font-mono text-white",
														children: [secSmooth, "%"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2436,
														columnNumber: 23
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2432,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("input", {
													type: "range",
													min: "0",
													max: "40",
													value: secSmooth,
													onChange: (e) => setSecSmooth(Number(e.target.value)),
													className: "w-full accent-emerald-500 cursor-pointer h-1.5 bg-slate-800 rounded"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2438,
													columnNumber: 21
												}, this)] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2431,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ _jsxDEV("div", {
													className: "pt-1 flex items-center gap-1.5",
													children: [/* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: handleBakeSectionAdjustment,
														disabled: !selectionBox || isProcessing,
														className: "flex-1 py-1.5 px-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-[11px] rounded-xl shadow-md flex items-center justify-center gap-1 disabled:opacity-50",
														children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2456,
															columnNumber: 23
														}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Bake into Photo" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 2457,
															columnNumber: 23
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 2450,
														columnNumber: 21
													}, this), /* @__PURE__ */ _jsxDEV("button", {
														type: "button",
														onClick: handleInvertSelection,
														disabled: !selectionBox,
														className: "py-1.5 px-2 bg-slate-800 text-slate-300 hover:text-white font-bold text-[11px] rounded-xl border border-slate-700 disabled:opacity-50",
														title: "Invert Selection Box",
														children: "🔄 Invert"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 2459,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2449,
													columnNumber: 19
												}, this)
											]
										},
										void 0,
										true,
										{
											fileName: _jsxFileName,
											lineNumber: 2308,
											columnNumber: 17
										},
										this
									) : 
									/* WHOLE PHOTO COLOR GRADING CONTROLS */
									/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-2.5 animate-in fade-in",
										children: [
											/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between text-slate-400 mb-0.5",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-amber-300 font-semibold",
													children: "Skin Smoothing"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2476,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "font-mono text-white",
													children: [skinSmooth, "%"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2477,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2475,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "range",
												min: "0",
												max: "50",
												value: skinSmooth,
												onChange: (e) => setSkinSmooth(Number(e.target.value)),
												className: "w-full accent-amber-500 cursor-pointer h-1.5 bg-slate-800 rounded"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2479,
												columnNumber: 21
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2474,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between text-slate-400 mb-0.5",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Brightness" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2492,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "font-mono text-white",
													children: [brightness > 0 ? `+${brightness}` : brightness, "%"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2493,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2491,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "range",
												min: "-30",
												max: "30",
												value: brightness,
												onChange: (e) => setBrightness(Number(e.target.value)),
												className: "w-full accent-blue-500 cursor-pointer h-1.5 bg-slate-800 rounded"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2495,
												columnNumber: 21
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2490,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between text-slate-400 mb-0.5",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Contrast" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2508,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "font-mono text-white",
													children: [contrast > 0 ? `+${contrast}` : contrast, "%"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 2509,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2507,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "range",
												min: "-30",
												max: "30",
												value: contrast,
												onChange: (e) => setContrast(Number(e.target.value)),
												className: "w-full accent-blue-500 cursor-pointer h-1.5 bg-slate-800 rounded"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2511,
												columnNumber: 21
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2506,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between text-slate-400 mb-0.5",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Warmth / Tone" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2524,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "font-mono text-white",
													children: warmth > 0 ? `+${warmth}` : warmth
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 2525,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2523,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "range",
												min: "-30",
												max: "30",
												value: warmth,
												onChange: (e) => setWarmth(Number(e.target.value)),
												className: "w-full accent-orange-500 cursor-pointer h-1.5 bg-slate-800 rounded"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2527,
												columnNumber: 21
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 2522,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2472,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "pt-2 border-t border-slate-800",
										children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "flex items-center justify-between cursor-pointer",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "font-bold text-slate-300",
												children: "Exam Name & Date Strip"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2542,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "checkbox",
												checked: showNameDate,
												onChange: (e) => setShowNameDate(e.target.checked),
												className: "accent-blue-500 rounded"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2543,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2541,
											columnNumber: 17
										}, this), showNameDate && /* @__PURE__ */ _jsxDEV("div", {
											className: "mt-2 space-y-1.5",
											children: [/* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												placeholder: "Candidate Name",
												value: candidateName,
												onChange: (e) => setCandidateName(e.target.value),
												className: "w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-white text-[11px] font-bold"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2552,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("input", {
												type: "text",
												placeholder: "Date (DD/MM/YYYY)",
												value: photoDate,
												onChange: (e) => setPhotoDate(e.target.value),
												className: "w-full bg-slate-950 border border-slate-700 rounded px-2 py-1 text-white text-[11px] font-bold"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 2559,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 2551,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 2540,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 2244,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 2133,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 2011,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 1730,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsUUFBUSxpQkFBOEI7QUFDaEUsU0FDRSxRQUNBLFNBRUEsVUFNQSxLQUNBLFVBQ0EsY0FHQSxTQUNBLE9BQ0EsVUFFQSxPQUdBLE9BQ0EsT0FHQSxRQUlBLGlCQU1LO0FBQ1AsU0FBUyxhQUFhO0FBQ3RCLFNBQVMseUJBQXlCO0FBQ2xDLFNBQVMsdUJBQXVCOzs7QUE0QmhDLE1BQU0saUJBQWlDO0NBQ3JDO0VBQ0UsSUFBSTtFQUNKLE1BQU07RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFVBQVU7R0FDUixZQUFZO0dBQ1osVUFBVTtHQUNWLFlBQVk7R0FDWixRQUFRO0dBQ1IsTUFBTTtHQUNOLFlBQVk7R0FDWixVQUFVO0dBQ1YsWUFBWTtHQUNaLGFBQWE7RUFDZjtDQUNGO0NBQ0E7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sVUFBVTtHQUNSLFlBQVk7R0FDWixVQUFVO0dBQ1YsWUFBWTtHQUNaLFFBQVE7R0FDUixNQUFNO0dBQ04sWUFBWTtHQUNaLFVBQVU7R0FDVixZQUFZO0dBQ1osYUFBYTtFQUNmO0NBQ0Y7Q0FDQTtFQUNFLElBQUk7RUFDSixNQUFNO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixVQUFVO0dBQ1IsWUFBWTtHQUNaLFVBQVU7R0FDVixZQUFZO0dBQ1osUUFBUTtHQUNSLE1BQU07R0FDTixZQUFZO0dBQ1osVUFBVTtHQUNWLFlBQVk7R0FDWixhQUFhO0VBQ2Y7Q0FDRjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE1BQU07RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLFVBQVU7R0FDUixZQUFZO0dBQ1osVUFBVTtHQUNWLFlBQVk7R0FDWixRQUFRO0dBQ1IsTUFBTTtHQUNOLFlBQVk7R0FDWixVQUFVO0dBQ1YsWUFBWTtHQUNaLGFBQWE7RUFDZjtDQUNGO0NBQ0E7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sVUFBVTtHQUNSLFlBQVk7R0FDWixVQUFVO0dBQ1YsWUFBWTtHQUNaLFFBQVEsQ0FBQztHQUNULE1BQU0sQ0FBQztHQUNQLFlBQVk7R0FDWixVQUFVO0dBQ1YsWUFBWTtHQUNaLGFBQWE7RUFDZjtDQUNGO0NBQ0E7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sVUFBVTtHQUNSLFlBQVk7R0FDWixVQUFVO0dBQ1YsWUFBWTtHQUNaLFFBQVE7R0FDUixNQUFNO0dBQ04sWUFBWTtHQUNaLFVBQVU7R0FDVixZQUFZO0dBQ1osYUFBYTtFQUNmO0NBQ0Y7QUFDRjtBQUVBLE9BQU8sTUFBTSwyQkFBcUM7O0NBRWhELE1BQU0scUJBQXFCLE9BQWlDLElBQUk7O0NBR2hFLE1BQU0sa0JBQWtCLE9BQWlDLElBQUk7O0NBRzdELE1BQU0sdUJBQXVCLE9BQWlDLElBQUk7O0NBR2xFLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFxQixRQUFROztDQUdqRSxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQXdCLElBQUk7Q0FDNUQsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBd0IsSUFBSTtDQUM1RSxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBbUIsQ0FBQyxDQUFDO0NBQzdELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFpQixDQUFDLENBQUM7Q0FFM0QsTUFBTSxjQUFjLE9BQWdDLElBQUk7O0NBR3hELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFzQixlQUFlO0NBQzNFLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBaUIsQ0FBQzs7Q0FHOUMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFpQixTQUFTOztDQUd4RCxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUFrQixJQUFJOztDQUdwRSxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBa0IsSUFBSTtDQUMxRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBaUIsYUFBYTs7Q0FHdEUsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQWlCLENBQUM7Q0FDdEQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFpQixDQUFDO0NBQ2xELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFpQixFQUFFO0NBQ3ZELE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBaUIsQ0FBQztDQUM5QyxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQWlCLENBQUM7Q0FDMUMsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQWlCLEVBQUU7Q0FDdkQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQWlCLEVBQUU7Q0FDdkQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFpQixFQUFFO0NBQ25ELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFrQixLQUFLOztDQUc3RCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBaUIsQ0FBRztDQUN4RCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBbUM7RUFBRSxHQUFHO0VBQUcsR0FBRztDQUFFLENBQUM7Q0FDbkYsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBa0IsS0FBSztDQUNuRSxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBa0IsS0FBSztDQUN6RCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQW1DO0VBQUUsR0FBRztFQUFHLEdBQUc7Q0FBRSxDQUFDOzs7Q0FJakYsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBaUIsRUFBRTtDQUMvRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBaUIsQ0FBQzs7Q0FHMUQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQWtCLENBQUMsQ0FBQztDQUN0RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBa0IsS0FBSztDQUMvRCxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFrQixLQUFLO0NBQ3ZFLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFpQixDQUFDOztDQUd0RCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBaUIsRUFBRTtDQUNyRCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBa0IsS0FBSzs7Q0FHM0QsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFnRSxJQUFJOztDQUdsRyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBZ0UsSUFBSTtDQUM1RyxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFrQixLQUFLO0NBQ25FLE1BQU0sQ0FBQyxvQkFBb0IseUJBQXlCLFNBQTBDLElBQUk7Q0FDbEcsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQStCLE1BQU07O0NBRzdFLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFpQixFQUFFO0NBQzdELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFpQixFQUFFO0NBQ3pELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFpQixDQUFDO0NBQ3BELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFpQixDQUFDO0NBQzVELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFpQixFQUFFO0NBQ3JELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFpQixDQUFDOztDQUd0RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBa0IsS0FBSztDQUMvRCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBaUIsZ0JBQWdCO0NBQzNFLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUNoQyxJQUFJLEtBQUssQ0FBQyxDQUFDLG1CQUFtQixTQUFTO0VBQUUsS0FBSztFQUFXLE9BQU87RUFBVyxNQUFNO0NBQVUsQ0FBQyxDQUM5RjtDQUVBLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFrQixLQUFLO0NBQy9ELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUF3QixJQUFJOztDQUdoRSxJQUFJLGNBQWM7Q0FDbEIsSUFBSSxlQUFlO0NBRW5CLElBQUksZ0JBQWdCLGlCQUFpQjtFQUNuQyxjQUFjO0VBQ2QsZUFBZTtDQUNqQixPQUFPLElBQUksZ0JBQWdCLGdCQUFnQjtFQUN6QyxjQUFjO0VBQ2QsZUFBZTtDQUNqQixPQUFPLElBQUksZ0JBQWdCLGdCQUFnQjtFQUN6QyxjQUFjO0VBQ2QsZUFBZTtDQUNqQixPQUFPO0VBQ0wsY0FBYztFQUNkLGVBQWU7Q0FDakI7Ozs7Q0FLQSxnQkFBZ0I7RUFDZCxNQUFNLGlCQUFpQixNQUFxQjs7R0FFMUMsSUFBSyxFQUFFLE9BQXVCLFlBQVksV0FBWSxFQUFFLE9BQXVCLFlBQVksWUFBWTtJQUNyRztHQUNGOztHQUdBLElBQUksRUFBRSxTQUFTLFdBQVcsQ0FBQyxFQUFFLFFBQVE7SUFDbkMsa0JBQWtCLElBQUk7R0FDeEI7O0dBR0EsSUFBSSxFQUFFLFdBQVcsRUFBRSxJQUFJLFlBQVksTUFBTSxPQUFPLENBQUMsRUFBRSxVQUFVO0lBQzNELEVBQUUsZUFBZTtJQUNqQixXQUFXO0dBQ2I7O0dBR0EsSUFBSyxFQUFFLFdBQVcsRUFBRSxJQUFJLFlBQVksTUFBTSxPQUFTLEVBQUUsV0FBVyxFQUFFLFlBQVksRUFBRSxJQUFJLFlBQVksTUFBTSxLQUFNO0lBQzFHLEVBQUUsZUFBZTtJQUNqQixXQUFXO0dBQ2I7O0dBR0EsSUFBSSxDQUFDLEVBQUUsV0FBVyxDQUFDLEVBQUUsVUFBVSxDQUFDLEVBQUUsU0FBUztJQUN6QyxRQUFRLEVBQUUsSUFBSSxZQUFZLEdBQTFCO0tBQ0UsS0FBSztNQUFLLGNBQWMsUUFBUTtNQUFHO0tBQ25DLEtBQUs7TUFBSyxjQUFjLGdCQUFnQjtNQUFHLGdCQUFnQixXQUFXO01BQUc7S0FDekUsS0FBSztNQUFLLDBCQUEwQjtNQUFHO0tBQ3ZDLEtBQUs7TUFBSyxjQUFjLE1BQU07TUFBRyxZQUFZO01BQUc7S0FDaEQsS0FBSztNQUFLLGNBQWMsWUFBWTtNQUFHO0tBQ3ZDLEtBQUs7TUFBSyxjQUFjLFVBQVU7TUFBRztLQUNyQyxLQUFLO01BQUssY0FBYyxlQUFlO01BQUc7S0FDMUMsS0FBSztNQUFLLGNBQWMsY0FBYztNQUFHO0tBQ3pDLEtBQUs7TUFBSyxjQUFjLGNBQWM7TUFBRztLQUN6QyxLQUFLO01BQUssY0FBYyxNQUFNO01BQUc7S0FDakMsS0FBSztNQUFLLGNBQWMsTUFBTTtNQUFHO0tBQ2pDLEtBQUs7TUFBSyxvQkFBbUIsU0FBUSxDQUFDLElBQUk7TUFBRztLQUM3QyxLQUFLO01BQUssY0FBYSxTQUFRLEtBQUssSUFBSSxHQUFHLE9BQU8sQ0FBQyxDQUFDO01BQUc7S0FDdkQsS0FBSztNQUFLLGNBQWEsU0FBUSxLQUFLLElBQUksSUFBSSxPQUFPLENBQUMsQ0FBQztNQUFHO0tBQ3hELEtBQUs7TUFDSCxJQUFJLGVBQWUsWUFBWTtPQUM3QixhQUFhLENBQUMsQ0FBQztPQUNmLGdCQUFnQixLQUFLO01BQ3ZCO01BQ0EsSUFBSSxlQUFlLFFBQVE7T0FDekIsV0FBVyxJQUFJO09BQ2YsY0FBYyxRQUFRO01BQ3hCO01BQ0E7SUFDSjtHQUNGOztHQUdBLElBQUksRUFBRSxZQUFZLEVBQUUsUUFBUSxPQUFPLEVBQUUsUUFBUSxNQUFNO0lBQ2pELEVBQUUsZUFBZTtJQUNqQixlQUFjLFNBQVEsS0FBSyxJQUFJLEdBQUssT0FBTyxHQUFJLENBQUM7R0FDbEQ7R0FDQSxJQUFJLEVBQUUsWUFBWSxFQUFFLFFBQVEsT0FBTyxFQUFFLFFBQVEsTUFBTTtJQUNqRCxFQUFFLGVBQWU7SUFDakIsZUFBYyxTQUFRLEtBQUssSUFBSSxJQUFLLE9BQU8sR0FBSSxDQUFDO0dBQ2xEO0dBQ0EsSUFBSSxFQUFFLFdBQVcsRUFBRSxRQUFRLEtBQUs7SUFDOUIsRUFBRSxlQUFlO0lBQ2pCLGNBQWMsQ0FBRztJQUNqQixhQUFhO0tBQUUsR0FBRztLQUFHLEdBQUc7SUFBRSxDQUFDO0dBQzdCO0VBQ0Y7RUFFQSxNQUFNLGVBQWUsTUFBcUI7R0FDeEMsSUFBSSxFQUFFLFNBQVMsU0FBUztJQUN0QixrQkFBa0IsS0FBSztJQUN2QixhQUFhLEtBQUs7R0FDcEI7RUFDRjtFQUVBLE9BQU8saUJBQWlCLFdBQVcsYUFBYTtFQUNoRCxPQUFPLGlCQUFpQixTQUFTLFdBQVc7RUFDNUMsYUFBYTtHQUNYLE9BQU8sb0JBQW9CLFdBQVcsYUFBYTtHQUNuRCxPQUFPLG9CQUFvQixTQUFTLFdBQVc7RUFDakQ7Q0FDRixHQUFHO0VBQUM7RUFBWTtFQUFjO0NBQVksQ0FBQzs7Q0FHM0MsTUFBTSxpQkFBaUIsV0FBbUI7RUFDeEMsaUJBQWdCLFNBQVE7R0FDdEIsTUFBTSxjQUFjLEtBQUssTUFBTSxHQUFHLGVBQWUsQ0FBQztHQUNsRCxNQUFNLFVBQVUsQ0FBQyxHQUFHLGFBQWEsTUFBTTtHQUN2QyxJQUFJLFFBQVEsU0FBUyxJQUFJLFFBQVEsTUFBTTtHQUN2QyxPQUFPO0VBQ1QsQ0FBQztFQUNELGlCQUFnQixTQUFRLEtBQUssSUFBSSxJQUFJLE9BQU8sQ0FBQyxDQUFDO0NBQ2hEO0NBRUEsTUFBTSxtQkFBbUI7RUFDdkIsSUFBSSxlQUFlLGNBQWMsVUFBVSxTQUFTLEdBQUc7R0FDckQsSUFBSSxjQUFjO0lBQ2hCLGdCQUFnQixLQUFLO0dBQ3ZCLE9BQU87SUFDTCxjQUFhLFNBQVEsS0FBSyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7R0FDeEM7R0FDQTtFQUNGO0VBRUEsSUFBSSxlQUFlLEdBQUc7R0FDcEIsTUFBTSxVQUFVLGVBQWU7R0FDL0IsZ0JBQWdCLE9BQU87R0FDdkIsWUFBWSxhQUFhLFFBQVE7RUFDbkM7Q0FDRjtDQUVBLE1BQU0sbUJBQW1CO0VBQ3ZCLElBQUksZUFBZSxhQUFhLFNBQVMsR0FBRztHQUMxQyxNQUFNLFVBQVUsZUFBZTtHQUMvQixnQkFBZ0IsT0FBTztHQUN2QixZQUFZLGFBQWEsUUFBUTtFQUNuQztDQUNGOztDQUdBLGdCQUFnQjtFQUNkLElBQUksVUFBVTtHQUNaLE1BQU0sTUFBTSxJQUFJLE1BQU07R0FDdEIsSUFBSSxjQUFjO0dBQ2xCLElBQUksZUFBZTtJQUNqQixZQUFZLFVBQVU7SUFDdEIsbUJBQW1CO0lBQ25CLGtCQUFrQjtJQUNsQixnQkFBZ0I7R0FDbEI7R0FDQSxJQUFJLE1BQU07RUFDWixPQUFPO0dBQ0wsWUFBWSxVQUFVO0dBQ3RCLG1CQUFtQjtHQUNuQixrQkFBa0I7R0FDbEIsZ0JBQWdCO0VBQ2xCO0NBQ0YsR0FBRyxDQUFDLFFBQVEsQ0FBQzs7Q0FHYixnQkFBZ0I7RUFDZCxtQkFBbUI7RUFDbkIsa0JBQWtCO0VBQ2xCLGdCQUFnQjtDQUNsQixHQUFHO0VBQ0Q7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsQ0FBQzs7Q0FHRCxNQUFNLG9CQUFvQjtFQUN4QixNQUFNLFNBQVMsZ0JBQWdCO0VBQy9CLElBQUksQ0FBQyxRQUFRO0VBQ2IsTUFBTSxJQUFJLEtBQUssSUFBSSxPQUFPLFFBQVEsSUFBSyxPQUFPLFNBQVMsTUFBTyxLQUFLLEdBQUc7RUFDdEUsTUFBTSxJQUFJLEtBQUssS0FBSztFQUNwQixXQUFXO0dBQ1QsSUFBSSxPQUFPLFFBQVEsS0FBSztHQUN4QixJQUFJLE9BQU8sU0FBUyxLQUFLO0dBQ3pCO0dBQ0E7RUFDRixDQUFDO0NBQ0g7O0NBR0EsTUFBTSx3QkFBd0I7RUFDNUIsTUFBTSxTQUFTLGdCQUFnQjtFQUMvQixNQUFNLE1BQU0sWUFBWTtFQUN4QixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxTQUFTO0VBRWpDLElBQUk7R0FDRixNQUFNLGFBQWEsU0FBUyxjQUFjLFFBQVE7R0FDbEQsV0FBVyxRQUFRO0dBQ25CLFdBQVcsU0FBUztHQUNwQixNQUFNLE9BQU8sV0FBVyxXQUFXLElBQUk7R0FDdkMsSUFBSSxDQUFDLE1BQU07O0dBR1gsS0FBSyxVQUNILFFBQ0EsUUFBUSxHQUNSLFFBQVEsR0FDUixRQUFRLEdBQ1IsUUFBUSxHQUNSLEdBQ0EsR0FDQSxXQUFXLE9BQ1gsV0FBVyxNQUNiO0dBRUEsTUFBTSxhQUFhLFdBQVcsVUFBVSxjQUFjLEdBQUk7R0FDMUQsWUFBWSxVQUFVO0dBQ3RCLGNBQWMsVUFBVTtHQUN4QixXQUFXLElBQUk7R0FDZixjQUFjLFFBQVE7R0FDdEIsY0FBYyw2Q0FBNkM7R0FDM0QsaUJBQWlCLGNBQWMsSUFBSSxHQUFHLEdBQUk7RUFDNUMsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7RUFDakI7Q0FDRjs7Ozs7Q0FNQSxNQUFNLHVCQUF1QixRQUFnQixXQUFtQjtFQUM5RCxNQUFNLE1BQU0sWUFBWTtFQUN4QixJQUFJLENBQUMsS0FBSztFQUVWLGdCQUFnQixJQUFJO0VBRXBCLElBQUk7R0FDRixNQUFNLGFBQWEsU0FBUyxjQUFjLFFBQVE7R0FDbEQsV0FBVyxRQUFRLElBQUk7R0FDdkIsV0FBVyxTQUFTLElBQUk7R0FDeEIsTUFBTSxPQUFPLFdBQVcsV0FBVyxJQUFJO0dBQ3ZDLElBQUksQ0FBQyxNQUFNO0dBRVgsS0FBSyxVQUFVLEtBQUssR0FBRyxDQUFDO0dBQ3hCLE1BQU0sVUFBVSxLQUFLLGFBQWEsR0FBRyxHQUFHLFdBQVcsT0FBTyxXQUFXLE1BQU07R0FDM0UsTUFBTSxPQUFPLFFBQVE7R0FDckIsTUFBTSxJQUFJLFdBQVc7R0FDckIsTUFBTSxJQUFJLFdBQVc7O0dBR3JCLE1BQU0sU0FBUyxLQUFLLE1BQU0sS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLElBQUksR0FBRyxNQUFNLENBQUMsQ0FBQztHQUM5RCxNQUFNLFNBQVMsS0FBSyxNQUFNLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxJQUFJLEdBQUcsTUFBTSxDQUFDLENBQUM7R0FDOUQsTUFBTSxjQUFjLFNBQVMsSUFBSSxVQUFVO0dBRTNDLE1BQU0sVUFBVSxLQUFLO0dBQ3JCLE1BQU0sVUFBVSxLQUFLLGFBQWE7R0FDbEMsTUFBTSxVQUFVLEtBQUssYUFBYTs7R0FHbEMsTUFBTSxRQUFRLFNBQVMsY0FBYyxLQUFLO0dBQzFDLE1BQU0sTUFBTSxRQUFRO0dBQ3BCLFNBQVMsS0FBSyxZQUFZLEtBQUs7R0FDL0IsTUFBTSxXQUFXLE9BQU8saUJBQWlCLEtBQUssQ0FBQyxDQUFDO0dBQ2hELFNBQVMsS0FBSyxZQUFZLEtBQUs7R0FDL0IsTUFBTSxNQUFNLFNBQVMsTUFBTSxNQUFNLENBQUMsRUFBRSxJQUFJLE1BQU0sS0FBSztJQUFDO0lBQUs7SUFBSztHQUFHOztHQUdqRSxNQUFNLFVBQVUsSUFBSSxXQUFXLElBQUksQ0FBQztHQUNwQyxNQUFNLFFBQWtCLENBQUMsU0FBUyxTQUFTLENBQUM7R0FDNUMsUUFBUSxTQUFTLFNBQVMsS0FBSztHQUUvQixNQUFNLFFBQVEsS0FBSyxJQUFJLGlCQUFpQixLQUFLLENBQUM7O0dBRzlDLElBQUksT0FBTztHQUNYLE9BQU8sT0FBTyxNQUFNLFFBQVE7SUFDMUIsTUFBTSxPQUFPLE1BQU07SUFDbkIsTUFBTSxLQUFLLE9BQU87SUFDbEIsTUFBTSxLQUFLLEtBQUssTUFBTSxPQUFPLENBQUM7SUFDOUIsTUFBTSxNQUFNLE9BQU87O0lBR25CLEtBQUssT0FBTyxJQUFJO0lBQ2hCLEtBQUssTUFBTSxLQUFLLElBQUk7SUFDcEIsS0FBSyxNQUFNLEtBQUssSUFBSTtJQUNwQixLQUFLLE1BQU0sS0FBSzs7SUFHaEIsTUFBTSxZQUFZO0tBQ2hCLENBQUMsS0FBSyxHQUFHLEVBQUU7S0FDWCxDQUFDLEtBQUssR0FBRyxFQUFFO0tBQ1gsQ0FBQyxJQUFJLEtBQUssQ0FBQztLQUNYLENBQUMsSUFBSSxLQUFLLENBQUM7SUFDYjtJQUVBLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7S0FDMUIsTUFBTSxLQUFLLFVBQVUsRUFBRSxDQUFDO0tBQ3hCLE1BQU0sS0FBSyxVQUFVLEVBQUUsQ0FBQztLQUV4QixJQUFJLE1BQU0sS0FBSyxLQUFLLEtBQUssTUFBTSxLQUFLLEtBQUssR0FBRztNQUMxQyxNQUFNLE9BQU8sS0FBSyxLQUFLO01BQ3ZCLElBQUksQ0FBQyxRQUFRLE9BQU87T0FDbEIsTUFBTSxPQUFPLE9BQU87T0FDcEIsTUFBTSxLQUFLLEtBQUs7T0FDaEIsTUFBTSxLQUFLLEtBQUssT0FBTztPQUN2QixNQUFNLEtBQUssS0FBSyxPQUFPOztPQUd2QixNQUFNLFNBQ0osS0FBSyxJQUFJLEtBQUssU0FBUyxDQUFDLElBQ3hCLEtBQUssSUFBSSxLQUFLLFNBQVMsQ0FBQyxJQUN4QixLQUFLLElBQUksS0FBSyxTQUFTLENBQUM7T0FFMUIsSUFBSSxVQUFVLE9BQU87UUFDbkIsUUFBUSxRQUFRO1FBQ2hCLE1BQU0sS0FBSyxJQUFJO09BQ2pCO01BQ0Y7S0FDRjtJQUNGO0dBQ0Y7R0FFQSxLQUFLLGFBQWEsU0FBUyxHQUFHLENBQUM7R0FDL0IsTUFBTSxhQUFhLFdBQVcsVUFBVSxjQUFjLEdBQUk7R0FFMUQsSUFBSSxDQUFDLG9CQUFvQixVQUFVO0lBQ2pDLG9CQUFvQixRQUFRO0dBQzlCO0dBRUEsWUFBWSxVQUFVO0dBQ3RCLGNBQWMsVUFBVTtHQUN4QixjQUFjLGlEQUFpRCxPQUFPLElBQUksT0FBTyxHQUFHO0dBQ3BGLGlCQUFpQixjQUFjLElBQUksR0FBRyxHQUFJO0VBQzVDLFNBQVMsR0FBRztHQUNWLFFBQVEsTUFBTSxDQUFDO0VBQ2pCLFVBQVU7R0FDUixnQkFBZ0IsS0FBSztFQUN2QjtDQUNGOztDQUdBLE1BQU0sa0NBQWtDO0VBQ3RDLE1BQU0sTUFBTSxZQUFZO0VBQ3hCLElBQUksQ0FBQyxLQUFLO0VBRVYsZ0JBQWdCLElBQUk7RUFFcEIsSUFBSTtHQUNGLE1BQU0sYUFBYSxTQUFTLGNBQWMsUUFBUTtHQUNsRCxXQUFXLFFBQVEsSUFBSTtHQUN2QixXQUFXLFNBQVMsSUFBSTtHQUN4QixNQUFNLE9BQU8sV0FBVyxXQUFXLElBQUk7R0FDdkMsSUFBSSxDQUFDLE1BQU07R0FFWCxLQUFLLFVBQVUsS0FBSyxHQUFHLENBQUM7R0FDeEIsTUFBTSxVQUFVLEtBQUssYUFBYSxHQUFHLEdBQUcsV0FBVyxPQUFPLFdBQVcsTUFBTTtHQUMzRSxNQUFNLE9BQU8sUUFBUTtHQUNyQixNQUFNLElBQUksV0FBVztHQUNyQixNQUFNLElBQUksV0FBVzs7R0FHckIsTUFBTSxnQkFBZ0IsWUFBWTtHQUNsQyxJQUFJLE1BQU07SUFBQztJQUFLO0lBQUs7R0FBRztHQUN4QixJQUFJLENBQUMsZUFBZTtJQUNsQixNQUFNLFFBQVEsU0FBUyxjQUFjLEtBQUs7SUFDMUMsTUFBTSxNQUFNLFFBQVE7SUFDcEIsU0FBUyxLQUFLLFlBQVksS0FBSztJQUMvQixNQUFNLFdBQVcsT0FBTyxpQkFBaUIsS0FBSyxDQUFDLENBQUM7SUFDaEQsU0FBUyxLQUFLLFlBQVksS0FBSztJQUMvQixNQUFNLFNBQVMsTUFBTSxNQUFNLENBQUMsRUFBRSxJQUFJLE1BQU0sS0FBSztLQUFDO0tBQUs7S0FBSztJQUFHO0dBQzdEOztHQUdBLE1BQU0sV0FBVyxLQUFLLEtBQUssTUFBTSxJQUFJLEtBQUssTUFBTTtHQUNoRCxNQUFNLFdBQVcsS0FBSyxLQUFLLE1BQU0sSUFBSSxLQUFLLElBQUksTUFBTTtHQUNwRCxNQUFNLFdBQVcsS0FBSyxLQUFLLE1BQU0sSUFBSSxLQUFLLElBQUksTUFBTTtHQUVwRCxNQUFNLFVBQVUsSUFBSSxXQUFXLElBQUksQ0FBQztHQUNwQyxNQUFNLFFBQWtCLENBQUM7O0dBR3pCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7SUFDMUIsTUFBTSxLQUFLLENBQUM7SUFDWixNQUFNLEtBQUssS0FBSyxJQUFJLEtBQUssQ0FBQztJQUMxQixRQUFRLEtBQUs7SUFDYixRQUFRLEtBQUssSUFBSSxLQUFLLEtBQUs7R0FDN0I7R0FDQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLO0lBQzFCLE1BQU0sS0FBSyxJQUFJLENBQUM7SUFDaEIsTUFBTSxLQUFNLElBQUksSUFBSyxJQUFJLENBQUM7SUFDMUIsUUFBUSxJQUFJLEtBQUs7SUFDakIsUUFBUyxJQUFJLElBQUssSUFBSSxLQUFLO0dBQzdCO0dBRUEsTUFBTSxRQUFRLEtBQUssSUFBSSxpQkFBaUIsS0FBSyxDQUFDO0dBRTlDLElBQUksT0FBTztHQUNYLE9BQU8sT0FBTyxNQUFNLFFBQVE7SUFDMUIsTUFBTSxPQUFPLE1BQU07SUFDbkIsTUFBTSxLQUFLLE9BQU87SUFDbEIsTUFBTSxLQUFLLEtBQUssTUFBTSxPQUFPLENBQUM7SUFDOUIsTUFBTSxNQUFNLE9BQU87O0lBR25CLElBQUksZUFBZTtLQUNqQixLQUFLLE1BQU0sS0FBSztJQUNsQixPQUFPO0tBQ0wsS0FBSyxPQUFPLElBQUk7S0FDaEIsS0FBSyxNQUFNLEtBQUssSUFBSTtLQUNwQixLQUFLLE1BQU0sS0FBSyxJQUFJO0tBQ3BCLEtBQUssTUFBTSxLQUFLO0lBQ2xCO0lBRUEsTUFBTSxZQUFZO0tBQ2hCLENBQUMsS0FBSyxHQUFHLEVBQUU7S0FDWCxDQUFDLEtBQUssR0FBRyxFQUFFO0tBQ1gsQ0FBQyxJQUFJLEtBQUssQ0FBQztLQUNYLENBQUMsSUFBSSxLQUFLLENBQUM7SUFDYjtJQUVBLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7S0FDMUIsTUFBTSxLQUFLLFVBQVUsRUFBRSxDQUFDO0tBQ3hCLE1BQU0sS0FBSyxVQUFVLEVBQUUsQ0FBQztLQUV4QixJQUFJLE1BQU0sS0FBSyxLQUFLLEtBQUssTUFBTSxLQUFLLEtBQUssR0FBRztNQUMxQyxNQUFNLE9BQU8sS0FBSyxLQUFLO01BQ3ZCLElBQUksQ0FBQyxRQUFRLE9BQU87T0FDbEIsTUFBTSxPQUFPLE9BQU87T0FDcEIsTUFBTSxLQUFLLEtBQUs7T0FDaEIsTUFBTSxLQUFLLEtBQUssT0FBTztPQUN2QixNQUFNLEtBQUssS0FBSyxPQUFPO09BRXZCLE1BQU0sU0FDSixLQUFLLElBQUksS0FBSyxTQUFTLENBQUMsSUFDeEIsS0FBSyxJQUFJLEtBQUssU0FBUyxDQUFDLElBQ3hCLEtBQUssSUFBSSxLQUFLLFNBQVMsQ0FBQztPQUUxQixJQUFJLFVBQVUsT0FBTztRQUNuQixRQUFRLFFBQVE7UUFDaEIsTUFBTSxLQUFLLElBQUk7T0FDakI7TUFDRjtLQUNGO0lBQ0Y7R0FDRjtHQUVBLEtBQUssYUFBYSxTQUFTLEdBQUcsQ0FBQztHQUMvQixNQUFNLGFBQWEsV0FBVyxVQUFVLGdCQUFnQixjQUFjLGNBQWMsR0FBSTtHQUV4RixJQUFJLENBQUMsb0JBQW9CLFVBQVU7SUFDakMsb0JBQW9CLFFBQVE7R0FDOUI7R0FFQSxZQUFZLFVBQVU7R0FDdEIsY0FBYyxVQUFVO0dBQ3hCLGNBQWMsZ0JBQWdCLHFEQUFxRCx3REFBd0Q7R0FDM0ksaUJBQWlCLGNBQWMsSUFBSSxHQUFHLEdBQUk7RUFDNUMsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7RUFDakIsVUFBVTtHQUNSLGdCQUFnQixLQUFLO0VBQ3ZCO0NBQ0Y7Ozs7Q0FLQSxNQUFNLHFCQUFxQixTQUFpQixTQUFpQixTQUF1QztFQUNsRyxNQUFNLE1BQU0sWUFBWTtFQUN4QixJQUFJLENBQUMsS0FBSztFQUVWLElBQUk7R0FDRixNQUFNLGFBQWEsU0FBUyxjQUFjLFFBQVE7R0FDbEQsV0FBVyxRQUFRLElBQUk7R0FDdkIsV0FBVyxTQUFTLElBQUk7R0FDeEIsTUFBTSxPQUFPLFdBQVcsV0FBVyxJQUFJO0dBQ3ZDLElBQUksQ0FBQyxNQUFNO0dBRVgsS0FBSyxVQUFVLEtBQUssR0FBRyxDQUFDO0dBRXhCLE1BQU0sTUFBTTtHQUNaLE1BQU0sSUFBSSxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksSUFBSSxPQUFPLE9BQU8sQ0FBQztHQUNsRCxNQUFNLElBQUksS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLElBQUksUUFBUSxPQUFPLENBQUM7R0FFbkQsSUFBSSxTQUFTLFdBQVc7O0lBRXRCLE1BQU0sVUFBVSxLQUFLLGFBQ25CLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxHQUNuQixLQUFLLElBQUksR0FBRyxJQUFJLEdBQUcsR0FDbkIsTUFBTSxHQUNOLE1BQU0sQ0FDUjtJQUNBLE1BQU0sT0FBTyxRQUFROztJQUdyQixJQUFJLE9BQU8sR0FBRyxPQUFPLEdBQUcsT0FBTyxHQUFHLFFBQVE7SUFDMUMsS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLE1BQU0sR0FBRyxNQUFNO0tBQ25DLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxNQUFNLEdBQUcsTUFBTTtNQUNuQyxNQUFNLElBQUksS0FBSyxNQUFNLEtBQUssS0FBSyxLQUFLLEdBQUc7TUFDdkMsSUFBSSxLQUFLLE1BQU0sTUFBTyxLQUFLLEtBQUs7T0FDOUIsTUFBTSxLQUFLLEtBQUssTUFBTSxJQUFJLE1BQU07T0FDaEMsUUFBUSxLQUFLO09BQ2IsUUFBUSxLQUFLLElBQUk7T0FDakIsUUFBUSxLQUFLLElBQUk7T0FDakI7TUFDRjtLQUNGO0lBQ0Y7SUFFQSxJQUFJLFFBQVEsR0FBRztLQUNiLE1BQU0sT0FBTyxPQUFPO0tBQ3BCLE1BQU0sT0FBTyxPQUFPO0tBQ3BCLE1BQU0sT0FBTyxPQUFPO0tBRXBCLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxNQUFNLEdBQUcsTUFBTTtNQUNuQyxLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssTUFBTSxHQUFHLE1BQU07T0FDbkMsTUFBTSxJQUFJLEtBQUssTUFBTSxLQUFLLEtBQUssS0FBSyxHQUFHO09BQ3ZDLElBQUksSUFBSSxLQUFLO1FBQ1gsTUFBTSxLQUFLLEtBQUssTUFBTSxJQUFJLE1BQU07UUFDaEMsTUFBTSxjQUFjLElBQUssSUFBSTtRQUM3QixLQUFLLEtBQUssS0FBSyxNQUFNLElBQUksZUFBZSxPQUFPO1FBQy9DLEtBQUssSUFBSSxLQUFLLEtBQUssSUFBSSxNQUFNLElBQUksZUFBZSxPQUFPO1FBQ3ZELEtBQUssSUFBSSxLQUFLLEtBQUssSUFBSSxNQUFNLElBQUksZUFBZSxPQUFPO09BQ3pEO01BQ0Y7S0FDRjtLQUNBLEtBQUssYUFBYSxTQUFTLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxHQUFHLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxDQUFDO0lBQ3ZFO0dBQ0YsT0FBTyxJQUFJLFNBQVMsVUFBVTs7SUFFNUIsS0FBSyxLQUFLO0lBQ1YsS0FBSyxVQUFVO0lBQ2YsS0FBSyxJQUFJLEdBQUcsR0FBRyxLQUFLLEdBQUcsS0FBSyxLQUFLLENBQUM7SUFDbEMsS0FBSyxLQUFLO0lBQ1YsS0FBSyxTQUFTO0lBQ2QsS0FBSyxVQUFVLEtBQUssR0FBRyxDQUFDO0lBQ3hCLEtBQUssUUFBUTtHQUNmLE9BQU87O0lBRUwsS0FBSyxLQUFLO0lBQ1YsS0FBSyxVQUFVO0lBQ2YsS0FBSyxJQUFJLEdBQUcsR0FBRyxLQUFLLEdBQUcsS0FBSyxLQUFLLENBQUM7SUFDbEMsS0FBSyxLQUFLO0lBQ1YsS0FBSyxTQUFTO0lBQ2QsS0FBSyxVQUFVLEtBQUssR0FBRyxDQUFDO0lBQ3hCLEtBQUssUUFBUTtHQUNmO0dBRUEsTUFBTSxhQUFhLFdBQVcsVUFBVSxjQUFjLEdBQUk7R0FDMUQsWUFBWSxVQUFVO0dBQ3RCLGNBQWMsVUFBVTtFQUMxQixTQUFTLEdBQUc7R0FDVixRQUFRLE1BQU0sQ0FBQztFQUNqQjtDQUNGOzs7O0NBS0EsTUFBTSw2QkFBNkI7RUFDakMsTUFBTSxNQUFNLFlBQVk7RUFDeEIsSUFBSSxDQUFDLE9BQU8sVUFBVSxTQUFTLEdBQUc7RUFFbEMsSUFBSTtHQUNGLE1BQU0sYUFBYSxTQUFTLGNBQWMsUUFBUTtHQUNsRCxXQUFXLFFBQVEsSUFBSTtHQUN2QixXQUFXLFNBQVMsSUFBSTtHQUN4QixNQUFNLE9BQU8sV0FBVyxXQUFXLElBQUk7R0FDdkMsSUFBSSxDQUFDLE1BQU07O0dBR1gsS0FBSyxZQUFZO0dBQ2pCLEtBQUssU0FBUyxHQUFHLEdBQUcsV0FBVyxPQUFPLFdBQVcsTUFBTTs7R0FHdkQsTUFBTSxlQUFlLFNBQVMsY0FBYyxRQUFRO0dBQ3BELGFBQWEsUUFBUSxJQUFJO0dBQ3pCLGFBQWEsU0FBUyxJQUFJO0dBQzFCLE1BQU0sT0FBTyxhQUFhLFdBQVcsSUFBSTtHQUV6QyxJQUFJLE1BQU07SUFDUixLQUFLLFVBQVUsS0FBSyxHQUFHLENBQUM7SUFFeEIsTUFBTSxhQUFhLFNBQVMsY0FBYyxRQUFRO0lBQ2xELFdBQVcsUUFBUSxJQUFJO0lBQ3ZCLFdBQVcsU0FBUyxJQUFJO0lBQ3hCLE1BQU0sT0FBTyxXQUFXLFdBQVcsSUFBSTtJQUV2QyxJQUFJLE1BQU07S0FDUixJQUFJLGFBQWEsR0FBRztNQUNsQixLQUFLLFNBQVMsUUFBUSxXQUFXO0tBQ25DO0tBRUEsS0FBSyxVQUFVO0tBQ2YsS0FBSyxPQUFPLFVBQVUsRUFBRSxDQUFDLElBQUksSUFBSSxPQUFPLFVBQVUsRUFBRSxDQUFDLElBQUksSUFBSSxNQUFNO0tBQ25FLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxVQUFVLFFBQVEsS0FBSztNQUN6QyxLQUFLLE9BQU8sVUFBVSxFQUFFLENBQUMsSUFBSSxJQUFJLE9BQU8sVUFBVSxFQUFFLENBQUMsSUFBSSxJQUFJLE1BQU07S0FDckU7S0FDQSxLQUFLLFVBQVU7S0FDZixLQUFLLFlBQVk7S0FDakIsS0FBSyxLQUFLO0tBRVYsS0FBSywyQkFBMkI7S0FDaEMsS0FBSyxVQUFVLFlBQVksR0FBRyxDQUFDO0lBQ2pDO0lBRUEsS0FBSyxVQUFVLGNBQWMsR0FBRyxDQUFDO0dBQ25DO0dBRUEsTUFBTSxhQUFhLFdBQVcsVUFBVSxjQUFjLEdBQUk7R0FDMUQsSUFBSSxDQUFDLG9CQUFvQixVQUFVO0lBQ2pDLG9CQUFvQixRQUFRO0dBQzlCO0dBRUEsWUFBWSxVQUFVO0dBQ3RCLGNBQWMsVUFBVTtHQUN4QixhQUFhLENBQUMsQ0FBQztHQUNmLGdCQUFnQixLQUFLO0dBQ3JCLGNBQWMsUUFBUTtHQUN0QixjQUFjLDJDQUEyQztHQUN6RCxpQkFBaUIsY0FBYyxJQUFJLEdBQUcsR0FBSTtFQUM1QyxTQUFTLEdBQUc7R0FDVixRQUFRLE1BQU0sQ0FBQztFQUNqQjtDQUNGOzs7O0NBS0EsTUFBTSxzQkFBc0IsU0FBK0M7RUFDekUsUUFBUSxNQUFSO0dBQ0UsS0FBSztJQUNILGdCQUFnQjtLQUFFLEdBQUc7S0FBTSxHQUFHO0tBQU0sR0FBRztLQUFNLEdBQUc7SUFBSyxDQUFDO0lBQ3REO0dBQ0YsS0FBSztJQUNILGdCQUFnQjtLQUFFLEdBQUc7S0FBTSxHQUFHO0tBQU0sR0FBRztLQUFNLEdBQUc7SUFBSyxDQUFDO0lBQ3REO0dBQ0YsS0FBSztJQUNILGdCQUFnQjtLQUFFLEdBQUc7S0FBTSxHQUFHO0tBQU0sR0FBRztLQUFNLEdBQUc7SUFBSyxDQUFDO0lBQ3REO0dBQ0YsS0FBSztJQUNILGdCQUFnQjtLQUFFLEdBQUc7S0FBTSxHQUFHO0tBQU0sR0FBRztLQUFNLEdBQUc7SUFBSyxDQUFDO0lBQ3REO0VBQ0o7RUFDQSxjQUFjLGdCQUFnQjtFQUM5QixnQkFBZ0IsV0FBVztDQUM3QjtDQUVBLE1BQU0sNkJBQTZCO0VBQ2pDLGdCQUFnQixJQUFJO0VBQ3BCLGdCQUFnQixNQUFNO0NBQ3hCO0NBRUEsTUFBTSw4QkFBOEI7RUFDbEMsSUFBSSxDQUFDLGNBQWM7O0VBRW5CLGdCQUFnQjtHQUNkLEdBQUcsS0FBSyxJQUFJLEdBQUcsS0FBSyxhQUFhLElBQUksYUFBYSxFQUFFO0dBQ3BELEdBQUcsYUFBYTtHQUNoQixHQUFHLGFBQWE7R0FDaEIsR0FBRyxhQUFhO0VBQ2xCLENBQUM7Q0FDSDtDQUVBLE1BQU0sb0NBQW9DO0VBQ3hDLE1BQU0sTUFBTSxZQUFZO0VBQ3hCLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYztFQUUzQixnQkFBZ0IsSUFBSTtFQUNwQixJQUFJO0dBQ0YsTUFBTSxhQUFhLFNBQVMsY0FBYyxRQUFRO0dBQ2xELFdBQVcsUUFBUSxJQUFJO0dBQ3ZCLFdBQVcsU0FBUyxJQUFJO0dBQ3hCLE1BQU0sT0FBTyxXQUFXLFdBQVcsSUFBSTtHQUN2QyxJQUFJLENBQUMsTUFBTTs7R0FHWCxLQUFLLFVBQVUsS0FBSyxHQUFHLENBQUM7O0dBR3hCLE1BQU0sT0FBTyxhQUFhLElBQUksSUFBSTtHQUNsQyxNQUFNLE9BQU8sYUFBYSxJQUFJLElBQUk7R0FDbEMsTUFBTSxPQUFPLGFBQWEsSUFBSSxJQUFJO0dBQ2xDLE1BQU0sT0FBTyxhQUFhLElBQUksSUFBSTtHQUVsQyxLQUFLLEtBQUs7R0FDVixLQUFLLFVBQVU7R0FDZixLQUFLLEtBQUssTUFBTSxNQUFNLE1BQU0sSUFBSTtHQUNoQyxLQUFLLEtBQUs7R0FFVixNQUFNLGVBQWUsTUFBTTtHQUMzQixNQUFNLGFBQWEsTUFBTTtHQUN6QixNQUFNLFlBQVksTUFBTTtHQUN4QixLQUFLLFNBQVMsY0FBYyxhQUFhLGNBQWMsV0FBVyxjQUFjLFVBQVU7R0FDMUYsS0FBSyxVQUFVLEtBQUssR0FBRyxDQUFDO0dBRXhCLElBQUksY0FBYyxLQUFLLENBQUMsYUFBYTtJQUNuQyxLQUFLLDJCQUEyQjtJQUNoQyxLQUFLLFlBQVksWUFBWSxJQUN6QixzQkFBc0IsS0FBSyxJQUFJLEtBQU8sWUFBWSxNQUFPLEVBQUcsRUFBRSxLQUM5RCxzQkFBc0IsS0FBSyxJQUFJLEtBQU8sS0FBSyxJQUFJLFNBQVMsSUFBSSxNQUFPLEVBQUcsRUFBRTtJQUM1RSxLQUFLLFNBQVMsTUFBTSxNQUFNLE1BQU0sSUFBSTtHQUN0QztHQUVBLEtBQUssUUFBUTtHQUViLE1BQU0sYUFBYSxXQUFXLFVBQVUsY0FBYyxHQUFJO0dBQzFELElBQUksQ0FBQyxvQkFBb0IsVUFBVTtJQUNqQyxvQkFBb0IsUUFBUTtHQUM5QjtHQUNBLFlBQVksVUFBVTtHQUN0QixjQUFjLFVBQVU7R0FDeEIsY0FBYyx1REFBdUQ7R0FDckUsaUJBQWlCLGNBQWMsSUFBSSxHQUFHLEdBQUk7RUFDNUMsU0FBUyxHQUFHO0dBQ1YsUUFBUSxNQUFNLENBQUM7RUFDakIsVUFBVTtHQUNSLGdCQUFnQixLQUFLO0VBQ3ZCO0NBQ0Y7Ozs7Q0FLQSxNQUFNLDJCQUEyQjtFQUMvQixNQUFNLFNBQVMsZ0JBQWdCO0VBQy9CLE1BQU0sTUFBTSxZQUFZO0VBQ3hCLElBQUksQ0FBQyxRQUFRO0VBRWIsTUFBTSxNQUFNLE9BQU8sV0FBVyxJQUFJO0VBQ2xDLElBQUksQ0FBQyxLQUFLOztFQUdWLE9BQU8sUUFBUTtFQUNmLE9BQU8sU0FBUzs7RUFHaEIsSUFBSSxZQUFZO0VBQ2hCLElBQUksU0FBUyxHQUFHLEdBQUcsT0FBTyxPQUFPLE9BQU8sTUFBTTtFQUU5QyxJQUFJLENBQUMsS0FBSzs7R0FFUixJQUFJLFlBQVk7R0FDaEIsSUFBSSxPQUFPO0dBQ1gsSUFBSSxZQUFZO0dBQ2hCLElBQUksU0FBUyx5Q0FBeUMsT0FBTyxRQUFRLEdBQUcsT0FBTyxTQUFTLElBQUksRUFBRTtHQUM5RixJQUFJLE9BQU87R0FDWCxJQUFJLFNBQVMsc0VBQXNFLE9BQU8sUUFBUSxHQUFHLE9BQU8sU0FBUyxJQUFJLEVBQUU7R0FDM0g7RUFDRjtFQUVBLElBQUksS0FBSzs7RUFHVCxJQUFJLFVBQVUsT0FBTyxRQUFRLElBQUksVUFBVSxHQUFHLE9BQU8sU0FBUyxJQUFJLFVBQVUsQ0FBQztFQUM3RSxJQUFJLE1BQU0sWUFBWSxVQUFVOztFQUdoQyxNQUFNLFNBQVMsSUFBSSxRQUFRLElBQUk7RUFDL0IsSUFBSSxVQUFVO0VBQ2QsSUFBSSxVQUFVLE1BQU07RUFDcEIsSUFBSSxVQUFVLEtBQUs7R0FDakIsVUFBVTtHQUNWLFVBQVUsTUFBTTtFQUNsQjtFQUVBLE1BQU0sUUFBUSxDQUFDLFVBQVU7RUFDekIsTUFBTSxRQUFRLENBQUMsVUFBVTs7RUFHekIsTUFBTSxnQkFBZ0IsTUFBTSxjQUFjLGFBQWEsSUFBSSxLQUFNLFdBQVc7RUFDNUUsTUFBTSxjQUFjLE1BQU0sWUFBWSxhQUFhLElBQUk7RUFDdkQsTUFBTSxnQkFBZ0IsY0FBYyxJQUFJLE1BQU0sY0FBYyxhQUFhLElBQUk7RUFFN0UsSUFBSSxZQUFZLGNBQWMsY0FBYyxjQUFjLFlBQVksY0FBYyxjQUFjO0VBQ2xHLElBQUksYUFBYSxhQUFhO0VBRTlCLElBQUksU0FBUztFQUNiLElBQUksVUFBVSxLQUFLLE9BQU8sT0FBTyxTQUFTLE9BQU87O0VBR2pELE1BQU0sWUFBWSxhQUFhLEtBQUssSUFBSSxZQUFZLEVBQUUsSUFBSTtFQUMxRCxNQUFNLFVBQVUsYUFBYSxLQUFLLElBQUksVUFBVSxFQUFFLElBQUk7RUFDdEQsSUFBSSxZQUFZLEtBQUssVUFBVSxHQUFHO0dBQ2hDLElBQUksS0FBSztHQUNULElBQUksMkJBQTJCO0dBQy9CLElBQUksY0FBYyxLQUFLLElBQUksS0FBTyxZQUFZLE9BQVUsVUFBVSxHQUFLO0dBQ3ZFLElBQUksU0FBUyxRQUFRLEtBQUssSUFBSSxHQUFHLFlBQVksQ0FBQyxFQUFFO0dBQ2hELElBQUksVUFBVSxLQUFLLE9BQU8sT0FBTyxTQUFTLE9BQU87R0FDakQsSUFBSSxRQUFRO0VBQ2Q7O0VBR0EsSUFBSSxXQUFXLEtBQUssQ0FBQyxhQUFhO0dBQ2hDLElBQUksS0FBSztHQUNULElBQUksMkJBQTJCO0dBQy9CLElBQUksWUFBWSxTQUFTLElBQ3JCLHNCQUFzQixLQUFLLElBQUksS0FBTyxTQUFTLE1BQU8sRUFBRyxFQUFFLEtBQzNELHNCQUFzQixLQUFLLElBQUksS0FBTyxLQUFLLElBQUksTUFBTSxJQUFJLE1BQU8sRUFBRyxFQUFFO0dBQ3pFLElBQUksU0FBUyxPQUFPLE9BQU8sU0FBUyxPQUFPO0dBQzNDLElBQUksUUFBUTtFQUNkO0VBRUEsSUFBSSxTQUFTLEtBQUssQ0FBQyxhQUFhO0dBQzlCLElBQUksS0FBSztHQUNULElBQUksMkJBQTJCO0dBQy9CLElBQUksWUFBWSxPQUFPLElBQ25CLHNCQUFzQixLQUFLLElBQUksS0FBTyxPQUFPLE1BQU8sRUFBRyxFQUFFLEtBQ3pELHNCQUFzQixLQUFLLElBQUksS0FBTyxLQUFLLElBQUksSUFBSSxJQUFJLE1BQU8sRUFBRyxFQUFFO0dBQ3ZFLElBQUksU0FBUyxPQUFPLE9BQU8sU0FBUyxPQUFPO0dBQzNDLElBQUksUUFBUTtFQUNkOzs7O0VBS0EsSUFBSSxnQkFBZ0IsYUFBYSxJQUFJLFFBQVMsYUFBYSxJQUFJLE1BQU87R0FDcEUsTUFBTSxPQUFPLFFBQVEsYUFBYSxJQUFJO0dBQ3RDLE1BQU0sT0FBTyxRQUFRLGFBQWEsSUFBSTtHQUN0QyxNQUFNLE9BQU8sYUFBYSxJQUFJO0dBQzlCLE1BQU0sT0FBTyxhQUFhLElBQUk7R0FFOUIsSUFBSSxLQUFLO0dBQ1QsSUFBSSxVQUFVO0dBQ2QsSUFBSSxLQUFLLE1BQU0sTUFBTSxNQUFNLElBQUk7R0FDL0IsSUFBSSxLQUFLO0dBRVQsTUFBTSxlQUFlLGdCQUFnQjtHQUNyQyxNQUFNLGFBQWEsY0FBYztHQUNqQyxNQUFNLFlBQVksY0FBYyxJQUFJLGdCQUFnQjtHQUVwRCxJQUFJLFNBQVMsY0FBYyxhQUFhLGNBQWMsV0FBVyxjQUFjLFVBQVU7R0FDekYsSUFBSSxVQUFVLEtBQUssT0FBTyxPQUFPLFNBQVMsT0FBTzs7R0FHakQsSUFBSSxZQUFZLEdBQUc7SUFDakIsSUFBSSxLQUFLO0lBQ1QsSUFBSSwyQkFBMkI7SUFDL0IsSUFBSSxjQUFjLEtBQUssSUFBSSxLQUFNLFlBQVksSUFBSztJQUNsRCxJQUFJLFNBQVMsUUFBUSxLQUFLLElBQUksR0FBRyxZQUFZLENBQUMsRUFBRTtJQUNoRCxJQUFJLFVBQVUsS0FBSyxPQUFPLE9BQU8sU0FBUyxPQUFPO0lBQ2pELElBQUksUUFBUTtHQUNkOztHQUdBLElBQUksY0FBYyxLQUFLLENBQUMsYUFBYTtJQUNuQyxJQUFJLEtBQUs7SUFDVCxJQUFJLDJCQUEyQjtJQUMvQixJQUFJLFlBQVksWUFBWSxJQUN4QixzQkFBc0IsS0FBSyxJQUFJLEtBQU8sWUFBWSxNQUFPLEVBQUcsRUFBRSxLQUM5RCxzQkFBc0IsS0FBSyxJQUFJLEtBQU8sS0FBSyxJQUFJLFNBQVMsSUFBSSxNQUFPLEVBQUcsRUFBRTtJQUM1RSxJQUFJLFNBQVMsTUFBTSxNQUFNLE1BQU0sSUFBSTtJQUNuQyxJQUFJLFFBQVE7R0FDZDtHQUVBLElBQUksUUFBUTs7R0FHWixJQUFJLEtBQUs7R0FDVCxJQUFJLGNBQWM7R0FDbEIsSUFBSSxZQUFZO0dBQ2hCLElBQUksWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0dBQ3RCLElBQUksV0FBVyxNQUFNLE1BQU0sTUFBTSxJQUFJOztHQUdyQyxNQUFNLGFBQWE7R0FDbkIsSUFBSSxZQUFZO0dBQ2hCLElBQUksY0FBYztHQUNsQixJQUFJLFlBQVk7R0FDaEIsSUFBSSxZQUFZLENBQUMsQ0FBQztHQUNsQjtJQUNFLENBQUMsTUFBTSxJQUFJO0lBQ1gsQ0FBQyxPQUFPLE1BQU0sSUFBSTtJQUNsQixDQUFDLE1BQU0sT0FBTyxJQUFJO0lBQ2xCLENBQUMsT0FBTyxNQUFNLE9BQU8sSUFBSTtHQUMzQixDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksUUFBUTtJQUN0QixJQUFJLFNBQVMsS0FBSyxhQUFhLEdBQUcsS0FBSyxhQUFhLEdBQUcsWUFBWSxVQUFVO0lBQzdFLElBQUksV0FBVyxLQUFLLGFBQWEsR0FBRyxLQUFLLGFBQWEsR0FBRyxZQUFZLFVBQVU7R0FDakYsQ0FBQzs7R0FHRCxJQUFJLFlBQVk7R0FDaEIsSUFBSSxTQUFTLE1BQU0sS0FBSyxJQUFJLE9BQU8sT0FBTyxFQUFFLEdBQUcsS0FBSyxFQUFFO0dBQ3RELElBQUksWUFBWTtHQUNoQixJQUFJLE9BQU87R0FDWCxJQUFJLFNBQVMsZUFBZSxnQkFBZ0IsSUFBSSxNQUFNLEtBQUssY0FBYyxNQUFNLGNBQWMsSUFBSSxNQUFNLEtBQUssWUFBWSxLQUFLLE9BQU8sR0FBRyxLQUFLLElBQUksT0FBTyxPQUFPLEVBQUUsSUFBSSxFQUFFO0dBQ3RLLElBQUksUUFBUTtFQUNkO0VBRUEsSUFBSSxRQUFROzs7OztFQU1aLElBQUksZUFBZSxjQUFjLFVBQVUsU0FBUyxHQUFHO0dBQ3JELElBQUksS0FBSztHQUNULElBQUksVUFBVSxPQUFPLFFBQVEsSUFBSSxVQUFVLEdBQUcsT0FBTyxTQUFTLElBQUksVUFBVSxDQUFDO0dBQzdFLElBQUksTUFBTSxZQUFZLFVBQVU7R0FFaEMsSUFBSSxVQUFVO0dBQ2QsTUFBTSxTQUFTLFFBQVEsVUFBVSxFQUFFLENBQUMsSUFBSTtHQUN4QyxNQUFNLFNBQVMsUUFBUSxVQUFVLEVBQUUsQ0FBQyxJQUFJO0dBQ3hDLElBQUksT0FBTyxRQUFRLE1BQU07R0FFekIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxLQUFLO0lBQ3pDLE1BQU0sS0FBSyxRQUFRLFVBQVUsRUFBRSxDQUFDLElBQUk7SUFDcEMsTUFBTSxLQUFLLFFBQVEsVUFBVSxFQUFFLENBQUMsSUFBSTtJQUNwQyxJQUFJLE9BQU8sSUFBSSxFQUFFO0dBQ25CO0dBRUEsSUFBSSxjQUFjO0lBQ2hCLElBQUksVUFBVTtJQUNkLElBQUksWUFBWTtJQUNoQixJQUFJLEtBQUs7R0FDWDtHQUVBLElBQUksY0FBYyxlQUFlLFlBQVk7R0FDN0MsSUFBSSxZQUFZLElBQUk7R0FDcEIsSUFBSSxZQUFZLGVBQWUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7R0FDMUMsSUFBSSxPQUFPOztHQUdYLFVBQVUsU0FBUyxJQUFJLFFBQVE7SUFDN0IsTUFBTSxLQUFLLFFBQVEsR0FBRyxJQUFJO0lBQzFCLE1BQU0sS0FBSyxRQUFRLEdBQUcsSUFBSTtJQUMxQixNQUFNLFVBQVUsUUFBUTtJQUV4QixJQUFJLFVBQVU7SUFDZCxJQUFJLElBQUksSUFBSSxLQUFLLFVBQVUsSUFBSSxLQUFLLFlBQVksR0FBRyxLQUFLLEtBQUssQ0FBQztJQUM5RCxJQUFJLFlBQVksVUFBVyxtQkFBbUIsWUFBWSxZQUFhO0lBQ3ZFLElBQUksY0FBYztJQUNsQixJQUFJLFlBQVksSUFBSTtJQUNwQixJQUFJLEtBQUs7SUFDVCxJQUFJLE9BQU87R0FDYixDQUFDO0dBRUQsSUFBSSxRQUFRO0VBQ2Q7O0VBR0EsSUFBSSxlQUFlLFVBQVUsU0FBUztHQUNwQyxJQUFJLEtBQUs7O0dBRVQsSUFBSSxZQUFZO0dBQ2hCLElBQUksU0FBUyxHQUFHLEdBQUcsT0FBTyxPQUFPLFFBQVEsQ0FBQztHQUMxQyxJQUFJLFNBQVMsR0FBRyxRQUFRLElBQUksUUFBUSxHQUFHLE9BQU8sT0FBTyxPQUFPLFVBQVUsUUFBUSxJQUFJLFFBQVEsRUFBRTtHQUM1RixJQUFJLFNBQVMsR0FBRyxRQUFRLEdBQUcsUUFBUSxHQUFHLFFBQVEsQ0FBQztHQUMvQyxJQUFJLFNBQVMsUUFBUSxJQUFJLFFBQVEsR0FBRyxRQUFRLEdBQUcsT0FBTyxTQUFTLFFBQVEsSUFBSSxRQUFRLElBQUksUUFBUSxDQUFDOztHQUdoRyxJQUFJLGNBQWM7R0FDbEIsSUFBSSxZQUFZO0dBQ2hCLElBQUksV0FBVyxRQUFRLEdBQUcsUUFBUSxHQUFHLFFBQVEsR0FBRyxRQUFRLENBQUM7O0dBR3pELElBQUksY0FBYztHQUNsQixJQUFJLFlBQVk7R0FDaEIsSUFBSSxVQUFVO0dBQ2QsSUFBSSxPQUFPLFFBQVEsSUFBSSxRQUFRLElBQUksR0FBRyxRQUFRLENBQUM7R0FDL0MsSUFBSSxPQUFPLFFBQVEsSUFBSSxRQUFRLElBQUksR0FBRyxRQUFRLElBQUksUUFBUSxDQUFDO0dBQzNELElBQUksT0FBTyxRQUFRLElBQUssUUFBUSxJQUFJLElBQUssR0FBRyxRQUFRLENBQUM7R0FDckQsSUFBSSxPQUFPLFFBQVEsSUFBSyxRQUFRLElBQUksSUFBSyxHQUFHLFFBQVEsSUFBSSxRQUFRLENBQUM7R0FDakUsSUFBSSxPQUFPLFFBQVEsR0FBRyxRQUFRLElBQUksUUFBUSxJQUFJLENBQUM7R0FDL0MsSUFBSSxPQUFPLFFBQVEsSUFBSSxRQUFRLEdBQUcsUUFBUSxJQUFJLFFBQVEsSUFBSSxDQUFDO0dBQzNELElBQUksT0FBTyxRQUFRLEdBQUcsUUFBUSxJQUFLLFFBQVEsSUFBSSxJQUFLLENBQUM7R0FDckQsSUFBSSxPQUFPLFFBQVEsSUFBSSxRQUFRLEdBQUcsUUFBUSxJQUFLLFFBQVEsSUFBSSxJQUFLLENBQUM7R0FDakUsSUFBSSxPQUFPO0dBRVgsSUFBSSxRQUFRO0VBQ2Q7Q0FDRjs7Q0FHQSxNQUFNLHVCQUF1QixTQUFpQixZQUFvQjtFQUNoRSxNQUFNLFNBQVMsZ0JBQWdCO0VBQy9CLE1BQU0sTUFBTSxZQUFZO0VBQ3hCLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxPQUFPO0VBRTVCLE1BQU0sT0FBTyxPQUFPLHNCQUFzQjtFQUMxQyxNQUFNLFNBQVMsT0FBTyxRQUFRLEtBQUs7RUFDbkMsTUFBTSxTQUFTLE9BQU8sU0FBUyxLQUFLO0VBRXBDLE1BQU0sVUFBVSxVQUFVLEtBQUssUUFBUTtFQUN2QyxNQUFNLFVBQVUsVUFBVSxLQUFLLE9BQU87O0VBR3RDLE1BQU0sVUFBVSxVQUFVLE9BQU8sUUFBUSxJQUFJLFVBQVUsTUFBTTtFQUM3RCxNQUFNLFVBQVUsVUFBVSxPQUFPLFNBQVMsSUFBSSxVQUFVLE1BQU07RUFFOUQsTUFBTSxTQUFTLElBQUksUUFBUSxJQUFJO0VBQy9CLElBQUksVUFBVTtFQUNkLElBQUksVUFBVSxNQUFNO0VBQ3BCLElBQUksVUFBVSxLQUFLO0dBQ2pCLFVBQVU7R0FDVixVQUFVLE1BQU07RUFDbEI7RUFFQSxNQUFNLFFBQVEsQ0FBQyxVQUFVO0VBQ3pCLE1BQU0sUUFBUSxDQUFDLFVBQVU7RUFFekIsTUFBTSxTQUFTLFNBQVMsU0FBUztFQUNqQyxNQUFNLFNBQVMsU0FBUyxTQUFTO0VBRWpDLE1BQU0sT0FBTyxRQUFRLElBQUk7RUFDekIsTUFBTSxPQUFPLFFBQVEsSUFBSTtFQUV6QixPQUFPO0dBQ0w7R0FDQTtHQUNBO0dBQ0E7R0FDQSxVQUFVLFNBQVMsS0FBSyxTQUFTLEtBQUssU0FBUyxLQUFLLFNBQVM7RUFDL0Q7Q0FDRjs7Q0FHQSxNQUFNLHlCQUF5QixNQUEyQztFQUN4RSxJQUFJLGtCQUFrQixlQUFlLFVBQVUsRUFBRSxXQUFXLEdBQUc7R0FDN0QsYUFBYSxJQUFJO0dBQ2pCLFlBQVk7SUFBRSxHQUFHLEVBQUUsVUFBVSxVQUFVO0lBQUcsR0FBRyxFQUFFLFVBQVUsVUFBVTtHQUFFLENBQUM7R0FDdEU7RUFDRjtFQUVBLE1BQU0sU0FBUyxvQkFBb0IsRUFBRSxTQUFTLEVBQUUsT0FBTztFQUN2RCxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sVUFBVTs7RUFHakMsSUFBSSxlQUFlLGtCQUFrQjtHQUNuQyxrQkFBa0IsSUFBSTtHQUN0QixzQkFBc0I7SUFBRSxHQUFHLE9BQU87SUFBTyxHQUFHLE9BQU87R0FBTSxDQUFDO0dBQzFELGdCQUFnQjtJQUFFLEdBQUcsT0FBTztJQUFPLEdBQUcsT0FBTztJQUFPLEdBQUc7SUFBTSxHQUFHO0dBQUssQ0FBQztHQUN0RSxnQkFBZ0IsV0FBVztFQUM3QixPQUFPLElBQUksZUFBZSxjQUFjO0dBQ3RDLG9CQUFvQixPQUFPLE1BQU0sT0FBTyxJQUFJO0VBQzlDLE9BQU8sSUFBSSxlQUFlLFlBQVk7R0FDcEMsSUFBSSxVQUFVLFVBQVUsS0FBSyxDQUFDLGNBQWM7SUFDMUMsTUFBTSxRQUFRLFVBQVU7SUFDeEIsTUFBTSxPQUFPLEtBQUssTUFBTSxPQUFPLFFBQVEsTUFBTSxHQUFHLE9BQU8sUUFBUSxNQUFNLENBQUM7SUFDdEUsSUFBSSxPQUFPLEtBQU07S0FDZixnQkFBZ0IsSUFBSTtLQUNwQjtJQUNGO0dBQ0Y7R0FDQSxJQUFJLENBQUMsY0FBYztJQUNqQixjQUFhLFNBQVEsQ0FBQyxHQUFHLE1BQU07S0FBRSxHQUFHLE9BQU87S0FBTyxHQUFHLE9BQU87SUFBTSxDQUFDLENBQUM7R0FDdEU7RUFDRixPQUFPLElBQUksZUFBZSxpQkFBaUI7R0FDekMsa0JBQWtCLE9BQU8sTUFBTSxPQUFPLE1BQU0sU0FBUztFQUN2RCxPQUFPLElBQUksZUFBZSxnQkFBZ0I7R0FDeEMsa0JBQWtCLE9BQU8sTUFBTSxPQUFPLE1BQU0sUUFBUTtFQUN0RCxPQUFPLElBQUksZUFBZSxnQkFBZ0I7R0FDeEMsa0JBQWtCLE9BQU8sTUFBTSxPQUFPLE1BQU0sS0FBSztFQUNuRCxPQUFPLElBQUksZUFBZSxRQUFRO0dBQ2hDLElBQUksRUFBRSxRQUFRO0lBQ1osZUFBYyxTQUFRLEtBQUssSUFBSSxJQUFLLE9BQU8sRUFBRyxDQUFDO0dBQ2pELE9BQU87SUFDTCxlQUFjLFNBQVEsS0FBSyxJQUFJLEdBQUssT0FBTyxFQUFHLENBQUM7R0FDakQ7RUFDRjtDQUNGOztDQUdBLE1BQU0seUJBQXlCLE1BQTJDO0VBQ3hFLElBQUksV0FBVztHQUNiLGFBQWE7SUFDWCxHQUFHLEVBQUUsVUFBVSxTQUFTO0lBQ3hCLEdBQUcsRUFBRSxVQUFVLFNBQVM7R0FDMUIsQ0FBQztHQUNEO0VBQ0Y7RUFFQSxJQUFJLGtCQUFrQixzQkFBc0IsZUFBZSxrQkFBa0I7R0FDM0UsTUFBTSxTQUFTLG9CQUFvQixFQUFFLFNBQVMsRUFBRSxPQUFPO0dBQ3ZELElBQUksUUFBUTtJQUNWLE1BQU0sT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksR0FBRyxPQUFPLEtBQUssQ0FBQztJQUNsRCxNQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEdBQUcsT0FBTyxLQUFLLENBQUM7SUFDbEQsTUFBTSxPQUFPLEtBQUssSUFBSSxtQkFBbUIsR0FBRyxJQUFJO0lBQ2hELE1BQU0sT0FBTyxLQUFLLElBQUksbUJBQW1CLEdBQUcsSUFBSTtJQUNoRCxNQUFNLE9BQU8sS0FBSyxJQUFJLEtBQU0sS0FBSyxJQUFJLE9BQU8sbUJBQW1CLENBQUMsQ0FBQztJQUNqRSxNQUFNLE9BQU8sS0FBSyxJQUFJLEtBQU0sS0FBSyxJQUFJLE9BQU8sbUJBQW1CLENBQUMsQ0FBQztJQUNqRSxnQkFBZ0I7S0FBRSxHQUFHO0tBQU0sR0FBRztLQUFNLEdBQUc7S0FBTSxHQUFHO0lBQUssQ0FBQztHQUN4RDtHQUNBO0VBQ0Y7RUFFQSxJQUFJLGVBQWUsY0FBYyxVQUFVLFVBQVUsS0FBSyxDQUFDLGNBQWM7R0FDdkUsTUFBTSxTQUFTLG9CQUFvQixFQUFFLFNBQVMsRUFBRSxPQUFPO0dBQ3ZELElBQUksUUFBUTtJQUNWLE1BQU0sUUFBUSxVQUFVO0lBQ3hCLE1BQU0sT0FBTyxLQUFLLE1BQU0sT0FBTyxRQUFRLE1BQU0sR0FBRyxPQUFPLFFBQVEsTUFBTSxDQUFDO0lBQ3RFLG9CQUFvQixPQUFPLEdBQUk7R0FDakM7RUFDRjtDQUNGOztDQUdBLE1BQU0sNEJBQTRCO0VBQ2hDLGFBQWEsS0FBSztFQUNsQixrQkFBa0IsS0FBSztFQUN2QixzQkFBc0IsSUFBSTtDQUM1Qjs7Q0FHQSxNQUFNLHFCQUFxQixNQUEyQztFQUNwRSxFQUFFLGVBQWU7RUFDakIsTUFBTSxhQUFhLEVBQUUsU0FBUyxJQUFJLE9BQU87RUFDekMsZUFBYyxTQUFRLEtBQUssSUFBSSxJQUFLLEtBQUssSUFBSSxHQUFLLE9BQU8sVUFBVSxDQUFDLENBQUM7Q0FDdkU7Ozs7Q0FLQSxNQUFNLDBCQUEwQjtFQUM5QixNQUFNLFNBQVMscUJBQXFCO0VBQ3BDLE1BQU0sTUFBTSxZQUFZO0VBQ3hCLElBQUksQ0FBQyxRQUFRO0VBRWIsTUFBTSxNQUFNLE9BQU8sV0FBVyxJQUFJO0VBQ2xDLElBQUksQ0FBQyxLQUFLO0VBRVYsT0FBTyxRQUFRO0VBQ2YsT0FBTyxTQUFTOztFQUdoQixJQUFJLFlBQVk7RUFDaEIsSUFBSSxTQUFTLEdBQUcsR0FBRyxPQUFPLE9BQU8sT0FBTyxNQUFNO0VBRTlDLElBQUksQ0FBQyxLQUFLO0dBQ1IsSUFBSSxZQUFZO0dBQ2hCLElBQUksT0FBTztHQUNYLElBQUksWUFBWTtHQUNoQixJQUFJLFNBQVMsc0JBQXNCLE9BQU8sUUFBUSxHQUFHLE9BQU8sU0FBUyxDQUFDO0dBQ3RFO0VBQ0Y7O0VBR0EsTUFBTSxPQUFPLFlBQVksV0FBVyxJQUFJO0VBQ3hDLE1BQU0sT0FBTyxnQkFBZ0Isa0JBQWtCLElBQUksT0FBUSxXQUFXLEtBQUssSUFBSSxJQUFLO0VBQ3BGLE1BQU0sT0FBTyxnQkFBZ0Isa0JBQWtCLElBQUksT0FBTyxJQUFJO0VBRTlELE1BQU0sTUFBTTtFQUNaLE1BQU0sU0FBUztFQUNmLE1BQU0sU0FBUyxPQUFPLFFBQVEsU0FBUyxLQUFLLE9BQU8sS0FBSyxPQUFPO0VBQy9ELE1BQU0sUUFBUSxTQUFTLEtBQUs7RUFFNUIsSUFBSSxRQUFRO0VBQ1osS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sS0FBSztHQUM3QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxLQUFLO0lBQzdCLElBQUksU0FBUyxRQUFRO0lBQ3JCLE1BQU0sSUFBSSxTQUFTLEtBQUssUUFBUTtJQUNoQyxNQUFNLElBQUksU0FBUyxLQUFLLFFBQVE7O0lBR2hDLElBQUksWUFBWTtJQUNoQixJQUFJLFNBQVMsR0FBRyxHQUFHLE9BQU8sS0FBSzs7SUFHL0IsSUFBSSxVQUFVLEtBQUssR0FBRyxHQUFHLE9BQU8sS0FBSzs7SUFHckMsSUFBSSxjQUFjO0lBQ2xCLElBQUksWUFBWTtJQUNoQixJQUFJLFdBQVcsR0FBRyxHQUFHLE9BQU8sS0FBSztJQUVqQztHQUNGO0VBQ0Y7Q0FDRjs7OztDQUtBLE1BQU0sd0JBQXdCO0VBQzVCLE1BQU0sU0FBUyxtQkFBbUI7RUFDbEMsTUFBTSxNQUFNLFlBQVk7RUFDeEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLO0VBRXJCLE1BQU0sTUFBTSxPQUFPLFdBQVcsSUFBSTtFQUNsQyxJQUFJLENBQUMsS0FBSztFQUVWLE9BQU8sUUFBUTtFQUNmLE9BQU8sU0FBUztFQUVoQixJQUFJLFlBQVk7RUFDaEIsSUFBSSxTQUFTLEdBQUcsR0FBRyxhQUFhLFlBQVk7O0VBRzVDLE1BQU0sVUFBVTtFQUNoQixNQUFNLFVBQVU7RUFDaEIsTUFBTSxlQUFlLFNBQVMsY0FBYyxRQUFRO0VBQ3BELGFBQWEsUUFBUTtFQUNyQixhQUFhLFNBQVM7RUFDdEIsTUFBTSxPQUFPLGFBQWEsV0FBVyxJQUFJO0VBRXpDLElBQUksTUFBTTtHQUNSLEtBQUssWUFBWTtHQUNqQixLQUFLLFNBQVMsR0FBRyxHQUFHLFNBQVMsT0FBTzs7R0FHcEMsTUFBTSxnQkFBZ0IsTUFBTSxjQUFjLGFBQWEsSUFBSSxLQUFNLFdBQVc7R0FDNUUsTUFBTSxjQUFjLE1BQU0sWUFBWSxhQUFhLElBQUk7R0FDdkQsTUFBTSxnQkFBZ0IsY0FBYyxJQUFJLE1BQU0sY0FBYyxhQUFhLElBQUk7R0FFN0UsSUFBSSxZQUFZLGNBQWMsY0FBYyxjQUFjLFlBQVksY0FBYyxjQUFjO0dBQ2xHLElBQUksYUFBYSxhQUFhO0dBQzlCLEtBQUssU0FBUztHQUVkLE1BQU0sU0FBUyxJQUFJLFFBQVEsSUFBSTtHQUMvQixJQUFJLEtBQUs7R0FDVCxJQUFJLEtBQUs7R0FDVCxJQUFJLFNBQVMsVUFBVSxTQUFTO0lBQzlCLEtBQUssVUFBVTtHQUNqQixPQUFPO0lBQ0wsS0FBSyxVQUFVO0dBQ2pCO0dBRUEsS0FBSyxVQUFVLE1BQU0sVUFBVSxNQUFNLElBQUksVUFBVSxNQUFNLEdBQUcsSUFBSSxFQUFFOztHQUdsRSxJQUFJLGdCQUFnQixhQUFhLElBQUksUUFBUyxhQUFhLElBQUksTUFBTztJQUNwRSxNQUFNLFFBQVEsVUFBVSxNQUFNLElBQUksYUFBYSxJQUFJO0lBQ25ELE1BQU0sUUFBUSxVQUFVLE1BQU0sSUFBSSxhQUFhLElBQUk7SUFDbkQsTUFBTSxPQUFPLGFBQWEsSUFBSTtJQUM5QixNQUFNLE9BQU8sYUFBYSxJQUFJO0lBRTlCLEtBQUssS0FBSztJQUNWLEtBQUssVUFBVTtJQUNmLEtBQUssS0FBSyxNQUFNLE1BQU0sTUFBTSxJQUFJO0lBQ2hDLEtBQUssS0FBSztJQUVWLE1BQU0sZUFBZSxnQkFBZ0I7SUFDckMsTUFBTSxhQUFhLGNBQWM7SUFDakMsTUFBTSxZQUFZLGNBQWMsSUFBSSxnQkFBZ0I7SUFFcEQsS0FBSyxTQUFTLGNBQWMsYUFBYSxjQUFjLFdBQVcsY0FBYyxVQUFVO0lBQzFGLEtBQUssVUFBVSxNQUFNLFVBQVUsTUFBTSxJQUFJLFVBQVUsTUFBTSxHQUFHLElBQUksRUFBRTtJQUVsRSxJQUFJLGNBQWMsS0FBSyxDQUFDLGFBQWE7S0FDbkMsS0FBSywyQkFBMkI7S0FDaEMsS0FBSyxZQUFZLFlBQVksSUFDekIsc0JBQXNCLEtBQUssSUFBSSxLQUFPLFlBQVksTUFBTyxFQUFHLEVBQUUsS0FDOUQsc0JBQXNCLEtBQUssSUFBSSxLQUFPLEtBQUssSUFBSSxTQUFTLElBQUksTUFBTyxFQUFHLEVBQUU7S0FDNUUsS0FBSyxTQUFTLE1BQU0sTUFBTSxNQUFNLElBQUk7SUFDdEM7SUFDQSxLQUFLLFFBQVE7R0FDZjs7R0FHQSxNQUFNLFlBQVksYUFBYSxLQUFLLElBQUksWUFBWSxFQUFFLElBQUk7R0FDMUQsTUFBTSxVQUFVLGFBQWEsS0FBSyxJQUFJLFVBQVUsRUFBRSxJQUFJO0dBQ3RELElBQUksWUFBWSxLQUFLLFVBQVUsR0FBRztJQUNoQyxLQUFLLEtBQUs7SUFDVixLQUFLLDJCQUEyQjtJQUNoQyxLQUFLLGNBQWMsS0FBSyxJQUFJLEtBQU8sWUFBWSxPQUFVLFVBQVUsR0FBSztJQUN4RSxLQUFLLFNBQVMsUUFBUSxLQUFLLElBQUksR0FBRyxZQUFZLENBQUMsRUFBRTtJQUNqRCxLQUFLLFVBQVUsTUFBTSxVQUFVLE1BQU0sSUFBSSxVQUFVLE1BQU0sR0FBRyxJQUFJLEVBQUU7SUFDbEUsS0FBSyxRQUFRO0dBQ2Y7O0dBR0EsSUFBSSxjQUFjO0lBQ2hCLE1BQU0sT0FBTztJQUNiLEtBQUssWUFBWTtJQUNqQixLQUFLLFNBQVMsR0FBRyxVQUFVLE1BQU0sU0FBUyxJQUFJO0lBQzlDLEtBQUssWUFBWTtJQUNqQixLQUFLLE9BQU87SUFDWixLQUFLLFlBQVk7SUFDakIsS0FBSyxTQUFTLGNBQWMsWUFBWSxHQUFHLFVBQVUsR0FBRyxVQUFVLE9BQU8sRUFBRTtJQUMzRSxLQUFLLE9BQU87SUFDWixLQUFLLFNBQVMsU0FBUyxhQUFhLFVBQVUsR0FBRyxVQUFVLE9BQU8sRUFBRTtJQUNwRSxLQUFLLGNBQWM7SUFDbkIsS0FBSyxZQUFZO0lBQ2pCLEtBQUssVUFBVTtJQUNmLEtBQUssT0FBTyxHQUFHLFVBQVUsSUFBSTtJQUM3QixLQUFLLE9BQU8sU0FBUyxVQUFVLElBQUk7SUFDbkMsS0FBSyxPQUFPO0dBQ2Q7R0FFQSxLQUFLLGNBQWM7R0FDbkIsS0FBSyxZQUFZO0dBQ2pCLEtBQUssV0FBVyxHQUFHLEdBQUcsU0FBUyxPQUFPO0VBQ3hDOztFQUdBLE1BQU0sT0FBTyxnQkFBZ0Isa0JBQWtCLElBQUksZ0JBQWdCLGlCQUFrQixXQUFXLEtBQUssSUFBSSxJQUFLO0VBQzlHLE1BQU0sT0FBTyxnQkFBZ0Isa0JBQWtCLElBQUk7RUFFbkQsTUFBTSxPQUFPLFlBQVksV0FBVyxJQUFJO0VBQ3hDLE1BQU0sVUFBVSxPQUFPLEtBQUs7RUFDNUIsTUFBTSxVQUFVLE9BQU8sS0FBSztFQUM1QixNQUFNLGFBQWEsY0FBYyxVQUFVO0VBQzNDLE1BQU0sYUFBYSxlQUFlLFVBQVU7RUFFNUMsTUFBTSxNQUFNLE9BQU8sS0FBSztFQUN4QixNQUFNLFdBQVcsY0FBYyxPQUFPLEtBQUssT0FBTztFQUNsRCxJQUFJLFFBQVE7RUFDWixJQUFJLFFBQVEsV0FBVyxLQUFLO0VBRTVCLElBQUksT0FBTyxTQUFTLE9BQU8sS0FBSyxNQUFNLFlBQVk7R0FDaEQsU0FBUyxjQUFjLE9BQU8sS0FBSyxPQUFPO0dBQzFDLFFBQVEsU0FBUyxLQUFLO0VBQ3hCO0VBRUEsTUFBTSxPQUFPLE9BQU8sS0FBSyxhQUFhLE9BQU8sVUFBVSxPQUFPLEtBQUs7RUFDbkUsTUFBTSxPQUFPLE9BQU8sS0FBSyxhQUFhLE9BQU8sVUFBVSxPQUFPLEtBQUs7RUFFbkUsSUFBSSxRQUFRO0VBQ1osS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sS0FBSztHQUM3QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxLQUFLO0lBQzdCLElBQUksU0FBUyxRQUFRO0lBQ3JCLE1BQU0sSUFBSSxVQUFVLEtBQUssUUFBUTtJQUNqQyxNQUFNLElBQUksVUFBVSxLQUFLLFFBQVE7SUFFakMsSUFBSSxVQUFVLGNBQWMsR0FBRyxHQUFHLE9BQU8sS0FBSztJQUM5QyxJQUFJLGNBQWM7SUFDbEIsSUFBSSxZQUFZO0lBQ2hCLElBQUksV0FBVyxHQUFHLEdBQUcsT0FBTyxLQUFLO0lBQ2pDO0dBQ0Y7RUFDRjs7RUFHQSxJQUFJLEtBQUs7RUFDVCxJQUFJLGNBQWM7RUFDbEIsSUFBSSxZQUFZO0VBQ2hCLElBQUksWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0VBQ3RCLElBQUksVUFBVTtFQUNkLElBQUksT0FBTyxJQUFJLGVBQWUsQ0FBQztFQUMvQixJQUFJLE9BQU8sY0FBYyxJQUFJLGVBQWUsQ0FBQztFQUM3QyxJQUFJLE9BQU87RUFDWCxJQUFJLFFBQVE7Q0FDZDs7Q0FHQSxNQUFNLGdCQUFnQixNQUEyQztFQUMvRCxNQUFNLE9BQU8sRUFBRSxPQUFPLFFBQVE7RUFDOUIsSUFBSSxDQUFDLE1BQU07RUFFWCxNQUFNLFNBQVMsSUFBSSxXQUFXO0VBQzlCLE9BQU8sVUFBVSxVQUFVO0dBQ3pCLE1BQU0sTUFBTSxNQUFNLFFBQVE7R0FDMUIsWUFBWSxHQUFHO0dBQ2Ysb0JBQW9CLEdBQUc7R0FDdkIsZ0JBQWdCLENBQUMsR0FBRyxDQUFDO0dBQ3JCLGdCQUFnQixDQUFDO0dBQ2pCLGNBQWMsQ0FBRztHQUNqQixhQUFhO0lBQUUsR0FBRztJQUFHLEdBQUc7R0FBRSxDQUFDO0dBQzNCLGFBQWEsQ0FBQyxDQUFDO0dBQ2YsZ0JBQWdCLEtBQUs7R0FDckIsY0FBYyxJQUFJO0dBQ2xCLGdCQUFnQixhQUFhO0VBQy9CO0VBQ0EsT0FBTyxjQUFjLElBQUk7RUFDekIsRUFBRSxPQUFPLFFBQVE7Q0FDbkI7O0NBR0EsTUFBTSwwQkFBMEI7RUFDOUIsTUFBTSxTQUFTLG1CQUFtQjtFQUNsQyxJQUFJLENBQUMsUUFBUTtFQUViLElBQUk7R0FDRixNQUFNLFVBQVUsT0FBTyxVQUFVLGNBQWMsQ0FBRztHQUNsRCxnQkFBZ0IsU0FBUztJQUN2QjtJQUNBLE9BQU8sWUFBWSxZQUFZLEdBQUcsT0FBTztJQUN6QyxhQUFhO0dBQ2YsQ0FBQztHQUVELGNBQWMsdUNBQXVDLFlBQVksUUFBUSxLQUFLLEdBQUcsQ0FBQyxDQUFDLFlBQVksRUFBRSxLQUFLLE9BQU8sU0FBUztHQUN0SCxpQkFBaUIsY0FBYyxJQUFJLEdBQUcsR0FBSTtFQUM1QyxTQUFTLEdBQUc7R0FDVixRQUFRLE1BQU0sQ0FBQztHQUNmLE9BQU8sTUFBTTtFQUNmO0NBQ0Y7O0NBR0EsTUFBTSwrQkFBK0I7RUFDbkMsTUFBTSxTQUFTLG1CQUFtQjtFQUNsQyxJQUFJLENBQUMsUUFBUTtFQUViLElBQUk7R0FDRixNQUFNLFVBQVUsT0FBTyxVQUFVLGNBQWMsR0FBSTtHQUNuRCxNQUFNLGNBQWMsWUFBWSxTQUFTLFdBQVc7R0FDcEQsTUFBTSxPQUFPLFlBQVksV0FBVyxJQUFJO0dBRXhDLE1BQU0sTUFBTSxJQUFJLE1BQU07SUFDcEIsYUFBYSxjQUFjLGNBQWM7SUFDekMsTUFBTSxPQUFPLE9BQU87SUFDcEIsUUFBUSxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUM7R0FDN0IsQ0FBQztHQUVELElBQUksTUFBTTtJQUNSLElBQUksU0FBUyxTQUFTLFFBQVEsR0FBRyxHQUFHLGNBQWMsTUFBTSxLQUFLLGNBQWMsTUFBTSxHQUFHO0dBQ3RGLE9BQU87SUFDTCxJQUFJLFNBQVMsU0FBUyxRQUFRLEdBQUcsR0FBRyxjQUFjLElBQUksR0FBRyxjQUFjLElBQUksQ0FBQztHQUM5RTtHQUVBLE1BQU0sV0FBVyxZQUFZLFlBQVksR0FBRyxPQUFPLFVBQVUsS0FBSyxJQUFJLEVBQUU7R0FDeEUsSUFBSSxLQUFLLFFBQVE7R0FFakIsa0JBQWtCO0lBQ2hCLElBQUksWUFBWSxLQUFLLElBQUk7SUFDekIsT0FBTztJQUNQLE1BQU07SUFDTixNQUFNLEdBQUcsWUFBWSxRQUFRLEtBQUssR0FBRyxFQUFFLElBQUksT0FBTztJQUNsRCxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsbUJBQW1CLE9BQU87R0FDbEQsQ0FBQztFQUNILFNBQVMsR0FBRztHQUNWLFFBQVEsTUFBTSxDQUFDO0VBQ2pCO0NBQ0Y7O0NBR0EsTUFBTSwrQkFBK0I7RUFDbkMsTUFBTSxTQUFTLG1CQUFtQjtFQUNsQyxJQUFJLENBQUMsUUFBUTtFQUViLElBQUk7R0FDRixNQUFNLFVBQVUsT0FBTyxVQUFVLGNBQWMsR0FBSTtHQUNuRCxNQUFNLElBQUksU0FBUyxjQUFjLEdBQUc7R0FDcEMsRUFBRSxPQUFPO0dBQ1QsTUFBTSxXQUFXLFlBQVksWUFBWSxHQUFHLE9BQU8saUJBQWlCLEtBQUssSUFBSSxFQUFFO0dBQy9FLEVBQUUsV0FBVztHQUNiLEVBQUUsTUFBTTtHQUVSLGtCQUFrQjtJQUNoQixJQUFJLFlBQVksS0FBSyxJQUFJO0lBQ3pCLE9BQU87SUFDUCxNQUFNO0lBQ04sTUFBTSxHQUFHLFlBQVksUUFBUSxLQUFLLEdBQUcsRUFBRSxJQUFJLE9BQU87SUFDbEQsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLG1CQUFtQixPQUFPO0dBQ2xELENBQUM7RUFDSCxTQUFTLEdBQUc7R0FDVixRQUFRLE1BQU0sQ0FBQztFQUNqQjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsVUFBRDtJQUFRLEtBQUs7SUFBb0IsV0FBVTtHQUFVOzs7OztHQUdwRCxjQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsY0FBRCxFQUFjLFdBQVUseUNBQTBDOzs7O2VBQ2xFLHdCQUFDLFFBQUQsWUFBTyxXQUFpQjs7OzthQUNyQjs7Ozs7Y0FDTCx3QkFBQyxVQUFEO0tBQVEsZUFBZSxjQUFjLElBQUk7S0FBRyxXQUFVO2VBQW9DO0lBQVM7Ozs7WUFDaEc7Ozs7OztHQUlQLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FFRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCO1NBQ0csZUFBZSxZQUFZLHdCQUFDLFFBQUQsWUFBTSxpQkFBb0I7Ozs7O1NBQ3JELGVBQWUsb0JBQW9CLHdCQUFDLFFBQUQsWUFBTSx3Q0FBMkM7Ozs7O1NBQ3BGLGVBQWUsZ0JBQWdCLHdCQUFDLFFBQUQsWUFBTSx3QkFBMkI7Ozs7O1NBQ2hFLGVBQWUsY0FBYyx3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7OztTQUN6RCxlQUFlLFVBQVUsd0JBQUMsUUFBRCxZQUFNLHVCQUEwQjs7Ozs7U0FDekQsZUFBZSxtQkFBbUIsd0JBQUMsUUFBRCxZQUFNLHNCQUF5Qjs7Ozs7U0FDakUsZUFBZSxrQkFBa0Isd0JBQUMsUUFBRCxZQUFNLHdCQUEyQjs7Ozs7U0FDbEUsZUFBZSxrQkFBa0Isd0JBQUMsUUFBRCxZQUFNLDZCQUFnQzs7Ozs7U0FDdkUsZUFBZSxVQUFVLHdCQUFDLFFBQUQsWUFBTSxpQkFBb0I7Ozs7O1NBQ25ELGVBQWUsVUFBVSx3QkFBQyxRQUFELFlBQU0sY0FBaUI7Ozs7O1FBQzdDOzs7Ozs7TUFDSDs7Ozs7TUFHSixlQUFlLG9CQUNkLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQTJDO1FBQWM7Ozs7O1FBQ3pFLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZSxtQkFBbUIsTUFBTTtTQUN4QyxXQUFVO21CQUNYO1FBRU87Ozs7O1FBQ1Isd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxlQUFlLG1CQUFtQixTQUFTO1NBQzNDLFdBQVU7bUJBQ1g7UUFFTzs7Ozs7UUFDUix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWUsbUJBQW1CLE1BQU07U0FDeEMsV0FBVTttQkFDWDtRQUVPOzs7OztRQUNSLHdCQUFDLFVBQUQ7U0FDRSxNQUFLO1NBQ0wsZUFBZSxtQkFBbUIsTUFBTTtTQUN4QyxXQUFVO21CQUNYO1FBRU87Ozs7O1FBRVAsZ0JBQ0M7U0FDRSx3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLFNBQVM7VUFDVCxXQUFVO1VBQ1YsT0FBTTtvQkFDUDtTQUVPOzs7OztTQUNSLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsU0FBUztVQUNULFdBQVU7VUFDVixPQUFNO29CQUpSLENBTUUsd0JBQUMsT0FBRCxFQUFPLFdBQVUsY0FBZTs7OztvQkFDaEMsd0JBQUMsUUFBRCxZQUFNLGVBQWtCOzs7O2tCQUNsQjs7Ozs7O1NBQ1Isd0JBQUMsVUFBRDtVQUNFLE1BQUs7VUFDTCxTQUFTO1VBQ1QsV0FBVTtvQkFDWDtTQUVPOzs7OztRQUNSOzs7OztPQUVEOzs7Ozs7TUFJTixlQUFlLGdCQUNkLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWlCO1FBQWdCOzs7OztRQUNqRCx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLEtBQUk7U0FDSixLQUFJO1NBQ0osT0FBTztTQUNQLFdBQVcsTUFBTSxrQkFBa0IsT0FBTyxFQUFFLE9BQU8sS0FBSyxDQUFDO1NBQ3pELFdBQVU7U0FDVixPQUFNO1FBQ1A7Ozs7O1FBQ0Qsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWtDO1FBQXFCOzs7OztRQUV2RSx3QkFBQyxVQUFEO1NBQ0UsU0FBUztTQUNULFVBQVUsZ0JBQWdCLENBQUM7U0FDM0IsV0FBVTtTQUNWLE9BQU07bUJBSlIsQ0FNRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7O21CQUNuQyx3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7O2lCQUN0Qjs7Ozs7O09BQ0w7Ozs7OztNQUlOLGVBQWUsY0FDZCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQjtVQUNHLFVBQVU7VUFBTztVQUFTLGVBQWUsa0JBQWtCO1NBQ3hEOzs7Ozs7UUFFTCxDQUFDLGdCQUFnQixVQUFVLFVBQVUsS0FDcEMsd0JBQUMsVUFBRDtTQUNFLGVBQWUsZ0JBQWdCLElBQUk7U0FDbkMsV0FBVTttQkFDWDtRQUVPOzs7OztRQUdULFVBQVUsVUFBVSxLQUNuQix3QkFBQyxVQUFEO1NBQ0UsU0FBUztTQUNULFdBQVU7bUJBRlosQ0FJRSx3QkFBQyxPQUFELEVBQU8sV0FBVSxjQUFlOzs7O21CQUNoQyx3QkFBQyxRQUFELFlBQU0sZUFBa0I7Ozs7aUJBQ2xCOzs7Ozs7UUFHVix3QkFBQyxVQUFEO1NBQ0UsZUFBZTtVQUFFLGFBQWEsQ0FBQyxDQUFDO1VBQUcsZ0JBQWdCLEtBQUs7U0FBRztTQUMzRCxXQUFVO21CQUNYO1FBRU87Ozs7O09BQ0w7Ozs7OztNQUlOLGVBQWUsVUFDZCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFxRTtRQUUvRTs7Ozs7UUFDTix3QkFBQyxVQUFEO1NBQ0UsU0FBUztTQUNULFdBQVU7bUJBQ1g7UUFFTzs7Ozs7UUFDUix3QkFBQyxVQUFEO1NBQ0UsZUFBZTtVQUFFLFdBQVcsSUFBSTtVQUFHLGNBQWMsUUFBUTtTQUFHO1NBQzVELFdBQVU7bUJBQ1g7UUFFTzs7Ozs7T0FDTDs7Ozs7O09BSUwsZUFBZSxtQkFBbUIsZUFBZSxrQkFBa0IsZUFBZSxtQkFDbEYsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaUI7UUFBaUI7Ozs7O1FBQ2xELHdCQUFDLFNBQUQ7U0FDRSxNQUFLO1NBQ0wsS0FBSTtTQUNKLEtBQUk7U0FDSixPQUFPO1NBQ1AsV0FBVyxNQUFNLGFBQWEsT0FBTyxFQUFFLE9BQU8sS0FBSyxDQUFDO1NBQ3BELFdBQVU7UUFDWDs7Ozs7UUFDRCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEIsQ0FBa0QsV0FBVSxJQUFROzs7Ozs7UUFDcEUsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQTZCO1FBQTJCOzs7OztPQUNyRTs7Ozs7O01BSVAsd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxTQUFTO09BQ1QsVUFBVSxnQkFBZ0IsQ0FBQztPQUMzQixXQUFVO09BQ1YsT0FBTTtpQkFMUixDQU9FLHdCQUFDLFVBQUQsRUFBVSxXQUFVLDZCQUE4Qjs7OztpQkFDbEQsd0JBQUMsUUFBRCxZQUFNLHNCQUF5Qjs7OztlQUN6Qjs7Ozs7O01BR1Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaUI7T0FBUzs7OztpQkFDekM7UUFDQztTQUFFLE1BQU07U0FBUyxPQUFPO1FBQVU7UUFDbEM7U0FBRSxNQUFNO1NBQVksT0FBTztRQUFVO1FBQ3JDO1NBQUUsTUFBTTtTQUFlLE9BQU87UUFBVTtRQUN4QztTQUFFLE1BQU07U0FBUSxPQUFPO1FBQVU7UUFDakM7U0FBRSxNQUFNO1NBQU8sT0FBTztRQUFVO1FBQ2hDO1NBQUUsTUFBTTtTQUFzQixPQUFPO1FBQWM7T0FDckQsQ0FBQyxDQUFDLEtBQUssTUFDTCx3QkFBQyxVQUFEO1FBRUUsZUFBZSxXQUFXLEVBQUUsS0FBSztRQUNqQyxXQUFXLDhEQUNULFlBQVksRUFBRSxRQUFRLCtDQUErQyxtQ0FDdEUsR0FBRyxFQUFFLFVBQVUsZ0JBQWdCLHNPQUFzTztRQUN0USxPQUFPLEVBQUUsVUFBVSxnQkFBZ0IsRUFBRSxpQkFBaUIsRUFBRSxNQUFNLElBQUksQ0FBQztRQUNuRSxPQUFPLCtCQUErQixFQUFFO09BQ3pDLEdBUE0sRUFBRTs7OztjQU9SLENBQ0YsQ0FDRTs7Ozs7O0tBQ0Y7Ozs7O2NBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUVFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRDtRQUNFLFNBQVM7UUFDVCxVQUFVLGdCQUFnQixLQUFLLFVBQVUsV0FBVztRQUNwRCxXQUFVO1FBQ1YsT0FBTTtrQkFFTix3QkFBQyxPQUFELEVBQU8sV0FBVSxjQUFlOzs7OztPQUMxQjs7OztpQkFDUix3QkFBQyxVQUFEO1FBQ0UsU0FBUztRQUNULFVBQVUsZ0JBQWdCLGFBQWEsU0FBUztRQUNoRCxXQUFVO1FBQ1YsT0FBTTtrQkFFTix3QkFBQyxPQUFELEVBQU8sV0FBVSxjQUFlOzs7OztPQUMxQjs7OztlQUNMOzs7Ozs7TUFHTCx3QkFBQyxVQUFEO09BQ0UsZUFBZSxvQkFBbUIsU0FBUSxDQUFDLElBQUk7T0FDL0MsV0FBVywrRkFDVCxrQkFBa0IsaURBQWlEO09BRXJFLE9BQU07aUJBTFIsQ0FPRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxjQUFlOzs7O2lCQUNqQyx3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7O2VBQ3RCOzs7Ozs7TUFHUix3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFdBQVU7T0FDVixPQUFNO2lCQUhSLENBS0Usd0JBQUMsU0FBRCxFQUFTLFdBQVUseUJBQTBCOzs7O2lCQUM3Qyx3QkFBQyxRQUFELFlBQU0sMkJBQThCOzs7O2VBQzlCOzs7Ozs7S0FDTDs7Ozs7WUFDRjs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUVFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BRUc7UUFDQztTQUFFLElBQUk7U0FBVSxPQUFPO1NBQXNCLE1BQU07UUFBSztRQUN4RDtTQUFFLElBQUk7U0FBa0IsT0FBTztTQUE4QixNQUFNO1FBQUs7UUFDeEU7U0FBRSxJQUFJO1NBQVcsT0FBTztTQUE4QixNQUFNO1FBQUk7UUFDaEU7U0FBRSxJQUFJO1NBQVEsT0FBTztTQUFxQixNQUFNO1FBQUs7UUFDckQ7U0FBRSxJQUFJO1NBQWMsT0FBTztTQUF3QixNQUFNO1FBQUs7UUFDOUQ7U0FBRSxJQUFJO1NBQVksT0FBTztTQUF1QixNQUFNO1FBQU07UUFDNUQ7U0FBRSxJQUFJO1NBQWlCLE9BQU87U0FBMEIsTUFBTTtRQUFLO1FBQ25FO1NBQUUsSUFBSTtTQUFnQixPQUFPO1NBQXFCLE1BQU07UUFBSTtRQUM1RDtTQUFFLElBQUk7U0FBZ0IsT0FBTztTQUEwQixNQUFNO1FBQU07UUFDbkU7U0FBRSxJQUFJO1NBQVEsT0FBTztTQUE2QixNQUFNO1FBQUk7UUFDNUQ7U0FBRSxJQUFJO1NBQVEsT0FBTztTQUFpQixNQUFNO1FBQUs7T0FDbkQsQ0FBQyxDQUFDLEtBQUssTUFBTTtRQUNYLE1BQU0sV0FBVyxlQUFlLEVBQUU7UUFDbEMsT0FDRSx3QkFBQyxVQUFEO1NBRUUsZUFBZTtVQUNiLElBQUksRUFBRSxPQUFPLFdBQVc7V0FDdEIsMEJBQTBCO1dBQzFCO1VBQ0Y7VUFDQSxjQUFjLEVBQUUsRUFBZ0I7VUFDaEMsSUFBSSxFQUFFLE9BQU8sUUFBUSxZQUFZO1VBQ2pDLElBQUksRUFBRSxPQUFPLGtCQUFrQjtXQUM3QixnQkFBZ0IsV0FBVztXQUMzQixJQUFJLENBQUMsY0FBYyxtQkFBbUIsTUFBTTtVQUM5QztTQUNGO1NBQ0EsV0FBVyxnRkFDVCxXQUNJLHVGQUNBO1NBRU4sT0FBTyxFQUFFO21CQUVULHdCQUFDLFFBQUQsWUFBTyxFQUFFLEtBQVc7Ozs7O1FBQ2QsR0FyQkQsRUFBRTs7OztlQXFCRDtPQUVaLENBQUM7T0FFRCx3QkFBQyxPQUFELEVBQUssV0FBVSxxREFBc0Q7Ozs7O09BR3JFLHdCQUFDLFNBQUQ7UUFBTyxXQUFVO1FBQTZLLE9BQU07a0JBQXBNLENBQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7OztrQkFDN0Isd0JBQUMsU0FBRDtTQUFPLE1BQUs7U0FBTyxRQUFPO1NBQVUsVUFBVTtTQUFjLFdBQVU7UUFBVTs7OztnQkFDM0U7Ozs7OztNQUNKOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVyxHQUFHLGtCQUFrQixrQkFBa0IsaUJBQWlCO2dCQUF4RTtPQUVFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXVCO1NBQTZCOzs7OztTQUNwRSx3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7U0FDYix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FBb0QsS0FBSyxNQUFNLGFBQWEsR0FBRyxHQUFFLEdBQU87Ozs7OztTQUN4Rix3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7U0FDYix3QkFBQyxRQUFELFlBQU0sOENBQWlEOzs7OztRQUNwRDs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ2Isd0JBQUMsVUFBRDtTQUNFLEtBQUs7U0FDTCxhQUFhO1NBQ2IsYUFBYTtTQUNiLFdBQVc7U0FDWCxjQUFjO1NBQ2QsU0FBUztTQUNULFdBQVcsZ0VBQ1Qsa0JBQWtCLGVBQWUsU0FDN0IsdUNBQ0EsZUFBZSxnQkFBZ0IsZUFBZSxhQUM5QyxxQkFDQSxlQUFlLG1CQUFtQixlQUFlLGtCQUFrQixlQUFlLGlCQUNsRixnQkFDQTtRQUVQOzs7OztPQUNFOzs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFELGFBQU0sVUFBTSx3QkFBQyxVQUFEO1VBQVEsV0FBVTtvQkFBd0IsV0FBVyxRQUFRLEtBQUssR0FBRztTQUFVOzs7O2lCQUFPOzs7O21CQUNqRyxZQUNDLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLGNBQWU7Ozs7b0JBQUMsOEJBQzdCOzs7OztpQkFFTDs7Ozs7a0JBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxVQUFEO1dBQ0UsZUFBZTtZQUFFLGNBQWMsQ0FBRztZQUFHLGFBQWE7YUFBRSxHQUFHO2FBQUcsR0FBRztZQUFFLENBQUM7V0FBRztXQUNuRSxXQUFVO3FCQUNYO1VBRU87Ozs7O1VBQ1Isd0JBQUMsVUFBRDtXQUNFLGVBQWUsZUFBYyxTQUFRLEtBQUssSUFBSSxHQUFLLE9BQU8sR0FBSSxDQUFDO1dBQy9ELFdBQVU7cUJBQ1g7VUFFTzs7Ozs7VUFDUix3QkFBQyxVQUFEO1dBQ0UsZUFBZSxlQUFjLFNBQVEsS0FBSyxJQUFJLElBQUssT0FBTyxHQUFJLENBQUM7V0FDL0QsV0FBVTtxQkFDWDtVQUVPOzs7OztTQUNMOzs7OztnQkFDRjs7Ozs7O01BQ0Y7Ozs7OztLQUdKLG1CQUNDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BRUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQW9DO1dBQXdCOzs7O3FCQUM1RSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFDYixnQkFBZ0Isa0JBQWtCLFlBQVk7V0FDM0M7Ozs7bUJBQ0g7Ozs7O29CQUNMLHdCQUFDLFVBQUQ7V0FDRSxlQUFlLG1CQUFtQixLQUFLO1dBQ3ZDLFdBQVU7V0FDVixPQUFNO3FCQUVOLHdCQUFDLFdBQUQsRUFBVyxXQUFVLGNBQWU7Ozs7O1VBQzlCOzs7O2tCQUNMOzs7Ozs7U0FHTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDYix3QkFBQyxVQUFEO1dBQ0UsS0FBSztXQUNMLE9BQU87V0FDUCxRQUFRO1dBQ1IsV0FBVTtVQUNYOzs7OztTQUNFOzs7OztTQUdMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsVUFBRDtXQUNFLGVBQWU7WUFBRSxlQUFlLGVBQWU7WUFBRyxVQUFVLENBQUM7V0FBRztXQUNoRSxXQUFXLHVFQUNULGdCQUFnQixrQkFDWixrQ0FDQTtxQkFFUDtVQUVPOzs7O29CQUNSLHdCQUFDLFVBQUQ7V0FDRSxlQUFlO1lBQUUsZUFBZSxjQUFjO1lBQUcsVUFBVSxFQUFFO1dBQUc7V0FDaEUsV0FBVyx1RUFDVCxnQkFBZ0IsaUJBQ1osb0NBQ0E7cUJBRVA7VUFFTzs7OztrQkFDTDs7Ozs7O1NBR0wsd0JBQUMsVUFBRDtVQUNFLFNBQVM7VUFDVCxXQUFVO29CQUZaLENBSUUsd0JBQUMsU0FBRCxFQUFTLFdBQVUsY0FBZTs7OztvQkFDbEMsd0JBQUMsUUFBRCxZQUFNLHNCQUF5Qjs7OztrQkFDekI7Ozs7OztRQUNMOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsNkJBQThCOzs7O29CQUNsRCx3QkFBQyxRQUFELFlBQU0sc0JBQXlCOzs7O2tCQUMzQjs7Ozs7bUJBQ04sd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTZFO1NBRXZGOzs7O2lCQUNIOzs7OztrQkFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWixlQUFlLEtBQUssTUFBTTtVQUN6QixNQUFNLGFBQWEsaUJBQWlCLEVBQUUsTUFBTTtVQUM1QyxPQUNFLHdCQUFDLFVBQUQ7V0FFRSxlQUFlO1lBQ2IsZ0JBQWdCLEVBQUUsRUFBRTtZQUNwQixjQUFjLEVBQUUsU0FBUyxVQUFVO1lBQ25DLFlBQVksRUFBRSxTQUFTLFFBQVE7WUFDL0IsY0FBYyxFQUFFLFNBQVMsVUFBVTtZQUNuQyxVQUFVLEVBQUUsU0FBUyxNQUFNO1lBQzNCLFFBQVEsRUFBRSxTQUFTLElBQUk7WUFDdkIsY0FBYyxFQUFFLFNBQVMsVUFBVTtZQUNuQyxZQUFZLEVBQUUsU0FBUyxRQUFRO1lBQy9CLGNBQWMsRUFBRSxTQUFTLFVBQVU7WUFDbkMsZUFBZSxFQUFFLFNBQVMsV0FBVztZQUNyQyxjQUFjLElBQUk7V0FDcEI7V0FDQSxXQUFXLGtEQUNULGFBQ0ksNEVBQ0E7cUJBR04sd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU8sRUFBRSxLQUFXOzs7O3NCQUNwQix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBWSxFQUFFO1lBQVc7Ozs7b0JBQ3RDOzs7Ozs7VUFDQyxHQXhCRCxFQUFFOzs7O2lCQXdCRDtTQUVaLENBQUM7UUFDRTs7OztnQkFDRjs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUNFLHdCQUFDLFNBQUQsRUFBUyxXQUFVLDRCQUE2Qjs7OztxQkFDaEQsd0JBQUMsUUFBRCxZQUFNLHVCQUEwQjs7OzttQkFDNUI7Ozs7O29CQUNOLHdCQUFDLFVBQUQ7V0FDRSxlQUFlO1lBQ2IsSUFBSSxpQkFBaUIsYUFBYTthQUNoQyxpQkFBaUIsQ0FBQzthQUNsQixlQUFlLENBQUM7YUFDaEIsaUJBQWlCLENBQUM7YUFDbEIsYUFBYSxDQUFDO2FBQ2QsYUFBYSxDQUFDO1lBQ2hCLE9BQU87YUFDTCxjQUFjLENBQUM7YUFDZixZQUFZLENBQUM7YUFDYixjQUFjLENBQUM7YUFDZixVQUFVLENBQUM7YUFDWCxRQUFRLENBQUM7YUFDVCxjQUFjLENBQUM7YUFDZixZQUFZLENBQUM7YUFDYixlQUFlLEtBQUs7WUFDdEI7V0FDRjtXQUNBLFdBQVU7cUJBQ1g7VUFFTzs7OztrQkFDTDs7Ozs7O1NBR0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1dBQ0UsTUFBSztXQUNMLGVBQWUsZ0JBQWdCLE1BQU07V0FDckMsV0FBVywwRkFDVCxpQkFBaUIsU0FDYixrQ0FDQTtxQkFHTix3QkFBQyxRQUFELFlBQU0saUJBQW9COzs7OztVQUNwQjs7OztvQkFDUix3QkFBQyxVQUFEO1dBQ0UsTUFBSztXQUNMLGVBQWU7WUFDYixnQkFBZ0IsV0FBVztZQUMzQixJQUFJLENBQUMsY0FBYyxtQkFBbUIsTUFBTTtZQUM1QyxjQUFjLGdCQUFnQjtXQUNoQztXQUNBLFdBQVcsMEZBQ1QsaUJBQWlCLGNBQ2Isb0ZBQ0E7cUJBR04sd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7Ozs7VUFDckI7Ozs7a0JBQ0w7Ozs7OztTQUdKLGlCQUFpQixjQUVoQjtVQUFDOztVQUFEO1dBQUssV0FBVTtxQkFBZjtZQUNFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQStCO2FBRXpDOzs7O3VCQUNMLGVBQ0Msd0JBQUMsVUFBRDtjQUNFLE1BQUs7Y0FDTCxTQUFTO2NBQ1QsV0FBVTt3QkFDWDthQUVPOzs7O3dCQUVSLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUE2QjthQUF1Qjs7OztxQkFFbkU7Ozs7OztZQUdMLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmO2NBQ0Usd0JBQUMsVUFBRDtlQUNFLE1BQUs7ZUFDTCxlQUFlLG1CQUFtQixNQUFNO2VBQ3hDLFdBQVU7eUJBQ1g7Y0FFTzs7Ozs7Y0FDUix3QkFBQyxVQUFEO2VBQ0UsTUFBSztlQUNMLGVBQWUsbUJBQW1CLFNBQVM7ZUFDM0MsV0FBVTt5QkFDWDtjQUVPOzs7OztjQUNSLHdCQUFDLFVBQUQ7ZUFDRSxNQUFLO2VBQ0wsZUFBZSxtQkFBbUIsTUFBTTtlQUN4QyxXQUFVO3lCQUNYO2NBRU87Ozs7O2NBQ1Isd0JBQUMsVUFBRDtlQUNFLE1BQUs7ZUFDTCxlQUFlLG1CQUFtQixNQUFNO2VBQ3hDLFdBQVU7eUJBQ1g7Y0FFTzs7Ozs7YUFDTDs7Ozs7O1lBR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQWhCLENBQ0Usd0JBQUMsS0FBRCxFQUFLLFdBQVUsY0FBZTs7Ozt3QkFBQyxxQkFDM0I7Ozs7O3VCQUNOLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFoQixDQUF3QyxnQkFBZ0IsSUFBSSxJQUFJLGtCQUFrQixlQUFjLEdBQU87Ozs7O3FCQUNwRzs7Ozs7c0JBQ0wsd0JBQUMsU0FBRDthQUNFLE1BQUs7YUFDTCxLQUFJO2FBQ0osS0FBSTthQUNKLE9BQU87YUFDUCxXQUFXLE1BQU0saUJBQWlCLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQzthQUN4RCxXQUFVO1lBQ1g7Ozs7b0JBQ0U7Ozs7O1lBR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQWhCLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsY0FBZTs7Ozt3QkFBQyxtQkFDaEM7Ozs7O3VCQUNOLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFoQixDQUF3QyxjQUFjLElBQUksSUFBSSxnQkFBZ0IsYUFBWSxHQUFPOzs7OztxQkFDOUY7Ozs7O3NCQUNMLHdCQUFDLFNBQUQ7YUFDRSxNQUFLO2FBQ0wsS0FBSTthQUNKLEtBQUk7YUFDSixPQUFPO2FBQ1AsV0FBVyxNQUFNLGVBQWUsT0FBTyxFQUFFLE9BQU8sS0FBSyxDQUFDO2FBQ3RELFdBQVU7WUFDWDs7OztvQkFDRTs7Ozs7WUFHTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDthQUFLLFdBQVU7dUJBQWYsQ0FDRSx3QkFBQyxRQUFEO2NBQU0sV0FBVTt3QkFBaEIsQ0FDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSxjQUFlOzs7O3dCQUFDLHdCQUM3Qjs7Ozs7dUJBQ04sd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQXdCLFlBQVksSUFBSSxJQUFJLGNBQWM7YUFBZ0I7Ozs7cUJBQ3ZGOzs7OztzQkFDTCx3QkFBQyxTQUFEO2FBQ0UsTUFBSzthQUNMLEtBQUk7YUFDSixLQUFJO2FBQ0osT0FBTzthQUNQLFdBQVcsTUFBTSxhQUFhLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQzthQUNwRCxXQUFVO1lBQ1g7Ozs7b0JBQ0U7Ozs7O1lBR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQWhCLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsY0FBZTs7Ozt3QkFBQyxxQkFDaEM7Ozs7O3VCQUNOLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFoQixDQUF3QyxnQkFBZ0IsSUFBSSxJQUFJLGtCQUFrQixlQUFjLEdBQU87Ozs7O3FCQUNwRzs7Ozs7c0JBQ0wsd0JBQUMsU0FBRDthQUNFLE1BQUs7YUFDTCxLQUFJO2FBQ0osS0FBSTthQUNKLE9BQU87YUFDUCxXQUFXLE1BQU0saUJBQWlCLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQzthQUN4RCxXQUFVO1lBQ1g7Ozs7b0JBQ0U7Ozs7O1lBR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQWhCLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsY0FBZTs7Ozt3QkFBQyxxQkFDaEM7Ozs7O3VCQUNOLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFoQixDQUF3QyxXQUFVLEdBQU87Ozs7O3FCQUN0RDs7Ozs7c0JBQ0wsd0JBQUMsU0FBRDthQUNFLE1BQUs7YUFDTCxLQUFJO2FBQ0osS0FBSTthQUNKLE9BQU87YUFDUCxXQUFXLE1BQU0sYUFBYSxPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7YUFDcEQsV0FBVTtZQUNYOzs7O29CQUNFOzs7OztZQUdMLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsVUFBRDtjQUNFLE1BQUs7Y0FDTCxTQUFTO2NBQ1QsVUFBVSxDQUFDLGdCQUFnQjtjQUMzQixXQUFVO3dCQUpaLENBTUUsd0JBQUMsT0FBRCxFQUFPLFdBQVUsY0FBZTs7Ozt3QkFDaEMsd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7OztzQkFDckI7Ozs7O3VCQUNSLHdCQUFDLFVBQUQ7Y0FDRSxNQUFLO2NBQ0wsU0FBUztjQUNULFVBQVUsQ0FBQztjQUNYLFdBQVU7Y0FDVixPQUFNO3dCQUNQO2FBRU87Ozs7cUJBQ0w7Ozs7OztXQUNGOzs7Ozs7Ozs7Ozs7U0FHTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUVFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUErQjtZQUFvQjs7OztzQkFDbkUsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQWhCLENBQXdDLFlBQVcsR0FBTzs7Ozs7b0JBQ3ZEOzs7OztxQkFDTCx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLEtBQUk7WUFDSixLQUFJO1lBQ0osT0FBTztZQUNQLFdBQVcsTUFBTSxjQUFjLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQztZQUNyRCxXQUFVO1dBQ1g7Ozs7bUJBQ0U7Ozs7O1dBR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLGFBQWdCOzs7O3NCQUN0Qix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBaEIsQ0FBd0MsYUFBYSxJQUFJLElBQUksZUFBZSxZQUFXLEdBQU87Ozs7O29CQUMzRjs7Ozs7cUJBQ0wsd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxLQUFJO1lBQ0osS0FBSTtZQUNKLE9BQU87WUFDUCxXQUFXLE1BQU0sY0FBYyxPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7WUFDckQsV0FBVTtXQUNYOzs7O21CQUNFOzs7OztXQUdMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxXQUFjOzs7O3NCQUNwQix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBaEIsQ0FBd0MsV0FBVyxJQUFJLElBQUksYUFBYSxVQUFTLEdBQU87Ozs7O29CQUNyRjs7Ozs7cUJBQ0wsd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxLQUFJO1lBQ0osS0FBSTtZQUNKLE9BQU87WUFDUCxXQUFXLE1BQU0sWUFBWSxPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7WUFDbkQsV0FBVTtXQUNYOzs7O21CQUNFOzs7OztXQUdMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxnQkFBbUI7Ozs7c0JBQ3pCLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUF3QixTQUFTLElBQUksSUFBSSxXQUFXO1lBQWE7Ozs7b0JBQzlFOzs7OztxQkFDTCx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLEtBQUk7WUFDSixLQUFJO1lBQ0osT0FBTztZQUNQLFdBQVcsTUFBTSxVQUFVLE9BQU8sRUFBRSxPQUFPLEtBQUssQ0FBQztZQUNqRCxXQUFVO1dBQ1g7Ozs7bUJBQ0U7Ozs7O1VBQ0Y7Ozs7OztTQUlQLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQWpCLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQTJCO1dBQTRCOzs7O3FCQUN2RSx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLFNBQVM7WUFDVCxXQUFXLE1BQU0sZ0JBQWdCLEVBQUUsT0FBTyxPQUFPO1lBQ2pELFdBQVU7V0FDWDs7OzttQkFDSTs7Ozs7b0JBQ04sZ0JBQ0Msd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1lBQ0UsTUFBSztZQUNMLGFBQVk7WUFDWixPQUFPO1lBQ1AsV0FBVyxNQUFNLGlCQUFpQixFQUFFLE9BQU8sS0FBSztZQUNoRCxXQUFVO1dBQ1g7Ozs7cUJBQ0Qsd0JBQUMsU0FBRDtZQUNFLE1BQUs7WUFDTCxhQUFZO1lBQ1osT0FBTztZQUNQLFdBQVcsTUFBTSxhQUFhLEVBQUUsT0FBTyxLQUFLO1lBQzVDLFdBQVU7V0FDWDs7OzttQkFDRTs7Ozs7a0JBRUo7Ozs7OztRQUNGOzs7Ozs7TUFDRjs7Ozs7O0lBRUo7Ozs7OztFQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQYXNzcG9ydFN0dWRpb1ZpZXcudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlUmVmLCB1c2VFZmZlY3QsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgXG4gIFVwbG9hZCwgXG4gIFByaW50ZXIsIFxuICBEb3dubG9hZCwgXG4gIFNwYXJrbGVzLCBcbiAgUm90YXRlQ3csIFxuICBab29tSW4sIFxuICBab29tT3V0LFxuICBQYWxldHRlLCBcbiAgQ2FsZW5kYXIsIFxuICBTdW4sIFxuICBDb250cmFzdCwgXG4gIENoZWNrQ2lyY2xlMiwgXG4gIFNjaXNzb3JzLFxuICBXYW5kMixcbiAgU2xpZGVycyxcbiAgRmxhbWUsXG4gIERyb3BsZXRzLFxuICBSb3RhdGVDY3csXG4gIENoZWNrLFxuICBQZW5Ub29sLFxuICBNb3ZlLFxuICBVbmRvMixcbiAgUmVkbzIsXG4gIFRyYXNoMixcbiAgRXllLFxuICBMYXllcnMsXG4gIEhlbHBDaXJjbGUsXG4gIFgsXG4gIE1heGltaXplMixcbiAgTWluaW1pemUyLFxuICBDcm9wLFxuICBQYWludGJydXNoLFxuICBTcGFya2xlLFxuICBJbWFnZSBhcyBJbWFnZUljb24sXG4gIENoZWNrU3F1YXJlXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBqc1BERiB9IGZyb20gJ2pzcGRmJztcbmltcG9ydCB7IGFkZERvd25sb2FkUmVjb3JkIH0gZnJvbSAnLi4vdXRpbHMvc3RvcmFnZSc7XG5pbXBvcnQgeyBwcmludEltYWdlU2hlZXQgfSBmcm9tICcuLi91dGlscy9wcmludGVyJztcblxudHlwZSBQYXBlckZvcm1hdCA9ICc0eDZfbGFuZHNjYXBlJyB8ICdhNF9sYW5kc2NhcGUnIHwgJzR4Nl9wb3J0cmFpdCcgfCAnYTRfcG9ydHJhaXQnO1xudHlwZSBBY3RpdmVUb29sID0gJ3NlbGVjdCcgfCAnc2VjdGlvbl9zZWxlY3QnIHwgJ21hZ2ljX3dhbmQnIHwgJ3Blbl90b29sJyB8ICdjcm9wJyB8ICdibGVtaXNoX2JydXNoJyB8ICdiZWF1dHlfYnJ1c2gnIHwgJ2V5ZV9icmlnaHRlbicgfCAnaGFuZCcgfCAnem9vbSc7XG5cbmludGVyZmFjZSBQb2ludCB7XG4gIHg6IG51bWJlcjtcbiAgeTogbnVtYmVyO1xufVxuXG5pbnRlcmZhY2UgQmVhdXR5UHJlc2V0IHtcbiAgaWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICBpY29uOiBzdHJpbmc7XG4gIGRlc2M6IHN0cmluZztcbiAgc2V0dGluZ3M6IHtcbiAgICBicmlnaHRuZXNzOiBudW1iZXI7XG4gICAgY29udHJhc3Q6IG51bWJlcjtcbiAgICBzYXR1cmF0aW9uOiBudW1iZXI7XG4gICAgd2FybXRoOiBudW1iZXI7XG4gICAgdGludDogbnVtYmVyO1xuICAgIHNraW5TbW9vdGg6IG51bWJlcjtcbiAgICBmYWNlR2xvdzogbnVtYmVyO1xuICAgIHNoYWRvd0xpZnQ6IG51bWJlcjtcbiAgICBpc0dyYXlzY2FsZTogYm9vbGVhbjtcbiAgfTtcbn1cblxuY29uc3QgQkVBVVRZX1BSRVNFVFM6IEJlYXV0eVByZXNldFtdID0gW1xuICB7XG4gICAgaWQ6ICdhdXRvX2JlYXV0eScsXG4gICAgbmFtZTogJ0F1dG8gU3R1ZGlvIEJlYXV0eScsXG4gICAgaWNvbjogJ+KcqCcsXG4gICAgZGVzYzogJ1Ntb290aCBza2luICYgcmFkaWFudCBmYWNpYWwgbGlnaHRpbmcnLFxuICAgIHNldHRpbmdzOiB7XG4gICAgICBicmlnaHRuZXNzOiA4LFxuICAgICAgY29udHJhc3Q6IDYsXG4gICAgICBzYXR1cmF0aW9uOiAxMixcbiAgICAgIHdhcm10aDogOCxcbiAgICAgIHRpbnQ6IDQsXG4gICAgICBza2luU21vb3RoOiAyMCxcbiAgICAgIGZhY2VHbG93OiAyNSxcbiAgICAgIHNoYWRvd0xpZnQ6IDE1LFxuICAgICAgaXNHcmF5c2NhbGU6IGZhbHNlXG4gICAgfVxuICB9LFxuICB7XG4gICAgaWQ6ICdpbmRpYW5fd2FybScsXG4gICAgbmFtZTogJ0luZGlhbiBTdHVkaW8gVG9uZScsXG4gICAgaWNvbjogJ/Cfk7gnLFxuICAgIGRlc2M6ICdHb2xkZW4gd2FybSBnbG93LCByZW1vdmVzIGNhbWVyYSBwYWxlIHRvbmUnLFxuICAgIHNldHRpbmdzOiB7XG4gICAgICBicmlnaHRuZXNzOiA2LFxuICAgICAgY29udHJhc3Q6IDgsXG4gICAgICBzYXR1cmF0aW9uOiAxNSxcbiAgICAgIHdhcm10aDogMTgsXG4gICAgICB0aW50OiAyLFxuICAgICAgc2tpblNtb290aDogMTYsXG4gICAgICBmYWNlR2xvdzogMjAsXG4gICAgICBzaGFkb3dMaWZ0OiAxMixcbiAgICAgIGlzR3JheXNjYWxlOiBmYWxzZVxuICAgIH1cbiAgfSxcbiAge1xuICAgIGlkOiAnZ2xhbW91cl9zb2Z0JyxcbiAgICBuYW1lOiAnU29mdCBHbGFtb3VyIEdsb3cnLFxuICAgIGljb246ICfwn4yfJyxcbiAgICBkZXNjOiAnQWlyYnJ1c2hlZCBwb3JjZWxhaW4gc2tpbiB3aXRoIHNvZnQgaGlnaGxpZ2h0cycsXG4gICAgc2V0dGluZ3M6IHtcbiAgICAgIGJyaWdodG5lc3M6IDEyLFxuICAgICAgY29udHJhc3Q6IDQsXG4gICAgICBzYXR1cmF0aW9uOiA4LFxuICAgICAgd2FybXRoOiAxMCxcbiAgICAgIHRpbnQ6IDYsXG4gICAgICBza2luU21vb3RoOiAzMixcbiAgICAgIGZhY2VHbG93OiAzNSxcbiAgICAgIHNoYWRvd0xpZnQ6IDIwLFxuICAgICAgaXNHcmF5c2NhbGU6IGZhbHNlXG4gICAgfVxuICB9LFxuICB7XG4gICAgaWQ6ICdjcmlzcF9mb3JtYWwnLFxuICAgIG5hbWU6ICdTaGFycCBGb3JtYWwgSUQnLFxuICAgIGljb246ICfwn5K8JyxcbiAgICBkZXNjOiAnTmV1dHJhbCB3aGl0ZSBiYWxhbmNlICYgY3Jpc3AgZmFjaWFsIGVkZ2VzJyxcbiAgICBzZXR0aW5nczoge1xuICAgICAgYnJpZ2h0bmVzczogNCxcbiAgICAgIGNvbnRyYXN0OiAxMixcbiAgICAgIHNhdHVyYXRpb246IDUsXG4gICAgICB3YXJtdGg6IDAsXG4gICAgICB0aW50OiAwLFxuICAgICAgc2tpblNtb290aDogOCxcbiAgICAgIGZhY2VHbG93OiAxMCxcbiAgICAgIHNoYWRvd0xpZnQ6IDgsXG4gICAgICBpc0dyYXlzY2FsZTogZmFsc2VcbiAgICB9XG4gIH0sXG4gIHtcbiAgICBpZDogJ2Nvb2xfY2xlYW4nLFxuICAgIG5hbWU6ICdDb29sIFdoaXRlIEJhbGFuY2UnLFxuICAgIGljb246ICfinYTvuI8nLFxuICAgIGRlc2M6ICdSZW1vdmVzIHllbGxvdy9vcmFuZ2UgbGlnaHRpbmcgY2FzdCcsXG4gICAgc2V0dGluZ3M6IHtcbiAgICAgIGJyaWdodG5lc3M6IDgsXG4gICAgICBjb250cmFzdDogOCxcbiAgICAgIHNhdHVyYXRpb246IDQsXG4gICAgICB3YXJtdGg6IC0xNCxcbiAgICAgIHRpbnQ6IC0yLFxuICAgICAgc2tpblNtb290aDogMTQsXG4gICAgICBmYWNlR2xvdzogMTUsXG4gICAgICBzaGFkb3dMaWZ0OiAxMCxcbiAgICAgIGlzR3JheXNjYWxlOiBmYWxzZVxuICAgIH1cbiAgfSxcbiAge1xuICAgIGlkOiAnYndfZm9ybWFsJyxcbiAgICBuYW1lOiAnQiZXIE9mZmljaWFsIEV4YW0nLFxuICAgIGljb246ICfwn5akJyxcbiAgICBkZXNjOiAnSGlnaCBjb250cmFzdCBtb25vY2hyb21lIGZvciBTU0MvVVBTQycsXG4gICAgc2V0dGluZ3M6IHtcbiAgICAgIGJyaWdodG5lc3M6IDYsXG4gICAgICBjb250cmFzdDogMTYsXG4gICAgICBzYXR1cmF0aW9uOiAwLFxuICAgICAgd2FybXRoOiAwLFxuICAgICAgdGludDogMCxcbiAgICAgIHNraW5TbW9vdGg6IDEyLFxuICAgICAgZmFjZUdsb3c6IDEwLFxuICAgICAgc2hhZG93TGlmdDogMTAsXG4gICAgICBpc0dyYXlzY2FsZTogdHJ1ZVxuICAgIH1cbiAgfVxuXTtcblxuZXhwb3J0IGNvbnN0IFBhc3Nwb3J0U3R1ZGlvVmlldzogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIC8vIE1haW4gU2hlZXQgQ2FudmFzIChIaWRkZW4gb3IgcmVuZGVyZWQgZm9yIDR4NiAvIEE0IHNoZWV0IGNhbGN1bGF0aW9uKVxuICBjb25zdCBmdWxsU2hlZXRDYW52YXNSZWYgPSB1c2VSZWY8SFRNTENhbnZhc0VsZW1lbnQgfCBudWxsPihudWxsKTtcbiAgXG4gIC8vIFBob3Rvc2hvcC1TdHlsZSBFZGl0aW5nIENhbnZhcyAoUHJpbWFyeSBpbnRlcmFjdGl2ZSB3b3Jrc3BhY2UpXG4gIGNvbnN0IGVkaXRvckNhbnZhc1JlZiA9IHVzZVJlZjxIVE1MQ2FudmFzRWxlbWVudCB8IG51bGw+KG51bGwpO1xuICBcbiAgLy8gTWluaSBQcmV2aWV3IENhbnZhcyAoQ29tcGFjdCBTaGVldCBQcmV2aWV3IHdpZGdldClcbiAgY29uc3QgbWluaVByZXZpZXdDYW52YXNSZWYgPSB1c2VSZWY8SFRNTENhbnZhc0VsZW1lbnQgfCBudWxsPihudWxsKTtcblxuICAvLyBBY3RpdmUgVG9vbCBTZWxlY3Rpb24gKFBob3Rvc2hvcCBUb29sYmFyKVxuICBjb25zdCBbYWN0aXZlVG9vbCwgc2V0QWN0aXZlVG9vbF0gPSB1c2VTdGF0ZTxBY3RpdmVUb29sPignc2VsZWN0Jyk7XG5cbiAgLy8gUGhvdG8gU291cmNlICYgSGlzdG9yeSBTdGFjayBmb3IgVW5kbyAvIFJlZG9cbiAgY29uc3QgW3Bob3RvU3JjLCBzZXRQaG90b1NyY10gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW29yaWdpbmFsUGhvdG9TcmMsIHNldE9yaWdpbmFsUGhvdG9TcmNdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IFtoaXN0b3J5U3RhY2ssIHNldEhpc3RvcnlTdGFja10gPSB1c2VTdGF0ZTxzdHJpbmdbXT4oW10pO1xuICBjb25zdCBbaGlzdG9yeUluZGV4LCBzZXRIaXN0b3J5SW5kZXhdID0gdXNlU3RhdGU8bnVtYmVyPigtMSk7XG5cbiAgY29uc3QgcGhvdG9JbWdSZWYgPSB1c2VSZWY8SFRNTEltYWdlRWxlbWVudCB8IG51bGw+KG51bGwpO1xuXG4gIC8vIFBhcGVyICYgTGF5b3V0IHNldHRpbmdzOiBEZWZhdWx0IGlzIDR4NiBMQU5EU0NBUEUgd2l0aCA4IENPUElFU1xuICBjb25zdCBbcGFwZXJGb3JtYXQsIHNldFBhcGVyRm9ybWF0XSA9IHVzZVN0YXRlPFBhcGVyRm9ybWF0PignNHg2X2xhbmRzY2FwZScpO1xuICBjb25zdCBbY29waWVzLCBzZXRDb3BpZXNdID0gdXNlU3RhdGU8bnVtYmVyPig4KTtcblxuICAvLyBTdHVkaW8gYmFja2dyb3VuZCByZXBsYWNlbWVudCBjb2xvclxuICBjb25zdCBbYmdDb2xvciwgc2V0QmdDb2xvcl0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcjZmZmZmZmJyk7XG5cbiAgLy8gTWluaSBQcmV2aWV3IFZpc2liaWxpdHkgU3RhdGUgKENvbGxhcHNpYmxlIC8gRXhwYW5kYWJsZSlcbiAgY29uc3QgW3Nob3dNaW5pUHJldmlldywgc2V0U2hvd01pbmlQcmV2aWV3XSA9IHVzZVN0YXRlPGJvb2xlYW4+KHRydWUpO1xuXG4gIC8vIEF1dG8gQmVhdXR5IE1vZGUgVG9nZ2xlXG4gIGNvbnN0IFthdXRvQmVhdXR5LCBzZXRBdXRvQmVhdXR5XSA9IHVzZVN0YXRlPGJvb2xlYW4+KHRydWUpO1xuICBjb25zdCBbYWN0aXZlUHJlc2V0LCBzZXRBY3RpdmVQcmVzZXRdID0gdXNlU3RhdGU8c3RyaW5nPignYXV0b19iZWF1dHknKTtcblxuICAvLyBDb2xvciBHcmFkaW5nIFBhcmFtZXRlcnNcbiAgY29uc3QgW2JyaWdodG5lc3MsIHNldEJyaWdodG5lc3NdID0gdXNlU3RhdGU8bnVtYmVyPig4KTtcbiAgY29uc3QgW2NvbnRyYXN0LCBzZXRDb250cmFzdF0gPSB1c2VTdGF0ZTxudW1iZXI+KDYpO1xuICBjb25zdCBbc2F0dXJhdGlvbiwgc2V0U2F0dXJhdGlvbl0gPSB1c2VTdGF0ZTxudW1iZXI+KDEyKTtcbiAgY29uc3QgW3dhcm10aCwgc2V0V2FybXRoXSA9IHVzZVN0YXRlPG51bWJlcj4oOCk7XG4gIGNvbnN0IFt0aW50LCBzZXRUaW50XSA9IHVzZVN0YXRlPG51bWJlcj4oNCk7XG4gIGNvbnN0IFtzaGFkb3dMaWZ0LCBzZXRTaGFkb3dMaWZ0XSA9IHVzZVN0YXRlPG51bWJlcj4oMTUpO1xuICBjb25zdCBbc2tpblNtb290aCwgc2V0U2tpblNtb290aF0gPSB1c2VTdGF0ZTxudW1iZXI+KDIwKTtcbiAgY29uc3QgW2ZhY2VHbG93LCBzZXRGYWNlR2xvd10gPSB1c2VTdGF0ZTxudW1iZXI+KDI1KTtcbiAgY29uc3QgW2lzR3JheXNjYWxlLCBzZXRJc0dyYXlzY2FsZV0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG5cbiAgLy8gQ2FudmFzIFZpZXdwb3J0IFBhbiAmIFpvb21cbiAgY29uc3QgW2NhbnZhc1pvb20sIHNldENhbnZhc1pvb21dID0gdXNlU3RhdGU8bnVtYmVyPigxLjApO1xuICBjb25zdCBbY2FudmFzUGFuLCBzZXRDYW52YXNQYW5dID0gdXNlU3RhdGU8eyB4OiBudW1iZXI7IHk6IG51bWJlciB9Pih7IHg6IDAsIHk6IDAgfSk7XG4gIGNvbnN0IFtpc1NwYWNlUHJlc3NlZCwgc2V0SXNTcGFjZVByZXNzZWRdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbaXNQYW5uaW5nLCBzZXRJc1Bhbm5pbmddID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbcGFuU3RhcnQsIHNldFBhblN0YXJ0XSA9IHVzZVN0YXRlPHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfT4oeyB4OiAwLCB5OiAwIH0pO1xuXG4gIC8vIFRvb2wgU3BlY2lmaWMgU3RhdGVzOlxuICAvLyAxLiBNYWdpYyBXYW5kIC8gTWFnaWMgQ3V0XG4gIGNvbnN0IFttYWdpY1RvbGVyYW5jZSwgc2V0TWFnaWNUb2xlcmFuY2VdID0gdXNlU3RhdGU8bnVtYmVyPigzMik7XG4gIGNvbnN0IFttYWdpY0ZlYXRoZXIsIHNldE1hZ2ljRmVhdGhlcl0gPSB1c2VTdGF0ZTxudW1iZXI+KDIpO1xuXG4gIC8vIDIuIFBlbiBUb29sIChNYW51YWwgVmVjdG9yIEN1dG91dClcbiAgY29uc3QgW3BlblBvaW50cywgc2V0UGVuUG9pbnRzXSA9IHVzZVN0YXRlPFBvaW50W10+KFtdKTtcbiAgY29uc3QgW2lzUGF0aENsb3NlZCwgc2V0SXNQYXRoQ2xvc2VkXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW2lzTmVhclN0YXJ0UG9pbnQsIHNldElzTmVhclN0YXJ0UG9pbnRdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbcGVuRmVhdGhlciwgc2V0UGVuRmVhdGhlcl0gPSB1c2VTdGF0ZTxudW1iZXI+KDIpO1xuXG4gIC8vIDMuIEJydXNoZXMgKEJsZW1pc2gsIEJlYXV0eSwgRXllIEJyaWdodGVuKVxuICBjb25zdCBbYnJ1c2hTaXplLCBzZXRCcnVzaFNpemVdID0gdXNlU3RhdGU8bnVtYmVyPigyNCk7XG4gIGNvbnN0IFtpc0JydXNoaW5nLCBzZXRJc0JydXNoaW5nXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcblxuICAvLyA0LiBDcm9wIFRvb2xcbiAgY29uc3QgW2Nyb3BCb3gsIHNldENyb3BCb3hdID0gdXNlU3RhdGU8eyB4OiBudW1iZXI7IHk6IG51bWJlcjsgdzogbnVtYmVyOyBoOiBudW1iZXIgfSB8IG51bGw+KG51bGwpO1xuXG4gIC8vIDUuIFNlY3Rpb24gU2VsZWN0aW9uICYgTG9jYWwgQ29sb3IgR3JhZGluZyBTdGF0ZVxuICBjb25zdCBbc2VsZWN0aW9uQm94LCBzZXRTZWxlY3Rpb25Cb3hdID0gdXNlU3RhdGU8eyB4OiBudW1iZXI7IHk6IG51bWJlcjsgdzogbnVtYmVyOyBoOiBudW1iZXIgfSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbaXNTZWxlY3RpbmdCb3gsIHNldElzU2VsZWN0aW5nQm94XSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW3NlbGVjdGlvblN0YXJ0Tm9ybSwgc2V0U2VsZWN0aW9uU3RhcnROb3JtXSA9IHVzZVN0YXRlPHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbZ3JhZGluZ1Njb3BlLCBzZXRHcmFkaW5nU2NvcGVdID0gdXNlU3RhdGU8J2Z1bGwnIHwgJ3NlbGVjdGlvbic+KCdmdWxsJyk7XG5cbiAgLy8gTG9jYWwgc2VjdGlvbiBjb2xvciBncmFkaW5nIHBhcmFtZXRlcnNcbiAgY29uc3QgW3NlY0JyaWdodG5lc3MsIHNldFNlY0JyaWdodG5lc3NdID0gdXNlU3RhdGU8bnVtYmVyPigxNSk7XG4gIGNvbnN0IFtzZWNDb250cmFzdCwgc2V0U2VjQ29udHJhc3RdID0gdXNlU3RhdGU8bnVtYmVyPigxMik7XG4gIGNvbnN0IFtzZWNXYXJtdGgsIHNldFNlY1dhcm10aF0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCBbc2VjU2F0dXJhdGlvbiwgc2V0U2VjU2F0dXJhdGlvbl0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCBbc2VjU21vb3RoLCBzZXRTZWNTbW9vdGhdID0gdXNlU3RhdGU8bnVtYmVyPigxNSk7XG4gIGNvbnN0IFtzZWNGZWF0aGVyLCBzZXRTZWNGZWF0aGVyXSA9IHVzZVN0YXRlPG51bWJlcj4oOCk7XG5cbiAgLy8gRXhhbSBOYW1lICYgRGF0ZSBvdmVybGF5IChmb3IgU1NDLCBQb2xpY2UgQmhhcnRpLCBVUFNDKVxuICBjb25zdCBbc2hvd05hbWVEYXRlLCBzZXRTaG93TmFtZURhdGVdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbY2FuZGlkYXRlTmFtZSwgc2V0Q2FuZGlkYXRlTmFtZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KCdDQU5ESURBVEUgTkFNRScpO1xuICBjb25zdCBbcGhvdG9EYXRlLCBzZXRQaG90b0RhdGVdID0gdXNlU3RhdGU8c3RyaW5nPihcbiAgICBuZXcgRGF0ZSgpLnRvTG9jYWxlRGF0ZVN0cmluZygnZW4tSU4nLCB7IGRheTogJzItZGlnaXQnLCBtb250aDogJzItZGlnaXQnLCB5ZWFyOiAnbnVtZXJpYycgfSlcbiAgKTtcblxuICBjb25zdCBbaXNQcm9jZXNzaW5nLCBzZXRJc1Byb2Nlc3NpbmddID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbcHJpbnRBbGVydCwgc2V0UHJpbnRBbGVydF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICAvLyAzMDAgRFBJIENhbnZhcyBEaW1lbnNpb25zIGZvciBmdWxsIHNoZWV0XG4gIGxldCBTSEVFVF9XSURUSCA9IDE4MDA7XG4gIGxldCBTSEVFVF9IRUlHSFQgPSAxMjAwO1xuXG4gIGlmIChwYXBlckZvcm1hdCA9PT0gJzR4Nl9sYW5kc2NhcGUnKSB7XG4gICAgU0hFRVRfV0lEVEggPSAxODAwO1xuICAgIFNIRUVUX0hFSUdIVCA9IDEyMDA7XG4gIH0gZWxzZSBpZiAocGFwZXJGb3JtYXQgPT09ICdhNF9sYW5kc2NhcGUnKSB7XG4gICAgU0hFRVRfV0lEVEggPSAzNTA4O1xuICAgIFNIRUVUX0hFSUdIVCA9IDI0ODA7XG4gIH0gZWxzZSBpZiAocGFwZXJGb3JtYXQgPT09ICc0eDZfcG9ydHJhaXQnKSB7XG4gICAgU0hFRVRfV0lEVEggPSAxMjAwO1xuICAgIFNIRUVUX0hFSUdIVCA9IDE4MDA7XG4gIH0gZWxzZSB7XG4gICAgU0hFRVRfV0lEVEggPSAyNDgwO1xuICAgIFNIRUVUX0hFSUdIVCA9IDM1MDg7XG4gIH1cblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIEtFWUJPQVJEIFNIT1JUQ1VUUyBMSVNURU5FUiAoUGhvdG9zaG9wIFN0YW5kYXJkOiBWLCBDLCBXLCBQLCBCLCBTLCBILCBaLCBDdHJsK1osIEN0cmwrUClcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGhhbmRsZUtleURvd24gPSAoZTogS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgICAgLy8gRG9uJ3QgdHJpZ2dlciBpZiB1c2VyIGlzIHR5cGluZyBpbiB0ZXh0IGlucHV0XG4gICAgICBpZiAoKGUudGFyZ2V0IGFzIEhUTUxFbGVtZW50KS50YWdOYW1lID09PSAnSU5QVVQnIHx8IChlLnRhcmdldCBhcyBIVE1MRWxlbWVudCkudGFnTmFtZSA9PT0gJ1RFWFRBUkVBJykge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIC8vIFNwYWNlYmFyIGZvciB0ZW1wb3JhcnkgSGFuZCBQYW4gdG9vbFxuICAgICAgaWYgKGUuY29kZSA9PT0gJ1NwYWNlJyAmJiAhZS5yZXBlYXQpIHtcbiAgICAgICAgc2V0SXNTcGFjZVByZXNzZWQodHJ1ZSk7XG4gICAgICB9XG5cbiAgICAgIC8vIFVuZG86IEN0cmwgKyBaXG4gICAgICBpZiAoZS5jdHJsS2V5ICYmIGUua2V5LnRvTG93ZXJDYXNlKCkgPT09ICd6JyAmJiAhZS5zaGlmdEtleSkge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGhhbmRsZVVuZG8oKTtcbiAgICAgIH1cblxuICAgICAgLy8gUmVkbzogQ3RybCArIFkgb3IgQ3RybCArIFNoaWZ0ICsgWlxuICAgICAgaWYgKChlLmN0cmxLZXkgJiYgZS5rZXkudG9Mb3dlckNhc2UoKSA9PT0gJ3knKSB8fCAoZS5jdHJsS2V5ICYmIGUuc2hpZnRLZXkgJiYgZS5rZXkudG9Mb3dlckNhc2UoKSA9PT0gJ3onKSkge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGhhbmRsZVJlZG8oKTtcbiAgICAgIH1cblxuICAgICAgLy8gVG9vbHMgU3dpdGNoZXIgU2hvcnRjdXRzOlxuICAgICAgaWYgKCFlLmN0cmxLZXkgJiYgIWUuYWx0S2V5ICYmICFlLm1ldGFLZXkpIHtcbiAgICAgICAgc3dpdGNoIChlLmtleS50b0xvd2VyQ2FzZSgpKSB7XG4gICAgICAgICAgY2FzZSAndic6IHNldEFjdGl2ZVRvb2woJ3NlbGVjdCcpOyBicmVhaztcbiAgICAgICAgICBjYXNlICdxJzogc2V0QWN0aXZlVG9vbCgnc2VjdGlvbl9zZWxlY3QnKTsgc2V0R3JhZGluZ1Njb3BlKCdzZWxlY3Rpb24nKTsgYnJlYWs7XG4gICAgICAgICAgY2FzZSAncic6IGhhbmRsZUF1dG9CYWNrZ3JvdW5kRXJhc2UoKTsgYnJlYWs7XG4gICAgICAgICAgY2FzZSAnYyc6IHNldEFjdGl2ZVRvb2woJ2Nyb3AnKTsgaW5pdENyb3BCb3goKTsgYnJlYWs7XG4gICAgICAgICAgY2FzZSAndyc6IHNldEFjdGl2ZVRvb2woJ21hZ2ljX3dhbmQnKTsgYnJlYWs7XG4gICAgICAgICAgY2FzZSAncCc6IHNldEFjdGl2ZVRvb2woJ3Blbl90b29sJyk7IGJyZWFrO1xuICAgICAgICAgIGNhc2UgJ2InOiBzZXRBY3RpdmVUb29sKCdibGVtaXNoX2JydXNoJyk7IGJyZWFrO1xuICAgICAgICAgIGNhc2UgJ3MnOiBzZXRBY3RpdmVUb29sKCdiZWF1dHlfYnJ1c2gnKTsgYnJlYWs7XG4gICAgICAgICAgY2FzZSAnZSc6IHNldEFjdGl2ZVRvb2woJ2V5ZV9icmlnaHRlbicpOyBicmVhaztcbiAgICAgICAgICBjYXNlICdoJzogc2V0QWN0aXZlVG9vbCgnaGFuZCcpOyBicmVhaztcbiAgICAgICAgICBjYXNlICd6Jzogc2V0QWN0aXZlVG9vbCgnem9vbScpOyBicmVhaztcbiAgICAgICAgICBjYXNlICdtJzogc2V0U2hvd01pbmlQcmV2aWV3KHByZXYgPT4gIXByZXYpOyBicmVhaztcbiAgICAgICAgICBjYXNlICdbJzogc2V0QnJ1c2hTaXplKHByZXYgPT4gTWF0aC5tYXgoOCwgcHJldiAtIDQpKTsgYnJlYWs7XG4gICAgICAgICAgY2FzZSAnXSc6IHNldEJydXNoU2l6ZShwcmV2ID0+IE1hdGgubWluKDgwLCBwcmV2ICsgNCkpOyBicmVhaztcbiAgICAgICAgICBjYXNlICdlc2NhcGUnOiBcbiAgICAgICAgICAgIGlmIChhY3RpdmVUb29sID09PSAncGVuX3Rvb2wnKSB7XG4gICAgICAgICAgICAgIHNldFBlblBvaW50cyhbXSk7XG4gICAgICAgICAgICAgIHNldElzUGF0aENsb3NlZChmYWxzZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoYWN0aXZlVG9vbCA9PT0gJ2Nyb3AnKSB7XG4gICAgICAgICAgICAgIHNldENyb3BCb3gobnVsbCk7XG4gICAgICAgICAgICAgIHNldEFjdGl2ZVRvb2woJ3NlbGVjdCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gWm9vbSBTaG9ydGN1dHM6IEN0cmwgKyAnKycgLyBDdHJsICsgJy0nIC8gQ3RybCArICcwJ1xuICAgICAgaWYgKGUuY3RybEtleSAmJiAoZS5rZXkgPT09ICc9JyB8fCBlLmtleSA9PT0gJysnKSkge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIHNldENhbnZhc1pvb20ocHJldiA9PiBNYXRoLm1pbig0LjAsIHByZXYgKyAwLjI1KSk7XG4gICAgICB9XG4gICAgICBpZiAoZS5jdHJsS2V5ICYmIChlLmtleSA9PT0gJy0nIHx8IGUua2V5ID09PSAnXycpKSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgc2V0Q2FudmFzWm9vbShwcmV2ID0+IE1hdGgubWF4KDAuNCwgcHJldiAtIDAuMjUpKTtcbiAgICAgIH1cbiAgICAgIGlmIChlLmN0cmxLZXkgJiYgZS5rZXkgPT09ICcwJykge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIHNldENhbnZhc1pvb20oMS4wKTtcbiAgICAgICAgc2V0Q2FudmFzUGFuKHsgeDogMCwgeTogMCB9KTtcbiAgICAgIH1cbiAgICB9O1xuXG4gICAgY29uc3QgaGFuZGxlS2V5VXAgPSAoZTogS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgICAgaWYgKGUuY29kZSA9PT0gJ1NwYWNlJykge1xuICAgICAgICBzZXRJc1NwYWNlUHJlc3NlZChmYWxzZSk7XG4gICAgICAgIHNldElzUGFubmluZyhmYWxzZSk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93bik7XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2tleXVwJywgaGFuZGxlS2V5VXApO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIGhhbmRsZUtleURvd24pO1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2tleXVwJywgaGFuZGxlS2V5VXApO1xuICAgIH07XG4gIH0sIFthY3RpdmVUb29sLCBoaXN0b3J5SW5kZXgsIGhpc3RvcnlTdGFja10pO1xuXG4gIC8vIFB1c2ggbmV3IHN0YXRlIHRvIHVuZG8vcmVkbyBoaXN0b3J5XG4gIGNvbnN0IHB1c2hUb0hpc3RvcnkgPSAobmV3U3JjOiBzdHJpbmcpID0+IHtcbiAgICBzZXRIaXN0b3J5U3RhY2socHJldiA9PiB7XG4gICAgICBjb25zdCB1cFRvQ3VycmVudCA9IHByZXYuc2xpY2UoMCwgaGlzdG9yeUluZGV4ICsgMSk7XG4gICAgICBjb25zdCB1cGRhdGVkID0gWy4uLnVwVG9DdXJyZW50LCBuZXdTcmNdO1xuICAgICAgaWYgKHVwZGF0ZWQubGVuZ3RoID4gMTUpIHVwZGF0ZWQuc2hpZnQoKTtcbiAgICAgIHJldHVybiB1cGRhdGVkO1xuICAgIH0pO1xuICAgIHNldEhpc3RvcnlJbmRleChwcmV2ID0+IE1hdGgubWluKDE0LCBwcmV2ICsgMSkpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVVuZG8gPSAoKSA9PiB7XG4gICAgaWYgKGFjdGl2ZVRvb2wgPT09ICdwZW5fdG9vbCcgJiYgcGVuUG9pbnRzLmxlbmd0aCA+IDApIHtcbiAgICAgIGlmIChpc1BhdGhDbG9zZWQpIHtcbiAgICAgICAgc2V0SXNQYXRoQ2xvc2VkKGZhbHNlKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNldFBlblBvaW50cyhwcmV2ID0+IHByZXYuc2xpY2UoMCwgLTEpKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoaGlzdG9yeUluZGV4ID4gMCkge1xuICAgICAgY29uc3QgbmV4dElkeCA9IGhpc3RvcnlJbmRleCAtIDE7XG4gICAgICBzZXRIaXN0b3J5SW5kZXgobmV4dElkeCk7XG4gICAgICBzZXRQaG90b1NyYyhoaXN0b3J5U3RhY2tbbmV4dElkeF0pO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVSZWRvID0gKCkgPT4ge1xuICAgIGlmIChoaXN0b3J5SW5kZXggPCBoaXN0b3J5U3RhY2subGVuZ3RoIC0gMSkge1xuICAgICAgY29uc3QgbmV4dElkeCA9IGhpc3RvcnlJbmRleCArIDE7XG4gICAgICBzZXRIaXN0b3J5SW5kZXgobmV4dElkeCk7XG4gICAgICBzZXRQaG90b1NyYyhoaXN0b3J5U3RhY2tbbmV4dElkeF0pO1xuICAgIH1cbiAgfTtcblxuICAvLyBMb2FkIHBob3RvIGludG8gSW1hZ2Ugb2JqZWN0XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHBob3RvU3JjKSB7XG4gICAgICBjb25zdCBpbWcgPSBuZXcgSW1hZ2UoKTtcbiAgICAgIGltZy5jcm9zc09yaWdpbiA9ICdhbm9ueW1vdXMnO1xuICAgICAgaW1nLm9ubG9hZCA9ICgpID0+IHtcbiAgICAgICAgcGhvdG9JbWdSZWYuY3VycmVudCA9IGltZztcbiAgICAgICAgcmVuZGVyRWRpdG9yQ2FudmFzKCk7XG4gICAgICAgIHJlbmRlck1pbmlQcmV2aWV3KCk7XG4gICAgICAgIHJlbmRlckZ1bGxTaGVldCgpO1xuICAgICAgfTtcbiAgICAgIGltZy5zcmMgPSBwaG90b1NyYztcbiAgICB9IGVsc2Uge1xuICAgICAgcGhvdG9JbWdSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICByZW5kZXJFZGl0b3JDYW52YXMoKTtcbiAgICAgIHJlbmRlck1pbmlQcmV2aWV3KCk7XG4gICAgICByZW5kZXJGdWxsU2hlZXQoKTtcbiAgICB9XG4gIH0sIFtwaG90b1NyY10pO1xuXG4gIC8vIFJlLXJlbmRlciB3aGVuIGFkanVzdG1lbnRzIGNoYW5nZVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHJlbmRlckVkaXRvckNhbnZhcygpO1xuICAgIHJlbmRlck1pbmlQcmV2aWV3KCk7XG4gICAgcmVuZGVyRnVsbFNoZWV0KCk7XG4gIH0sIFtcbiAgICBwaG90b1NyYyxcbiAgICBhY3RpdmVUb29sLFxuICAgIHBlblBvaW50cyxcbiAgICBpc1BhdGhDbG9zZWQsXG4gICAgaXNOZWFyU3RhcnRQb2ludCxcbiAgICBjcm9wQm94LFxuICAgIGNhbnZhc1pvb20sXG4gICAgY2FudmFzUGFuLFxuICAgIGJnQ29sb3IsXG4gICAgYXV0b0JlYXV0eSxcbiAgICBicmlnaHRuZXNzLFxuICAgIGNvbnRyYXN0LFxuICAgIHNhdHVyYXRpb24sXG4gICAgd2FybXRoLFxuICAgIHRpbnQsXG4gICAgc2hhZG93TGlmdCxcbiAgICBza2luU21vb3RoLFxuICAgIGZhY2VHbG93LFxuICAgIGlzR3JheXNjYWxlLFxuICAgIHBhcGVyRm9ybWF0LFxuICAgIGNvcGllcyxcbiAgICBzaG93TmFtZURhdGUsXG4gICAgY2FuZGlkYXRlTmFtZSxcbiAgICBwaG90b0RhdGVcbiAgXSk7XG5cbiAgLy8gSW5pdGlhbGl6ZSBjcm9wIGJveCB0byAzNTo0NSByYXRpb1xuICBjb25zdCBpbml0Q3JvcEJveCA9ICgpID0+IHtcbiAgICBjb25zdCBjYW52YXMgPSBlZGl0b3JDYW52YXNSZWYuY3VycmVudDtcbiAgICBpZiAoIWNhbnZhcykgcmV0dXJuO1xuICAgIGNvbnN0IHcgPSBNYXRoLm1pbihjYW52YXMud2lkdGggKiAwLjcsIGNhbnZhcy5oZWlnaHQgKiAwLjcgKiAoMzUgLyA0NSkpO1xuICAgIGNvbnN0IGggPSB3ICogKDQ1IC8gMzUpO1xuICAgIHNldENyb3BCb3goe1xuICAgICAgeDogKGNhbnZhcy53aWR0aCAtIHcpIC8gMixcbiAgICAgIHk6IChjYW52YXMuaGVpZ2h0IC0gaCkgLyAyLFxuICAgICAgdyxcbiAgICAgIGhcbiAgICB9KTtcbiAgfTtcblxuICAvLyBBcHBseSBDcm9wXG4gIGNvbnN0IGhhbmRsZUFwcGx5Q3JvcCA9ICgpID0+IHtcbiAgICBjb25zdCBjYW52YXMgPSBlZGl0b3JDYW52YXNSZWYuY3VycmVudDtcbiAgICBjb25zdCBpbWcgPSBwaG90b0ltZ1JlZi5jdXJyZW50O1xuICAgIGlmICghY2FudmFzIHx8ICFpbWcgfHwgIWNyb3BCb3gpIHJldHVybjtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBjcm9wQ2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnY2FudmFzJyk7XG4gICAgICBjcm9wQ2FudmFzLndpZHRoID0gNzAwO1xuICAgICAgY3JvcENhbnZhcy5oZWlnaHQgPSA5MDA7XG4gICAgICBjb25zdCBjQ3R4ID0gY3JvcENhbnZhcy5nZXRDb250ZXh0KCcyZCcpO1xuICAgICAgaWYgKCFjQ3R4KSByZXR1cm47XG5cbiAgICAgIC8vIEV4dHJhY3QgY3JvcHBlZCBhcmVhIGZyb20gZWRpdG9yIGNhbnZhc1xuICAgICAgY0N0eC5kcmF3SW1hZ2UoXG4gICAgICAgIGNhbnZhcyxcbiAgICAgICAgY3JvcEJveC54LFxuICAgICAgICBjcm9wQm94LnksXG4gICAgICAgIGNyb3BCb3gudyxcbiAgICAgICAgY3JvcEJveC5oLFxuICAgICAgICAwLFxuICAgICAgICAwLFxuICAgICAgICBjcm9wQ2FudmFzLndpZHRoLFxuICAgICAgICBjcm9wQ2FudmFzLmhlaWdodFxuICAgICAgKTtcblxuICAgICAgY29uc3QgY3JvcHBlZFVybCA9IGNyb3BDYW52YXMudG9EYXRhVVJMKCdpbWFnZS9qcGVnJywgMC45OCk7XG4gICAgICBzZXRQaG90b1NyYyhjcm9wcGVkVXJsKTtcbiAgICAgIHB1c2hUb0hpc3RvcnkoY3JvcHBlZFVybCk7XG4gICAgICBzZXRDcm9wQm94KG51bGwpO1xuICAgICAgc2V0QWN0aXZlVG9vbCgnc2VsZWN0Jyk7XG4gICAgICBzZXRQcmludEFsZXJ0KCfinILvuI8gUGhvdG8gY3JvcHBlZCB0byAzNcOXNDVtbSBwYXNzcG9ydCByYXRpbyEnKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0UHJpbnRBbGVydChudWxsKSwgMzAwMCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBNQUdJQyBXQU5EIC8gTUFHSUMgQ1VUIChGSVhFRCAmIEhJR0gtUFJFQ0lTSU9OIEZMT09EIEZJTEwpXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gQkZTIENvbm5lY3RlZCBGbG9vZC1GaWxsIGZyb20gY2xpY2tlZCBwaXhlbFxuICBjb25zdCBleGVjdXRlTWFnaWNXYW5kQ3V0ID0gKGNsaWNrWDogbnVtYmVyLCBjbGlja1k6IG51bWJlcikgPT4ge1xuICAgIGNvbnN0IGltZyA9IHBob3RvSW1nUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFpbWcpIHJldHVybjtcblxuICAgIHNldElzUHJvY2Vzc2luZyh0cnVlKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCB3b3JrQ2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnY2FudmFzJyk7XG4gICAgICB3b3JrQ2FudmFzLndpZHRoID0gaW1nLndpZHRoO1xuICAgICAgd29ya0NhbnZhcy5oZWlnaHQgPSBpbWcuaGVpZ2h0O1xuICAgICAgY29uc3Qgd0N0eCA9IHdvcmtDYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcbiAgICAgIGlmICghd0N0eCkgcmV0dXJuO1xuXG4gICAgICB3Q3R4LmRyYXdJbWFnZShpbWcsIDAsIDApO1xuICAgICAgY29uc3QgaW1nRGF0YSA9IHdDdHguZ2V0SW1hZ2VEYXRhKDAsIDAsIHdvcmtDYW52YXMud2lkdGgsIHdvcmtDYW52YXMuaGVpZ2h0KTtcbiAgICAgIGNvbnN0IGRhdGEgPSBpbWdEYXRhLmRhdGE7XG4gICAgICBjb25zdCB3ID0gd29ya0NhbnZhcy53aWR0aDtcbiAgICAgIGNvbnN0IGggPSB3b3JrQ2FudmFzLmhlaWdodDtcblxuICAgICAgLy8gU2NhbGUgY2xpY2tYLCBjbGlja1kgdG8gb3JpZ2luYWwgaW1hZ2UgcGl4ZWxzXG4gICAgICBjb25zdCBzdGFydFggPSBNYXRoLmZsb29yKE1hdGgubWF4KDAsIE1hdGgubWluKHcgLSAxLCBjbGlja1gpKSk7XG4gICAgICBjb25zdCBzdGFydFkgPSBNYXRoLmZsb29yKE1hdGgubWF4KDAsIE1hdGgubWluKGggLSAxLCBjbGlja1kpKSk7XG4gICAgICBjb25zdCBzdGFydEluZGV4ID0gKHN0YXJ0WSAqIHcgKyBzdGFydFgpICogNDtcblxuICAgICAgY29uc3QgdGFyZ2V0UiA9IGRhdGFbc3RhcnRJbmRleF07XG4gICAgICBjb25zdCB0YXJnZXRHID0gZGF0YVtzdGFydEluZGV4ICsgMV07XG4gICAgICBjb25zdCB0YXJnZXRCID0gZGF0YVtzdGFydEluZGV4ICsgMl07XG5cbiAgICAgIC8vIFBhcnNlIHRhcmdldCBiYWNrZ3JvdW5kIGNvbG9yXG4gICAgICBjb25zdCBkdW1teSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgICAgZHVtbXkuc3R5bGUuY29sb3IgPSBiZ0NvbG9yO1xuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChkdW1teSk7XG4gICAgICBjb25zdCBjb21wdXRlZCA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKGR1bW15KS5jb2xvcjtcbiAgICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoZHVtbXkpO1xuICAgICAgY29uc3QgcmdiID0gY29tcHV0ZWQubWF0Y2goL1xcZCsvZyk/Lm1hcChOdW1iZXIpIHx8IFsyNTUsIDI1NSwgMjU1XTtcblxuICAgICAgLy8gVmlzaXRlZCBhcnJheSB0byBwcmV2ZW50IGluZmluaXRlIGxvb3BcbiAgICAgIGNvbnN0IHZpc2l0ZWQgPSBuZXcgVWludDhBcnJheSh3ICogaCk7XG4gICAgICBjb25zdCBxdWV1ZTogbnVtYmVyW10gPSBbc3RhcnRYICsgc3RhcnRZICogd107XG4gICAgICB2aXNpdGVkW3N0YXJ0WCArIHN0YXJ0WSAqIHddID0gMTtcblxuICAgICAgY29uc3QgdG9sU3EgPSBNYXRoLnBvdyhtYWdpY1RvbGVyYW5jZSAqIDIuMiwgMik7XG5cbiAgICAgIC8vIEJGUyBmbG9vZCBmaWxsXG4gICAgICBsZXQgaGVhZCA9IDA7XG4gICAgICB3aGlsZSAoaGVhZCA8IHF1ZXVlLmxlbmd0aCkge1xuICAgICAgICBjb25zdCBjdXJyID0gcXVldWVbaGVhZCsrXTtcbiAgICAgICAgY29uc3QgY3ggPSBjdXJyICUgdztcbiAgICAgICAgY29uc3QgY3kgPSBNYXRoLmZsb29yKGN1cnIgLyB3KTtcbiAgICAgICAgY29uc3QgaWR4ID0gY3VyciAqIDQ7XG5cbiAgICAgICAgLy8gUmVwbGFjZSBwaXhlbCBjb2xvciB3aXRoIHN0dWRpbyBiYWNrZ3JvdW5kXG4gICAgICAgIGRhdGFbaWR4XSA9IHJnYlswXTtcbiAgICAgICAgZGF0YVtpZHggKyAxXSA9IHJnYlsxXTtcbiAgICAgICAgZGF0YVtpZHggKyAyXSA9IHJnYlsyXTtcbiAgICAgICAgZGF0YVtpZHggKyAzXSA9IDI1NTtcblxuICAgICAgICAvLyBDaGVjayA0LWRpcmVjdGlvbmFsIG5laWdoYm9yc1xuICAgICAgICBjb25zdCBuZWlnaGJvcnMgPSBbXG4gICAgICAgICAgW2N4ICsgMSwgY3ldLFxuICAgICAgICAgIFtjeCAtIDEsIGN5XSxcbiAgICAgICAgICBbY3gsIGN5ICsgMV0sXG4gICAgICAgICAgW2N4LCBjeSAtIDFdXG4gICAgICAgIF07XG5cbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCA0OyBpKyspIHtcbiAgICAgICAgICBjb25zdCBueCA9IG5laWdoYm9yc1tpXVswXTtcbiAgICAgICAgICBjb25zdCBueSA9IG5laWdoYm9yc1tpXVsxXTtcblxuICAgICAgICAgIGlmIChueCA+PSAwICYmIG54IDwgdyAmJiBueSA+PSAwICYmIG55IDwgaCkge1xuICAgICAgICAgICAgY29uc3QgblBvcyA9IG54ICsgbnkgKiB3O1xuICAgICAgICAgICAgaWYgKCF2aXNpdGVkW25Qb3NdKSB7XG4gICAgICAgICAgICAgIGNvbnN0IG5JZHggPSBuUG9zICogNDtcbiAgICAgICAgICAgICAgY29uc3QgbnIgPSBkYXRhW25JZHhdO1xuICAgICAgICAgICAgICBjb25zdCBuZyA9IGRhdGFbbklkeCArIDFdO1xuICAgICAgICAgICAgICBjb25zdCBuYiA9IGRhdGFbbklkeCArIDJdO1xuXG4gICAgICAgICAgICAgIC8vIENvbG9yIGRpc3RhbmNlIGZyb20gdGFyZ2V0XG4gICAgICAgICAgICAgIGNvbnN0IGRpc3RTcSA9XG4gICAgICAgICAgICAgICAgTWF0aC5wb3cobnIgLSB0YXJnZXRSLCAyKSArXG4gICAgICAgICAgICAgICAgTWF0aC5wb3cobmcgLSB0YXJnZXRHLCAyKSArXG4gICAgICAgICAgICAgICAgTWF0aC5wb3cobmIgLSB0YXJnZXRCLCAyKTtcblxuICAgICAgICAgICAgICBpZiAoZGlzdFNxIDw9IHRvbFNxKSB7XG4gICAgICAgICAgICAgICAgdmlzaXRlZFtuUG9zXSA9IDE7XG4gICAgICAgICAgICAgICAgcXVldWUucHVzaChuUG9zKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICB3Q3R4LnB1dEltYWdlRGF0YShpbWdEYXRhLCAwLCAwKTtcbiAgICAgIGNvbnN0IHJlc0RhdGFVcmwgPSB3b3JrQ2FudmFzLnRvRGF0YVVSTCgnaW1hZ2UvanBlZycsIDAuOTgpO1xuXG4gICAgICBpZiAoIW9yaWdpbmFsUGhvdG9TcmMgJiYgcGhvdG9TcmMpIHtcbiAgICAgICAgc2V0T3JpZ2luYWxQaG90b1NyYyhwaG90b1NyYyk7XG4gICAgICB9XG5cbiAgICAgIHNldFBob3RvU3JjKHJlc0RhdGFVcmwpO1xuICAgICAgcHVzaFRvSGlzdG9yeShyZXNEYXRhVXJsKTtcbiAgICAgIHNldFByaW50QWxlcnQoYPCfqoQgTWFnaWMgV2FuZCBlcmFzZWQgY29ubmVjdGVkIGJhY2tncm91bmQgYXQgKCR7c3RhcnRYfSwgJHtzdGFydFl9KSFgKTtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0UHJpbnRBbGVydChudWxsKSwgMzAwMCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0SXNQcm9jZXNzaW5nKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gMS1DbGljayBBdXRvIEJhY2tncm91bmQgRXJhc2VyIChTZWVkcyBmbG9vZCBmaWxsIGZyb20gYWxsIDQgb3V0ZXIgYm9yZGVycylcbiAgY29uc3QgaGFuZGxlQXV0b0JhY2tncm91bmRFcmFzZSA9ICgpID0+IHtcbiAgICBjb25zdCBpbWcgPSBwaG90b0ltZ1JlZi5jdXJyZW50O1xuICAgIGlmICghaW1nKSByZXR1cm47XG5cbiAgICBzZXRJc1Byb2Nlc3NpbmcodHJ1ZSk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3Qgd29ya0NhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xuICAgICAgd29ya0NhbnZhcy53aWR0aCA9IGltZy53aWR0aDtcbiAgICAgIHdvcmtDYW52YXMuaGVpZ2h0ID0gaW1nLmhlaWdodDtcbiAgICAgIGNvbnN0IHdDdHggPSB3b3JrQ2FudmFzLmdldENvbnRleHQoJzJkJyk7XG4gICAgICBpZiAoIXdDdHgpIHJldHVybjtcblxuICAgICAgd0N0eC5kcmF3SW1hZ2UoaW1nLCAwLCAwKTtcbiAgICAgIGNvbnN0IGltZ0RhdGEgPSB3Q3R4LmdldEltYWdlRGF0YSgwLCAwLCB3b3JrQ2FudmFzLndpZHRoLCB3b3JrQ2FudmFzLmhlaWdodCk7XG4gICAgICBjb25zdCBkYXRhID0gaW1nRGF0YS5kYXRhO1xuICAgICAgY29uc3QgdyA9IHdvcmtDYW52YXMud2lkdGg7XG4gICAgICBjb25zdCBoID0gd29ya0NhbnZhcy5oZWlnaHQ7XG5cbiAgICAgIC8vIFRhcmdldCBiYWNrZ3JvdW5kIGNvbG9yIHBhcnNlXG4gICAgICBjb25zdCBpc1RyYW5zcGFyZW50ID0gYmdDb2xvciA9PT0gJ3RyYW5zcGFyZW50JztcbiAgICAgIGxldCByZ2IgPSBbMjU1LCAyNTUsIDI1NV07XG4gICAgICBpZiAoIWlzVHJhbnNwYXJlbnQpIHtcbiAgICAgICAgY29uc3QgZHVtbXkgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgICAgZHVtbXkuc3R5bGUuY29sb3IgPSBiZ0NvbG9yO1xuICAgICAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGR1bW15KTtcbiAgICAgICAgY29uc3QgY29tcHV0ZWQgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShkdW1teSkuY29sb3I7XG4gICAgICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoZHVtbXkpO1xuICAgICAgICByZ2IgPSBjb21wdXRlZC5tYXRjaCgvXFxkKy9nKT8ubWFwKE51bWJlcikgfHwgWzI1NSwgMjU1LCAyNTVdO1xuICAgICAgfVxuXG4gICAgICAvLyBTYW1wbGUgcmVmZXJlbmNlIGJhY2tncm91bmQgY29sb3IgZnJvbSB0b3AgY29ybmVyc1xuICAgICAgY29uc3QgY29ybmVyUiA9IChkYXRhWzBdICsgZGF0YVsodyAtIDEpICogNF0pIC8gMjtcbiAgICAgIGNvbnN0IGNvcm5lckcgPSAoZGF0YVsxXSArIGRhdGFbKHcgLSAxKSAqIDQgKyAxXSkgLyAyO1xuICAgICAgY29uc3QgY29ybmVyQiA9IChkYXRhWzJdICsgZGF0YVsodyAtIDEpICogNCArIDJdKSAvIDI7XG5cbiAgICAgIGNvbnN0IHZpc2l0ZWQgPSBuZXcgVWludDhBcnJheSh3ICogaCk7XG4gICAgICBjb25zdCBxdWV1ZTogbnVtYmVyW10gPSBbXTtcblxuICAgICAgLy8gU2VlZCBhbGwgNCBvdXRlciBib3JkZXJzXG4gICAgICBmb3IgKGxldCB4ID0gMDsgeCA8IHc7IHgrKykge1xuICAgICAgICBxdWV1ZS5wdXNoKHgpOyAvLyB0b3BcbiAgICAgICAgcXVldWUucHVzaCh4ICsgKGggLSAxKSAqIHcpOyAvLyBib3R0b21cbiAgICAgICAgdmlzaXRlZFt4XSA9IDE7XG4gICAgICAgIHZpc2l0ZWRbeCArIChoIC0gMSkgKiB3XSA9IDE7XG4gICAgICB9XG4gICAgICBmb3IgKGxldCB5ID0gMDsgeSA8IGg7IHkrKykge1xuICAgICAgICBxdWV1ZS5wdXNoKHkgKiB3KTsgLy8gbGVmdFxuICAgICAgICBxdWV1ZS5wdXNoKCh3IC0gMSkgKyB5ICogdyk7IC8vIHJpZ2h0XG4gICAgICAgIHZpc2l0ZWRbeSAqIHddID0gMTtcbiAgICAgICAgdmlzaXRlZFsodyAtIDEpICsgeSAqIHddID0gMTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgdG9sU3EgPSBNYXRoLnBvdyhtYWdpY1RvbGVyYW5jZSAqIDIuMiwgMik7XG5cbiAgICAgIGxldCBoZWFkID0gMDtcbiAgICAgIHdoaWxlIChoZWFkIDwgcXVldWUubGVuZ3RoKSB7XG4gICAgICAgIGNvbnN0IGN1cnIgPSBxdWV1ZVtoZWFkKytdO1xuICAgICAgICBjb25zdCBjeCA9IGN1cnIgJSB3O1xuICAgICAgICBjb25zdCBjeSA9IE1hdGguZmxvb3IoY3VyciAvIHcpO1xuICAgICAgICBjb25zdCBpZHggPSBjdXJyICogNDtcblxuICAgICAgICAvLyBSZXBsYWNlIGJhY2tncm91bmQgcGl4ZWxcbiAgICAgICAgaWYgKGlzVHJhbnNwYXJlbnQpIHtcbiAgICAgICAgICBkYXRhW2lkeCArIDNdID0gMDsgLy8gVHJhbnNwYXJlbnQgY3V0b3V0XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZGF0YVtpZHhdID0gcmdiWzBdO1xuICAgICAgICAgIGRhdGFbaWR4ICsgMV0gPSByZ2JbMV07XG4gICAgICAgICAgZGF0YVtpZHggKyAyXSA9IHJnYlsyXTtcbiAgICAgICAgICBkYXRhW2lkeCArIDNdID0gMjU1O1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgbmVpZ2hib3JzID0gW1xuICAgICAgICAgIFtjeCArIDEsIGN5XSxcbiAgICAgICAgICBbY3ggLSAxLCBjeV0sXG4gICAgICAgICAgW2N4LCBjeSArIDFdLFxuICAgICAgICAgIFtjeCwgY3kgLSAxXVxuICAgICAgICBdO1xuXG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgNDsgaSsrKSB7XG4gICAgICAgICAgY29uc3QgbnggPSBuZWlnaGJvcnNbaV1bMF07XG4gICAgICAgICAgY29uc3QgbnkgPSBuZWlnaGJvcnNbaV1bMV07XG5cbiAgICAgICAgICBpZiAobnggPj0gMCAmJiBueCA8IHcgJiYgbnkgPj0gMCAmJiBueSA8IGgpIHtcbiAgICAgICAgICAgIGNvbnN0IG5Qb3MgPSBueCArIG55ICogdztcbiAgICAgICAgICAgIGlmICghdmlzaXRlZFtuUG9zXSkge1xuICAgICAgICAgICAgICBjb25zdCBuSWR4ID0gblBvcyAqIDQ7XG4gICAgICAgICAgICAgIGNvbnN0IG5yID0gZGF0YVtuSWR4XTtcbiAgICAgICAgICAgICAgY29uc3QgbmcgPSBkYXRhW25JZHggKyAxXTtcbiAgICAgICAgICAgICAgY29uc3QgbmIgPSBkYXRhW25JZHggKyAyXTtcblxuICAgICAgICAgICAgICBjb25zdCBkaXN0U3EgPVxuICAgICAgICAgICAgICAgIE1hdGgucG93KG5yIC0gY29ybmVyUiwgMikgK1xuICAgICAgICAgICAgICAgIE1hdGgucG93KG5nIC0gY29ybmVyRywgMikgK1xuICAgICAgICAgICAgICAgIE1hdGgucG93KG5iIC0gY29ybmVyQiwgMik7XG5cbiAgICAgICAgICAgICAgaWYgKGRpc3RTcSA8PSB0b2xTcSkge1xuICAgICAgICAgICAgICAgIHZpc2l0ZWRbblBvc10gPSAxO1xuICAgICAgICAgICAgICAgIHF1ZXVlLnB1c2goblBvcyk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgd0N0eC5wdXRJbWFnZURhdGEoaW1nRGF0YSwgMCwgMCk7XG4gICAgICBjb25zdCByZXNEYXRhVXJsID0gd29ya0NhbnZhcy50b0RhdGFVUkwoaXNUcmFuc3BhcmVudCA/ICdpbWFnZS9wbmcnIDogJ2ltYWdlL2pwZWcnLCAwLjk4KTtcblxuICAgICAgaWYgKCFvcmlnaW5hbFBob3RvU3JjICYmIHBob3RvU3JjKSB7XG4gICAgICAgIHNldE9yaWdpbmFsUGhvdG9TcmMocGhvdG9TcmMpO1xuICAgICAgfVxuXG4gICAgICBzZXRQaG90b1NyYyhyZXNEYXRhVXJsKTtcbiAgICAgIHB1c2hUb0hpc3RvcnkocmVzRGF0YVVybCk7XG4gICAgICBzZXRQcmludEFsZXJ0KGlzVHJhbnNwYXJlbnQgPyAn4pyoIDEtQ2xpY2sgVHJhbnNwYXJlbnQgQmFja2dyb3VuZCBDdXRvdXQgY3JlYXRlZCEnIDogJ+KcqCAxLUNsaWNrIE1hZ2ljIEF1dG8gQmFja2dyb3VuZCBzdWNjZXNzZnVsbHkgcmVwbGFjZWQhJyk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFByaW50QWxlcnQobnVsbCksIDMwMDApO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzUHJvY2Vzc2luZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gU1BPVCBCTEVNSVNIIFJFTU9WRVIgJiBCRUFVVFkgQlJVU0hcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBjb25zdCBhcHBseUhlYWxpbmdCcnVzaCA9IChjZW50ZXJYOiBudW1iZXIsIGNlbnRlclk6IG51bWJlciwgbW9kZTogJ2JsZW1pc2gnIHwgJ2JlYXV0eScgfCAnZXllJykgPT4ge1xuICAgIGNvbnN0IGltZyA9IHBob3RvSW1nUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFpbWcpIHJldHVybjtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCB3b3JrQ2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnY2FudmFzJyk7XG4gICAgICB3b3JrQ2FudmFzLndpZHRoID0gaW1nLndpZHRoO1xuICAgICAgd29ya0NhbnZhcy5oZWlnaHQgPSBpbWcuaGVpZ2h0O1xuICAgICAgY29uc3Qgd0N0eCA9IHdvcmtDYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcbiAgICAgIGlmICghd0N0eCkgcmV0dXJuO1xuXG4gICAgICB3Q3R4LmRyYXdJbWFnZShpbWcsIDAsIDApO1xuXG4gICAgICBjb25zdCByYWQgPSBicnVzaFNpemU7XG4gICAgICBjb25zdCB4ID0gTWF0aC5tYXgoMCwgTWF0aC5taW4oaW1nLndpZHRoLCBjZW50ZXJYKSk7XG4gICAgICBjb25zdCB5ID0gTWF0aC5tYXgoMCwgTWF0aC5taW4oaW1nLmhlaWdodCwgY2VudGVyWSkpO1xuXG4gICAgICBpZiAobW9kZSA9PT0gJ2JsZW1pc2gnKSB7XG4gICAgICAgIC8vIFNhbXBsZSBzdXJyb3VuZGluZyByaW5nIG9mIHNraW4gcGl4ZWxzIGFuZCBibGVuZCBpbnRvIGNlbnRlclxuICAgICAgICBjb25zdCBpbWdEYXRhID0gd0N0eC5nZXRJbWFnZURhdGEoXG4gICAgICAgICAgTWF0aC5tYXgoMCwgeCAtIHJhZCksXG4gICAgICAgICAgTWF0aC5tYXgoMCwgeSAtIHJhZCksXG4gICAgICAgICAgcmFkICogMixcbiAgICAgICAgICByYWQgKiAyXG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IGRhdGEgPSBpbWdEYXRhLmRhdGE7XG5cbiAgICAgICAgLy8gQXZlcmFnZSBzdXJyb3VuZGluZyByaW5nXG4gICAgICAgIGxldCByU3VtID0gMCwgZ1N1bSA9IDAsIGJTdW0gPSAwLCBjb3VudCA9IDA7XG4gICAgICAgIGZvciAobGV0IHB5ID0gMDsgcHkgPCByYWQgKiAyOyBweSsrKSB7XG4gICAgICAgICAgZm9yIChsZXQgcHggPSAwOyBweCA8IHJhZCAqIDI7IHB4KyspIHtcbiAgICAgICAgICAgIGNvbnN0IGQgPSBNYXRoLmh5cG90KHB4IC0gcmFkLCBweSAtIHJhZCk7XG4gICAgICAgICAgICBpZiAoZCA+PSByYWQgKiAwLjcgJiYgZCA8PSByYWQpIHtcbiAgICAgICAgICAgICAgY29uc3QgaSA9IChweSAqIHJhZCAqIDIgKyBweCkgKiA0O1xuICAgICAgICAgICAgICByU3VtICs9IGRhdGFbaV07XG4gICAgICAgICAgICAgIGdTdW0gKz0gZGF0YVtpICsgMV07XG4gICAgICAgICAgICAgIGJTdW0gKz0gZGF0YVtpICsgMl07XG4gICAgICAgICAgICAgIGNvdW50Kys7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGNvdW50ID4gMCkge1xuICAgICAgICAgIGNvbnN0IGF2Z1IgPSByU3VtIC8gY291bnQ7XG4gICAgICAgICAgY29uc3QgYXZnRyA9IGdTdW0gLyBjb3VudDtcbiAgICAgICAgICBjb25zdCBhdmdCID0gYlN1bSAvIGNvdW50O1xuXG4gICAgICAgICAgZm9yIChsZXQgcHkgPSAwOyBweSA8IHJhZCAqIDI7IHB5KyspIHtcbiAgICAgICAgICAgIGZvciAobGV0IHB4ID0gMDsgcHggPCByYWQgKiAyOyBweCsrKSB7XG4gICAgICAgICAgICAgIGNvbnN0IGQgPSBNYXRoLmh5cG90KHB4IC0gcmFkLCBweSAtIHJhZCk7XG4gICAgICAgICAgICAgIGlmIChkIDwgcmFkKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaSA9IChweSAqIHJhZCAqIDIgKyBweCkgKiA0O1xuICAgICAgICAgICAgICAgIGNvbnN0IGFscGhhV2VpZ2h0ID0gMSAtIChkIC8gcmFkKTtcbiAgICAgICAgICAgICAgICBkYXRhW2ldID0gZGF0YVtpXSAqICgxIC0gYWxwaGFXZWlnaHQpICsgYXZnUiAqIGFscGhhV2VpZ2h0O1xuICAgICAgICAgICAgICAgIGRhdGFbaSArIDFdID0gZGF0YVtpICsgMV0gKiAoMSAtIGFscGhhV2VpZ2h0KSArIGF2Z0cgKiBhbHBoYVdlaWdodDtcbiAgICAgICAgICAgICAgICBkYXRhW2kgKyAyXSA9IGRhdGFbaSArIDJdICogKDEgLSBhbHBoYVdlaWdodCkgKyBhdmdCICogYWxwaGFXZWlnaHQ7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgd0N0eC5wdXRJbWFnZURhdGEoaW1nRGF0YSwgTWF0aC5tYXgoMCwgeCAtIHJhZCksIE1hdGgubWF4KDAsIHkgLSByYWQpKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChtb2RlID09PSAnYmVhdXR5Jykge1xuICAgICAgICAvLyBTb2Z0IHNraW4gYWlyYnJ1c2ggYmx1clxuICAgICAgICB3Q3R4LnNhdmUoKTtcbiAgICAgICAgd0N0eC5iZWdpblBhdGgoKTtcbiAgICAgICAgd0N0eC5hcmMoeCwgeSwgcmFkLCAwLCBNYXRoLlBJICogMik7XG4gICAgICAgIHdDdHguY2xpcCgpO1xuICAgICAgICB3Q3R4LmZpbHRlciA9ICdibHVyKDRweCkgYnJpZ2h0bmVzcygxMDUlKSc7XG4gICAgICAgIHdDdHguZHJhd0ltYWdlKGltZywgMCwgMCk7XG4gICAgICAgIHdDdHgucmVzdG9yZSgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gRXllICYgVGVldGggV2hpdGVuZXJcbiAgICAgICAgd0N0eC5zYXZlKCk7XG4gICAgICAgIHdDdHguYmVnaW5QYXRoKCk7XG4gICAgICAgIHdDdHguYXJjKHgsIHksIHJhZCwgMCwgTWF0aC5QSSAqIDIpO1xuICAgICAgICB3Q3R4LmNsaXAoKTtcbiAgICAgICAgd0N0eC5maWx0ZXIgPSAnYnJpZ2h0bmVzcygxMTglKSBjb250cmFzdCgxMDYlKSBzYXR1cmF0ZSg2MCUpJztcbiAgICAgICAgd0N0eC5kcmF3SW1hZ2UoaW1nLCAwLCAwKTtcbiAgICAgICAgd0N0eC5yZXN0b3JlKCk7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHJlc0RhdGFVcmwgPSB3b3JrQ2FudmFzLnRvRGF0YVVSTCgnaW1hZ2UvanBlZycsIDAuOTgpO1xuICAgICAgc2V0UGhvdG9TcmMocmVzRGF0YVVybCk7XG4gICAgICBwdXNoVG9IaXN0b3J5KHJlc0RhdGFVcmwpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gUEVOIFRPT0w6IEFQUExZIFZFQ1RPUiBDVVRPVVRcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBjb25zdCBoYW5kbGVBcHBseVBlbkN1dG91dCA9ICgpID0+IHtcbiAgICBjb25zdCBpbWcgPSBwaG90b0ltZ1JlZi5jdXJyZW50O1xuICAgIGlmICghaW1nIHx8IHBlblBvaW50cy5sZW5ndGggPCAzKSByZXR1cm47XG5cbiAgICB0cnkge1xuICAgICAgY29uc3Qgd29ya0NhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xuICAgICAgd29ya0NhbnZhcy53aWR0aCA9IGltZy53aWR0aDtcbiAgICAgIHdvcmtDYW52YXMuaGVpZ2h0ID0gaW1nLmhlaWdodDtcbiAgICAgIGNvbnN0IHdDdHggPSB3b3JrQ2FudmFzLmdldENvbnRleHQoJzJkJyk7XG4gICAgICBpZiAoIXdDdHgpIHJldHVybjtcblxuICAgICAgLy8gMS4gRmlsbCBzdHVkaW8gYmFja2dyb3VuZFxuICAgICAgd0N0eC5maWxsU3R5bGUgPSBiZ0NvbG9yO1xuICAgICAgd0N0eC5maWxsUmVjdCgwLCAwLCB3b3JrQ2FudmFzLndpZHRoLCB3b3JrQ2FudmFzLmhlaWdodCk7XG5cbiAgICAgIC8vIDIuIENyZWF0ZSBvZmZzY3JlZW4gcGVyc29uIGxheWVyIGNsaXBwZWQgdG8gcGF0aFxuICAgICAgY29uc3QgcGVyc29uQ2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnY2FudmFzJyk7XG4gICAgICBwZXJzb25DYW52YXMud2lkdGggPSBpbWcud2lkdGg7XG4gICAgICBwZXJzb25DYW52YXMuaGVpZ2h0ID0gaW1nLmhlaWdodDtcbiAgICAgIGNvbnN0IHBDdHggPSBwZXJzb25DYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcblxuICAgICAgaWYgKHBDdHgpIHtcbiAgICAgICAgcEN0eC5kcmF3SW1hZ2UoaW1nLCAwLCAwKTtcblxuICAgICAgICBjb25zdCBtYXNrQ2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnY2FudmFzJyk7XG4gICAgICAgIG1hc2tDYW52YXMud2lkdGggPSBpbWcud2lkdGg7XG4gICAgICAgIG1hc2tDYW52YXMuaGVpZ2h0ID0gaW1nLmhlaWdodDtcbiAgICAgICAgY29uc3QgbUN0eCA9IG1hc2tDYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcblxuICAgICAgICBpZiAobUN0eCkge1xuICAgICAgICAgIGlmIChwZW5GZWF0aGVyID4gMCkge1xuICAgICAgICAgICAgbUN0eC5maWx0ZXIgPSBgYmx1cigke3BlbkZlYXRoZXJ9cHgpYDtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBtQ3R4LmJlZ2luUGF0aCgpO1xuICAgICAgICAgIG1DdHgubW92ZVRvKHBlblBvaW50c1swXS54ICogaW1nLndpZHRoLCBwZW5Qb2ludHNbMF0ueSAqIGltZy5oZWlnaHQpO1xuICAgICAgICAgIGZvciAobGV0IGkgPSAxOyBpIDwgcGVuUG9pbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBtQ3R4LmxpbmVUbyhwZW5Qb2ludHNbaV0ueCAqIGltZy53aWR0aCwgcGVuUG9pbnRzW2ldLnkgKiBpbWcuaGVpZ2h0KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgbUN0eC5jbG9zZVBhdGgoKTtcbiAgICAgICAgICBtQ3R4LmZpbGxTdHlsZSA9ICcjMDAwMDAwJztcbiAgICAgICAgICBtQ3R4LmZpbGwoKTtcblxuICAgICAgICAgIHBDdHguZ2xvYmFsQ29tcG9zaXRlT3BlcmF0aW9uID0gJ2Rlc3RpbmF0aW9uLWluJztcbiAgICAgICAgICBwQ3R4LmRyYXdJbWFnZShtYXNrQ2FudmFzLCAwLCAwKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHdDdHguZHJhd0ltYWdlKHBlcnNvbkNhbnZhcywgMCwgMCk7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHJlc0RhdGFVcmwgPSB3b3JrQ2FudmFzLnRvRGF0YVVSTCgnaW1hZ2UvanBlZycsIDAuOTgpO1xuICAgICAgaWYgKCFvcmlnaW5hbFBob3RvU3JjICYmIHBob3RvU3JjKSB7XG4gICAgICAgIHNldE9yaWdpbmFsUGhvdG9TcmMocGhvdG9TcmMpO1xuICAgICAgfVxuXG4gICAgICBzZXRQaG90b1NyYyhyZXNEYXRhVXJsKTtcbiAgICAgIHB1c2hUb0hpc3RvcnkocmVzRGF0YVVybCk7XG4gICAgICBzZXRQZW5Qb2ludHMoW10pO1xuICAgICAgc2V0SXNQYXRoQ2xvc2VkKGZhbHNlKTtcbiAgICAgIHNldEFjdGl2ZVRvb2woJ3NlbGVjdCcpO1xuICAgICAgc2V0UHJpbnRBbGVydCgn8J+Wiu+4jyBQZW4gVG9vbCBDdXRvdXQgYXBwbGllZCBzdWNjZXNzZnVsbHkhJyk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFByaW50QWxlcnQobnVsbCksIDMwMDApO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gU0VDVElPTiBTRUxFQ1RJT04gJiBMT0NBTCBDT0xPUiBHUkFESU5HIEhBTkRMRVJTXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgY29uc3QgaGFuZGxlU2VsZWN0UHJlc2V0ID0gKHR5cGU6ICdmYWNlJyB8ICdjbG90aGVzJyB8ICdleWVzJyB8ICdmdWxsJykgPT4ge1xuICAgIHN3aXRjaCAodHlwZSkge1xuICAgICAgY2FzZSAnZmFjZSc6XG4gICAgICAgIHNldFNlbGVjdGlvbkJveCh7IHg6IDAuMTgsIHk6IDAuMTAsIHc6IDAuNjQsIGg6IDAuNTIgfSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnY2xvdGhlcyc6XG4gICAgICAgIHNldFNlbGVjdGlvbkJveCh7IHg6IDAuMDUsIHk6IDAuNTgsIHc6IDAuOTAsIGg6IDAuNDIgfSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnZXllcyc6XG4gICAgICAgIHNldFNlbGVjdGlvbkJveCh7IHg6IDAuMjIsIHk6IDAuMjQsIHc6IDAuNTYsIGg6IDAuMjAgfSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnZnVsbCc6XG4gICAgICAgIHNldFNlbGVjdGlvbkJveCh7IHg6IDAuMDIsIHk6IDAuMDIsIHc6IDAuOTYsIGg6IDAuOTYgfSk7XG4gICAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBzZXRBY3RpdmVUb29sKCdzZWN0aW9uX3NlbGVjdCcpO1xuICAgIHNldEdyYWRpbmdTY29wZSgnc2VsZWN0aW9uJyk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ2xlYXJTZWxlY3Rpb24gPSAoKSA9PiB7XG4gICAgc2V0U2VsZWN0aW9uQm94KG51bGwpO1xuICAgIHNldEdyYWRpbmdTY29wZSgnZnVsbCcpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUludmVydFNlbGVjdGlvbiA9ICgpID0+IHtcbiAgICBpZiAoIXNlbGVjdGlvbkJveCkgcmV0dXJuO1xuICAgIC8vIEludmVydCBzZWxlY3Rpb24gYm94IGNvb3JkaW5hdGVzXG4gICAgc2V0U2VsZWN0aW9uQm94KHtcbiAgICAgIHg6IE1hdGgubWF4KDAsIDEgLSAoc2VsZWN0aW9uQm94LnggKyBzZWxlY3Rpb25Cb3gudykpLFxuICAgICAgeTogc2VsZWN0aW9uQm94LnksXG4gICAgICB3OiBzZWxlY3Rpb25Cb3gudyxcbiAgICAgIGg6IHNlbGVjdGlvbkJveC5oXG4gICAgfSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQmFrZVNlY3Rpb25BZGp1c3RtZW50ID0gKCkgPT4ge1xuICAgIGNvbnN0IGltZyA9IHBob3RvSW1nUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFpbWcgfHwgIXNlbGVjdGlvbkJveCkgcmV0dXJuO1xuXG4gICAgc2V0SXNQcm9jZXNzaW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB3b3JrQ2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnY2FudmFzJyk7XG4gICAgICB3b3JrQ2FudmFzLndpZHRoID0gaW1nLndpZHRoO1xuICAgICAgd29ya0NhbnZhcy5oZWlnaHQgPSBpbWcuaGVpZ2h0O1xuICAgICAgY29uc3Qgd0N0eCA9IHdvcmtDYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcbiAgICAgIGlmICghd0N0eCkgcmV0dXJuO1xuXG4gICAgICAvLyAxLiBEcmF3IGJhc2UgcGhvdG9cbiAgICAgIHdDdHguZHJhd0ltYWdlKGltZywgMCwgMCk7XG5cbiAgICAgIC8vIDIuIERyYXcgc2VjdGlvbiB3aXRoIGxvY2FsIGFkanVzdG1lbnRzXG4gICAgICBjb25zdCBzZWNYID0gc2VsZWN0aW9uQm94LnggKiBpbWcud2lkdGg7XG4gICAgICBjb25zdCBzZWNZID0gc2VsZWN0aW9uQm94LnkgKiBpbWcuaGVpZ2h0O1xuICAgICAgY29uc3Qgc2VjVyA9IHNlbGVjdGlvbkJveC53ICogaW1nLndpZHRoO1xuICAgICAgY29uc3Qgc2VjSCA9IHNlbGVjdGlvbkJveC5oICogaW1nLmhlaWdodDtcblxuICAgICAgd0N0eC5zYXZlKCk7XG4gICAgICB3Q3R4LmJlZ2luUGF0aCgpO1xuICAgICAgd0N0eC5yZWN0KHNlY1gsIHNlY1ksIHNlY1csIHNlY0gpO1xuICAgICAgd0N0eC5jbGlwKCk7XG5cbiAgICAgIGNvbnN0IHNlY0VmZkJyaWdodCA9IDEwMCArIHNlY0JyaWdodG5lc3M7XG4gICAgICBjb25zdCBzZWNFZmZDb250ID0gMTAwICsgc2VjQ29udHJhc3Q7XG4gICAgICBjb25zdCBzZWNFZmZTYXQgPSAxMDAgKyBzZWNTYXR1cmF0aW9uO1xuICAgICAgd0N0eC5maWx0ZXIgPSBgYnJpZ2h0bmVzcygke3NlY0VmZkJyaWdodH0lKSBjb250cmFzdCgke3NlY0VmZkNvbnR9JSkgc2F0dXJhdGUoJHtzZWNFZmZTYXR9JSlgO1xuICAgICAgd0N0eC5kcmF3SW1hZ2UoaW1nLCAwLCAwKTtcblxuICAgICAgaWYgKHNlY1dhcm10aCAhPT0gMCAmJiAhaXNHcmF5c2NhbGUpIHtcbiAgICAgICAgd0N0eC5nbG9iYWxDb21wb3NpdGVPcGVyYXRpb24gPSAnY29sb3InO1xuICAgICAgICB3Q3R4LmZpbGxTdHlsZSA9IHNlY1dhcm10aCA+IDBcbiAgICAgICAgICA/IGByZ2JhKDI1NSwgMTc1LCA3NSwgJHtNYXRoLm1pbigwLjQ1LCAoc2VjV2FybXRoIC8gMTAwKSAqIDAuNSl9KWBcbiAgICAgICAgICA6IGByZ2JhKDgwLCAxNjUsIDI1NSwgJHtNYXRoLm1pbigwLjQ1LCAoTWF0aC5hYnMoc2VjV2FybXRoKSAvIDEwMCkgKiAwLjUpfSlgO1xuICAgICAgICB3Q3R4LmZpbGxSZWN0KHNlY1gsIHNlY1ksIHNlY1csIHNlY0gpO1xuICAgICAgfVxuXG4gICAgICB3Q3R4LnJlc3RvcmUoKTtcblxuICAgICAgY29uc3QgcmVzRGF0YVVybCA9IHdvcmtDYW52YXMudG9EYXRhVVJMKCdpbWFnZS9qcGVnJywgMC45OCk7XG4gICAgICBpZiAoIW9yaWdpbmFsUGhvdG9TcmMgJiYgcGhvdG9TcmMpIHtcbiAgICAgICAgc2V0T3JpZ2luYWxQaG90b1NyYyhwaG90b1NyYyk7XG4gICAgICB9XG4gICAgICBzZXRQaG90b1NyYyhyZXNEYXRhVXJsKTtcbiAgICAgIHB1c2hUb0hpc3RvcnkocmVzRGF0YVVybCk7XG4gICAgICBzZXRQcmludEFsZXJ0KCfinIUgU2VjdGlvbiBjb2xvciBncmFkaW5nIHBlcm1hbmVudGx5IGJha2VkIGludG8gcGhvdG8hJyk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFByaW50QWxlcnQobnVsbCksIDQwMDApO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldElzUHJvY2Vzc2luZyhmYWxzZSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gTUFJTiBFRElUT1IgQ0FOVkFTIFJFTkRFUiAoQ2VudHJhbCBQaG90b3Nob3AtU3R5bGUgV29ya3NwYWNlKVxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIGNvbnN0IHJlbmRlckVkaXRvckNhbnZhcyA9ICgpID0+IHtcbiAgICBjb25zdCBjYW52YXMgPSBlZGl0b3JDYW52YXNSZWYuY3VycmVudDtcbiAgICBjb25zdCBpbWcgPSBwaG90b0ltZ1JlZi5jdXJyZW50O1xuICAgIGlmICghY2FudmFzKSByZXR1cm47XG5cbiAgICBjb25zdCBjdHggPSBjYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcbiAgICBpZiAoIWN0eCkgcmV0dXJuO1xuXG4gICAgLy8gRml4ZWQgaW50ZXJuYWwgc2l6ZSBmb3Igc2hhcnAgMksgZWRpdGluZyBjYW52YXNcbiAgICBjYW52YXMud2lkdGggPSA5MDA7XG4gICAgY2FudmFzLmhlaWdodCA9IDcwMDtcblxuICAgIC8vIERhcmsgd29ya3NwYWNlIGNoZWNrZXJlZCBiYWNrZ3JvdW5kXG4gICAgY3R4LmZpbGxTdHlsZSA9ICcjMDkwZDE2JztcbiAgICBjdHguZmlsbFJlY3QoMCwgMCwgY2FudmFzLndpZHRoLCBjYW52YXMuaGVpZ2h0KTtcblxuICAgIGlmICghaW1nKSB7XG4gICAgICAvLyBFbXB0eSBzdGF0ZVxuICAgICAgY3R4LmZpbGxTdHlsZSA9ICcjNjQ3NDhiJztcbiAgICAgIGN0eC5mb250ID0gJ2JvbGQgMTZweCBzYW5zLXNlcmlmJztcbiAgICAgIGN0eC50ZXh0QWxpZ24gPSAnY2VudGVyJztcbiAgICAgIGN0eC5maWxsVGV4dCgnVXBsb2FkIG9yIERyYWcgQ3VzdG9tZXIgUGhvdG8gdG8gRWRpdCcsIGNhbnZhcy53aWR0aCAvIDIsIGNhbnZhcy5oZWlnaHQgLyAyIC0gMTApO1xuICAgICAgY3R4LmZvbnQgPSAnMTJweCBzYW5zLXNlcmlmJztcbiAgICAgIGN0eC5maWxsVGV4dCgnUGhvdG9zaG9wLXN0eWxlIHRvb2xzOiBQZW4sIE1hZ2ljIFdhbmQsIEJsZW1pc2gsIENyb3AsIEF1dG8gQmVhdXR5JywgY2FudmFzLndpZHRoIC8gMiwgY2FudmFzLmhlaWdodCAvIDIgKyAxNSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY3R4LnNhdmUoKTtcblxuICAgIC8vIFBhbiAmIFpvb20gdHJhbnNmb3JtYXRpb25zXG4gICAgY3R4LnRyYW5zbGF0ZShjYW52YXMud2lkdGggLyAyICsgY2FudmFzUGFuLngsIGNhbnZhcy5oZWlnaHQgLyAyICsgY2FudmFzUGFuLnkpO1xuICAgIGN0eC5zY2FsZShjYW52YXNab29tLCBjYW52YXNab29tKTtcblxuICAgIC8vIENhbGN1bGF0ZSBkaW1lbnNpb25zIG1haW50YWluaW5nIGFzcGVjdCByYXRpb1xuICAgIGNvbnN0IGFzcGVjdCA9IGltZy53aWR0aCAvIGltZy5oZWlnaHQ7XG4gICAgbGV0IHJlbmRlclcgPSA0NjA7XG4gICAgbGV0IHJlbmRlckggPSA0NjAgLyBhc3BlY3Q7XG4gICAgaWYgKHJlbmRlckggPiA1NjApIHtcbiAgICAgIHJlbmRlckggPSA1NjA7XG4gICAgICByZW5kZXJXID0gNTYwICogYXNwZWN0O1xuICAgIH1cblxuICAgIGNvbnN0IGRyYXdYID0gLXJlbmRlclcgLyAyO1xuICAgIGNvbnN0IGRyYXdZID0gLXJlbmRlckggLyAyO1xuXG4gICAgLy8gQXBwbHkgY29sb3IgZ3JhZGluZyBmaWx0ZXJzXG4gICAgY29uc3QgZWZmQnJpZ2h0bmVzcyA9IDEwMCArIGJyaWdodG5lc3MgKyAoYXV0b0JlYXV0eSA/IDYgOiAwKSArIChmYWNlR2xvdyAqIDAuMTIpO1xuICAgIGNvbnN0IGVmZkNvbnRyYXN0ID0gMTAwICsgY29udHJhc3QgKyAoYXV0b0JlYXV0eSA/IDQgOiAwKTtcbiAgICBjb25zdCBlZmZTYXR1cmF0aW9uID0gaXNHcmF5c2NhbGUgPyAwIDogMTAwICsgc2F0dXJhdGlvbiArIChhdXRvQmVhdXR5ID8gOCA6IDApO1xuXG4gICAgbGV0IGZpbHRlclN0ciA9IGBicmlnaHRuZXNzKCR7ZWZmQnJpZ2h0bmVzc30lKSBjb250cmFzdCgke2VmZkNvbnRyYXN0fSUpIHNhdHVyYXRlKCR7ZWZmU2F0dXJhdGlvbn0lKWA7XG4gICAgaWYgKGlzR3JheXNjYWxlKSBmaWx0ZXJTdHIgKz0gJyBncmF5c2NhbGUoMTAwJSknO1xuXG4gICAgY3R4LmZpbHRlciA9IGZpbHRlclN0cjtcbiAgICBjdHguZHJhd0ltYWdlKGltZywgZHJhd1gsIGRyYXdZLCByZW5kZXJXLCByZW5kZXJIKTtcblxuICAgIC8vIFNvZnQgQmVhdXR5IExheWVyIChTb2Z0LUxpZ2h0IHBhc3MpXG4gICAgY29uc3QgZWZmU21vb3RoID0gYXV0b0JlYXV0eSA/IE1hdGgubWF4KHNraW5TbW9vdGgsIDE2KSA6IHNraW5TbW9vdGg7XG4gICAgY29uc3QgZWZmR2xvdyA9IGF1dG9CZWF1dHkgPyBNYXRoLm1heChmYWNlR2xvdywgMjApIDogZmFjZUdsb3c7XG4gICAgaWYgKGVmZlNtb290aCA+IDAgfHwgZWZmR2xvdyA+IDApIHtcbiAgICAgIGN0eC5zYXZlKCk7XG4gICAgICBjdHguZ2xvYmFsQ29tcG9zaXRlT3BlcmF0aW9uID0gJ3NvZnQtbGlnaHQnO1xuICAgICAgY3R4Lmdsb2JhbEFscGhhID0gTWF0aC5taW4oMC42NSwgKGVmZlNtb290aCAqIDAuMDEyKSArIChlZmZHbG93ICogMC4wMSkpO1xuICAgICAgY3R4LmZpbHRlciA9IGBibHVyKCR7TWF0aC5tYXgoMiwgZWZmU21vb3RoIC8gOCl9cHgpIGJyaWdodG5lc3MoMTIwJSlgO1xuICAgICAgY3R4LmRyYXdJbWFnZShpbWcsIGRyYXdYLCBkcmF3WSwgcmVuZGVyVywgcmVuZGVySCk7XG4gICAgICBjdHgucmVzdG9yZSgpO1xuICAgIH1cblxuICAgIC8vIFdhcm10aCAmIFRpbnRcbiAgICBpZiAod2FybXRoICE9PSAwICYmICFpc0dyYXlzY2FsZSkge1xuICAgICAgY3R4LnNhdmUoKTtcbiAgICAgIGN0eC5nbG9iYWxDb21wb3NpdGVPcGVyYXRpb24gPSAnY29sb3InO1xuICAgICAgY3R4LmZpbGxTdHlsZSA9IHdhcm10aCA+IDBcbiAgICAgICAgPyBgcmdiYSgyNTUsIDE3NSwgNzUsICR7TWF0aC5taW4oMC4zNSwgKHdhcm10aCAvIDEwMCkgKiAwLjQpfSlgXG4gICAgICAgIDogYHJnYmEoODAsIDE2NSwgMjU1LCAke01hdGgubWluKDAuMzUsIChNYXRoLmFicyh3YXJtdGgpIC8gMTAwKSAqIDAuNCl9KWA7XG4gICAgICBjdHguZmlsbFJlY3QoZHJhd1gsIGRyYXdZLCByZW5kZXJXLCByZW5kZXJIKTtcbiAgICAgIGN0eC5yZXN0b3JlKCk7XG4gICAgfVxuXG4gICAgaWYgKHRpbnQgIT09IDAgJiYgIWlzR3JheXNjYWxlKSB7XG4gICAgICBjdHguc2F2ZSgpO1xuICAgICAgY3R4Lmdsb2JhbENvbXBvc2l0ZU9wZXJhdGlvbiA9ICdjb2xvcic7XG4gICAgICBjdHguZmlsbFN0eWxlID0gdGludCA+IDBcbiAgICAgICAgPyBgcmdiYSgyNTUsIDYwLCAxODAsICR7TWF0aC5taW4oMC4yNSwgKHRpbnQgLyAxMDApICogMC4zKX0pYFxuICAgICAgICA6IGByZ2JhKDYwLCAyMjAsIDEwMCwgJHtNYXRoLm1pbigwLjI1LCAoTWF0aC5hYnModGludCkgLyAxMDApICogMC4zKX0pYDtcbiAgICAgIGN0eC5maWxsUmVjdChkcmF3WCwgZHJhd1ksIHJlbmRlclcsIHJlbmRlckgpO1xuICAgICAgY3R4LnJlc3RvcmUoKTtcbiAgICB9XG5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gTE9DQUwgU0VDVElPTiBDT0xPUiBHUkFESU5HIE9WRVJMQVkgKEluc2lkZSBQaG90byBDb29yZGluYXRlcylcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgaWYgKHNlbGVjdGlvbkJveCAmJiBzZWxlY3Rpb25Cb3gudyA+IDAuMDA1ICYmIHNlbGVjdGlvbkJveC5oID4gMC4wMDUpIHtcbiAgICAgIGNvbnN0IHNlY1ggPSBkcmF3WCArIHNlbGVjdGlvbkJveC54ICogcmVuZGVyVztcbiAgICAgIGNvbnN0IHNlY1kgPSBkcmF3WSArIHNlbGVjdGlvbkJveC55ICogcmVuZGVySDtcbiAgICAgIGNvbnN0IHNlY1cgPSBzZWxlY3Rpb25Cb3gudyAqIHJlbmRlclc7XG4gICAgICBjb25zdCBzZWNIID0gc2VsZWN0aW9uQm94LmggKiByZW5kZXJIO1xuXG4gICAgICBjdHguc2F2ZSgpO1xuICAgICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgICAgY3R4LnJlY3Qoc2VjWCwgc2VjWSwgc2VjVywgc2VjSCk7XG4gICAgICBjdHguY2xpcCgpO1xuXG4gICAgICBjb25zdCBzZWNFZmZCcmlnaHQgPSBlZmZCcmlnaHRuZXNzICsgc2VjQnJpZ2h0bmVzcztcbiAgICAgIGNvbnN0IHNlY0VmZkNvbnQgPSBlZmZDb250cmFzdCArIHNlY0NvbnRyYXN0O1xuICAgICAgY29uc3Qgc2VjRWZmU2F0ID0gaXNHcmF5c2NhbGUgPyAwIDogZWZmU2F0dXJhdGlvbiArIHNlY1NhdHVyYXRpb247XG5cbiAgICAgIGN0eC5maWx0ZXIgPSBgYnJpZ2h0bmVzcygke3NlY0VmZkJyaWdodH0lKSBjb250cmFzdCgke3NlY0VmZkNvbnR9JSkgc2F0dXJhdGUoJHtzZWNFZmZTYXR9JSlgO1xuICAgICAgY3R4LmRyYXdJbWFnZShpbWcsIGRyYXdYLCBkcmF3WSwgcmVuZGVyVywgcmVuZGVySCk7XG5cbiAgICAgIC8vIExvY2FsIFNvZnQgQWlyYnJ1c2ggUGFzc1xuICAgICAgaWYgKHNlY1Ntb290aCA+IDApIHtcbiAgICAgICAgY3R4LnNhdmUoKTtcbiAgICAgICAgY3R4Lmdsb2JhbENvbXBvc2l0ZU9wZXJhdGlvbiA9ICdzb2Z0LWxpZ2h0JztcbiAgICAgICAgY3R4Lmdsb2JhbEFscGhhID0gTWF0aC5taW4oMC42NSwgc2VjU21vb3RoICogMC4wMTUpO1xuICAgICAgICBjdHguZmlsdGVyID0gYGJsdXIoJHtNYXRoLm1heCgyLCBzZWNTbW9vdGggLyA3KX1weCkgYnJpZ2h0bmVzcygxMjAlKWA7XG4gICAgICAgIGN0eC5kcmF3SW1hZ2UoaW1nLCBkcmF3WCwgZHJhd1ksIHJlbmRlclcsIHJlbmRlckgpO1xuICAgICAgICBjdHgucmVzdG9yZSgpO1xuICAgICAgfVxuXG4gICAgICAvLyBMb2NhbCBXYXJtdGhcbiAgICAgIGlmIChzZWNXYXJtdGggIT09IDAgJiYgIWlzR3JheXNjYWxlKSB7XG4gICAgICAgIGN0eC5zYXZlKCk7XG4gICAgICAgIGN0eC5nbG9iYWxDb21wb3NpdGVPcGVyYXRpb24gPSAnY29sb3InO1xuICAgICAgICBjdHguZmlsbFN0eWxlID0gc2VjV2FybXRoID4gMFxuICAgICAgICAgID8gYHJnYmEoMjU1LCAxNzUsIDc1LCAke01hdGgubWluKDAuNDUsIChzZWNXYXJtdGggLyAxMDApICogMC41KX0pYFxuICAgICAgICAgIDogYHJnYmEoODAsIDE2NSwgMjU1LCAke01hdGgubWluKDAuNDUsIChNYXRoLmFicyhzZWNXYXJtdGgpIC8gMTAwKSAqIDAuNSl9KWA7XG4gICAgICAgIGN0eC5maWxsUmVjdChzZWNYLCBzZWNZLCBzZWNXLCBzZWNIKTtcbiAgICAgICAgY3R4LnJlc3RvcmUoKTtcbiAgICAgIH1cblxuICAgICAgY3R4LnJlc3RvcmUoKTtcblxuICAgICAgLy8gRHJhdyBBbmltYXRlZCBDeWFuIFNlbGVjdGlvbiBNYXJxdWVlXG4gICAgICBjdHguc2F2ZSgpO1xuICAgICAgY3R4LnN0cm9rZVN0eWxlID0gJyMwNmI2ZDQnO1xuICAgICAgY3R4LmxpbmVXaWR0aCA9IDIuNTtcbiAgICAgIGN0eC5zZXRMaW5lRGFzaChbOCwgNl0pO1xuICAgICAgY3R4LnN0cm9rZVJlY3Qoc2VjWCwgc2VjWSwgc2VjVywgc2VjSCk7XG5cbiAgICAgIC8vIENvcm5lciBoYW5kbGVzXG4gICAgICBjb25zdCBoYW5kbGVTaXplID0gODtcbiAgICAgIGN0eC5maWxsU3R5bGUgPSAnI2ZmZmZmZic7XG4gICAgICBjdHguc3Ryb2tlU3R5bGUgPSAnIzA4OTFiMic7XG4gICAgICBjdHgubGluZVdpZHRoID0gMS41O1xuICAgICAgY3R4LnNldExpbmVEYXNoKFtdKTtcbiAgICAgIFtcbiAgICAgICAgW3NlY1gsIHNlY1ldLFxuICAgICAgICBbc2VjWCArIHNlY1csIHNlY1ldLFxuICAgICAgICBbc2VjWCwgc2VjWSArIHNlY0hdLFxuICAgICAgICBbc2VjWCArIHNlY1csIHNlY1kgKyBzZWNIXVxuICAgICAgXS5mb3JFYWNoKChbaHgsIGh5XSkgPT4ge1xuICAgICAgICBjdHguZmlsbFJlY3QoaHggLSBoYW5kbGVTaXplIC8gMiwgaHkgLSBoYW5kbGVTaXplIC8gMiwgaGFuZGxlU2l6ZSwgaGFuZGxlU2l6ZSk7XG4gICAgICAgIGN0eC5zdHJva2VSZWN0KGh4IC0gaGFuZGxlU2l6ZSAvIDIsIGh5IC0gaGFuZGxlU2l6ZSAvIDIsIGhhbmRsZVNpemUsIGhhbmRsZVNpemUpO1xuICAgICAgfSk7XG5cbiAgICAgIC8vIFNlY3Rpb24gQmFkZ2VcbiAgICAgIGN0eC5maWxsU3R5bGUgPSAncmdiYSg2LCAxODIsIDIxMiwgMC45NSknO1xuICAgICAgY3R4LmZpbGxSZWN0KHNlY1gsIE1hdGgubWF4KGRyYXdZLCBzZWNZIC0gMjQpLCAxNzAsIDIyKTtcbiAgICAgIGN0eC5maWxsU3R5bGUgPSAnI2ZmZmZmZic7XG4gICAgICBjdHguZm9udCA9ICdib2xkIDEycHggc2Fucy1zZXJpZic7XG4gICAgICBjdHguZmlsbFRleHQoYPCfjq8gU2VjdGlvbiAoJHtzZWNCcmlnaHRuZXNzID4gMCA/ICcrJyA6ICcnfSR7c2VjQnJpZ2h0bmVzc31CIC8gJHtzZWNDb250cmFzdCA+IDAgPyAnKycgOiAnJ30ke3NlY0NvbnRyYXN0fUMpYCwgc2VjWCArIDYsIE1hdGgubWF4KGRyYXdZLCBzZWNZIC0gMjQpICsgMTYpO1xuICAgICAgY3R4LnJlc3RvcmUoKTtcbiAgICB9XG5cbiAgICBjdHgucmVzdG9yZSgpO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIE9WRVJMQVlTOiBQZW4gVG9vbCBQYXRoIC8gQ3JvcCBCb3hcbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgLy8gUGVuIFRvb2wgUGF0aFxuICAgIGlmIChhY3RpdmVUb29sID09PSAncGVuX3Rvb2wnICYmIHBlblBvaW50cy5sZW5ndGggPiAwKSB7XG4gICAgICBjdHguc2F2ZSgpO1xuICAgICAgY3R4LnRyYW5zbGF0ZShjYW52YXMud2lkdGggLyAyICsgY2FudmFzUGFuLngsIGNhbnZhcy5oZWlnaHQgLyAyICsgY2FudmFzUGFuLnkpO1xuICAgICAgY3R4LnNjYWxlKGNhbnZhc1pvb20sIGNhbnZhc1pvb20pO1xuXG4gICAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgICBjb25zdCBmaXJzdFggPSBkcmF3WCArIHBlblBvaW50c1swXS54ICogcmVuZGVyVztcbiAgICAgIGNvbnN0IGZpcnN0WSA9IGRyYXdZICsgcGVuUG9pbnRzWzBdLnkgKiByZW5kZXJIO1xuICAgICAgY3R4Lm1vdmVUbyhmaXJzdFgsIGZpcnN0WSk7XG5cbiAgICAgIGZvciAobGV0IGkgPSAxOyBpIDwgcGVuUG9pbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IHB4ID0gZHJhd1ggKyBwZW5Qb2ludHNbaV0ueCAqIHJlbmRlclc7XG4gICAgICAgIGNvbnN0IHB5ID0gZHJhd1kgKyBwZW5Qb2ludHNbaV0ueSAqIHJlbmRlckg7XG4gICAgICAgIGN0eC5saW5lVG8ocHgsIHB5KTtcbiAgICAgIH1cblxuICAgICAgaWYgKGlzUGF0aENsb3NlZCkge1xuICAgICAgICBjdHguY2xvc2VQYXRoKCk7XG4gICAgICAgIGN0eC5maWxsU3R5bGUgPSAncmdiYSgxNCwgMTY1LCAyMzMsIDAuMjUpJztcbiAgICAgICAgY3R4LmZpbGwoKTtcbiAgICAgIH1cblxuICAgICAgY3R4LnN0cm9rZVN0eWxlID0gaXNQYXRoQ2xvc2VkID8gJyMxMGI5ODEnIDogJyMzOGJkZjgnO1xuICAgICAgY3R4LmxpbmVXaWR0aCA9IDIgLyBjYW52YXNab29tO1xuICAgICAgY3R4LnNldExpbmVEYXNoKGlzUGF0aENsb3NlZCA/IFtdIDogWzQsIDRdKTtcbiAgICAgIGN0eC5zdHJva2UoKTtcblxuICAgICAgLy8gUG9pbnRzXG4gICAgICBwZW5Qb2ludHMuZm9yRWFjaCgocHQsIGlkeCkgPT4ge1xuICAgICAgICBjb25zdCBweCA9IGRyYXdYICsgcHQueCAqIHJlbmRlclc7XG4gICAgICAgIGNvbnN0IHB5ID0gZHJhd1kgKyBwdC55ICogcmVuZGVySDtcbiAgICAgICAgY29uc3QgaXNGaXJzdCA9IGlkeCA9PT0gMDtcblxuICAgICAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgICAgIGN0eC5hcmMocHgsIHB5LCAoaXNGaXJzdCA/IDcgOiA1KSAvIGNhbnZhc1pvb20sIDAsIE1hdGguUEkgKiAyKTtcbiAgICAgICAgY3R4LmZpbGxTdHlsZSA9IGlzRmlyc3QgPyAoaXNOZWFyU3RhcnRQb2ludCA/ICcjMjJjNTVlJyA6ICcjZWFiMzA4JykgOiAnIzM4YmRmOCc7XG4gICAgICAgIGN0eC5zdHJva2VTdHlsZSA9ICcjMGYxNzJhJztcbiAgICAgICAgY3R4LmxpbmVXaWR0aCA9IDIgLyBjYW52YXNab29tO1xuICAgICAgICBjdHguZmlsbCgpO1xuICAgICAgICBjdHguc3Ryb2tlKCk7XG4gICAgICB9KTtcblxuICAgICAgY3R4LnJlc3RvcmUoKTtcbiAgICB9XG5cbiAgICAvLyBDcm9wIFRvb2wgQm94IE92ZXJsYXlcbiAgICBpZiAoYWN0aXZlVG9vbCA9PT0gJ2Nyb3AnICYmIGNyb3BCb3gpIHtcbiAgICAgIGN0eC5zYXZlKCk7XG4gICAgICAvLyBEaW0gb3V0ZXIgYXJlYVxuICAgICAgY3R4LmZpbGxTdHlsZSA9ICdyZ2JhKDAsIDAsIDAsIDAuNiknO1xuICAgICAgY3R4LmZpbGxSZWN0KDAsIDAsIGNhbnZhcy53aWR0aCwgY3JvcEJveC55KTtcbiAgICAgIGN0eC5maWxsUmVjdCgwLCBjcm9wQm94LnkgKyBjcm9wQm94LmgsIGNhbnZhcy53aWR0aCwgY2FudmFzLmhlaWdodCAtIChjcm9wQm94LnkgKyBjcm9wQm94LmgpKTtcbiAgICAgIGN0eC5maWxsUmVjdCgwLCBjcm9wQm94LnksIGNyb3BCb3gueCwgY3JvcEJveC5oKTtcbiAgICAgIGN0eC5maWxsUmVjdChjcm9wQm94LnggKyBjcm9wQm94LncsIGNyb3BCb3gueSwgY2FudmFzLndpZHRoIC0gKGNyb3BCb3gueCArIGNyb3BCb3gudyksIGNyb3BCb3guaCk7XG5cbiAgICAgIC8vIENyb3AgYm9yZGVyXG4gICAgICBjdHguc3Ryb2tlU3R5bGUgPSAnIzM4YmRmOCc7XG4gICAgICBjdHgubGluZVdpZHRoID0gMjtcbiAgICAgIGN0eC5zdHJva2VSZWN0KGNyb3BCb3gueCwgY3JvcEJveC55LCBjcm9wQm94LncsIGNyb3BCb3guaCk7XG5cbiAgICAgIC8vIFJ1bGUgb2YgdGhpcmRzIGxpbmVzXG4gICAgICBjdHguc3Ryb2tlU3R5bGUgPSAncmdiYSgyNTUsIDI1NSwgMjU1LCAwLjMpJztcbiAgICAgIGN0eC5saW5lV2lkdGggPSAxO1xuICAgICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgICAgY3R4Lm1vdmVUbyhjcm9wQm94LnggKyBjcm9wQm94LncgLyAzLCBjcm9wQm94LnkpO1xuICAgICAgY3R4LmxpbmVUbyhjcm9wQm94LnggKyBjcm9wQm94LncgLyAzLCBjcm9wQm94LnkgKyBjcm9wQm94LmgpO1xuICAgICAgY3R4Lm1vdmVUbyhjcm9wQm94LnggKyAoY3JvcEJveC53ICogMikgLyAzLCBjcm9wQm94LnkpO1xuICAgICAgY3R4LmxpbmVUbyhjcm9wQm94LnggKyAoY3JvcEJveC53ICogMikgLyAzLCBjcm9wQm94LnkgKyBjcm9wQm94LmgpO1xuICAgICAgY3R4Lm1vdmVUbyhjcm9wQm94LngsIGNyb3BCb3gueSArIGNyb3BCb3guaCAvIDMpO1xuICAgICAgY3R4LmxpbmVUbyhjcm9wQm94LnggKyBjcm9wQm94LncsIGNyb3BCb3gueSArIGNyb3BCb3guaCAvIDMpO1xuICAgICAgY3R4Lm1vdmVUbyhjcm9wQm94LngsIGNyb3BCb3gueSArIChjcm9wQm94LmggKiAyKSAvIDMpO1xuICAgICAgY3R4LmxpbmVUbyhjcm9wQm94LnggKyBjcm9wQm94LncsIGNyb3BCb3gueSArIChjcm9wQm94LmggKiAyKSAvIDMpO1xuICAgICAgY3R4LnN0cm9rZSgpO1xuXG4gICAgICBjdHgucmVzdG9yZSgpO1xuICAgIH1cbiAgfTtcblxuICAvLyBDb252ZXJ0IEVkaXRvciBDYW52YXMgQ2xpY2sgdG8gSW1hZ2UgQ29vcmRpbmF0ZXNcbiAgY29uc3QgY2FudmFzVG9JbWFnZUNvb3JkcyA9IChjbGllbnRYOiBudW1iZXIsIGNsaWVudFk6IG51bWJlcikgPT4ge1xuICAgIGNvbnN0IGNhbnZhcyA9IGVkaXRvckNhbnZhc1JlZi5jdXJyZW50O1xuICAgIGNvbnN0IGltZyA9IHBob3RvSW1nUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjYW52YXMgfHwgIWltZykgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCByZWN0ID0gY2FudmFzLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIGNvbnN0IHNjYWxlWCA9IGNhbnZhcy53aWR0aCAvIHJlY3Qud2lkdGg7XG4gICAgY29uc3Qgc2NhbGVZID0gY2FudmFzLmhlaWdodCAvIHJlY3QuaGVpZ2h0O1xuXG4gICAgY29uc3QgY2xpY2tYID0gKGNsaWVudFggLSByZWN0LmxlZnQpICogc2NhbGVYO1xuICAgIGNvbnN0IGNsaWNrWSA9IChjbGllbnRZIC0gcmVjdC50b3ApICogc2NhbGVZO1xuXG4gICAgLy8gUmV2ZXJzZSBQYW4gJiBab29tXG4gICAgY29uc3QgbG9jYWxYID0gKGNsaWNrWCAtIChjYW52YXMud2lkdGggLyAyICsgY2FudmFzUGFuLngpKSAvIGNhbnZhc1pvb207XG4gICAgY29uc3QgbG9jYWxZID0gKGNsaWNrWSAtIChjYW52YXMuaGVpZ2h0IC8gMiArIGNhbnZhc1Bhbi55KSkgLyBjYW52YXNab29tO1xuXG4gICAgY29uc3QgYXNwZWN0ID0gaW1nLndpZHRoIC8gaW1nLmhlaWdodDtcbiAgICBsZXQgcmVuZGVyVyA9IDQ2MDtcbiAgICBsZXQgcmVuZGVySCA9IDQ2MCAvIGFzcGVjdDtcbiAgICBpZiAocmVuZGVySCA+IDU2MCkge1xuICAgICAgcmVuZGVySCA9IDU2MDtcbiAgICAgIHJlbmRlclcgPSA1NjAgKiBhc3BlY3Q7XG4gICAgfVxuXG4gICAgY29uc3QgZHJhd1ggPSAtcmVuZGVyVyAvIDI7XG4gICAgY29uc3QgZHJhd1kgPSAtcmVuZGVySCAvIDI7XG5cbiAgICBjb25zdCBub3JtWCA9IChsb2NhbFggLSBkcmF3WCkgLyByZW5kZXJXO1xuICAgIGNvbnN0IG5vcm1ZID0gKGxvY2FsWSAtIGRyYXdZKSAvIHJlbmRlckg7XG5cbiAgICBjb25zdCBpbWdYID0gbm9ybVggKiBpbWcud2lkdGg7XG4gICAgY29uc3QgaW1nWSA9IG5vcm1ZICogaW1nLmhlaWdodDtcblxuICAgIHJldHVybiB7XG4gICAgICBub3JtWCxcbiAgICAgIG5vcm1ZLFxuICAgICAgaW1nWCxcbiAgICAgIGltZ1ksXG4gICAgICBpc0luc2lkZTogbm9ybVggPj0gMCAmJiBub3JtWCA8PSAxICYmIG5vcm1ZID49IDAgJiYgbm9ybVkgPD0gMVxuICAgIH07XG4gIH07XG5cbiAgLy8gQ2FudmFzIE1vdXNlIERvd25cbiAgY29uc3QgaGFuZGxlRWRpdG9yTW91c2VEb3duID0gKGU6IFJlYWN0Lk1vdXNlRXZlbnQ8SFRNTENhbnZhc0VsZW1lbnQ+KSA9PiB7XG4gICAgaWYgKGlzU3BhY2VQcmVzc2VkIHx8IGFjdGl2ZVRvb2wgPT09ICdoYW5kJyB8fCBlLmJ1dHRvbiA9PT0gMSkge1xuICAgICAgc2V0SXNQYW5uaW5nKHRydWUpO1xuICAgICAgc2V0UGFuU3RhcnQoeyB4OiBlLmNsaWVudFggLSBjYW52YXNQYW4ueCwgeTogZS5jbGllbnRZIC0gY2FudmFzUGFuLnkgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgY29vcmRzID0gY2FudmFzVG9JbWFnZUNvb3JkcyhlLmNsaWVudFgsIGUuY2xpZW50WSk7XG4gICAgaWYgKCFjb29yZHMgfHwgIWNvb3Jkcy5pc0luc2lkZSkgcmV0dXJuO1xuXG4gICAgLy8gVG9vbCBhY3Rpb25zXG4gICAgaWYgKGFjdGl2ZVRvb2wgPT09ICdzZWN0aW9uX3NlbGVjdCcpIHtcbiAgICAgIHNldElzU2VsZWN0aW5nQm94KHRydWUpO1xuICAgICAgc2V0U2VsZWN0aW9uU3RhcnROb3JtKHsgeDogY29vcmRzLm5vcm1YLCB5OiBjb29yZHMubm9ybVkgfSk7XG4gICAgICBzZXRTZWxlY3Rpb25Cb3goeyB4OiBjb29yZHMubm9ybVgsIHk6IGNvb3Jkcy5ub3JtWSwgdzogMC4wMSwgaDogMC4wMSB9KTtcbiAgICAgIHNldEdyYWRpbmdTY29wZSgnc2VsZWN0aW9uJyk7XG4gICAgfSBlbHNlIGlmIChhY3RpdmVUb29sID09PSAnbWFnaWNfd2FuZCcpIHtcbiAgICAgIGV4ZWN1dGVNYWdpY1dhbmRDdXQoY29vcmRzLmltZ1gsIGNvb3Jkcy5pbWdZKTtcbiAgICB9IGVsc2UgaWYgKGFjdGl2ZVRvb2wgPT09ICdwZW5fdG9vbCcpIHtcbiAgICAgIGlmIChwZW5Qb2ludHMubGVuZ3RoID49IDMgJiYgIWlzUGF0aENsb3NlZCkge1xuICAgICAgICBjb25zdCBmaXJzdCA9IHBlblBvaW50c1swXTtcbiAgICAgICAgY29uc3QgZGlzdCA9IE1hdGguaHlwb3QoY29vcmRzLm5vcm1YIC0gZmlyc3QueCwgY29vcmRzLm5vcm1ZIC0gZmlyc3QueSk7XG4gICAgICAgIGlmIChkaXN0IDwgMC4wNSkge1xuICAgICAgICAgIHNldElzUGF0aENsb3NlZCh0cnVlKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmICghaXNQYXRoQ2xvc2VkKSB7XG4gICAgICAgIHNldFBlblBvaW50cyhwcmV2ID0+IFsuLi5wcmV2LCB7IHg6IGNvb3Jkcy5ub3JtWCwgeTogY29vcmRzLm5vcm1ZIH1dKTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGFjdGl2ZVRvb2wgPT09ICdibGVtaXNoX2JydXNoJykge1xuICAgICAgYXBwbHlIZWFsaW5nQnJ1c2goY29vcmRzLmltZ1gsIGNvb3Jkcy5pbWdZLCAnYmxlbWlzaCcpO1xuICAgIH0gZWxzZSBpZiAoYWN0aXZlVG9vbCA9PT0gJ2JlYXV0eV9icnVzaCcpIHtcbiAgICAgIGFwcGx5SGVhbGluZ0JydXNoKGNvb3Jkcy5pbWdYLCBjb29yZHMuaW1nWSwgJ2JlYXV0eScpO1xuICAgIH0gZWxzZSBpZiAoYWN0aXZlVG9vbCA9PT0gJ2V5ZV9icmlnaHRlbicpIHtcbiAgICAgIGFwcGx5SGVhbGluZ0JydXNoKGNvb3Jkcy5pbWdYLCBjb29yZHMuaW1nWSwgJ2V5ZScpO1xuICAgIH0gZWxzZSBpZiAoYWN0aXZlVG9vbCA9PT0gJ3pvb20nKSB7XG4gICAgICBpZiAoZS5hbHRLZXkpIHtcbiAgICAgICAgc2V0Q2FudmFzWm9vbShwcmV2ID0+IE1hdGgubWF4KDAuNCwgcHJldiAtIDAuMykpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc2V0Q2FudmFzWm9vbShwcmV2ID0+IE1hdGgubWluKDQuMCwgcHJldiArIDAuMykpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcblxuICAvLyBDYW52YXMgTW91c2UgTW92ZVxuICBjb25zdCBoYW5kbGVFZGl0b3JNb3VzZU1vdmUgPSAoZTogUmVhY3QuTW91c2VFdmVudDxIVE1MQ2FudmFzRWxlbWVudD4pID0+IHtcbiAgICBpZiAoaXNQYW5uaW5nKSB7XG4gICAgICBzZXRDYW52YXNQYW4oe1xuICAgICAgICB4OiBlLmNsaWVudFggLSBwYW5TdGFydC54LFxuICAgICAgICB5OiBlLmNsaWVudFkgLSBwYW5TdGFydC55XG4gICAgICB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoaXNTZWxlY3RpbmdCb3ggJiYgc2VsZWN0aW9uU3RhcnROb3JtICYmIGFjdGl2ZVRvb2wgPT09ICdzZWN0aW9uX3NlbGVjdCcpIHtcbiAgICAgIGNvbnN0IGNvb3JkcyA9IGNhbnZhc1RvSW1hZ2VDb29yZHMoZS5jbGllbnRYLCBlLmNsaWVudFkpO1xuICAgICAgaWYgKGNvb3Jkcykge1xuICAgICAgICBjb25zdCBjdXJYID0gTWF0aC5tYXgoMCwgTWF0aC5taW4oMSwgY29vcmRzLm5vcm1YKSk7XG4gICAgICAgIGNvbnN0IGN1clkgPSBNYXRoLm1heCgwLCBNYXRoLm1pbigxLCBjb29yZHMubm9ybVkpKTtcbiAgICAgICAgY29uc3QgYm94WCA9IE1hdGgubWluKHNlbGVjdGlvblN0YXJ0Tm9ybS54LCBjdXJYKTtcbiAgICAgICAgY29uc3QgYm94WSA9IE1hdGgubWluKHNlbGVjdGlvblN0YXJ0Tm9ybS55LCBjdXJZKTtcbiAgICAgICAgY29uc3QgYm94VyA9IE1hdGgubWF4KDAuMDEsIE1hdGguYWJzKGN1clggLSBzZWxlY3Rpb25TdGFydE5vcm0ueCkpO1xuICAgICAgICBjb25zdCBib3hIID0gTWF0aC5tYXgoMC4wMSwgTWF0aC5hYnMoY3VyWSAtIHNlbGVjdGlvblN0YXJ0Tm9ybS55KSk7XG4gICAgICAgIHNldFNlbGVjdGlvbkJveCh7IHg6IGJveFgsIHk6IGJveFksIHc6IGJveFcsIGg6IGJveEggfSk7XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKGFjdGl2ZVRvb2wgPT09ICdwZW5fdG9vbCcgJiYgcGVuUG9pbnRzLmxlbmd0aCA+PSAzICYmICFpc1BhdGhDbG9zZWQpIHtcbiAgICAgIGNvbnN0IGNvb3JkcyA9IGNhbnZhc1RvSW1hZ2VDb29yZHMoZS5jbGllbnRYLCBlLmNsaWVudFkpO1xuICAgICAgaWYgKGNvb3Jkcykge1xuICAgICAgICBjb25zdCBmaXJzdCA9IHBlblBvaW50c1swXTtcbiAgICAgICAgY29uc3QgZGlzdCA9IE1hdGguaHlwb3QoY29vcmRzLm5vcm1YIC0gZmlyc3QueCwgY29vcmRzLm5vcm1ZIC0gZmlyc3QueSk7XG4gICAgICAgIHNldElzTmVhclN0YXJ0UG9pbnQoZGlzdCA8IDAuMDUpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcblxuICAvLyBDYW52YXMgTW91c2UgVXBcbiAgY29uc3QgaGFuZGxlRWRpdG9yTW91c2VVcCA9ICgpID0+IHtcbiAgICBzZXRJc1Bhbm5pbmcoZmFsc2UpO1xuICAgIHNldElzU2VsZWN0aW5nQm94KGZhbHNlKTtcbiAgICBzZXRTZWxlY3Rpb25TdGFydE5vcm0obnVsbCk7XG4gIH07XG5cbiAgLy8gQ2FudmFzIE1vdXNlIFdoZWVsIChDZW50ZXJlZCBab29tKVxuICBjb25zdCBoYW5kbGVFZGl0b3JXaGVlbCA9IChlOiBSZWFjdC5XaGVlbEV2ZW50PEhUTUxDYW52YXNFbGVtZW50PikgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBjb25zdCB6b29tRmFjdG9yID0gZS5kZWx0YVkgPCAwID8gMS4xNSA6IDAuODg7XG4gICAgc2V0Q2FudmFzWm9vbShwcmV2ID0+IE1hdGgubWF4KDAuNCwgTWF0aC5taW4oNC4wLCBwcmV2ICogem9vbUZhY3RvcikpKTtcbiAgfTtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIE1JTkkgUFJFVklFVyBDQU5WQVMgUkVOREVSIChcInByZXZpZXcgbWluaSBkaWtobmEgY2hhaXllXCIpXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgY29uc3QgcmVuZGVyTWluaVByZXZpZXcgPSAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gbWluaVByZXZpZXdDYW52YXNSZWYuY3VycmVudDtcbiAgICBjb25zdCBpbWcgPSBwaG90b0ltZ1JlZi5jdXJyZW50O1xuICAgIGlmICghY2FudmFzKSByZXR1cm47XG5cbiAgICBjb25zdCBjdHggPSBjYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcbiAgICBpZiAoIWN0eCkgcmV0dXJuO1xuXG4gICAgY2FudmFzLndpZHRoID0gMjQwO1xuICAgIGNhbnZhcy5oZWlnaHQgPSAxNjA7XG5cbiAgICAvLyBQdXJlIHdoaXRlIHBob3RvIHBhcGVyXG4gICAgY3R4LmZpbGxTdHlsZSA9ICcjZmZmZmZmJztcbiAgICBjdHguZmlsbFJlY3QoMCwgMCwgY2FudmFzLndpZHRoLCBjYW52YXMuaGVpZ2h0KTtcblxuICAgIGlmICghaW1nKSB7XG4gICAgICBjdHguZmlsbFN0eWxlID0gJyM5NGEzYjgnO1xuICAgICAgY3R4LmZvbnQgPSAnMTBweCBzYW5zLXNlcmlmJztcbiAgICAgIGN0eC50ZXh0QWxpZ24gPSAnY2VudGVyJztcbiAgICAgIGN0eC5maWxsVGV4dCgnTWluaSBTaGVldCBQcmV2aWV3JywgY2FudmFzLndpZHRoIC8gMiwgY2FudmFzLmhlaWdodCAvIDIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIERyYXcgbWluaWF0dXJlIGdyaWQgKDR4NiBsYW5kc2NhcGUgOCBjb3BpZXMgb3IgQTQpXG4gICAgY29uc3QgaXNBNCA9IHBhcGVyRm9ybWF0LnN0YXJ0c1dpdGgoJ2E0Jyk7XG4gICAgY29uc3QgY29scyA9IHBhcGVyRm9ybWF0ID09PSAnNHg2X2xhbmRzY2FwZScgPyA0IDogaXNBNCA/IChjb3BpZXMgPT09IDMyID8gOCA6IDQpIDogMjtcbiAgICBjb25zdCByb3dzID0gcGFwZXJGb3JtYXQgPT09ICc0eDZfbGFuZHNjYXBlJyA/IDIgOiBpc0E0ID8gNCA6IDQ7XG5cbiAgICBjb25zdCBnYXAgPSA0O1xuICAgIGNvbnN0IG1hcmdpbiA9IDg7XG4gICAgY29uc3QgY2VsbFcgPSAoY2FudmFzLndpZHRoIC0gbWFyZ2luICogMiAtIChjb2xzIC0gMSkgKiBnYXApIC8gY29scztcbiAgICBjb25zdCBjZWxsSCA9IGNlbGxXICogKDQ1IC8gMzUpO1xuXG4gICAgbGV0IGNvdW50ID0gMDtcbiAgICBmb3IgKGxldCByID0gMDsgciA8IHJvd3M7IHIrKykge1xuICAgICAgZm9yIChsZXQgYyA9IDA7IGMgPCBjb2xzOyBjKyspIHtcbiAgICAgICAgaWYgKGNvdW50ID49IGNvcGllcykgYnJlYWs7XG4gICAgICAgIGNvbnN0IHggPSBtYXJnaW4gKyBjICogKGNlbGxXICsgZ2FwKTtcbiAgICAgICAgY29uc3QgeSA9IG1hcmdpbiArIHIgKiAoY2VsbEggKyBnYXApO1xuXG4gICAgICAgIC8vIEZpbGwgYmFja2dyb3VuZFxuICAgICAgICBjdHguZmlsbFN0eWxlID0gYmdDb2xvcjtcbiAgICAgICAgY3R4LmZpbGxSZWN0KHgsIHksIGNlbGxXLCBjZWxsSCk7XG5cbiAgICAgICAgLy8gRHJhdyBwaG90b1xuICAgICAgICBjdHguZHJhd0ltYWdlKGltZywgeCwgeSwgY2VsbFcsIGNlbGxIKTtcblxuICAgICAgICAvLyBDdXQgbWFya1xuICAgICAgICBjdHguc3Ryb2tlU3R5bGUgPSAnIzk0YTNiOCc7XG4gICAgICAgIGN0eC5saW5lV2lkdGggPSAwLjU7XG4gICAgICAgIGN0eC5zdHJva2VSZWN0KHgsIHksIGNlbGxXLCBjZWxsSCk7XG5cbiAgICAgICAgY291bnQrKztcbiAgICAgIH1cbiAgICB9XG4gIH07XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBGVUxMIFNIRUVUIDMwMCBEUEkgUkVOREVSIChGb3IgRGlyZWN0IFByaW50aW5nICYgUERGIC8gSlBHIEV4cG9ydClcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBjb25zdCByZW5kZXJGdWxsU2hlZXQgPSAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gZnVsbFNoZWV0Q2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgaW1nID0gcGhvdG9JbWdSZWYuY3VycmVudDtcbiAgICBpZiAoIWNhbnZhcyB8fCAhaW1nKSByZXR1cm47XG5cbiAgICBjb25zdCBjdHggPSBjYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcbiAgICBpZiAoIWN0eCkgcmV0dXJuO1xuXG4gICAgY2FudmFzLndpZHRoID0gU0hFRVRfV0lEVEg7XG4gICAgY2FudmFzLmhlaWdodCA9IFNIRUVUX0hFSUdIVDtcblxuICAgIGN0eC5maWxsU3R5bGUgPSAnI2ZmZmZmZic7XG4gICAgY3R4LmZpbGxSZWN0KDAsIDAsIFNIRUVUX1dJRFRILCBTSEVFVF9IRUlHSFQpO1xuXG4gICAgLy8gU2luZ2xlIHBob3RvIGNhbnZhcyBhdCAzMDAgRFBJXG4gICAgY29uc3Qgc2luZ2xlVyA9IDM1MDtcbiAgICBjb25zdCBzaW5nbGVIID0gNDUwO1xuICAgIGNvbnN0IHNpbmdsZUNhbnZhcyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpO1xuICAgIHNpbmdsZUNhbnZhcy53aWR0aCA9IHNpbmdsZVc7XG4gICAgc2luZ2xlQ2FudmFzLmhlaWdodCA9IHNpbmdsZUg7XG4gICAgY29uc3Qgc0N0eCA9IHNpbmdsZUNhbnZhcy5nZXRDb250ZXh0KCcyZCcpO1xuXG4gICAgaWYgKHNDdHgpIHtcbiAgICAgIHNDdHguZmlsbFN0eWxlID0gYmdDb2xvcjtcbiAgICAgIHNDdHguZmlsbFJlY3QoMCwgMCwgc2luZ2xlVywgc2luZ2xlSCk7XG5cbiAgICAgIC8vIENvbG9yIGZpbHRlcnNcbiAgICAgIGNvbnN0IGVmZkJyaWdodG5lc3MgPSAxMDAgKyBicmlnaHRuZXNzICsgKGF1dG9CZWF1dHkgPyA2IDogMCkgKyAoZmFjZUdsb3cgKiAwLjEyKTtcbiAgICAgIGNvbnN0IGVmZkNvbnRyYXN0ID0gMTAwICsgY29udHJhc3QgKyAoYXV0b0JlYXV0eSA/IDQgOiAwKTtcbiAgICAgIGNvbnN0IGVmZlNhdHVyYXRpb24gPSBpc0dyYXlzY2FsZSA/IDAgOiAxMDAgKyBzYXR1cmF0aW9uICsgKGF1dG9CZWF1dHkgPyA4IDogMCk7XG5cbiAgICAgIGxldCBmaWx0ZXJTdHIgPSBgYnJpZ2h0bmVzcygke2VmZkJyaWdodG5lc3N9JSkgY29udHJhc3QoJHtlZmZDb250cmFzdH0lKSBzYXR1cmF0ZSgke2VmZlNhdHVyYXRpb259JSlgO1xuICAgICAgaWYgKGlzR3JheXNjYWxlKSBmaWx0ZXJTdHIgKz0gJyBncmF5c2NhbGUoMTAwJSknO1xuICAgICAgc0N0eC5maWx0ZXIgPSBmaWx0ZXJTdHI7XG5cbiAgICAgIGNvbnN0IGFzcGVjdCA9IGltZy53aWR0aCAvIGltZy5oZWlnaHQ7XG4gICAgICBsZXQgZHcgPSBzaW5nbGVXO1xuICAgICAgbGV0IGRoID0gc2luZ2xlSDtcbiAgICAgIGlmIChhc3BlY3QgPiBzaW5nbGVXIC8gc2luZ2xlSCkge1xuICAgICAgICBkdyA9IHNpbmdsZUggKiBhc3BlY3Q7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBkaCA9IHNpbmdsZVcgLyBhc3BlY3Q7XG4gICAgICB9XG5cbiAgICAgIHNDdHguZHJhd0ltYWdlKGltZywgKHNpbmdsZVcgLSBkdykgLyAyLCAoc2luZ2xlSCAtIGRoKSAvIDIsIGR3LCBkaCk7XG5cbiAgICAgIC8vIExvY2FsIFNlY3Rpb24gQ29sb3IgR3JhZGluZyBwYXNzIG9uIHByaW50IHNoZWV0XG4gICAgICBpZiAoc2VsZWN0aW9uQm94ICYmIHNlbGVjdGlvbkJveC53ID4gMC4wMDUgJiYgc2VsZWN0aW9uQm94LmggPiAwLjAwNSkge1xuICAgICAgICBjb25zdCBzZWNYID0gKHNpbmdsZVcgLSBkdykgLyAyICsgc2VsZWN0aW9uQm94LnggKiBkdztcbiAgICAgICAgY29uc3Qgc2VjWSA9IChzaW5nbGVIIC0gZGgpIC8gMiArIHNlbGVjdGlvbkJveC55ICogZGg7XG4gICAgICAgIGNvbnN0IHNlY1cgPSBzZWxlY3Rpb25Cb3gudyAqIGR3O1xuICAgICAgICBjb25zdCBzZWNIID0gc2VsZWN0aW9uQm94LmggKiBkaDtcblxuICAgICAgICBzQ3R4LnNhdmUoKTtcbiAgICAgICAgc0N0eC5iZWdpblBhdGgoKTtcbiAgICAgICAgc0N0eC5yZWN0KHNlY1gsIHNlY1ksIHNlY1csIHNlY0gpO1xuICAgICAgICBzQ3R4LmNsaXAoKTtcblxuICAgICAgICBjb25zdCBzZWNFZmZCcmlnaHQgPSBlZmZCcmlnaHRuZXNzICsgc2VjQnJpZ2h0bmVzcztcbiAgICAgICAgY29uc3Qgc2VjRWZmQ29udCA9IGVmZkNvbnRyYXN0ICsgc2VjQ29udHJhc3Q7XG4gICAgICAgIGNvbnN0IHNlY0VmZlNhdCA9IGlzR3JheXNjYWxlID8gMCA6IGVmZlNhdHVyYXRpb24gKyBzZWNTYXR1cmF0aW9uO1xuXG4gICAgICAgIHNDdHguZmlsdGVyID0gYGJyaWdodG5lc3MoJHtzZWNFZmZCcmlnaHR9JSkgY29udHJhc3QoJHtzZWNFZmZDb250fSUpIHNhdHVyYXRlKCR7c2VjRWZmU2F0fSUpYDtcbiAgICAgICAgc0N0eC5kcmF3SW1hZ2UoaW1nLCAoc2luZ2xlVyAtIGR3KSAvIDIsIChzaW5nbGVIIC0gZGgpIC8gMiwgZHcsIGRoKTtcblxuICAgICAgICBpZiAoc2VjV2FybXRoICE9PSAwICYmICFpc0dyYXlzY2FsZSkge1xuICAgICAgICAgIHNDdHguZ2xvYmFsQ29tcG9zaXRlT3BlcmF0aW9uID0gJ2NvbG9yJztcbiAgICAgICAgICBzQ3R4LmZpbGxTdHlsZSA9IHNlY1dhcm10aCA+IDBcbiAgICAgICAgICAgID8gYHJnYmEoMjU1LCAxNzUsIDc1LCAke01hdGgubWluKDAuNDUsIChzZWNXYXJtdGggLyAxMDApICogMC41KX0pYFxuICAgICAgICAgICAgOiBgcmdiYSg4MCwgMTY1LCAyNTUsICR7TWF0aC5taW4oMC40NSwgKE1hdGguYWJzKHNlY1dhcm10aCkgLyAxMDApICogMC41KX0pYDtcbiAgICAgICAgICBzQ3R4LmZpbGxSZWN0KHNlY1gsIHNlY1ksIHNlY1csIHNlY0gpO1xuICAgICAgICB9XG4gICAgICAgIHNDdHgucmVzdG9yZSgpO1xuICAgICAgfVxuXG4gICAgICAvLyBTb2Z0IGxpZ2h0IGJlYXV0eSBwYXNzXG4gICAgICBjb25zdCBlZmZTbW9vdGggPSBhdXRvQmVhdXR5ID8gTWF0aC5tYXgoc2tpblNtb290aCwgMTYpIDogc2tpblNtb290aDtcbiAgICAgIGNvbnN0IGVmZkdsb3cgPSBhdXRvQmVhdXR5ID8gTWF0aC5tYXgoZmFjZUdsb3csIDIwKSA6IGZhY2VHbG93O1xuICAgICAgaWYgKGVmZlNtb290aCA+IDAgfHwgZWZmR2xvdyA+IDApIHtcbiAgICAgICAgc0N0eC5zYXZlKCk7XG4gICAgICAgIHNDdHguZ2xvYmFsQ29tcG9zaXRlT3BlcmF0aW9uID0gJ3NvZnQtbGlnaHQnO1xuICAgICAgICBzQ3R4Lmdsb2JhbEFscGhhID0gTWF0aC5taW4oMC42NSwgKGVmZlNtb290aCAqIDAuMDEyKSArIChlZmZHbG93ICogMC4wMSkpO1xuICAgICAgICBzQ3R4LmZpbHRlciA9IGBibHVyKCR7TWF0aC5tYXgoMiwgZWZmU21vb3RoIC8gOCl9cHgpIGJyaWdodG5lc3MoMTIwJSlgO1xuICAgICAgICBzQ3R4LmRyYXdJbWFnZShpbWcsIChzaW5nbGVXIC0gZHcpIC8gMiwgKHNpbmdsZUggLSBkaCkgLyAyLCBkdywgZGgpO1xuICAgICAgICBzQ3R4LnJlc3RvcmUoKTtcbiAgICAgIH1cblxuICAgICAgLy8gQ2FuZGlkYXRlIE5hbWUgJiBEYXRlIFN0cmlwXG4gICAgICBpZiAoc2hvd05hbWVEYXRlKSB7XG4gICAgICAgIGNvbnN0IGJveEggPSA1ODtcbiAgICAgICAgc0N0eC5maWxsU3R5bGUgPSAnI2ZmZmZmZic7XG4gICAgICAgIHNDdHguZmlsbFJlY3QoMCwgc2luZ2xlSCAtIGJveEgsIHNpbmdsZVcsIGJveEgpO1xuICAgICAgICBzQ3R4LmZpbGxTdHlsZSA9ICcjMDAwMDAwJztcbiAgICAgICAgc0N0eC5mb250ID0gJ2JvbGQgMTdweCBzYW5zLXNlcmlmJztcbiAgICAgICAgc0N0eC50ZXh0QWxpZ24gPSAnY2VudGVyJztcbiAgICAgICAgc0N0eC5maWxsVGV4dChjYW5kaWRhdGVOYW1lLnRvVXBwZXJDYXNlKCksIHNpbmdsZVcgLyAyLCBzaW5nbGVIIC0gYm94SCArIDIyKTtcbiAgICAgICAgc0N0eC5mb250ID0gJ2JvbGQgMTRweCBzYW5zLXNlcmlmJztcbiAgICAgICAgc0N0eC5maWxsVGV4dChgREFURTogJHtwaG90b0RhdGV9YCwgc2luZ2xlVyAvIDIsIHNpbmdsZUggLSBib3hIICsgNDUpO1xuICAgICAgICBzQ3R4LnN0cm9rZVN0eWxlID0gJyMwMDAwMDAnO1xuICAgICAgICBzQ3R4LmxpbmVXaWR0aCA9IDI7XG4gICAgICAgIHNDdHguYmVnaW5QYXRoKCk7XG4gICAgICAgIHNDdHgubW92ZVRvKDAsIHNpbmdsZUggLSBib3hIKTtcbiAgICAgICAgc0N0eC5saW5lVG8oc2luZ2xlVywgc2luZ2xlSCAtIGJveEgpO1xuICAgICAgICBzQ3R4LnN0cm9rZSgpO1xuICAgICAgfVxuXG4gICAgICBzQ3R4LnN0cm9rZVN0eWxlID0gJyMzMzQxNTUnO1xuICAgICAgc0N0eC5saW5lV2lkdGggPSAyO1xuICAgICAgc0N0eC5zdHJva2VSZWN0KDAsIDAsIHNpbmdsZVcsIHNpbmdsZUgpO1xuICAgIH1cblxuICAgIC8vIEdyaWQgcGxhY2VtZW50XG4gICAgY29uc3QgY29scyA9IHBhcGVyRm9ybWF0ID09PSAnNHg2X2xhbmRzY2FwZScgPyA0IDogcGFwZXJGb3JtYXQgPT09ICdhNF9sYW5kc2NhcGUnID8gKGNvcGllcyA9PT0gMzIgPyA4IDogNCkgOiAyO1xuICAgIGNvbnN0IHJvd3MgPSBwYXBlckZvcm1hdCA9PT0gJzR4Nl9sYW5kc2NhcGUnID8gMiA6IDQ7XG5cbiAgICBjb25zdCBpc0E0ID0gcGFwZXJGb3JtYXQuc3RhcnRzV2l0aCgnYTQnKTtcbiAgICBjb25zdCBtYXJnaW5YID0gaXNBNCA/IDkwIDogNjA7XG4gICAgY29uc3QgbWFyZ2luWSA9IGlzQTQgPyA4MCA6IDUwO1xuICAgIGNvbnN0IGF2YWlsYWJsZVcgPSBTSEVFVF9XSURUSCAtIG1hcmdpblggKiAyO1xuICAgIGNvbnN0IGF2YWlsYWJsZUggPSBTSEVFVF9IRUlHSFQgLSBtYXJnaW5ZICogMjtcblxuICAgIGNvbnN0IGdhcCA9IGlzQTQgPyAyMCA6IDE2O1xuICAgIGNvbnN0IHRhcmdldFcgPSAoYXZhaWxhYmxlVyAtIChjb2xzIC0gMSkgKiBnYXApIC8gY29scztcbiAgICBsZXQgZHJhd1cgPSB0YXJnZXRXO1xuICAgIGxldCBkcmF3SCA9IHRhcmdldFcgKiAoNDUgLyAzNSk7XG5cbiAgICBpZiAocm93cyAqIGRyYXdIICsgKHJvd3MgLSAxKSAqIGdhcCA+IGF2YWlsYWJsZUgpIHtcbiAgICAgIGRyYXdIID0gKGF2YWlsYWJsZUggLSAocm93cyAtIDEpICogZ2FwKSAvIHJvd3M7XG4gICAgICBkcmF3VyA9IGRyYXdIICogKDM1IC8gNDUpO1xuICAgIH1cblxuICAgIGNvbnN0IGdhcFggPSBjb2xzID4gMSA/IChhdmFpbGFibGVXIC0gY29scyAqIGRyYXdXKSAvIChjb2xzIC0gMSkgOiAwO1xuICAgIGNvbnN0IGdhcFkgPSByb3dzID4gMSA/IChhdmFpbGFibGVIIC0gcm93cyAqIGRyYXdIKSAvIChyb3dzIC0gMSkgOiAwO1xuXG4gICAgbGV0IGNvdW50ID0gMDtcbiAgICBmb3IgKGxldCByID0gMDsgciA8IHJvd3M7IHIrKykge1xuICAgICAgZm9yIChsZXQgYyA9IDA7IGMgPCBjb2xzOyBjKyspIHtcbiAgICAgICAgaWYgKGNvdW50ID49IGNvcGllcykgYnJlYWs7XG4gICAgICAgIGNvbnN0IHggPSBtYXJnaW5YICsgYyAqIChkcmF3VyArIGdhcFgpO1xuICAgICAgICBjb25zdCB5ID0gbWFyZ2luWSArIHIgKiAoZHJhd0ggKyBnYXBZKTtcblxuICAgICAgICBjdHguZHJhd0ltYWdlKHNpbmdsZUNhbnZhcywgeCwgeSwgZHJhd1csIGRyYXdIKTtcbiAgICAgICAgY3R4LnN0cm9rZVN0eWxlID0gJyM2NDc0OGInO1xuICAgICAgICBjdHgubGluZVdpZHRoID0gMTtcbiAgICAgICAgY3R4LnN0cm9rZVJlY3QoeCwgeSwgZHJhd1csIGRyYXdIKTtcbiAgICAgICAgY291bnQrKztcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBDZW50ZXIgY3V0dGluZyBsaW5lXG4gICAgY3R4LnNhdmUoKTtcbiAgICBjdHguc3Ryb2tlU3R5bGUgPSAnIzk0YTNiOCc7XG4gICAgY3R4LmxpbmVXaWR0aCA9IDEuNTtcbiAgICBjdHguc2V0TGluZURhc2goWzYsIDZdKTtcbiAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgY3R4Lm1vdmVUbygzMCwgU0hFRVRfSEVJR0hUIC8gMik7XG4gICAgY3R4LmxpbmVUbyhTSEVFVF9XSURUSCAtIDMwLCBTSEVFVF9IRUlHSFQgLyAyKTtcbiAgICBjdHguc3Ryb2tlKCk7XG4gICAgY3R4LnJlc3RvcmUoKTtcbiAgfTtcblxuICAvLyBVcGxvYWQgaGFuZGxlclxuICBjb25zdCBoYW5kbGVVcGxvYWQgPSAoZTogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHtcbiAgICBjb25zdCBmaWxlID0gZS50YXJnZXQuZmlsZXM/LlswXTtcbiAgICBpZiAoIWZpbGUpIHJldHVybjtcblxuICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XG4gICAgcmVhZGVyLm9ubG9hZCA9IChldmVudCkgPT4ge1xuICAgICAgY29uc3Qgc3JjID0gZXZlbnQudGFyZ2V0Py5yZXN1bHQgYXMgc3RyaW5nO1xuICAgICAgc2V0UGhvdG9TcmMoc3JjKTtcbiAgICAgIHNldE9yaWdpbmFsUGhvdG9TcmMoc3JjKTtcbiAgICAgIHNldEhpc3RvcnlTdGFjayhbc3JjXSk7XG4gICAgICBzZXRIaXN0b3J5SW5kZXgoMCk7XG4gICAgICBzZXRDYW52YXNab29tKDEuMCk7XG4gICAgICBzZXRDYW52YXNQYW4oeyB4OiAwLCB5OiAwIH0pO1xuICAgICAgc2V0UGVuUG9pbnRzKFtdKTtcbiAgICAgIHNldElzUGF0aENsb3NlZChmYWxzZSk7XG4gICAgICBzZXRBdXRvQmVhdXR5KHRydWUpO1xuICAgICAgc2V0QWN0aXZlUHJlc2V0KCdhdXRvX2JlYXV0eScpO1xuICAgIH07XG4gICAgcmVhZGVyLnJlYWRBc0RhdGFVUkwoZmlsZSk7XG4gICAgZS50YXJnZXQudmFsdWUgPSAnJztcbiAgfTtcblxuICAvLyBEaXJlY3QgSW4tQXBwIFByaW50XG4gIGNvbnN0IGhhbmRsZURpcmVjdFByaW50ID0gKCkgPT4ge1xuICAgIGNvbnN0IGNhbnZhcyA9IGZ1bGxTaGVldENhbnZhc1JlZi5jdXJyZW50O1xuICAgIGlmICghY2FudmFzKSByZXR1cm47XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgZGF0YVVybCA9IGNhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL2pwZWcnLCAxLjApO1xuICAgICAgcHJpbnRJbWFnZVNoZWV0KGRhdGFVcmwsIHtcbiAgICAgICAgcGFwZXJGb3JtYXQsXG4gICAgICAgIHRpdGxlOiBgUGFzc3BvcnRfJHtwYXBlckZvcm1hdH1fJHtjb3BpZXN9Q29waWVzYCxcbiAgICAgICAgY29waWVzQ291bnQ6IGNvcGllc1xuICAgICAgfSk7XG5cbiAgICAgIHNldFByaW50QWxlcnQoYPCflqjvuI8gUHJpbnQgY29tbWFuZCBzZW50IHRvIHByaW50ZXIhICgke3BhcGVyRm9ybWF0LnJlcGxhY2UoJ18nLCAnICcpLnRvVXBwZXJDYXNlKCl9IOKAoiAke2NvcGllc30gQ29waWVzKWApO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRQcmludEFsZXJ0KG51bGwpLCA0MDAwKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgd2luZG93LnByaW50KCk7XG4gICAgfVxuICB9O1xuXG4gIC8vIERvd25sb2FkIFBERlxuICBjb25zdCBoYW5kbGVEb3dubG9hZFNoZWV0UERGID0gKCkgPT4ge1xuICAgIGNvbnN0IGNhbnZhcyA9IGZ1bGxTaGVldENhbnZhc1JlZi5jdXJyZW50O1xuICAgIGlmICghY2FudmFzKSByZXR1cm47XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgZGF0YVVybCA9IGNhbnZhcy50b0RhdGFVUkwoJ2ltYWdlL2pwZWcnLCAwLjk4KTtcbiAgICAgIGNvbnN0IGlzTGFuZHNjYXBlID0gcGFwZXJGb3JtYXQuaW5jbHVkZXMoJ2xhbmRzY2FwZScpO1xuICAgICAgY29uc3QgaXNBNCA9IHBhcGVyRm9ybWF0LnN0YXJ0c1dpdGgoJ2E0Jyk7XG5cbiAgICAgIGNvbnN0IHBkZiA9IG5ldyBqc1BERih7XG4gICAgICAgIG9yaWVudGF0aW9uOiBpc0xhbmRzY2FwZSA/ICdsYW5kc2NhcGUnIDogJ3BvcnRyYWl0JyxcbiAgICAgICAgdW5pdDogaXNBNCA/ICdtbScgOiAnaW4nLFxuICAgICAgICBmb3JtYXQ6IGlzQTQgPyAnYTQnIDogWzQsIDZdXG4gICAgICB9KTtcblxuICAgICAgaWYgKGlzQTQpIHtcbiAgICAgICAgcGRmLmFkZEltYWdlKGRhdGFVcmwsICdKUEVHJywgMCwgMCwgaXNMYW5kc2NhcGUgPyAyOTcgOiAyMTAsIGlzTGFuZHNjYXBlID8gMjEwIDogMjk3KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHBkZi5hZGRJbWFnZShkYXRhVXJsLCAnSlBFRycsIDAsIDAsIGlzTGFuZHNjYXBlID8gNiA6IDQsIGlzTGFuZHNjYXBlID8gNCA6IDYpO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBmaWxlTmFtZSA9IGBQYXNzcG9ydF8ke3BhcGVyRm9ybWF0fV8ke2NvcGllc31fQ29waWVzXyR7RGF0ZS5ub3coKX0ucGRmYDtcbiAgICAgIHBkZi5zYXZlKGZpbGVOYW1lKTtcblxuICAgICAgYWRkRG93bmxvYWRSZWNvcmQoe1xuICAgICAgICBpZDogYHBhc3MtcGRmLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgICB0aXRsZTogZmlsZU5hbWUsXG4gICAgICAgIHR5cGU6ICdQYXNzcG9ydCBTaGVldCBQREYnLFxuICAgICAgICBzaXplOiBgJHtwYXBlckZvcm1hdC5yZXBsYWNlKCdfJywgJyAnKX0gKCR7Y29waWVzfSBDb3BpZXMpYCxcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZygnZW4tSU4nKVxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gRG93bmxvYWQgSEQgSlBHXG4gIGNvbnN0IGhhbmRsZURvd25sb2FkU2hlZXRKUEcgPSAoKSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gZnVsbFNoZWV0Q2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjYW52YXMpIHJldHVybjtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBkYXRhVXJsID0gY2FudmFzLnRvRGF0YVVSTCgnaW1hZ2UvanBlZycsIDAuOTgpO1xuICAgICAgY29uc3QgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcbiAgICAgIGEuaHJlZiA9IGRhdGFVcmw7XG4gICAgICBjb25zdCBmaWxlTmFtZSA9IGBQYXNzcG9ydF8ke3BhcGVyRm9ybWF0fV8ke2NvcGllc31fQ29waWVzXzMwMERQSV8ke0RhdGUubm93KCl9LmpwZ2A7XG4gICAgICBhLmRvd25sb2FkID0gZmlsZU5hbWU7XG4gICAgICBhLmNsaWNrKCk7XG5cbiAgICAgIGFkZERvd25sb2FkUmVjb3JkKHtcbiAgICAgICAgaWQ6IGBwYXNzLWpwZy0ke0RhdGUubm93KCl9YCxcbiAgICAgICAgdGl0bGU6IGZpbGVOYW1lLFxuICAgICAgICB0eXBlOiAnUGFzc3BvcnQgU2hlZXQgSlBHJyxcbiAgICAgICAgc2l6ZTogYCR7cGFwZXJGb3JtYXQucmVwbGFjZSgnXycsICcgJyl9ICgke2NvcGllc30gQ29waWVzIDMwMCBEUEkpYCxcbiAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZygnZW4tSU4nKVxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMyBzZWxlY3Qtbm9uZVwiPlxuICAgICAgey8qIEhpZGRlbiBGdWxsIFNoZWV0IDMwMCBEUEkgQ2FudmFzIGZvciBQcmludCAmIEV4cG9ydHMgKi99XG4gICAgICA8Y2FudmFzIHJlZj17ZnVsbFNoZWV0Q2FudmFzUmVmfSBjbGFzc05hbWU9XCJoaWRkZW5cIiAvPlxuXG4gICAgICB7LyogVE9QIE5PVElGSUNBVElPTiBCQU5ORVIgKi99XG4gICAgICB7cHJpbnRBbGVydCAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQteGwgYmctZW1lcmFsZC01MDAvMTAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMC8zMCB0ZXh0LWVtZXJhbGQtNDAwIHRleHQteHMgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGFuaW1hdGUtaW4gZmFkZS1pblwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNDAwIGZsZXgtc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgPHNwYW4+e3ByaW50QWxlcnR9PC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0UHJpbnRBbGVydChudWxsKX0gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTQwMCBob3Zlcjp0ZXh0LXdoaXRlXCI+4pyVPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIFBIT1RPU0hPUC1TVFlMRSBUT1AgT1BUSU9OUyBCQVIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBweC00IHB5LTIuNSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgc2hhZG93LW1kIGZsZXgtd3JhcCB0ZXh0LXhzXCI+XG4gICAgICAgIHsvKiBMZWZ0OiBBY3RpdmUgVG9vbCBOYW1lICYgRHluYW1pYyBUb29sIENvbnRyb2xzICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIGZsZXgtd3JhcFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHItMyBib3JkZXItciBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlIHRleHQtc20gZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICB7YWN0aXZlVG9vbCA9PT0gJ3NlbGVjdCcgJiYgPHNwYW4+4oaW77iPIFBvaW50ZXIgKFYpPC9zcGFuPn1cbiAgICAgICAgICAgICAge2FjdGl2ZVRvb2wgPT09ICdzZWN0aW9uX3NlbGVjdCcgJiYgPHNwYW4+8J+UsiBTZWN0aW9uIFNlbGVjdCAmIENvbG9yIEdyYWRpbmcgKFEpPC9zcGFuPn1cbiAgICAgICAgICAgICAge2FjdGl2ZVRvb2wgPT09ICdtYWdpY193YW5kJyAmJiA8c3Bhbj7wn6qEIE1hZ2ljIFdhbmQgQ3V0IChXKTwvc3Bhbj59XG4gICAgICAgICAgICAgIHthY3RpdmVUb29sID09PSAncGVuX3Rvb2wnICYmIDxzcGFuPvCflorvuI8gUGVuIFRvb2wgKFApPC9zcGFuPn1cbiAgICAgICAgICAgICAge2FjdGl2ZVRvb2wgPT09ICdjcm9wJyAmJiA8c3Bhbj7inILvuI8gUGFzc3BvcnQgQ3JvcCAoQyk8L3NwYW4+fVxuICAgICAgICAgICAgICB7YWN0aXZlVG9vbCA9PT0gJ2JsZW1pc2hfYnJ1c2gnICYmIDxzcGFuPvCfqbkgU3BvdCBIZWFsaW5nIChCKTwvc3Bhbj59XG4gICAgICAgICAgICAgIHthY3RpdmVUb29sID09PSAnYmVhdXR5X2JydXNoJyAmJiA8c3Bhbj7inKggQmVhdXR5IEFpcmJydXNoIChTKTwvc3Bhbj59XG4gICAgICAgICAgICAgIHthY3RpdmVUb29sID09PSAnZXllX2JyaWdodGVuJyAmJiA8c3Bhbj7wn5GB77iPIEV5ZS9UZWV0aCBCcmlnaHRlbiAoRSk8L3NwYW4+fVxuICAgICAgICAgICAgICB7YWN0aXZlVG9vbCA9PT0gJ2hhbmQnICYmIDxzcGFuPuKciyBIYW5kIFBhbiAoSCk8L3NwYW4+fVxuICAgICAgICAgICAgICB7YWN0aXZlVG9vbCA9PT0gJ3pvb20nICYmIDxzcGFuPvCflI0gWm9vbSAoWik8L3NwYW4+fVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIER5bmFtaWMgb3B0aW9ucyB3aGVuIFNlY3Rpb24gU2VsZWN0IGlzIGFjdGl2ZSAqL31cbiAgICAgICAgICB7YWN0aXZlVG9vbCA9PT0gJ3NlY3Rpb25fc2VsZWN0JyAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYW5pbWF0ZS1pbiBmYWRlLWluIGZsZXgtd3JhcFwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBmb250LXNlbWlib2xkIHRleHQtWzExcHhdXCI+UHJlc2V0czo8L3NwYW4+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTZWxlY3RQcmVzZXQoJ2ZhY2UnKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSByb3VuZGVkLW1kIGJnLXNsYXRlLTk1MCBob3ZlcjpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0yMDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgZm9udC1ib2xkIHRleHQtWzExcHhdXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIPCfkaQgRmFjZVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNlbGVjdFByZXNldCgnY2xvdGhlcycpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IHJvdW5kZWQtbWQgYmctc2xhdGUtOTUwIGhvdmVyOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTIwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBmb250LWJvbGQgdGV4dC1bMTFweF1cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAg8J+RlCBDbG90aGVzXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2VsZWN0UHJlc2V0KCdleWVzJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgcm91bmRlZC1tZCBiZy1zbGF0ZS05NTAgaG92ZXI6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtMjAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGZvbnQtYm9sZCB0ZXh0LVsxMXB4XVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICDwn5GB77iPIEV5ZXNcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTZWxlY3RQcmVzZXQoJ2Z1bGwnKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSByb3VuZGVkLW1kIGJnLXNsYXRlLTk1MCBob3ZlcjpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0yMDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgZm9udC1ib2xkIHRleHQtWzExcHhdXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIPCflLIgRnVsbFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICB7c2VsZWN0aW9uQm94ICYmIChcbiAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlSW52ZXJ0U2VsZWN0aW9ufVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSByb3VuZGVkLW1kIGJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTMwMCBmb250LWJvbGQgaG92ZXI6dGV4dC13aGl0ZSB0ZXh0LVsxMXB4XVwiXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiSW52ZXJ0IFNlbGVjdGlvblwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIPCflIQgSW52ZXJ0XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUJha2VTZWN0aW9uQWRqdXN0bWVudH1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHgtMi41IHB5LTAuNSByb3VuZGVkLW1kIGJnLWVtZXJhbGQtNjAwIGhvdmVyOmJnLWVtZXJhbGQtNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQtWzExcHhdIHNoYWRvd1wiXG4gICAgICAgICAgICAgICAgICAgIHRpdGxlPVwiQmFrZSBsb2NhbCBhZGp1c3RtZW50cyBpbnRvIHBob3RvXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPENoZWNrIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+QmFrZSBTZWN0aW9uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDbGVhclNlbGVjdGlvbn1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgcm91bmRlZC1tZCBiZy1zbGF0ZS04MDAgdGV4dC1yb3NlLTMwMCBob3Zlcjp0ZXh0LXJvc2UtMjAwIGZvbnQtYm9sZCB0ZXh0LVsxMXB4XVwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIENsZWFyXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogRHluYW1pYyBvcHRpb25zIHdoZW4gTWFnaWMgV2FuZCBpcyBhY3RpdmUgKi99XG4gICAgICAgICAge2FjdGl2ZVRvb2wgPT09ICdtYWdpY193YW5kJyAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGFuaW1hdGUtaW4gZmFkZS1pblwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPlRvbGVyYW5jZTo8L3NwYW4+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJyYW5nZVwiXG4gICAgICAgICAgICAgICAgbWluPVwiMTBcIlxuICAgICAgICAgICAgICAgIG1heD1cIjY1XCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17bWFnaWNUb2xlcmFuY2V9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNYWdpY1RvbGVyYW5jZShOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTIwIGFjY2VudC1za3ktNDAwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIkNvbG9yIHNpbWlsYXJpdHkgZGlzdGFuY2UgKDEwLTY1KVwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXdoaXRlIGZvbnQtYm9sZFwiPnttYWdpY1RvbGVyYW5jZX08L3NwYW4+XG5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUF1dG9CYWNrZ3JvdW5kRXJhc2V9XG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzUHJvY2Vzc2luZyB8fCAhcGhvdG9TcmN9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWwtMiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBiZy1ncmFkaWVudC10by1yIGZyb20tcHVycGxlLTYwMCB0by1pbmRpZ28tNjAwIGhvdmVyOmZyb20tcHVycGxlLTUwMCBob3Zlcjp0by1pbmRpZ28tNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHB4LTMgcHktMSByb3VuZGVkLWxnIHNoYWRvdy1zbVwiXG4gICAgICAgICAgICAgICAgdGl0bGU9XCIxLUNsaWNrIEF1dG8gRXJhc2VzIGJvcmRlcnMgaW53YXJkc1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPjEtQ2xpY2sgQXV0byBDdXQ8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiBEeW5hbWljIG9wdGlvbnMgd2hlbiBQZW4gVG9vbCBpcyBhY3RpdmUgKi99XG4gICAgICAgICAge2FjdGl2ZVRvb2wgPT09ICdwZW5fdG9vbCcgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBhbmltYXRlLWluIGZhZGUtaW5cIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgZm9udC1tb25vIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAge3BlblBvaW50cy5sZW5ndGh9IFBvaW50cyB7aXNQYXRoQ2xvc2VkID8gJ+KAoiBQYXRoIENsb3NlZCcgOiAnJ31cbiAgICAgICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgICAgIHshaXNQYXRoQ2xvc2VkICYmIHBlblBvaW50cy5sZW5ndGggPj0gMyAmJiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNQYXRoQ2xvc2VkKHRydWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMi41IHB5LTEgYmctZW1lcmFsZC02MDAgaG92ZXI6YmctZW1lcmFsZC01MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgcm91bmRlZC1sZ1wiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgQ2xvc2UgUGF0aFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICApfVxuXG4gICAgICAgICAgICAgIHtwZW5Qb2ludHMubGVuZ3RoID49IDMgJiYgKFxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUFwcGx5UGVuQ3V0b3V0fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgcHgtMyBweS0xIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1lbWVyYWxkLTYwMCB0by10ZWFsLTYwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCByb3VuZGVkLWxnIHNoYWRvdy1tZFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPENoZWNrIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPkFwcGx5IEN1dG91dDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRQZW5Qb2ludHMoW10pOyBzZXRJc1BhdGhDbG9zZWQoZmFsc2UpOyB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktMSBiZy1zbGF0ZS04MDAgdGV4dC1yb3NlLTMwMCBmb250LWJvbGQgcm91bmRlZC1sZyBob3ZlcjpiZy1yb3NlLTkwMC8zMFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBDbGVhclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogRHluYW1pYyBvcHRpb25zIHdoZW4gQ3JvcCBpcyBhY3RpdmUgKi99XG4gICAgICAgICAge2FjdGl2ZVRvb2wgPT09ICdjcm9wJyAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGFuaW1hdGUtaW4gZmFkZS1pblwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1za3ktNTAwLzIwIHRleHQtc2t5LTMwMCBweC0yIHB5LTAuNSByb3VuZGVkIGZvbnQtbW9ubyBmb250LWJvbGRcIj5cbiAgICAgICAgICAgICAgICBSYXRpbzogMzXDlzQ1bW0gU3RhbmRhcmRcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQXBwbHlDcm9wfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMSBiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTUwMCB0ZXh0LXdoaXRlIGZvbnQtYm9sZCByb3VuZGVkLWxnIHNoYWRvd1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBBcHBseSBDcm9wXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRDcm9wQm94KG51bGwpOyBzZXRBY3RpdmVUb29sKCdzZWxlY3QnKTsgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yIHB5LTEgYmctc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIGZvbnQtYm9sZCByb3VuZGVkLWxnXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIENhbmNlbFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICB7LyogRHluYW1pYyBvcHRpb25zIHdoZW4gQnJ1c2hlcyBhcmUgYWN0aXZlICovfVxuICAgICAgICAgIHsoYWN0aXZlVG9vbCA9PT0gJ2JsZW1pc2hfYnJ1c2gnIHx8IGFjdGl2ZVRvb2wgPT09ICdiZWF1dHlfYnJ1c2gnIHx8IGFjdGl2ZVRvb2wgPT09ICdleWVfYnJpZ2h0ZW4nKSAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGFuaW1hdGUtaW4gZmFkZS1pblwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPkJydXNoIFNpemU6PC9zcGFuPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICAgIG1pbj1cIjhcIlxuICAgICAgICAgICAgICAgIG1heD1cIjcwXCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17YnJ1c2hTaXplfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QnJ1c2hTaXplKE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMjAgYWNjZW50LWFtYmVyLTQwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXdoaXRlIGZvbnQtYm9sZFwiPnticnVzaFNpemV9cHg8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIHRleHQtWzEwcHhdXCI+VXNlIFsgYW5kIF0gdG8gcmVzaXplPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHsvKiAxLUNsaWNrIFJlbW92ZSBCRyBRdWljayBBY3Rpb24gKi99XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVBdXRvQmFja2dyb3VuZEVyYXNlfVxuICAgICAgICAgICAgZGlzYWJsZWQ9e2lzUHJvY2Vzc2luZyB8fCAhcGhvdG9TcmN9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IGJnLWdyYWRpZW50LXRvLXIgZnJvbS1wdXJwbGUtNjAwIHZpYS1pbmRpZ28tNjAwIHRvLXB1cnBsZS01MDAgaG92ZXI6ZnJvbS1wdXJwbGUtNTAwIGhvdmVyOnRvLWluZGlnby01MDAgdGV4dC13aGl0ZSBmb250LWV4dHJhYm9sZCB0ZXh0LXhzIHJvdW5kZWQteGwgc2hhZG93LW1kIHNoYWRvdy1wdXJwbGUtNjAwLzMwIHRyYW5zaXRpb24tYWxsIGhvdmVyOnNjYWxlLTEwNSBhY3RpdmU6c2NhbGUtOTUgZGlzYWJsZWQ6b3BhY2l0eS00MFwiXG4gICAgICAgICAgICB0aXRsZT1cIjEtQ2xpY2sgQXV0b21hdGljIEJhY2tncm91bmQgUmVtb3ZlIC8gUmVwbGFjZSB3aXRoIHNlbGVjdGVkIHN0dWRpbyBjb2xvclwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYW1iZXItMzAwXCIgLz5cbiAgICAgICAgICAgIDxzcGFuPuKaoSAxLUNsaWNrIFJlbW92ZSBCRzwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIHsvKiBTdHVkaW8gQmFja2dyb3VuZCBTd2F0Y2hlcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcGwtMyBib3JkZXItbCBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPkJHOjwvc3Bhbj5cbiAgICAgICAgICAgIHtbXG4gICAgICAgICAgICAgIHsgbmFtZTogJ1doaXRlJywgY29sb3I6ICcjZmZmZmZmJyB9LFxuICAgICAgICAgICAgICB7IG5hbWU6ICdTa3kgQmx1ZScsIGNvbG9yOiAnI2NjZTNmOCcgfSxcbiAgICAgICAgICAgICAgeyBuYW1lOiAnU3R1ZGlvIEJsdWUnLCBjb2xvcjogJyMyNTYzZWInIH0sXG4gICAgICAgICAgICAgIHsgbmFtZTogJ0dyZXknLCBjb2xvcjogJyNlMmU4ZjAnIH0sXG4gICAgICAgICAgICAgIHsgbmFtZTogJ1JlZCcsIGNvbG9yOiAnI2RjMjYyNicgfSxcbiAgICAgICAgICAgICAgeyBuYW1lOiAnVHJhbnNwYXJlbnQgQ3V0b3V0JywgY29sb3I6ICd0cmFuc3BhcmVudCcgfVxuICAgICAgICAgICAgXS5tYXAoKGMpID0+IChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIGtleT17Yy5uYW1lfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEJnQ29sb3IoYy5jb2xvcil9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy01IGgtNSByb3VuZGVkLWZ1bGwgYm9yZGVyIHNoYWRvdy1zbSB0cmFuc2l0aW9uLXRyYW5zZm9ybSAke1xuICAgICAgICAgICAgICAgICAgYmdDb2xvciA9PT0gYy5jb2xvciA/ICdzY2FsZS0xMjUgcmluZy0yIHJpbmctc2t5LTQwMCBib3JkZXItd2hpdGUnIDogJ2JvcmRlci1zbGF0ZS01MDAgaG92ZXI6c2NhbGUtMTEwJ1xuICAgICAgICAgICAgICAgIH0gJHtjLmNvbG9yID09PSAndHJhbnNwYXJlbnQnID8gJ2JnLVtsaW5lYXItZ3JhZGllbnQoNDVkZWcsI2NjY18yNSUsdHJhbnNwYXJlbnRfMjUlKSxsaW5lYXItZ3JhZGllbnQoLTQ1ZGVnLCNjY2NfMjUlLHRyYW5zcGFyZW50XzI1JSksbGluZWFyLWdyYWRpZW50KDQ1ZGVnLHRyYW5zcGFyZW50Xzc1JSwjY2NjXzc1JSksbGluZWFyLWdyYWRpZW50KC00NWRlZyx0cmFuc3BhcmVudF83NSUsI2NjY183NSUpXSBiZy1bc2l6ZTo2cHhfNnB4XSBiZy13aGl0ZScgOiAnJ31gfVxuICAgICAgICAgICAgICAgIHN0eWxlPXtjLmNvbG9yICE9PSAndHJhbnNwYXJlbnQnID8geyBiYWNrZ3JvdW5kQ29sb3I6IGMuY29sb3IgfSA6IHt9fVxuICAgICAgICAgICAgICAgIHRpdGxlPXtgQ2hhbmdlIHN0dWRpbyBiYWNrZ3JvdW5kIHRvICR7Yy5uYW1lfWB9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFJpZ2h0OiBVbmRvIC8gUmVkbyAmIFByaW50IC8gRXhwb3J0IGFjdGlvbnMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICB7LyogVW5kbyAvIFJlZG8gKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC1sZyBwLTAuNVwiPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVVbmRvfVxuICAgICAgICAgICAgICBkaXNhYmxlZD17aGlzdG9yeUluZGV4IDw9IDAgJiYgcGVuUG9pbnRzLmxlbmd0aCA9PT0gMH1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC13aGl0ZSBkaXNhYmxlZDpvcGFjaXR5LTMwIGRpc2FibGVkOmhvdmVyOnRleHQtc2xhdGUtMzAwXCJcbiAgICAgICAgICAgICAgdGl0bGU9XCJVbmRvIChDdHJsICsgWilcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8VW5kbzIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZVJlZG99XG4gICAgICAgICAgICAgIGRpc2FibGVkPXtoaXN0b3J5SW5kZXggPj0gaGlzdG9yeVN0YWNrLmxlbmd0aCAtIDF9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHRleHQtc2xhdGUtMzAwIGhvdmVyOnRleHQtd2hpdGUgZGlzYWJsZWQ6b3BhY2l0eS0zMCBkaXNhYmxlZDpob3Zlcjp0ZXh0LXNsYXRlLTMwMFwiXG4gICAgICAgICAgICAgIHRpdGxlPVwiUmVkbyAoQ3RybCArIFkpXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFJlZG8yIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIE1pbmkgUHJldmlldyBUb2dnbGUgQnV0dG9uICovfVxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dNaW5pUHJldmlldyhwcmV2ID0+ICFwcmV2KX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHB4LTIuNSBweS0xLjUgcm91bmRlZC1sZyBib3JkZXIgZm9udC1ib2xkIHRleHQteHMgdHJhbnNpdGlvbi1jb2xvcnMgJHtcbiAgICAgICAgICAgICAgc2hvd01pbmlQcmV2aWV3ID8gJ2JnLXNreS02MDAvMjAgdGV4dC1za3ktMzAwIGJvcmRlci1za3ktNTAwLzQwJyA6ICdiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS00MDAgYm9yZGVyLXNsYXRlLTcwMCdcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgdGl0bGU9XCJUb2dnbGUgTWluaSBTaGVldCBQcmV2aWV3IChNKVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPExheWVycyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5NaW5pIFByZXZpZXcgKE0pPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgey8qIERpcmVjdCBQcmludCBCdXR0b24gKi99XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRGlyZWN0UHJpbnR9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB2aWEtaW5kaWdvLTYwMCB0by1ibHVlLTUwMCBob3Zlcjpmcm9tLWJsdWUtNTAwIGhvdmVyOnRvLWluZGlnby01MDAgdGV4dC13aGl0ZSBmb250LWV4dHJhYm9sZCBweC0zLjUgcHktMS41IHJvdW5kZWQteGwgc2hhZG93LWxnIHNoYWRvdy1ibHVlLTYwMC8zMCB0cmFuc2l0aW9uLWFsbCBob3ZlcjpzY2FsZS0xMDVcIlxuICAgICAgICAgICAgdGl0bGU9XCJEaXJlY3QgUHJpbnQgU2hlZXQgKEN0cmwgKyBQKVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFByaW50ZXIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC13aGl0ZVwiIC8+XG4gICAgICAgICAgICA8c3Bhbj7wn5ao77iPIFByaW50IFNoZWV0IChDdHJsK1ApPC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogTUFJTiBQSE9UT1NIT1AgV09SS1NQQUNFIENPTlRBSU5FUiAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBsZzpncmlkLWNvbHMtMTIgZ2FwLTMgaXRlbXMtc3RhcnQgbWluLWgtWzY0MHB4XVwiPlxuICAgICAgICB7LyogMS4gTEVGVCBQSE9UT1NIT1AgVkVSVElDQUwgVE9PTEJBUiAoMSBDb2x1bW4pICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTEgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtMiBmbGV4IGxnOmZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBzaGFkb3ctbGdcIj5cbiAgICAgICAgICB7LyogVG9vbCBJY29ucyAqL31cbiAgICAgICAgICB7W1xuICAgICAgICAgICAgeyBpZDogJ3NlbGVjdCcsIGxhYmVsOiAnUG9pbnRlciAvIE1vdmUgKFYpJywgaWNvbjogJ+KGlu+4jycgfSxcbiAgICAgICAgICAgIHsgaWQ6ICdzZWN0aW9uX3NlbGVjdCcsIGxhYmVsOiAnU2VjdGlvbiBTZWxlY3Rpb24gVG9vbCAoUSknLCBpY29uOiAn8J+UsicgfSxcbiAgICAgICAgICAgIHsgaWQ6ICdhdXRvX2JnJywgbGFiZWw6ICcxLUNsaWNrIEF1dG8gUmVtb3ZlIEJHIChSKScsIGljb246ICfimqEnIH0sXG4gICAgICAgICAgICB7IGlkOiAnY3JvcCcsIGxhYmVsOiAnUGFzc3BvcnQgQ3JvcCAoQyknLCBpY29uOiAn4pyC77iPJyB9LFxuICAgICAgICAgICAgeyBpZDogJ21hZ2ljX3dhbmQnLCBsYWJlbDogJ01hZ2ljIFdhbmQgLyBDdXQgKFcpJywgaWNvbjogJ/CfqoQnIH0sXG4gICAgICAgICAgICB7IGlkOiAncGVuX3Rvb2wnLCBsYWJlbDogJ1BlbiBUb29sIEN1dG91dCAoUCknLCBpY29uOiAn8J+Wiu+4jycgfSxcbiAgICAgICAgICAgIHsgaWQ6ICdibGVtaXNoX2JydXNoJywgbGFiZWw6ICdTcG90IEhlYWxpbmcgQnJ1c2ggKEIpJywgaWNvbjogJ/CfqbknIH0sXG4gICAgICAgICAgICB7IGlkOiAnYmVhdXR5X2JydXNoJywgbGFiZWw6ICdTa2luIEFpcmJydXNoIChTKScsIGljb246ICfinKgnIH0sXG4gICAgICAgICAgICB7IGlkOiAnZXllX2JyaWdodGVuJywgbGFiZWw6ICdFeWUvVGVldGggV2hpdGVuZXIgKEUpJywgaWNvbjogJ/CfkYHvuI8nIH0sXG4gICAgICAgICAgICB7IGlkOiAnaGFuZCcsIGxhYmVsOiAnSGFuZCBUb29sIFBhbiAoSCAvIFNwYWNlKScsIGljb246ICfinIsnIH0sXG4gICAgICAgICAgICB7IGlkOiAnem9vbScsIGxhYmVsOiAnWm9vbSBUb29sIChaKScsIGljb246ICfwn5SNJyB9XG4gICAgICAgICAgXS5tYXAoKHQpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGlzQWN0aXZlID0gYWN0aXZlVG9vbCA9PT0gdC5pZDtcbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBrZXk9e3QuaWR9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgaWYgKHQuaWQgPT09ICdhdXRvX2JnJykge1xuICAgICAgICAgICAgICAgICAgICBoYW5kbGVBdXRvQmFja2dyb3VuZEVyYXNlKCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZVRvb2wodC5pZCBhcyBBY3RpdmVUb29sKTtcbiAgICAgICAgICAgICAgICAgIGlmICh0LmlkID09PSAnY3JvcCcpIGluaXRDcm9wQm94KCk7XG4gICAgICAgICAgICAgICAgICBpZiAodC5pZCA9PT0gJ3NlY3Rpb25fc2VsZWN0Jykge1xuICAgICAgICAgICAgICAgICAgICBzZXRHcmFkaW5nU2NvcGUoJ3NlbGVjdGlvbicpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIXNlbGVjdGlvbkJveCkgaGFuZGxlU2VsZWN0UHJlc2V0KCdmYWNlJyk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LTEwIGgtMTAgcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LWxnIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICBpc0FjdGl2ZVxuICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1sZyBzaGFkb3ctYmx1ZS02MDAvNDAgcmluZy0yIHJpbmctYmx1ZS00MDAgc2NhbGUtMTA1J1xuICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05NTAgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwLzgwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgdGl0bGU9e3QubGFiZWx9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8c3Bhbj57dC5pY29ufTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pfVxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTggYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBteS0xIGhpZGRlbiBsZzpibG9ja1wiIC8+XG5cbiAgICAgICAgICB7LyogVXBsb2FkIEJ1dHRvbiAqL31cbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHJvdW5kZWQteGwgYmctcHVycGxlLTYwMC8yMCBib3JkZXIgYm9yZGVyLXB1cnBsZS01MDAvNDAgdGV4dC1wdXJwbGUtMzAwIGhvdmVyOmJnLXB1cnBsZS02MDAvMzAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1jb2xvcnNcIiB0aXRsZT1cIlVwbG9hZCBDdXN0b21lciBQaG90b1wiPlxuICAgICAgICAgICAgPFVwbG9hZCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIGFjY2VwdD1cImltYWdlLypcIiBvbkNoYW5nZT17aGFuZGxlVXBsb2FkfSBjbGFzc05hbWU9XCJoaWRkZW5cIiAvPlxuICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiAyLiBDRU5URVIgQklHIEVESVRJTkcgQ0FOVkFTIFdPUktTUEFDRSAoOCBDb2x1bW5zIG9yIDExIENvbHVtbnMgaWYgbWluaSBwcmV2aWV3IGNvbGxhcHNlZCkgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgJHtzaG93TWluaVByZXZpZXcgPyAnbGc6Y29sLXNwYW4tOCcgOiAnbGc6Y29sLXNwYW4tMTEnfSByZWxhdGl2ZSBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy0yeGwgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gbWluLWgtWzY0MHB4XWB9PlxuICAgICAgICAgIHsvKiBab29tIC8gSW5mbyBPdmVybGF5IEJhciAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0zIGxlZnQtMyB6LTEwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGJnLXNsYXRlLTkwMC84NSBiYWNrZHJvcC1ibHVyLXNtIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHB4LTMgcHktMS41IHJvdW5kZWQteGwgdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS0zMDAgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtd2hpdGVcIj5QaG90b3Nob3AgU3R1ZGlvIENhbnZhczwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuPuKAojwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXNreS00MDAgZm9udC1ib2xkXCI+e01hdGgucm91bmQoY2FudmFzWm9vbSAqIDEwMCl9JTwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuPuKAojwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuPkhvbGQgU3BhY2ViYXIgKyBEcmFnIHRvIFBhbiDigKIgV2hlZWwgdG8gWm9vbTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBDZW50ZXIgQ2FudmFzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtMiBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgICAgICAgIDxjYW52YXNcbiAgICAgICAgICAgICAgcmVmPXtlZGl0b3JDYW52YXNSZWZ9XG4gICAgICAgICAgICAgIG9uTW91c2VEb3duPXtoYW5kbGVFZGl0b3JNb3VzZURvd259XG4gICAgICAgICAgICAgIG9uTW91c2VNb3ZlPXtoYW5kbGVFZGl0b3JNb3VzZU1vdmV9XG4gICAgICAgICAgICAgIG9uTW91c2VVcD17aGFuZGxlRWRpdG9yTW91c2VVcH1cbiAgICAgICAgICAgICAgb25Nb3VzZUxlYXZlPXtoYW5kbGVFZGl0b3JNb3VzZVVwfVxuICAgICAgICAgICAgICBvbldoZWVsPXtoYW5kbGVFZGl0b3JXaGVlbH1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgbWF4LXctZnVsbCBtYXgtaC1bNTgwcHhdIHctYXV0byBoLWF1dG8gcm91bmRlZC1sZyBzaGFkb3ctMnhsICR7XG4gICAgICAgICAgICAgICAgaXNTcGFjZVByZXNzZWQgfHwgYWN0aXZlVG9vbCA9PT0gJ2hhbmQnXG4gICAgICAgICAgICAgICAgICA/ICdjdXJzb3ItZ3JhYiBhY3RpdmU6Y3Vyc29yLWdyYWJiaW5nJ1xuICAgICAgICAgICAgICAgICAgOiBhY3RpdmVUb29sID09PSAnbWFnaWNfd2FuZCcgfHwgYWN0aXZlVG9vbCA9PT0gJ3Blbl90b29sJ1xuICAgICAgICAgICAgICAgICAgPyAnY3Vyc29yLWNyb3NzaGFpcidcbiAgICAgICAgICAgICAgICAgIDogYWN0aXZlVG9vbCA9PT0gJ2JsZW1pc2hfYnJ1c2gnIHx8IGFjdGl2ZVRvb2wgPT09ICdiZWF1dHlfYnJ1c2gnIHx8IGFjdGl2ZVRvb2wgPT09ICdleWVfYnJpZ2h0ZW4nXG4gICAgICAgICAgICAgICAgICA/ICdjdXJzb3ItY2VsbCdcbiAgICAgICAgICAgICAgICAgIDogJ2N1cnNvci1kZWZhdWx0J1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQm90dG9tIENhbnZhcyBRdWljayBTdGF0dXMgQmFyICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwLzgwIGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAvODAgcHgtNCBweS0yIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGZsZXgtd3JhcCBnYXAtMlwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICA8c3Bhbj5Ub29sOiA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgdXBwZXJjYXNlXCI+e2FjdGl2ZVRvb2wucmVwbGFjZSgnXycsICcgJyl9PC9zdHJvbmc+PC9zcGFuPlxuICAgICAgICAgICAgICB7cGhvdG9TcmMgJiYgKFxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgPENoZWNrIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gSGlnaC1SZXNvbHV0aW9uIFBob3RvIFJlYWR5XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0Q2FudmFzWm9vbSgxLjApOyBzZXRDYW52YXNQYW4oeyB4OiAwLCB5OiAwIH0pOyB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0yMDAgcm91bmRlZCB0ZXh0LVsxMXB4XSBmb250LW1vbm9cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgRml0IFNjcmVlbiAoQ3RybCswKVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldENhbnZhc1pvb20ocHJldiA9PiBNYXRoLm1pbig0LjAsIHByZXYgKyAwLjI1KSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTIwMCByb3VuZGVkIHRleHQtWzExcHhdIGZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICArXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0Q2FudmFzWm9vbShwcmV2ID0+IE1hdGgubWF4KDAuNCwgcHJldiAtIDAuMjUpKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMjAwIHJvdW5kZWQgdGV4dC1bMTFweF0gZm9udC1tb25vXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIC1cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIDMuIFJJR0hUIFNJREU6IENPTVBBQ1QgTUlOSSBQUkVWSUVXICYgQURKVVNUTUVOVFMgKDMgQ29sdW1ucykgKi99XG4gICAgICAgIHtzaG93TWluaVByZXZpZXcgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tMyBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIHsvKiBNSU5JIFNIRUVUIFBSRVZJRVcgV0lER0VUIChcInByZXZpZXcgbWluaSBkaWtobmEgY2hhaXllXCIpICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC0zIHNoYWRvdy14bCBzcGFjZS15LTIuNVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi0xLjUgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSB0ZXh0LXhzXCI+TWluaSBTaGVldCBQcmV2aWV3PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1tb25vIGJnLWJsdWUtNTAwLzIwIHRleHQtYmx1ZS0zMDAgcHgtMS41IHB5LTAuNSByb3VuZGVkIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICB7cGFwZXJGb3JtYXQgPT09ICc0eDZfbGFuZHNjYXBlJyA/ICc0w5c2ICg4KScgOiAnQTQnfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dNaW5pUHJldmlldyhmYWxzZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEgdGV4dC1zbGF0ZS01MDAgaG92ZXI6dGV4dC13aGl0ZSByb3VuZGVkXCJcbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiSGlkZSBNaW5pIFByZXZpZXcgKE0pXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8TWluaW1pemUyIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIE1pbmlhdHVyZSBDYW52YXMgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgZmxleCBqdXN0aWZ5LWNlbnRlciBiZy1zbGF0ZS05NTAgcC0yIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgb3ZlcmZsb3ctaGlkZGVuIHNoYWRvdy1pbm5lclwiPlxuICAgICAgICAgICAgICAgIDxjYW52YXNcbiAgICAgICAgICAgICAgICAgIHJlZj17bWluaVByZXZpZXdDYW52YXNSZWZ9XG4gICAgICAgICAgICAgICAgICB3aWR0aD17MjQwfVxuICAgICAgICAgICAgICAgICAgaGVpZ2h0PXsxNjB9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1hdXRvIGJnLXdoaXRlIHJvdW5kZWQgc2hhZG93LW1kIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHBvaW50ZXItZXZlbnRzLW5vbmVcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBGb3JtYXQgU3dpdGNoZXIgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4geyBzZXRQYXBlckZvcm1hdCgnNHg2X2xhbmRzY2FwZScpOyBzZXRDb3BpZXMoOCk7IH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0xLjUgcHgtMiByb3VuZGVkLWxnIHRleHQteHMgZm9udC1ib2xkIHRyYW5zaXRpb24tYWxsIHRleHQtY2VudGVyICR7XG4gICAgICAgICAgICAgICAgICAgIHBhcGVyRm9ybWF0ID09PSAnNHg2X2xhbmRzY2FwZSdcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdydcbiAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05NTAgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDTDlzYgKDggQ29waWVzKVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHsgc2V0UGFwZXJGb3JtYXQoJ2E0X2xhbmRzY2FwZScpOyBzZXRDb3BpZXMoMzIpOyB9fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHktMS41IHB4LTIgcm91bmRlZC1sZyB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCB0ZXh0LWNlbnRlciAke1xuICAgICAgICAgICAgICAgICAgICBwYXBlckZvcm1hdCA9PT0gJ2E0X2xhbmRzY2FwZSdcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1wdXJwbGUtNjAwIHRleHQtd2hpdGUgc2hhZG93J1xuICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTk1MCB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgQTQgTGFuZHNjYXBlXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBEaXJlY3QgUHJpbnQgQnV0dG9uIG9uIE1pbmkgUHJldmlldyAqL31cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZURpcmVjdFByaW50fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IGJnLWdyYWRpZW50LXRvLXIgZnJvbS1ibHVlLTYwMCB0by1pbmRpZ28tNjAwIGhvdmVyOmZyb20tYmx1ZS01MDAgaG92ZXI6dG8taW5kaWdvLTUwMCB0ZXh0LXdoaXRlIGZvbnQtZXh0cmFib2xkIHRleHQteHMgcHktMiByb3VuZGVkLXhsIHNoYWRvdy1tZCB0cmFuc2l0aW9uLWFsbCBhY3RpdmU6c2NhbGUtOTVcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPFByaW50ZXIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPvCflqjvuI8gUHJpbnQgU2hlZXQgTm93PC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogQVVUTyBCRUFVVFkgJiBQUkVTRVRTIEFDQ09SRElPTiAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHAtMy41IHNoYWRvdy1tZCBzcGFjZS15LTIuNVwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtd2hpdGUgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5BdXRvIEJlYXV0eSBQcmVzZXRzPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWFtYmVyLTQwMCBmb250LWJvbGQgYmctYW1iZXItNTAwLzEwIHB4LTEuNSBweS0wLjUgcm91bmRlZFwiPlxuICAgICAgICAgICAgICAgICAgMS1DbGlja1xuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICB7QkVBVVRZX1BSRVNFVFMubWFwKChwKSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBpc1NlbGVjdGVkID0gYWN0aXZlUHJlc2V0ID09PSBwLmlkICYmIGF1dG9CZWF1dHk7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtwLmlkfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEFjdGl2ZVByZXNldChwLmlkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEJyaWdodG5lc3MocC5zZXR0aW5ncy5icmlnaHRuZXNzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldENvbnRyYXN0KHAuc2V0dGluZ3MuY29udHJhc3QpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2F0dXJhdGlvbihwLnNldHRpbmdzLnNhdHVyYXRpb24pO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0V2FybXRoKHAuc2V0dGluZ3Mud2FybXRoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFRpbnQocC5zZXR0aW5ncy50aW50KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNraW5TbW9vdGgocC5zZXR0aW5ncy5za2luU21vb3RoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldEZhY2VHbG93KHAuc2V0dGluZ3MuZmFjZUdsb3cpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2hhZG93TGlmdChwLnNldHRpbmdzLnNoYWRvd0xpZnQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0SXNHcmF5c2NhbGUocC5zZXR0aW5ncy5pc0dyYXlzY2FsZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRBdXRvQmVhdXR5KHRydWUpO1xuICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQteGwgdGV4dC1sZWZ0IGJvcmRlciB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgICAgICAgICAgaXNTZWxlY3RlZFxuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1hbWJlci01MDAvMTAgYm9yZGVyLWFtYmVyLTUwMC82MCB0ZXh0LXdoaXRlIHJpbmctMSByaW5nLWFtYmVyLTUwMC8zMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtOTUwIGJvcmRlci1zbGF0ZS04MDAvODAgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6Ymctc2xhdGUtODAwJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0cnVuY2F0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e3AuaWNvbn08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPntwLm5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBDT0xPUiBHUkFESU5HICYgU0VDVElPTiBHUkFESU5HIFNMSURFUlMgUEFORUwgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBwLTMuNSBzaGFkb3ctbWQgc3BhY2UteS0zIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItMSBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtd2hpdGUgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIDxTbGlkZXJzIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYmx1ZS00MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+Q29sb3IgR3JhZGluZyAmIFNraW48L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGdyYWRpbmdTY29wZSA9PT0gJ3NlbGVjdGlvbicpIHtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRTZWNCcmlnaHRuZXNzKDApO1xuICAgICAgICAgICAgICAgICAgICAgIHNldFNlY0NvbnRyYXN0KDApO1xuICAgICAgICAgICAgICAgICAgICAgIHNldFNlY1NhdHVyYXRpb24oMCk7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0U2VjV2FybXRoKDApO1xuICAgICAgICAgICAgICAgICAgICAgIHNldFNlY1Ntb290aCgwKTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRCcmlnaHRuZXNzKDApO1xuICAgICAgICAgICAgICAgICAgICAgIHNldENvbnRyYXN0KDApO1xuICAgICAgICAgICAgICAgICAgICAgIHNldFNhdHVyYXRpb24oMCk7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0V2FybXRoKDApO1xuICAgICAgICAgICAgICAgICAgICAgIHNldFRpbnQoMCk7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0U2tpblNtb290aCgwKTtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRGYWNlR2xvdygwKTtcbiAgICAgICAgICAgICAgICAgICAgICBzZXRJc0dyYXlzY2FsZShmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBSZXNldFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogU0NPUEUgVE9HR0xFOiBXSE9MRSBQSE9UTyB2cyBTRUxFQ1RFRCBTRUNUSU9OICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTEuNSBwLTEgYmctc2xhdGUtOTUwIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEdyYWRpbmdTY29wZSgnZnVsbCcpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHktMS41IHB4LTIgcm91bmRlZC1sZyBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgZ3JhZGluZ1Njb3BlID09PSAnZnVsbCdcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdydcbiAgICAgICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+8J+MkCBXaG9sZSBQaG90bzwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0R3JhZGluZ1Njb3BlKCdzZWxlY3Rpb24nKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFzZWxlY3Rpb25Cb3gpIGhhbmRsZVNlbGVjdFByZXNldCgnZmFjZScpO1xuICAgICAgICAgICAgICAgICAgICBzZXRBY3RpdmVUb29sKCdzZWN0aW9uX3NlbGVjdCcpO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB5LTEuNSBweC0yIHJvdW5kZWQtbGcgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgIGdyYWRpbmdTY29wZSA9PT0gJ3NlbGVjdGlvbidcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ncmFkaWVudC10by1yIGZyb20tY3lhbi02MDAgdG8tYmx1ZS02MDAgdGV4dC13aGl0ZSBzaGFkb3cgc2hhZG93LWN5YW4tNjAwLzMwJ1xuICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj7wn5SyIFNlY3Rpb24gT25seTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIENPTkRJVElPTkFMIENPTlRST0xTIEJBU0VEIE9OIFNDT1BFICovfVxuICAgICAgICAgICAgICB7Z3JhZGluZ1Njb3BlID09PSAnc2VsZWN0aW9uJyA/IChcbiAgICAgICAgICAgICAgICAvKiBTRUNUSU9OIENPTE9SIEdSQURJTkcgQ09OVFJPTFMgKi9cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMi41IHB0LTEgYW5pbWF0ZS1pbiBmYWRlLWluXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxMXB4XSBiZy1jeWFuLTk1MC80MCBwLTIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWN5YW4tNTAwLzMwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtY3lhbi0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICDwn46vIFNlY3Rpb24gUHJlc2V0ICYgQm94OlxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIHtzZWxlY3Rpb25Cb3ggPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDbGVhclNlbGVjdGlvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcm9zZS00MDAgaG92ZXI6dW5kZXJsaW5lIHRleHQtWzEwcHhdIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgQ2xlYXJcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTQwMCB0ZXh0LVsxMHB4XVwiPkRyYXcgYm94IG9uIHBob3RvPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBQcmVzZXQgY2hpcHMgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTQgZ2FwLTEgdGV4dC1bMTBweF1cIj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNlbGVjdFByZXNldCgnZmFjZScpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHJvdW5kZWQtbGcgYmctc2xhdGUtOTUwIGhvdmVyOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTMwMCBmb250LWJvbGQgdGV4dC1jZW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAg8J+RpCBGYWNlXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU2VsZWN0UHJlc2V0KCdjbG90aGVzJyl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgcm91bmRlZC1sZyBiZy1zbGF0ZS05NTAgaG92ZXI6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIGZvbnQtYm9sZCB0ZXh0LWNlbnRlclwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICDwn5GUIENsb3RoZXNcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTZWxlY3RQcmVzZXQoJ2V5ZXMnKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSByb3VuZGVkLWxnIGJnLXNsYXRlLTk1MCBob3ZlcjpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgZm9udC1ib2xkIHRleHQtY2VudGVyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIPCfkYHvuI8gRXllc1xuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNlbGVjdFByZXNldCgnZnVsbCcpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHJvdW5kZWQtbGcgYmctc2xhdGUtOTUwIGhvdmVyOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTMwMCBmb250LWJvbGQgdGV4dC1jZW50ZXJcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAg8J+UsiBGdWxsXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBTZWN0aW9uIEJyaWdodG5lc3MgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtMzAwIG1iLTAuNSBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1hbWJlci0zMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxTdW4gY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiBTZWN0aW9uIEJyaWdodG5lc3NcbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtd2hpdGVcIj57c2VjQnJpZ2h0bmVzcyA+IDAgPyBgKyR7c2VjQnJpZ2h0bmVzc31gIDogc2VjQnJpZ2h0bmVzc30lPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgICAgICBtaW49XCItNDBcIlxuICAgICAgICAgICAgICAgICAgICAgIG1heD1cIjQwXCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VjQnJpZ2h0bmVzc31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlY0JyaWdodG5lc3MoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGFjY2VudC1hbWJlci01MDAgY3Vyc29yLXBvaW50ZXIgaC0xLjUgYmctc2xhdGUtODAwIHJvdW5kZWRcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBTZWN0aW9uIENvbnRyYXN0ICovfVxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNsYXRlLTMwMCBtYi0wLjUgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2t5LTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPENvbnRyYXN0IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gU2VjdGlvbiBDb250cmFzdFxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC13aGl0ZVwiPntzZWNDb250cmFzdCA+IDAgPyBgKyR7c2VjQ29udHJhc3R9YCA6IHNlY0NvbnRyYXN0fSU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIi00MFwiXG4gICAgICAgICAgICAgICAgICAgICAgbWF4PVwiNDBcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWNDb250cmFzdH1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlY0NvbnRyYXN0KE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBhY2NlbnQtc2t5LTUwMCBjdXJzb3ItcG9pbnRlciBoLTEuNSBiZy1zbGF0ZS04MDAgcm91bmRlZFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIFNlY3Rpb24gV2FybXRoICovfVxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNsYXRlLTMwMCBtYi0wLjUgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtb3JhbmdlLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPEZsYW1lIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gU2VjdGlvbiBXYXJtdGggLyBUb25lXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXdoaXRlXCI+e3NlY1dhcm10aCA+IDAgPyBgKyR7c2VjV2FybXRofWAgOiBzZWNXYXJtdGh9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgICAgICBtaW49XCItNDBcIlxuICAgICAgICAgICAgICAgICAgICAgIG1heD1cIjQwXCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VjV2FybXRofVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0U2VjV2FybXRoKE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBhY2NlbnQtb3JhbmdlLTUwMCBjdXJzb3ItcG9pbnRlciBoLTEuNSBiZy1zbGF0ZS04MDAgcm91bmRlZFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIFNlY3Rpb24gU2F0dXJhdGlvbiAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS0zMDAgbWItMC41IGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXBpbmstMzAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RHJvcGxldHMgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPiBTZWN0aW9uIFNhdHVyYXRpb25cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtd2hpdGVcIj57c2VjU2F0dXJhdGlvbiA+IDAgPyBgKyR7c2VjU2F0dXJhdGlvbn1gIDogc2VjU2F0dXJhdGlvbn0lPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgICAgICBtaW49XCItNDBcIlxuICAgICAgICAgICAgICAgICAgICAgIG1heD1cIjQwXCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VjU2F0dXJhdGlvbn1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlY1NhdHVyYXRpb24oTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGFjY2VudC1waW5rLTUwMCBjdXJzb3ItcG9pbnRlciBoLTEuNSBiZy1zbGF0ZS04MDAgcm91bmRlZFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIFNlY3Rpb24gU2tpbiBTbW9vdGggKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtMzAwIG1iLTAuNSBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz4gU2VjdGlvbiBTbW9vdGhuZXNzXG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXdoaXRlXCI+e3NlY1Ntb290aH0lPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgICAgICBtaW49XCIwXCJcbiAgICAgICAgICAgICAgICAgICAgICBtYXg9XCI0MFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlY1Ntb290aH1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNlY1Ntb290aChOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYWNjZW50LWVtZXJhbGQtNTAwIGN1cnNvci1wb2ludGVyIGgtMS41IGJnLXNsYXRlLTgwMCByb3VuZGVkXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7LyogQmFrZSAvIEludmVydCBCdXR0b25zICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0xIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUJha2VTZWN0aW9uQWRqdXN0bWVudH1cbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17IXNlbGVjdGlvbkJveCB8fCBpc1Byb2Nlc3Npbmd9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB5LTEuNSBweC0yIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1lbWVyYWxkLTYwMCB0by10ZWFsLTYwMCBob3Zlcjpmcm9tLWVtZXJhbGQtNTAwIGhvdmVyOnRvLXRlYWwtNTAwIHRleHQtd2hpdGUgZm9udC1leHRyYWJvbGQgdGV4dC1bMTFweF0gcm91bmRlZC14bCBzaGFkb3ctbWQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkJha2UgaW50byBQaG90bzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVJbnZlcnRTZWxlY3Rpb259XG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFzZWxlY3Rpb25Cb3h9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHktMS41IHB4LTIgYmctc2xhdGUtODAwIHRleHQtc2xhdGUtMzAwIGhvdmVyOnRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQtWzExcHhdIHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICAgICAgICAgICAgdGl0bGU9XCJJbnZlcnQgU2VsZWN0aW9uIEJveFwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICDwn5SEIEludmVydFxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIC8qIFdIT0xFIFBIT1RPIENPTE9SIEdSQURJTkcgQ09OVFJPTFMgKi9cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMi41IGFuaW1hdGUtaW4gZmFkZS1pblwiPlxuICAgICAgICAgICAgICAgICAgey8qIFNraW4gU21vb3RoICovfVxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNsYXRlLTQwMCBtYi0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTMwMCBmb250LXNlbWlib2xkXCI+U2tpbiBTbW9vdGhpbmc8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtd2hpdGVcIj57c2tpblNtb290aH0lPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cInJhbmdlXCJcbiAgICAgICAgICAgICAgICAgICAgICBtaW49XCIwXCJcbiAgICAgICAgICAgICAgICAgICAgICBtYXg9XCI1MFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NraW5TbW9vdGh9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTa2luU21vb3RoKE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBhY2NlbnQtYW1iZXItNTAwIGN1cnNvci1wb2ludGVyIGgtMS41IGJnLXNsYXRlLTgwMCByb3VuZGVkXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7LyogQnJpZ2h0bmVzcyAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS00MDAgbWItMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+QnJpZ2h0bmVzczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC13aGl0ZVwiPnticmlnaHRuZXNzID4gMCA/IGArJHticmlnaHRuZXNzfWAgOiBicmlnaHRuZXNzfSU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICAgICAgICAgIG1pbj1cIi0zMFwiXG4gICAgICAgICAgICAgICAgICAgICAgbWF4PVwiMzBcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXticmlnaHRuZXNzfVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0QnJpZ2h0bmVzcyhOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYWNjZW50LWJsdWUtNTAwIGN1cnNvci1wb2ludGVyIGgtMS41IGJnLXNsYXRlLTgwMCByb3VuZGVkXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7LyogQ29udHJhc3QgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtNDAwIG1iLTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkNvbnRyYXN0PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXdoaXRlXCI+e2NvbnRyYXN0ID4gMCA/IGArJHtjb250cmFzdH1gIDogY29udHJhc3R9JTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYW5nZVwiXG4gICAgICAgICAgICAgICAgICAgICAgbWluPVwiLTMwXCJcbiAgICAgICAgICAgICAgICAgICAgICBtYXg9XCIzMFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2NvbnRyYXN0fVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q29udHJhc3QoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGFjY2VudC1ibHVlLTUwMCBjdXJzb3ItcG9pbnRlciBoLTEuNSBiZy1zbGF0ZS04MDAgcm91bmRlZFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIFdhcm10aCAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS00MDAgbWItMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+V2FybXRoIC8gVG9uZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC13aGl0ZVwiPnt3YXJtdGggPiAwID8gYCske3dhcm10aH1gIDogd2FybXRofTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJyYW5nZVwiXG4gICAgICAgICAgICAgICAgICAgICAgbWluPVwiLTMwXCJcbiAgICAgICAgICAgICAgICAgICAgICBtYXg9XCIzMFwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3dhcm10aH1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFdhcm10aChOdW1iZXIoZS50YXJnZXQudmFsdWUpKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYWNjZW50LW9yYW5nZS01MDAgY3Vyc29yLXBvaW50ZXIgaC0xLjUgYmctc2xhdGUtODAwIHJvdW5kZWRcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgey8qIENhbmRpZGF0ZSBFeGFtIFN0cmlwICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMFwiPkV4YW0gTmFtZSAmIERhdGUgU3RyaXA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImNoZWNrYm94XCJcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17c2hvd05hbWVEYXRlfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFNob3dOYW1lRGF0ZShlLnRhcmdldC5jaGVja2VkKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWNjZW50LWJsdWUtNTAwIHJvdW5kZWRcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgIHtzaG93TmFtZURhdGUgJiYgKFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0yIHNwYWNlLXktMS41XCI+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkNhbmRpZGF0ZSBOYW1lXCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y2FuZGlkYXRlTmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldENhbmRpZGF0ZU5hbWUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZCBweC0yIHB5LTEgdGV4dC13aGl0ZSB0ZXh0LVsxMXB4XSBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJEYXRlIChERC9NTS9ZWVlZKVwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Bob3RvRGF0ZX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFBob3RvRGF0ZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkIHB4LTIgcHktMSB0ZXh0LXdoaXRlIHRleHQtWzExcHhdIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19