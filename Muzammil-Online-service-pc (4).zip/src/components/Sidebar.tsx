const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { LayoutDashboard, CreditCard, Camera, FileImage, Receipt, Users, FileText, Landmark, Sparkles, Download, Settings, Database, ChevronLeft, ChevronRight, ShieldCheck, Lock, Film } from "/node_modules/.vite/deps/lucide-react.js?v=090625a0";
var _jsxFileName = "/app/applet/src/components/Sidebar.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
export const Sidebar = ({ activeTab, onNavigate, isCollapsed, onToggleCollapse, user, pendingJobsCount, onLogout }) => {
	const navItems = [
		{
			id: "dashboard",
			label: "Dashboard",
			icon: LayoutDashboard,
			badge: null,
			shortcut: "Alt+1"
		},
		{
			id: "pvc_studio",
			label: "PVC Card Maker",
			icon: CreditCard,
			badge: "300 DPI",
			badgeColor: "bg-blue-500/20 text-blue-400 border-blue-500/30",
			shortcut: "Alt+2"
		},
		{
			id: "passport_studio",
			label: "Passport Studio",
			icon: Camera,
			badge: "4×6 / A4",
			badgeColor: "bg-purple-500/20 text-purple-400 border-purple-500/30",
			shortcut: "Alt+3"
		},
		{
			id: "video_studio",
			label: "Video Editing Studio",
			icon: Film,
			badge: "Multi-Layer",
			badgeColor: "bg-rose-500/20 text-rose-400 border-rose-500/30",
			shortcut: "Alt+V"
		},
		{
			id: "pdf_to_jpg",
			label: "PDF to HD JPG",
			icon: FileImage,
			badge: "Unlock",
			badgeColor: "bg-amber-500/20 text-amber-400 border-amber-500/30",
			shortcut: "Alt+4"
		},
		{
			id: "billing",
			label: "Billing Desk POS",
			icon: Receipt,
			badge: "Thermal",
			badgeColor: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
			shortcut: "Alt+5"
		},
		{
			id: "customers",
			label: "Customer CRM",
			icon: Users,
			badge: pendingJobsCount > 0 ? `${pendingJobsCount} Pending` : null,
			badgeColor: "bg-rose-500/20 text-rose-400 border-rose-500/30",
			shortcut: "Alt+6"
		},
		{
			id: "biodata_maker",
			label: "CV & BioData Maker",
			icon: FileText,
			badge: "A4",
			badgeColor: "bg-indigo-500/20 text-indigo-400 border-indigo-500/30",
			shortcut: "Alt+7"
		},
		{
			id: "workflow",
			label: "Cyber Cafe Workflow",
			icon: ShieldCheck,
			badge: "SOP",
			badgeColor: "bg-emerald-500/20 text-emerald-300 border-emerald-500/30",
			shortcut: null
		},
		...user.role === "admin" ? [{
			id: "master_admin",
			label: "Master Admin Panel",
			icon: Lock,
			badge: "Admin",
			badgeColor: "bg-rose-500/20 text-rose-300 border-rose-500/30",
			shortcut: null
		}] : [],
		{
			id: "portals",
			label: "Govt Portals Hub",
			icon: Landmark,
			badge: "50+",
			badgeColor: "bg-sky-500/20 text-sky-400 border-sky-500/30",
			shortcut: "Alt+8"
		},
		{
			id: "ai_assistant",
			label: "AI Scheme Guide",
			icon: Sparkles,
			badge: "AI",
			badgeColor: "bg-amber-500/20 text-amber-300 border-amber-500/30",
			shortcut: "Alt+9"
		},
		{
			id: "downloads",
			label: "Downloads & Files",
			icon: Download,
			badge: null,
			shortcut: null
		},
		{
			id: "settings",
			label: "Shop Settings",
			icon: Settings,
			badge: null,
			shortcut: null
		},
		{
			id: "backup",
			label: "Backup & Restore",
			icon: Database,
			badge: null,
			shortcut: null
		}
	];
	return /* @__PURE__ */ _jsxDEV("aside", {
		className: `bg-slate-900/95 border-r border-slate-800 transition-all duration-200 ease-in-out flex flex-col justify-between select-none z-20 flex-shrink-0 no-print ${isCollapsed ? "w-16" : "w-64"}`,
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "p-2 space-y-1 overflow-y-auto overflow-x-hidden flex-1",
			children: [!isCollapsed && /* @__PURE__ */ _jsxDEV("div", {
				className: "px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-slate-400",
				children: "Workstation Tools"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 170,
				columnNumber: 11
			}, this), navItems.map((item) => {
				const Icon = item.icon;
				const isActive = activeTab === item.id;
				return /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => onNavigate(item.id),
					title: isCollapsed ? `${item.label} (${item.shortcut || ""})` : undefined,
					className: `w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all group relative ${isActive ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30 font-bold" : "text-slate-300 hover:text-white hover:bg-slate-800/80"}`,
					children: [
						/* @__PURE__ */ _jsxDEV(Icon, { className: `w-4 h-4 flex-shrink-0 transition-transform group-hover:scale-110 ${isActive ? "text-white" : "text-slate-400 group-hover:text-blue-400"}` }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 189,
							columnNumber: 15
						}, this),
						!isCollapsed && /* @__PURE__ */ _jsxDEV("div", {
							className: "flex-1 flex items-center justify-between min-w-0",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "truncate",
								children: item.label
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 193,
								columnNumber: 19
							}, this), item.badge && /* @__PURE__ */ _jsxDEV("span", {
								className: `text-[10px] px-1.5 py-0.5 rounded border font-mono font-medium ${item.badgeColor || "bg-slate-800 text-slate-300 border-slate-700"}`,
								children: item.badge
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 195,
								columnNumber: 21
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 192,
							columnNumber: 17
						}, this),
						isActive && /* @__PURE__ */ _jsxDEV("div", { className: "absolute left-0 top-1/2 -translate-y-1/2 w-1 h-5 bg-white rounded-r-full" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 204,
							columnNumber: 17
						}, this)
					]
				}, item.id, true, {
					fileName: _jsxFileName,
					lineNumber: 179,
					columnNumber: 13
				}, this);
			})]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 168,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "p-2 border-t border-slate-800/80 bg-slate-950/40 space-y-1.5",
			children: [!isCollapsed && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-2.5 rounded-xl bg-slate-900 border border-slate-800",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between text-xs",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-1.5 text-slate-300 font-medium",
						children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 217,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Station Active" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 218,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 216,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-[10px] text-slate-400 font-mono",
						children: "v98.0 PC"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 220,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 215,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between mt-2 pt-1.5 border-t border-slate-800/60 text-[11px]",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-slate-400 truncate max-w-[120px]",
						children: ["@", user.username]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 223,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onLogout,
						className: "text-rose-400 hover:text-rose-300 font-bold flex items-center gap-1 hover:underline",
						title: "Lock Station & Logout",
						children: [/* @__PURE__ */ _jsxDEV(Lock, { className: "w-3 h-3" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 229,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Lock" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 230,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 224,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 222,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 214,
				columnNumber: 11
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				onClick: onToggleCollapse,
				className: "w-full flex items-center justify-center p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors text-xs",
				title: isCollapsed ? "Expand Sidebar (Ctrl + [)" : "Collapse Sidebar (Ctrl + [)",
				children: isCollapsed ? /* @__PURE__ */ _jsxDEV(ChevronRight, { className: "w-4 h-4" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 241,
					columnNumber: 26
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(ChevronLeft, { className: "w-4 h-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 243,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs",
						children: "Collapse Panel"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 244,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 242,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 236,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 212,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 162,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQ0UsaUJBQ0EsWUFDQSxRQUNBLFdBQ0EsU0FDQSxPQUNBLFVBQ0EsVUFDQSxVQUNBLFVBQ0EsVUFDQSxVQUNBLGFBQ0EsY0FDQSxhQUNBLE1BQ0EsWUFDSzs7O0FBYVAsT0FBTyxNQUFNLFdBQW1DLEVBQzlDLFdBQ0EsWUFDQSxhQUNBLGtCQUNBLE1BQ0Esa0JBQ0EsZUFDSTtDQUNKLE1BQU0sV0FBVztFQUNmO0dBQ0UsSUFBSTtHQUNKLE9BQU87R0FDUCxNQUFNO0dBQ04sT0FBTztHQUNQLFVBQVU7RUFDWjtFQUNBO0dBQ0UsSUFBSTtHQUNKLE9BQU87R0FDUCxNQUFNO0dBQ04sT0FBTztHQUNQLFlBQVk7R0FDWixVQUFVO0VBQ1o7RUFDQTtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLE9BQU87R0FDUCxZQUFZO0dBQ1osVUFBVTtFQUNaO0VBQ0E7R0FDRSxJQUFJO0dBQ0osT0FBTztHQUNQLE1BQU07R0FDTixPQUFPO0dBQ1AsWUFBWTtHQUNaLFVBQVU7RUFDWjtFQUNBO0dBQ0UsSUFBSTtHQUNKLE9BQU87R0FDUCxNQUFNO0dBQ04sT0FBTztHQUNQLFlBQVk7R0FDWixVQUFVO0VBQ1o7RUFDQTtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLE9BQU87R0FDUCxZQUFZO0dBQ1osVUFBVTtFQUNaO0VBQ0E7R0FDRSxJQUFJO0dBQ0osT0FBTztHQUNQLE1BQU07R0FDTixPQUFPLG1CQUFtQixJQUFJLEdBQUcsaUJBQWlCLFlBQVk7R0FDOUQsWUFBWTtHQUNaLFVBQVU7RUFDWjtFQUNBO0dBQ0UsSUFBSTtHQUNKLE9BQU87R0FDUCxNQUFNO0dBQ04sT0FBTztHQUNQLFlBQVk7R0FDWixVQUFVO0VBQ1o7RUFDQTtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLE9BQU87R0FDUCxZQUFZO0dBQ1osVUFBVTtFQUNaO0VBQ0EsR0FBSSxLQUFLLFNBQVMsVUFBVSxDQUFDO0dBQzNCLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLE9BQU87R0FDUCxZQUFZO0dBQ1osVUFBVTtFQUNaLENBQUMsSUFBSSxDQUFDO0VBQ047R0FDRSxJQUFJO0dBQ0osT0FBTztHQUNQLE1BQU07R0FDTixPQUFPO0dBQ1AsWUFBWTtHQUNaLFVBQVU7RUFDWjtFQUNBO0dBQ0UsSUFBSTtHQUNKLE9BQU87R0FDUCxNQUFNO0dBQ04sT0FBTztHQUNQLFlBQVk7R0FDWixVQUFVO0VBQ1o7RUFDQTtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLE9BQU87R0FDUCxVQUFVO0VBQ1o7RUFDQTtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLE9BQU87R0FDUCxVQUFVO0VBQ1o7RUFDQTtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtHQUNOLE9BQU87R0FDUCxVQUFVO0VBQ1o7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsU0FBRDtFQUNFLFdBQVcsMkpBQ1QsY0FBYyxTQUFTO1lBRjNCLENBTUUsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNHLENBQUMsZUFDQSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUEwRTtHQUVwRjs7OzthQUdOLFNBQVMsS0FBSyxTQUFTO0lBQ3RCLE1BQU0sT0FBTyxLQUFLO0lBQ2xCLE1BQU0sV0FBVyxjQUFjLEtBQUs7SUFDcEMsT0FDRSx3QkFBQyxVQUFEO0tBRUUsZUFBZSxXQUFXLEtBQUssRUFBRTtLQUNqQyxPQUFPLGNBQWMsR0FBRyxLQUFLLE1BQU0sSUFBSSxLQUFLLFlBQVksR0FBRyxLQUFLO0tBQ2hFLFdBQVcsNkdBQ1QsV0FDSSxrRUFDQTtlQVBSO01BVUUsd0JBQUMsTUFBRCxFQUFNLFdBQVcsb0VBQW9FLFdBQVcsZUFBZSw2Q0FBK0M7Ozs7O01BRTdKLENBQUMsZUFDQSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFZLEtBQUs7T0FBWTs7OztpQkFDNUMsS0FBSyxTQUNKLHdCQUFDLFFBQUQ7UUFBTSxXQUFXLGtFQUFrRSxLQUFLLGNBQWM7a0JBQ25HLEtBQUs7T0FDRjs7OztlQUVMOzs7Ozs7TUFJTixZQUNDLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDJFQUE0RTs7Ozs7S0FFdkY7T0ExQkQsS0FBSzs7OztXQTBCSjtHQUVaLENBQUMsQ0FDRTs7Ozs7WUFHTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0csQ0FBQyxlQUNBLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSwrQkFBZ0M7Ozs7Z0JBQ3ZELHdCQUFDLFFBQUQsWUFBTSxpQkFBb0I7Ozs7Y0FDdkI7Ozs7O2VBQ0wsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQXVDO0tBQWM7Ozs7YUFDbEU7Ozs7O2NBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQixDQUF3RCxLQUFFLEtBQUssUUFBZTs7Ozs7ZUFDOUUsd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO01BQ1YsT0FBTTtnQkFIUixDQUtFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7Z0JBQzNCLHdCQUFDLFFBQUQsWUFBTSxPQUFVOzs7O2NBQ1Y7Ozs7O2FBQ0w7Ozs7O1lBQ0Y7Ozs7O2FBR1Asd0JBQUMsVUFBRDtJQUNFLFNBQVM7SUFDVCxXQUFVO0lBQ1YsT0FBTyxjQUFjLDhCQUE4QjtjQUVsRCxjQUFjLHdCQUFDLGNBQUQsRUFBYyxXQUFVLFVBQVc7Ozs7ZUFDaEQsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLFVBQVc7Ozs7ZUFDbEMsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQVU7S0FBb0I7Ozs7YUFDM0M7Ozs7OztHQUVEOzs7O1dBQ0w7Ozs7O1VBQ0E7Ozs7OztBQUVYIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNpZGViYXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgTGF5b3V0RGFzaGJvYXJkLCBcbiAgQ3JlZGl0Q2FyZCwgXG4gIENhbWVyYSwgXG4gIEZpbGVJbWFnZSwgXG4gIFJlY2VpcHQsIFxuICBVc2VycywgXG4gIEZpbGVUZXh0LCBcbiAgTGFuZG1hcmssIFxuICBTcGFya2xlcywgXG4gIERvd25sb2FkLCBcbiAgU2V0dGluZ3MsIFxuICBEYXRhYmFzZSxcbiAgQ2hldnJvbkxlZnQsXG4gIENoZXZyb25SaWdodCxcbiAgU2hpZWxkQ2hlY2ssXG4gIExvY2ssXG4gIEZpbG1cbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IFVzZXJBY2NvdW50IH0gZnJvbSAnLi4vdHlwZXMnO1xuXG5pbnRlcmZhY2UgU2lkZWJhclByb3BzIHtcbiAgYWN0aXZlVGFiOiBzdHJpbmc7XG4gIG9uTmF2aWdhdGU6ICh0YWI6IHN0cmluZykgPT4gdm9pZDtcbiAgaXNDb2xsYXBzZWQ6IGJvb2xlYW47XG4gIG9uVG9nZ2xlQ29sbGFwc2U6ICgpID0+IHZvaWQ7XG4gIHVzZXI6IFVzZXJBY2NvdW50O1xuICBwZW5kaW5nSm9ic0NvdW50OiBudW1iZXI7XG4gIG9uTG9nb3V0OiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgU2lkZWJhcjogUmVhY3QuRkM8U2lkZWJhclByb3BzPiA9ICh7XG4gIGFjdGl2ZVRhYixcbiAgb25OYXZpZ2F0ZSxcbiAgaXNDb2xsYXBzZWQsXG4gIG9uVG9nZ2xlQ29sbGFwc2UsXG4gIHVzZXIsXG4gIHBlbmRpbmdKb2JzQ291bnQsXG4gIG9uTG9nb3V0XG59KSA9PiB7XG4gIGNvbnN0IG5hdkl0ZW1zID0gW1xuICAgIHtcbiAgICAgIGlkOiAnZGFzaGJvYXJkJyxcbiAgICAgIGxhYmVsOiAnRGFzaGJvYXJkJyxcbiAgICAgIGljb246IExheW91dERhc2hib2FyZCxcbiAgICAgIGJhZGdlOiBudWxsLFxuICAgICAgc2hvcnRjdXQ6ICdBbHQrMSdcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiAncHZjX3N0dWRpbycsXG4gICAgICBsYWJlbDogJ1BWQyBDYXJkIE1ha2VyJyxcbiAgICAgIGljb246IENyZWRpdENhcmQsXG4gICAgICBiYWRnZTogJzMwMCBEUEknLFxuICAgICAgYmFkZ2VDb2xvcjogJ2JnLWJsdWUtNTAwLzIwIHRleHQtYmx1ZS00MDAgYm9yZGVyLWJsdWUtNTAwLzMwJyxcbiAgICAgIHNob3J0Y3V0OiAnQWx0KzInXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogJ3Bhc3Nwb3J0X3N0dWRpbycsXG4gICAgICBsYWJlbDogJ1Bhc3Nwb3J0IFN0dWRpbycsXG4gICAgICBpY29uOiBDYW1lcmEsXG4gICAgICBiYWRnZTogJzTDlzYgLyBBNCcsXG4gICAgICBiYWRnZUNvbG9yOiAnYmctcHVycGxlLTUwMC8yMCB0ZXh0LXB1cnBsZS00MDAgYm9yZGVyLXB1cnBsZS01MDAvMzAnLFxuICAgICAgc2hvcnRjdXQ6ICdBbHQrMydcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiAndmlkZW9fc3R1ZGlvJyxcbiAgICAgIGxhYmVsOiAnVmlkZW8gRWRpdGluZyBTdHVkaW8nLFxuICAgICAgaWNvbjogRmlsbSxcbiAgICAgIGJhZGdlOiAnTXVsdGktTGF5ZXInLFxuICAgICAgYmFkZ2VDb2xvcjogJ2JnLXJvc2UtNTAwLzIwIHRleHQtcm9zZS00MDAgYm9yZGVyLXJvc2UtNTAwLzMwJyxcbiAgICAgIHNob3J0Y3V0OiAnQWx0K1YnXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogJ3BkZl90b19qcGcnLFxuICAgICAgbGFiZWw6ICdQREYgdG8gSEQgSlBHJyxcbiAgICAgIGljb246IEZpbGVJbWFnZSxcbiAgICAgIGJhZGdlOiAnVW5sb2NrJyxcbiAgICAgIGJhZGdlQ29sb3I6ICdiZy1hbWJlci01MDAvMjAgdGV4dC1hbWJlci00MDAgYm9yZGVyLWFtYmVyLTUwMC8zMCcsXG4gICAgICBzaG9ydGN1dDogJ0FsdCs0J1xuICAgIH0sXG4gICAge1xuICAgICAgaWQ6ICdiaWxsaW5nJyxcbiAgICAgIGxhYmVsOiAnQmlsbGluZyBEZXNrIFBPUycsXG4gICAgICBpY29uOiBSZWNlaXB0LFxuICAgICAgYmFkZ2U6ICdUaGVybWFsJyxcbiAgICAgIGJhZGdlQ29sb3I6ICdiZy1lbWVyYWxkLTUwMC8yMCB0ZXh0LWVtZXJhbGQtNDAwIGJvcmRlci1lbWVyYWxkLTUwMC8zMCcsXG4gICAgICBzaG9ydGN1dDogJ0FsdCs1J1xuICAgIH0sXG4gICAge1xuICAgICAgaWQ6ICdjdXN0b21lcnMnLFxuICAgICAgbGFiZWw6ICdDdXN0b21lciBDUk0nLFxuICAgICAgaWNvbjogVXNlcnMsXG4gICAgICBiYWRnZTogcGVuZGluZ0pvYnNDb3VudCA+IDAgPyBgJHtwZW5kaW5nSm9ic0NvdW50fSBQZW5kaW5nYCA6IG51bGwsXG4gICAgICBiYWRnZUNvbG9yOiAnYmctcm9zZS01MDAvMjAgdGV4dC1yb3NlLTQwMCBib3JkZXItcm9zZS01MDAvMzAnLFxuICAgICAgc2hvcnRjdXQ6ICdBbHQrNidcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiAnYmlvZGF0YV9tYWtlcicsXG4gICAgICBsYWJlbDogJ0NWICYgQmlvRGF0YSBNYWtlcicsXG4gICAgICBpY29uOiBGaWxlVGV4dCxcbiAgICAgIGJhZGdlOiAnQTQnLFxuICAgICAgYmFkZ2VDb2xvcjogJ2JnLWluZGlnby01MDAvMjAgdGV4dC1pbmRpZ28tNDAwIGJvcmRlci1pbmRpZ28tNTAwLzMwJyxcbiAgICAgIHNob3J0Y3V0OiAnQWx0KzcnXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogJ3dvcmtmbG93JyxcbiAgICAgIGxhYmVsOiAnQ3liZXIgQ2FmZSBXb3JrZmxvdycsXG4gICAgICBpY29uOiBTaGllbGRDaGVjayxcbiAgICAgIGJhZGdlOiAnU09QJyxcbiAgICAgIGJhZGdlQ29sb3I6ICdiZy1lbWVyYWxkLTUwMC8yMCB0ZXh0LWVtZXJhbGQtMzAwIGJvcmRlci1lbWVyYWxkLTUwMC8zMCcsXG4gICAgICBzaG9ydGN1dDogbnVsbFxuICAgIH0sXG4gICAgLi4uKHVzZXIucm9sZSA9PT0gJ2FkbWluJyA/IFt7XG4gICAgICBpZDogJ21hc3Rlcl9hZG1pbicsXG4gICAgICBsYWJlbDogJ01hc3RlciBBZG1pbiBQYW5lbCcsXG4gICAgICBpY29uOiBMb2NrLFxuICAgICAgYmFkZ2U6ICdBZG1pbicsXG4gICAgICBiYWRnZUNvbG9yOiAnYmctcm9zZS01MDAvMjAgdGV4dC1yb3NlLTMwMCBib3JkZXItcm9zZS01MDAvMzAnLFxuICAgICAgc2hvcnRjdXQ6IG51bGxcbiAgICB9XSA6IFtdKSxcbiAgICB7XG4gICAgICBpZDogJ3BvcnRhbHMnLFxuICAgICAgbGFiZWw6ICdHb3Z0IFBvcnRhbHMgSHViJyxcbiAgICAgIGljb246IExhbmRtYXJrLFxuICAgICAgYmFkZ2U6ICc1MCsnLFxuICAgICAgYmFkZ2VDb2xvcjogJ2JnLXNreS01MDAvMjAgdGV4dC1za3ktNDAwIGJvcmRlci1za3ktNTAwLzMwJyxcbiAgICAgIHNob3J0Y3V0OiAnQWx0KzgnXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogJ2FpX2Fzc2lzdGFudCcsXG4gICAgICBsYWJlbDogJ0FJIFNjaGVtZSBHdWlkZScsXG4gICAgICBpY29uOiBTcGFya2xlcyxcbiAgICAgIGJhZGdlOiAnQUknLFxuICAgICAgYmFkZ2VDb2xvcjogJ2JnLWFtYmVyLTUwMC8yMCB0ZXh0LWFtYmVyLTMwMCBib3JkZXItYW1iZXItNTAwLzMwJyxcbiAgICAgIHNob3J0Y3V0OiAnQWx0KzknXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogJ2Rvd25sb2FkcycsXG4gICAgICBsYWJlbDogJ0Rvd25sb2FkcyAmIEZpbGVzJyxcbiAgICAgIGljb246IERvd25sb2FkLFxuICAgICAgYmFkZ2U6IG51bGwsXG4gICAgICBzaG9ydGN1dDogbnVsbFxuICAgIH0sXG4gICAge1xuICAgICAgaWQ6ICdzZXR0aW5ncycsXG4gICAgICBsYWJlbDogJ1Nob3AgU2V0dGluZ3MnLFxuICAgICAgaWNvbjogU2V0dGluZ3MsXG4gICAgICBiYWRnZTogbnVsbCxcbiAgICAgIHNob3J0Y3V0OiBudWxsXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogJ2JhY2t1cCcsXG4gICAgICBsYWJlbDogJ0JhY2t1cCAmIFJlc3RvcmUnLFxuICAgICAgaWNvbjogRGF0YWJhc2UsXG4gICAgICBiYWRnZTogbnVsbCxcbiAgICAgIHNob3J0Y3V0OiBudWxsXG4gICAgfVxuICBdO1xuXG4gIHJldHVybiAoXG4gICAgPGFzaWRlIFxuICAgICAgY2xhc3NOYW1lPXtgYmctc2xhdGUtOTAwLzk1IGJvcmRlci1yIGJvcmRlci1zbGF0ZS04MDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMjAwIGVhc2UtaW4tb3V0IGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIHNlbGVjdC1ub25lIHotMjAgZmxleC1zaHJpbmstMCBuby1wcmludCAke1xuICAgICAgICBpc0NvbGxhcHNlZCA/ICd3LTE2JyA6ICd3LTY0J1xuICAgICAgfWB9XG4gICAgPlxuICAgICAgey8qIE5hdmlnYXRpb24gbWVudSBsaXN0ICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIgc3BhY2UteS0xIG92ZXJmbG93LXktYXV0byBvdmVyZmxvdy14LWhpZGRlbiBmbGV4LTFcIj5cbiAgICAgICAgeyFpc0NvbGxhcHNlZCAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC0zIHB5LTIgdGV4dC1bMTFweF0gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgV29ya3N0YXRpb24gVG9vbHNcbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7bmF2SXRlbXMubWFwKChpdGVtKSA9PiB7XG4gICAgICAgICAgY29uc3QgSWNvbiA9IGl0ZW0uaWNvbjtcbiAgICAgICAgICBjb25zdCBpc0FjdGl2ZSA9IGFjdGl2ZVRhYiA9PT0gaXRlbS5pZDtcbiAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBrZXk9e2l0ZW0uaWR9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uTmF2aWdhdGUoaXRlbS5pZCl9XG4gICAgICAgICAgICAgIHRpdGxlPXtpc0NvbGxhcHNlZCA/IGAke2l0ZW0ubGFiZWx9ICgke2l0ZW0uc2hvcnRjdXQgfHwgJyd9KWAgOiB1bmRlZmluZWR9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMyBweC0zIHB5LTIuNSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWFsbCBncm91cCByZWxhdGl2ZSAke1xuICAgICAgICAgICAgICAgIGlzQWN0aXZlXG4gICAgICAgICAgICAgICAgICA/ICdiZy1ibHVlLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1sZyBzaGFkb3ctYmx1ZS02MDAvMzAgZm9udC1ib2xkJ1xuICAgICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC13aGl0ZSBob3ZlcjpiZy1zbGF0ZS04MDAvODAnXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9e2B3LTQgaC00IGZsZXgtc2hyaW5rLTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZ3JvdXAtaG92ZXI6c2NhbGUtMTEwICR7aXNBY3RpdmUgPyAndGV4dC13aGl0ZScgOiAndGV4dC1zbGF0ZS00MDAgZ3JvdXAtaG92ZXI6dGV4dC1ibHVlLTQwMCd9YH0gLz5cbiAgICAgICAgICAgICAgXG4gICAgICAgICAgICAgIHshaXNDb2xsYXBzZWQgJiYgKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZVwiPntpdGVtLmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpdGVtLmJhZGdlICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPXtgdGV4dC1bMTBweF0gcHgtMS41IHB5LTAuNSByb3VuZGVkIGJvcmRlciBmb250LW1vbm8gZm9udC1tZWRpdW0gJHtpdGVtLmJhZGdlQ29sb3IgfHwgJ2JnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTMwMCBib3JkZXItc2xhdGUtNzAwJ31gfT5cbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5iYWRnZX1cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICB7LyogQWN0aXZlIEluZGljYXRvciBCYXIgKi99XG4gICAgICAgICAgICAgIHtpc0FjdGl2ZSAmJiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBsZWZ0LTAgdG9wLTEvMiAtdHJhbnNsYXRlLXktMS8yIHctMSBoLTUgYmctd2hpdGUgcm91bmRlZC1yLWZ1bGxcIiAvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKTtcbiAgICAgICAgfSl9XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEZvb3RlciAvIFRvZ2dsZSAmIFN5c3RlbSBTdGF0dXMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiBib3JkZXItdCBib3JkZXItc2xhdGUtODAwLzgwIGJnLXNsYXRlLTk1MC80MCBzcGFjZS15LTEuNVwiPlxuICAgICAgICB7IWlzQ29sbGFwc2VkICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMi41IHJvdW5kZWQteGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LXNsYXRlLTMwMCBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgIDxTaGllbGRDaGVjayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5TdGF0aW9uIEFjdGl2ZTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPnY5OC4wIFBDPC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBtdC0yIHB0LTEuNSBib3JkZXItdCBib3JkZXItc2xhdGUtODAwLzYwIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRydW5jYXRlIG1heC13LVsxMjBweF1cIj5Ae3VzZXIudXNlcm5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17b25Mb2dvdXR9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1yb3NlLTQwMCBob3Zlcjp0ZXh0LXJvc2UtMzAwIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBob3Zlcjp1bmRlcmxpbmVcIlxuICAgICAgICAgICAgICAgIHRpdGxlPVwiTG9jayBTdGF0aW9uICYgTG9nb3V0XCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxMb2NrIGNsYXNzTmFtZT1cInctMyBoLTNcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkxvY2s8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9e29uVG9nZ2xlQ29sbGFwc2V9XG4gICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtMiB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlIGhvdmVyOmJnLXNsYXRlLTgwMCByb3VuZGVkLWxnIHRyYW5zaXRpb24tY29sb3JzIHRleHQteHNcIlxuICAgICAgICAgIHRpdGxlPXtpc0NvbGxhcHNlZCA/IFwiRXhwYW5kIFNpZGViYXIgKEN0cmwgKyBbKVwiIDogXCJDb2xsYXBzZSBTaWRlYmFyIChDdHJsICsgWylcIn1cbiAgICAgICAgPlxuICAgICAgICAgIHtpc0NvbGxhcHNlZCA/IDxDaGV2cm9uUmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+IDogKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8Q2hldnJvbkxlZnQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHNcIj5Db2xsYXBzZSBQYW5lbDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9hc2lkZT5cbiAgKTtcbn07XG4iXX0=