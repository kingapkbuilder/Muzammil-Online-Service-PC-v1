const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=090625a0";
import { Sparkles, Send, User, Bot, Copy, Check } from "/node_modules/.vite/deps/lucide-react.js?v=090625a0";
import { SCHEME_GUIDES } from "/src/data/schemeKnowledge.ts";
var _jsxFileName = "/app/applet/src/components/AiAssistantView.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=090625a0";
export const AiAssistantView = () => {
	const [messages, setMessages] = useState([{
		sender: "assistant",
		text: `Namaskar! Welcome to the **Muzammil Online Service AI Digital Assistant**.\n\nI can help you with:\n• Required documents checklist for any scheme (Ladki Bahin, PM-KISAN, Ayushman Bharat, etc.)\n• Step-by-step portal application procedures\n• PAN card correction & Aadhaar update rules\n• PVC Card & Passport photo print presets\n\nType your question in Hindi, English, or Hinglish below, or click any quick topic!`,
		timestamp: new Date().toLocaleTimeString("en-IN", {
			hour: "2-digit",
			minute: "2-digit"
		})
	}]);
	const [input, setInput] = useState("");
	const [isLoading, setIsLoading] = useState(false);
	const [copiedIndex, setCopiedIndex] = useState(null);
	const quickPrompts = [
		"Majhi Ladki Bahin Yojana ke liye kya documents lagenge?",
		"PAN Card correction kaise karein?",
		"PM-KISAN eKYC aur land seeding process",
		"Ayushman Golden Card banane ka tarika",
		"PVC card 4x6 print setup on Epson L805"
	];
	const handleSendMessage = async (textToSend) => {
		const query = (textToSend || input).trim();
		if (!query || isLoading) return;
		const userMsg = {
			sender: "user",
			text: query,
			timestamp: new Date().toLocaleTimeString("en-IN", {
				hour: "2-digit",
				minute: "2-digit"
			})
		};
		setMessages((prev) => [...prev, userMsg]);
		setInput("");
		setIsLoading(true);
		try {
			// 1. Try server-side Gemini API endpoint
			const response = await fetch("/api/assistant", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({ prompt: query })
			});
			if (response.ok) {
				const data = await response.json();
				if (data.reply) {
					setMessages((prev) => [...prev, {
						sender: "assistant",
						text: data.reply,
						timestamp: new Date().toLocaleTimeString("en-IN", {
							hour: "2-digit",
							minute: "2-digit"
						})
					}]);
					setIsLoading(false);
					return;
				}
			}
		} catch {}
		// Smart Local Knowledge Base Fallback
		setTimeout(() => {
			const q = query.toLowerCase();
			let reply = "";
			if (q.includes("ladki") || q.includes("bahin") || q.includes("nari")) {
				const g = SCHEME_GUIDES.ladki_bahin;
				reply = `### ${g.title}\n\n**Eligibility:**\n${g.eligibility.map((e) => `• ${e}`).join("\n")}\n\n**Documents Required:**\n${g.documents.map((d) => `• ${d}`).join("\n")}\n\n**Application Steps:**\n${g.procedure.join("\n")}\n\n**Official Portal:** ${g.officialUrl}\n\n💡 **Tip:** ${g.notes}`;
			} else if (q.includes("kisan") || q.includes("pmkisan") || q.includes("farmer")) {
				const g = SCHEME_GUIDES.pm_kisan;
				reply = `### ${g.title}\n\n**Eligibility:**\n${g.eligibility.map((e) => `• ${e}`).join("\n")}\n\n**Documents Required:**\n${g.documents.map((d) => `• ${d}`).join("\n")}\n\n**Procedure:**\n${g.procedure.join("\n")}\n\n**Portal:** ${g.officialUrl}\n\n💡 ${g.notes}`;
			} else if (q.includes("pan") || q.includes("uti") || q.includes("nsdl")) {
				const g = SCHEME_GUIDES.pan_card;
				reply = `### ${g.title}\n\n**Required Documents:**\n${g.documents.map((d) => `• ${d}`).join("\n")}\n\n**Procedure:**\n${g.procedure.join("\n")}\n\n**Portal:** ${g.officialUrl}\n\n💡 ${g.notes}`;
			} else if (q.includes("ayushman") || q.includes("golden") || q.includes("health") || q.includes("pmjay")) {
				const g = SCHEME_GUIDES.ayushman_bharat;
				reply = `### ${g.title}\n\n**Eligibility:**\n${g.eligibility.map((e) => `• ${e}`).join("\n")}\n\n**Documents Required:**\n${g.documents.map((d) => `• ${d}`).join("\n")}\n\n**Procedure:**\n${g.procedure.join("\n")}\n\n**Portal:** ${g.officialUrl}\n\n💡 ${g.notes}`;
			} else if (q.includes("pvc") || q.includes("epson") || q.includes("print")) {
				reply = `### PVC Card Printing Setup for Cyber Cafe\n\n• **Standard Dimensions:** CR-80 format (85.6 mm × 54.0 mm, aspect ratio ~1.586).\n• **Sheet Paper:** 4×6 inch (10×15 cm) Premium Glossy Photo Paper.\n• **Resolution:** 300 DPI (1200 × 1800 px).\n• **Epson / Canon Setup:** In print properties, select Paper Type = 'Photo Paper Glossy', Quality = 'High', Scale = '100% / Actual Size'.\n• Our PVC Card Maker tool automatically aligns Front and Back cards with standard cutting guide lines!`;
			} else {
				reply = `Citizen Service Guidelines for **${query}**:\n\n1. **Standard Document Verification:** Always check original Aadhaar card with active mobile number.\n2. **Bank Account Seeding:** Ensure customer bank account has NPCI / DBT mapping active.\n3. **Application Acknowledgment:** Always generate and provide a printed receipt to the customer using our Billing Desk.\n4. **Official Portals:** Check our 'Govt Portals Hub' tab to launch verified central and state websites safely.`;
			}
			setMessages((prev) => [...prev, {
				sender: "assistant",
				text: reply,
				timestamp: new Date().toLocaleTimeString("en-IN", {
					hour: "2-digit",
					minute: "2-digit"
				})
			}]);
			setIsLoading(false);
		}, 400);
	};
	const handleCopy = (text, idx) => {
		navigator.clipboard.writeText(text);
		setCopiedIndex(idx);
		setTimeout(() => setCopiedIndex(null), 2e3);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "space-y-4 max-w-5xl mx-auto",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-md",
				children: /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-xl font-extrabold text-white",
						children: "AI Scheme & Citizen Service Assistant"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 130,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs px-2 py-0.5 rounded-full font-mono font-bold flex items-center gap-1",
						children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3 h-3 text-amber-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Smart Assistant" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 131,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 129,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400 mt-0.5",
					children: "Instant guidance on government rules, document checklists, and portal procedures for cyber cafe operators"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 136,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 128,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 127,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2 overflow-x-auto pb-1 text-xs",
				children: quickPrompts.map((prompt, idx) => /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => handleSendMessage(prompt),
					className: "bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 px-3 py-1.5 rounded-xl whitespace-nowrap transition-colors",
					children: prompt
				}, idx, false, {
					fileName: _jsxFileName,
					lineNumber: 145,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 143,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl min-h-[500px] flex flex-col justify-between space-y-4",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-4 overflow-y-auto max-h-[550px] pr-2",
					children: [messages.map((msg, idx) => /* @__PURE__ */ _jsxDEV("div", {
						className: `flex items-start gap-3 ${msg.sender === "user" ? "flex-row-reverse" : "flex-row"}`,
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: `w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 text-white shadow-md ${msg.sender === "user" ? "bg-blue-600" : "bg-gradient-to-tr from-amber-500 to-indigo-600"}`,
							children: msg.sender === "user" ? /* @__PURE__ */ _jsxDEV(User, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 168,
								columnNumber: 42
							}, this) : /* @__PURE__ */ _jsxDEV(Bot, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 168,
								columnNumber: 73
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 165,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: `max-w-2xl rounded-2xl p-4 text-xs leading-relaxed ${msg.sender === "user" ? "bg-blue-600 text-white shadow-md shadow-blue-600/20" : "bg-slate-950 text-slate-200 border border-slate-800 shadow-md"}`,
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "whitespace-pre-line select-text",
								children: msg.text
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 176,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] text-slate-400",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: msg.timestamp }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 181,
									columnNumber: 19
								}, this), msg.sender === "assistant" && /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleCopy(msg.text, idx),
									className: "hover:text-white flex items-center gap-1",
									children: copiedIndex === idx ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-3 h-3 text-emerald-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 189,
										columnNumber: 27
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-emerald-400",
										children: "Copied"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 190,
										columnNumber: 27
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 188,
										columnNumber: 25
									}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Copy, { className: "w-3 h-3" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 194,
										columnNumber: 27
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Copy Text" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 195,
										columnNumber: 27
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 193,
										columnNumber: 25
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 183,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 180,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 171,
							columnNumber: 15
						}, this)]
					}, idx, true, {
						fileName: _jsxFileName,
						lineNumber: 159,
						columnNumber: 13
					}, this)), isLoading && /* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 text-slate-400 text-xs italic pl-11",
						children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-4 h-4 animate-spin text-amber-400" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 207,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Analyzing government rules and procedure..." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 206,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 157,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "pt-3 border-t border-slate-800",
					children: /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: (e) => {
							e.preventDefault();
							handleSendMessage();
						},
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							placeholder: "Ask anything about Aadhaar, Ladki Bahin, PAN, PVC, Ration Card...",
							value: input,
							onChange: (e) => setInput(e.target.value),
							className: "flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 222,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							disabled: isLoading || !input.trim(),
							className: "bg-gradient-to-r from-amber-500 to-indigo-600 hover:from-amber-400 hover:to-indigo-500 text-white font-bold p-3 rounded-xl shadow-lg transition-transform active:scale-95 disabled:opacity-50",
							children: /* @__PURE__ */ _jsxDEV(Send, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 234,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 229,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 215,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 214,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 156,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 125,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUNFLFVBQ0EsTUFDQSxNQUNBLEtBQ0EsTUFDQSxhQUlLO0FBQ1AsU0FBUyxxQkFBcUI7OztBQVE5QixPQUFPLE1BQU0sd0JBQWtDO0NBQzdDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBb0IsQ0FDbEQ7RUFDRSxRQUFRO0VBQ1IsTUFBTTtFQUNOLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsU0FBUztHQUFFLE1BQU07R0FBVyxRQUFRO0VBQVUsQ0FBQztDQUMxRixDQUNGLENBQUM7Q0FFRCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxLQUFLO0NBQ2hELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUF3QixJQUFJO0NBRWxFLE1BQU0sZUFBZTtFQUNuQjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7Q0FFQSxNQUFNLG9CQUFvQixPQUFPLGVBQXdCO0VBQ3ZELE1BQU0sU0FBUyxjQUFjLE1BQUssQ0FBRSxLQUFLO0VBQ3pDLElBQUksQ0FBQyxTQUFTLFdBQVc7RUFFekIsTUFBTSxVQUFtQjtHQUN2QixRQUFRO0dBQ1IsTUFBTTtHQUNOLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsU0FBUztJQUFFLE1BQU07SUFBVyxRQUFRO0dBQVUsQ0FBQztFQUMxRjtFQUVBLGFBQVksU0FBUSxDQUFDLEdBQUcsTUFBTSxPQUFPLENBQUM7RUFDdEMsU0FBUyxFQUFFO0VBQ1gsYUFBYSxJQUFJO0VBRWpCLElBQUk7O0dBRUYsTUFBTSxXQUFXLE1BQU0sTUFBTSxrQkFBa0I7SUFDN0MsUUFBUTtJQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0lBQzlDLE1BQU0sS0FBSyxVQUFVLEVBQUUsUUFBUSxNQUFNLENBQUM7R0FDeEMsQ0FBQztHQUVELElBQUksU0FBUyxJQUFJO0lBQ2YsTUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFLO0lBQ2pDLElBQUksS0FBSyxPQUFPO0tBQ2QsYUFBWSxTQUFRLENBQ2xCLEdBQUcsTUFDSDtNQUNFLFFBQVE7TUFDUixNQUFNLEtBQUs7TUFDWCxXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsbUJBQW1CLFNBQVM7T0FBRSxNQUFNO09BQVcsUUFBUTtNQUFVLENBQUM7S0FDMUYsQ0FDRixDQUFDO0tBQ0QsYUFBYSxLQUFLO0tBQ2xCO0lBQ0Y7R0FDRjtFQUNGLFFBQVEsQ0FFUjs7RUFHQSxpQkFBaUI7R0FDZixNQUFNLElBQUksTUFBTSxZQUFZO0dBQzVCLElBQUksUUFBUTtHQUVaLElBQUksRUFBRSxTQUFTLE9BQU8sS0FBSyxFQUFFLFNBQVMsT0FBTyxLQUFLLEVBQUUsU0FBUyxNQUFNLEdBQUc7SUFDcEUsTUFBTSxJQUFJLGNBQWM7SUFDeEIsUUFBUSxPQUFPLEVBQUUsTUFBTSx3QkFBd0IsRUFBRSxZQUFZLEtBQUksTUFBSyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUssSUFBSSxFQUFFLCtCQUErQixFQUFFLFVBQVUsS0FBSSxNQUFLLEtBQUssR0FBRyxDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUUsOEJBQThCLEVBQUUsVUFBVSxLQUFLLElBQUksRUFBRSwyQkFBMkIsRUFBRSxZQUFZLGtCQUFrQixFQUFFO0dBQ3hSLE9BQU8sSUFBSSxFQUFFLFNBQVMsT0FBTyxLQUFLLEVBQUUsU0FBUyxTQUFTLEtBQUssRUFBRSxTQUFTLFFBQVEsR0FBRztJQUMvRSxNQUFNLElBQUksY0FBYztJQUN4QixRQUFRLE9BQU8sRUFBRSxNQUFNLHdCQUF3QixFQUFFLFlBQVksS0FBSSxNQUFLLEtBQUssR0FBRyxDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUUsK0JBQStCLEVBQUUsVUFBVSxLQUFJLE1BQUssS0FBSyxHQUFHLENBQUMsQ0FBQyxLQUFLLElBQUksRUFBRSxzQkFBc0IsRUFBRSxVQUFVLEtBQUssSUFBSSxFQUFFLGtCQUFrQixFQUFFLFlBQVksU0FBUyxFQUFFO0dBQzlQLE9BQU8sSUFBSSxFQUFFLFNBQVMsS0FBSyxLQUFLLEVBQUUsU0FBUyxLQUFLLEtBQUssRUFBRSxTQUFTLE1BQU0sR0FBRztJQUN2RSxNQUFNLElBQUksY0FBYztJQUN4QixRQUFRLE9BQU8sRUFBRSxNQUFNLCtCQUErQixFQUFFLFVBQVUsS0FBSSxNQUFLLEtBQUssR0FBRyxDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUUsc0JBQXNCLEVBQUUsVUFBVSxLQUFLLElBQUksRUFBRSxrQkFBa0IsRUFBRSxZQUFZLFNBQVMsRUFBRTtHQUMxTCxPQUFPLElBQUksRUFBRSxTQUFTLFVBQVUsS0FBSyxFQUFFLFNBQVMsUUFBUSxLQUFLLEVBQUUsU0FBUyxRQUFRLEtBQUssRUFBRSxTQUFTLE9BQU8sR0FBRztJQUN4RyxNQUFNLElBQUksY0FBYztJQUN4QixRQUFRLE9BQU8sRUFBRSxNQUFNLHdCQUF3QixFQUFFLFlBQVksS0FBSSxNQUFLLEtBQUssR0FBRyxDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUUsK0JBQStCLEVBQUUsVUFBVSxLQUFJLE1BQUssS0FBSyxHQUFHLENBQUMsQ0FBQyxLQUFLLElBQUksRUFBRSxzQkFBc0IsRUFBRSxVQUFVLEtBQUssSUFBSSxFQUFFLGtCQUFrQixFQUFFLFlBQVksU0FBUyxFQUFFO0dBQzlQLE9BQU8sSUFBSSxFQUFFLFNBQVMsS0FBSyxLQUFLLEVBQUUsU0FBUyxPQUFPLEtBQUssRUFBRSxTQUFTLE9BQU8sR0FBRztJQUMxRSxRQUFRO0dBQ1YsT0FBTztJQUNMLFFBQVEsb0NBQW9DLE1BQU07R0FDcEQ7R0FFQSxhQUFZLFNBQVEsQ0FDbEIsR0FBRyxNQUNIO0lBQ0UsUUFBUTtJQUNSLE1BQU07SUFDTixXQUFXLElBQUksS0FBSyxDQUFDLENBQUMsbUJBQW1CLFNBQVM7S0FBRSxNQUFNO0tBQVcsUUFBUTtJQUFVLENBQUM7R0FDMUYsQ0FDRixDQUFDO0dBQ0QsYUFBYSxLQUFLO0VBQ3BCLEdBQUcsR0FBRztDQUNSO0NBRUEsTUFBTSxjQUFjLE1BQWMsUUFBZ0I7RUFDaEQsVUFBVSxVQUFVLFVBQVUsSUFBSTtFQUNsQyxlQUFlLEdBQUc7RUFDbEIsaUJBQWlCLGVBQWUsSUFBSSxHQUFHLEdBQUk7Q0FDN0M7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FFRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQW9DO0tBQXlDOzs7O2VBQzNGLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHlCQUEwQjs7OztnQkFDOUMsd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7OztjQUN2Qjs7Ozs7YUFDSDs7Ozs7Y0FDTCx3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUFnQztJQUUxQzs7OztZQUNBOzs7OztHQUNGOzs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osYUFBYSxLQUFLLFFBQVEsUUFDekIsd0JBQUMsVUFBRDtLQUVFLGVBQWUsa0JBQWtCLE1BQU07S0FDdkMsV0FBVTtlQUVUO0lBQ0ssR0FMRDs7OztXQUtDLENBQ1Q7R0FDRTs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNHLFNBQVMsS0FBSyxLQUFLLFFBQ2xCLHdCQUFDLE9BQUQ7TUFFRSxXQUFXLDBCQUNULElBQUksV0FBVyxTQUFTLHFCQUFxQjtnQkFIakQsQ0FNRSx3QkFBQyxPQUFEO09BQUssV0FBVywwRkFDZCxJQUFJLFdBQVcsU0FBUyxnQkFBZ0I7aUJBRXZDLElBQUksV0FBVyxTQUFTLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7a0JBQUksd0JBQUMsS0FBRCxFQUFLLFdBQVUsVUFBVzs7Ozs7TUFDL0U7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVcscURBQ2QsSUFBSSxXQUFXLFNBQ1gsd0RBQ0E7aUJBSE4sQ0FLRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWixJQUFJO09BQ0Y7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU8sSUFBSSxVQUFnQjs7OztrQkFDMUIsSUFBSSxXQUFXLGVBQ2Qsd0JBQUMsVUFBRDtTQUNFLGVBQWUsV0FBVyxJQUFJLE1BQU0sR0FBRztTQUN2QyxXQUFVO21CQUVULGdCQUFnQixNQUNmLGdEQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLDJCQUE0Qjs7OzttQkFDN0Msd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQW1CO1NBQVk7Ozs7aUJBQy9DOzs7O29CQUVGLGdEQUNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7bUJBQzNCLHdCQUFDLFFBQUQsWUFBTSxZQUFlOzs7O2lCQUNyQjs7Ozs7UUFFRTs7OztnQkFFUDs7Ozs7ZUFDRjs7Ozs7Y0FDRjtRQTFDRTs7OztZQTBDRixDQUNOLEdBRUEsYUFDQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHNDQUF1Qzs7OztnQkFDM0Qsd0JBQUMsUUFBRCxZQUFNLDhDQUFpRDs7OztjQUNwRDs7Ozs7YUFFSjs7Ozs7Y0FHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFFBQUQ7TUFDRSxXQUFXLE1BQU07T0FDZixFQUFFLGVBQWU7T0FDakIsa0JBQWtCO01BQ3BCO01BQ0EsV0FBVTtnQkFMWixDQU9FLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsYUFBWTtPQUNaLE9BQU87T0FDUCxXQUFXLE1BQU0sU0FBUyxFQUFFLE9BQU8sS0FBSztPQUN4QyxXQUFVO01BQ1g7Ozs7Z0JBQ0Qsd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxVQUFVLGFBQWEsQ0FBQyxNQUFNLEtBQUs7T0FDbkMsV0FBVTtpQkFFVix3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7OztNQUNyQjs7OztjQUNKOzs7Ozs7SUFDSDs7OztZQUNGOzs7Ozs7RUFDRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQWlBc3Npc3RhbnRWaWV3LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBcbiAgU3BhcmtsZXMsIFxuICBTZW5kLCBcbiAgVXNlciwgXG4gIEJvdCwgXG4gIENvcHksIFxuICBDaGVjaywgXG4gIEhlbHBDaXJjbGUsIFxuICBCb29rT3BlbiwgXG4gIEV4dGVybmFsTGluayBcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IFNDSEVNRV9HVUlERVMgfSBmcm9tICcuLi9kYXRhL3NjaGVtZUtub3dsZWRnZSc7XG5cbmludGVyZmFjZSBNZXNzYWdlIHtcbiAgc2VuZGVyOiAndXNlcicgfCAnYXNzaXN0YW50JztcbiAgdGV4dDogc3RyaW5nO1xuICB0aW1lc3RhbXA6IHN0cmluZztcbn1cblxuZXhwb3J0IGNvbnN0IEFpQXNzaXN0YW50VmlldzogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIGNvbnN0IFttZXNzYWdlcywgc2V0TWVzc2FnZXNdID0gdXNlU3RhdGU8TWVzc2FnZVtdPihbXG4gICAge1xuICAgICAgc2VuZGVyOiAnYXNzaXN0YW50JyxcbiAgICAgIHRleHQ6IGBOYW1hc2thciEgV2VsY29tZSB0byB0aGUgKipNdXphbW1pbCBPbmxpbmUgU2VydmljZSBBSSBEaWdpdGFsIEFzc2lzdGFudCoqLlxcblxcbkkgY2FuIGhlbHAgeW91IHdpdGg6XFxu4oCiIFJlcXVpcmVkIGRvY3VtZW50cyBjaGVja2xpc3QgZm9yIGFueSBzY2hlbWUgKExhZGtpIEJhaGluLCBQTS1LSVNBTiwgQXl1c2htYW4gQmhhcmF0LCBldGMuKVxcbuKAoiBTdGVwLWJ5LXN0ZXAgcG9ydGFsIGFwcGxpY2F0aW9uIHByb2NlZHVyZXNcXG7igKIgUEFOIGNhcmQgY29ycmVjdGlvbiAmIEFhZGhhYXIgdXBkYXRlIHJ1bGVzXFxu4oCiIFBWQyBDYXJkICYgUGFzc3BvcnQgcGhvdG8gcHJpbnQgcHJlc2V0c1xcblxcblR5cGUgeW91ciBxdWVzdGlvbiBpbiBIaW5kaSwgRW5nbGlzaCwgb3IgSGluZ2xpc2ggYmVsb3csIG9yIGNsaWNrIGFueSBxdWljayB0b3BpYyFgLFxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZygnZW4tSU4nLCB7IGhvdXI6ICcyLWRpZ2l0JywgbWludXRlOiAnMi1kaWdpdCcgfSlcbiAgICB9XG4gIF0pO1xuXG4gIGNvbnN0IFtpbnB1dCwgc2V0SW5wdXRdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbaXNMb2FkaW5nLCBzZXRJc0xvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbY29waWVkSW5kZXgsIHNldENvcGllZEluZGV4XSA9IHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IHF1aWNrUHJvbXB0cyA9IFtcbiAgICAnTWFqaGkgTGFka2kgQmFoaW4gWW9qYW5hIGtlIGxpeWUga3lhIGRvY3VtZW50cyBsYWdlbmdlPycsXG4gICAgJ1BBTiBDYXJkIGNvcnJlY3Rpb24ga2Fpc2Uga2FyZWluPycsXG4gICAgJ1BNLUtJU0FOIGVLWUMgYXVyIGxhbmQgc2VlZGluZyBwcm9jZXNzJyxcbiAgICAnQXl1c2htYW4gR29sZGVuIENhcmQgYmFuYW5lIGthIHRhcmlrYScsXG4gICAgJ1BWQyBjYXJkIDR4NiBwcmludCBzZXR1cCBvbiBFcHNvbiBMODA1J1xuICBdO1xuXG4gIGNvbnN0IGhhbmRsZVNlbmRNZXNzYWdlID0gYXN5bmMgKHRleHRUb1NlbmQ/OiBzdHJpbmcpID0+IHtcbiAgICBjb25zdCBxdWVyeSA9ICh0ZXh0VG9TZW5kIHx8IGlucHV0KS50cmltKCk7XG4gICAgaWYgKCFxdWVyeSB8fCBpc0xvYWRpbmcpIHJldHVybjtcblxuICAgIGNvbnN0IHVzZXJNc2c6IE1lc3NhZ2UgPSB7XG4gICAgICBzZW5kZXI6ICd1c2VyJyxcbiAgICAgIHRleHQ6IHF1ZXJ5LFxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZygnZW4tSU4nLCB7IGhvdXI6ICcyLWRpZ2l0JywgbWludXRlOiAnMi1kaWdpdCcgfSlcbiAgICB9O1xuXG4gICAgc2V0TWVzc2FnZXMocHJldiA9PiBbLi4ucHJldiwgdXNlck1zZ10pO1xuICAgIHNldElucHV0KCcnKTtcbiAgICBzZXRJc0xvYWRpbmcodHJ1ZSk7XG5cbiAgICB0cnkge1xuICAgICAgLy8gMS4gVHJ5IHNlcnZlci1zaWRlIEdlbWluaSBBUEkgZW5kcG9pbnRcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goJy9hcGkvYXNzaXN0YW50Jywge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgcHJvbXB0OiBxdWVyeSB9KVxuICAgICAgfSk7XG5cbiAgICAgIGlmIChyZXNwb25zZS5vaykge1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICBpZiAoZGF0YS5yZXBseSkge1xuICAgICAgICAgIHNldE1lc3NhZ2VzKHByZXYgPT4gW1xuICAgICAgICAgICAgLi4ucHJldixcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgc2VuZGVyOiAnYXNzaXN0YW50JyxcbiAgICAgICAgICAgICAgdGV4dDogZGF0YS5yZXBseSxcbiAgICAgICAgICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvTG9jYWxlVGltZVN0cmluZygnZW4tSU4nLCB7IGhvdXI6ICcyLWRpZ2l0JywgbWludXRlOiAnMi1kaWdpdCcgfSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgICBdKTtcbiAgICAgICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gRmFsbGJhY2sgdG8gbG9jYWwgaW50ZWxsaWdlbnQga25vd2xlZGdlIGJhc2VcbiAgICB9XG5cbiAgICAvLyBTbWFydCBMb2NhbCBLbm93bGVkZ2UgQmFzZSBGYWxsYmFja1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgY29uc3QgcSA9IHF1ZXJ5LnRvTG93ZXJDYXNlKCk7XG4gICAgICBsZXQgcmVwbHkgPSAnJztcblxuICAgICAgaWYgKHEuaW5jbHVkZXMoJ2xhZGtpJykgfHwgcS5pbmNsdWRlcygnYmFoaW4nKSB8fCBxLmluY2x1ZGVzKCduYXJpJykpIHtcbiAgICAgICAgY29uc3QgZyA9IFNDSEVNRV9HVUlERVMubGFka2lfYmFoaW47XG4gICAgICAgIHJlcGx5ID0gYCMjIyAke2cudGl0bGV9XFxuXFxuKipFbGlnaWJpbGl0eToqKlxcbiR7Zy5lbGlnaWJpbGl0eS5tYXAoZSA9PiBg4oCiICR7ZX1gKS5qb2luKCdcXG4nKX1cXG5cXG4qKkRvY3VtZW50cyBSZXF1aXJlZDoqKlxcbiR7Zy5kb2N1bWVudHMubWFwKGQgPT4gYOKAoiAke2R9YCkuam9pbignXFxuJyl9XFxuXFxuKipBcHBsaWNhdGlvbiBTdGVwczoqKlxcbiR7Zy5wcm9jZWR1cmUuam9pbignXFxuJyl9XFxuXFxuKipPZmZpY2lhbCBQb3J0YWw6KiogJHtnLm9mZmljaWFsVXJsfVxcblxcbvCfkqEgKipUaXA6KiogJHtnLm5vdGVzfWA7XG4gICAgICB9IGVsc2UgaWYgKHEuaW5jbHVkZXMoJ2tpc2FuJykgfHwgcS5pbmNsdWRlcygncG1raXNhbicpIHx8IHEuaW5jbHVkZXMoJ2Zhcm1lcicpKSB7XG4gICAgICAgIGNvbnN0IGcgPSBTQ0hFTUVfR1VJREVTLnBtX2tpc2FuO1xuICAgICAgICByZXBseSA9IGAjIyMgJHtnLnRpdGxlfVxcblxcbioqRWxpZ2liaWxpdHk6KipcXG4ke2cuZWxpZ2liaWxpdHkubWFwKGUgPT4gYOKAoiAke2V9YCkuam9pbignXFxuJyl9XFxuXFxuKipEb2N1bWVudHMgUmVxdWlyZWQ6KipcXG4ke2cuZG9jdW1lbnRzLm1hcChkID0+IGDigKIgJHtkfWApLmpvaW4oJ1xcbicpfVxcblxcbioqUHJvY2VkdXJlOioqXFxuJHtnLnByb2NlZHVyZS5qb2luKCdcXG4nKX1cXG5cXG4qKlBvcnRhbDoqKiAke2cub2ZmaWNpYWxVcmx9XFxuXFxu8J+SoSAke2cubm90ZXN9YDtcbiAgICAgIH0gZWxzZSBpZiAocS5pbmNsdWRlcygncGFuJykgfHwgcS5pbmNsdWRlcygndXRpJykgfHwgcS5pbmNsdWRlcygnbnNkbCcpKSB7XG4gICAgICAgIGNvbnN0IGcgPSBTQ0hFTUVfR1VJREVTLnBhbl9jYXJkO1xuICAgICAgICByZXBseSA9IGAjIyMgJHtnLnRpdGxlfVxcblxcbioqUmVxdWlyZWQgRG9jdW1lbnRzOioqXFxuJHtnLmRvY3VtZW50cy5tYXAoZCA9PiBg4oCiICR7ZH1gKS5qb2luKCdcXG4nKX1cXG5cXG4qKlByb2NlZHVyZToqKlxcbiR7Zy5wcm9jZWR1cmUuam9pbignXFxuJyl9XFxuXFxuKipQb3J0YWw6KiogJHtnLm9mZmljaWFsVXJsfVxcblxcbvCfkqEgJHtnLm5vdGVzfWA7XG4gICAgICB9IGVsc2UgaWYgKHEuaW5jbHVkZXMoJ2F5dXNobWFuJykgfHwgcS5pbmNsdWRlcygnZ29sZGVuJykgfHwgcS5pbmNsdWRlcygnaGVhbHRoJykgfHwgcS5pbmNsdWRlcygncG1qYXknKSkge1xuICAgICAgICBjb25zdCBnID0gU0NIRU1FX0dVSURFUy5heXVzaG1hbl9iaGFyYXQ7XG4gICAgICAgIHJlcGx5ID0gYCMjIyAke2cudGl0bGV9XFxuXFxuKipFbGlnaWJpbGl0eToqKlxcbiR7Zy5lbGlnaWJpbGl0eS5tYXAoZSA9PiBg4oCiICR7ZX1gKS5qb2luKCdcXG4nKX1cXG5cXG4qKkRvY3VtZW50cyBSZXF1aXJlZDoqKlxcbiR7Zy5kb2N1bWVudHMubWFwKGQgPT4gYOKAoiAke2R9YCkuam9pbignXFxuJyl9XFxuXFxuKipQcm9jZWR1cmU6KipcXG4ke2cucHJvY2VkdXJlLmpvaW4oJ1xcbicpfVxcblxcbioqUG9ydGFsOioqICR7Zy5vZmZpY2lhbFVybH1cXG5cXG7wn5KhICR7Zy5ub3Rlc31gO1xuICAgICAgfSBlbHNlIGlmIChxLmluY2x1ZGVzKCdwdmMnKSB8fCBxLmluY2x1ZGVzKCdlcHNvbicpIHx8IHEuaW5jbHVkZXMoJ3ByaW50JykpIHtcbiAgICAgICAgcmVwbHkgPSBgIyMjIFBWQyBDYXJkIFByaW50aW5nIFNldHVwIGZvciBDeWJlciBDYWZlXFxuXFxu4oCiICoqU3RhbmRhcmQgRGltZW5zaW9uczoqKiBDUi04MCBmb3JtYXQgKDg1LjYgbW0gw5cgNTQuMCBtbSwgYXNwZWN0IHJhdGlvIH4xLjU4NikuXFxu4oCiICoqU2hlZXQgUGFwZXI6KiogNMOXNiBpbmNoICgxMMOXMTUgY20pIFByZW1pdW0gR2xvc3N5IFBob3RvIFBhcGVyLlxcbuKAoiAqKlJlc29sdXRpb246KiogMzAwIERQSSAoMTIwMCDDlyAxODAwIHB4KS5cXG7igKIgKipFcHNvbiAvIENhbm9uIFNldHVwOioqIEluIHByaW50IHByb3BlcnRpZXMsIHNlbGVjdCBQYXBlciBUeXBlID0gJ1Bob3RvIFBhcGVyIEdsb3NzeScsIFF1YWxpdHkgPSAnSGlnaCcsIFNjYWxlID0gJzEwMCUgLyBBY3R1YWwgU2l6ZScuXFxu4oCiIE91ciBQVkMgQ2FyZCBNYWtlciB0b29sIGF1dG9tYXRpY2FsbHkgYWxpZ25zIEZyb250IGFuZCBCYWNrIGNhcmRzIHdpdGggc3RhbmRhcmQgY3V0dGluZyBndWlkZSBsaW5lcyFgO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmVwbHkgPSBgQ2l0aXplbiBTZXJ2aWNlIEd1aWRlbGluZXMgZm9yICoqJHtxdWVyeX0qKjpcXG5cXG4xLiAqKlN0YW5kYXJkIERvY3VtZW50IFZlcmlmaWNhdGlvbjoqKiBBbHdheXMgY2hlY2sgb3JpZ2luYWwgQWFkaGFhciBjYXJkIHdpdGggYWN0aXZlIG1vYmlsZSBudW1iZXIuXFxuMi4gKipCYW5rIEFjY291bnQgU2VlZGluZzoqKiBFbnN1cmUgY3VzdG9tZXIgYmFuayBhY2NvdW50IGhhcyBOUENJIC8gREJUIG1hcHBpbmcgYWN0aXZlLlxcbjMuICoqQXBwbGljYXRpb24gQWNrbm93bGVkZ21lbnQ6KiogQWx3YXlzIGdlbmVyYXRlIGFuZCBwcm92aWRlIGEgcHJpbnRlZCByZWNlaXB0IHRvIHRoZSBjdXN0b21lciB1c2luZyBvdXIgQmlsbGluZyBEZXNrLlxcbjQuICoqT2ZmaWNpYWwgUG9ydGFsczoqKiBDaGVjayBvdXIgJ0dvdnQgUG9ydGFscyBIdWInIHRhYiB0byBsYXVuY2ggdmVyaWZpZWQgY2VudHJhbCBhbmQgc3RhdGUgd2Vic2l0ZXMgc2FmZWx5LmA7XG4gICAgICB9XG5cbiAgICAgIHNldE1lc3NhZ2VzKHByZXYgPT4gW1xuICAgICAgICAuLi5wcmV2LFxuICAgICAgICB7XG4gICAgICAgICAgc2VuZGVyOiAnYXNzaXN0YW50JyxcbiAgICAgICAgICB0ZXh0OiByZXBseSxcbiAgICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKCdlbi1JTicsIHsgaG91cjogJzItZGlnaXQnLCBtaW51dGU6ICcyLWRpZ2l0JyB9KVxuICAgICAgICB9XG4gICAgICBdKTtcbiAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XG4gICAgfSwgNDAwKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVDb3B5ID0gKHRleHQ6IHN0cmluZywgaWR4OiBudW1iZXIpID0+IHtcbiAgICBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dCh0ZXh0KTtcbiAgICBzZXRDb3BpZWRJbmRleChpZHgpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0Q29waWVkSW5kZXgobnVsbCksIDIwMDApO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTQgbWF4LXctNXhsIG14LWF1dG9cIj5cbiAgICAgIHsvKiBIZWFkZXIgYmFyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHAtNCByb3VuZGVkLTJ4bCBzaGFkb3ctbWRcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlXCI+QUkgU2NoZW1lICYgQ2l0aXplbiBTZXJ2aWNlIEFzc2lzdGFudDwvaDE+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1hbWJlci01MDAvMjAgdGV4dC1hbWJlci0zMDAgYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAgdGV4dC14cyBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgZm9udC1tb25vIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPlNtYXJ0IEFzc2lzdGFudDwvc3Bhbj5cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG10LTAuNVwiPlxuICAgICAgICAgICAgSW5zdGFudCBndWlkYW5jZSBvbiBnb3Zlcm5tZW50IHJ1bGVzLCBkb2N1bWVudCBjaGVja2xpc3RzLCBhbmQgcG9ydGFsIHByb2NlZHVyZXMgZm9yIGN5YmVyIGNhZmUgb3BlcmF0b3JzXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogUXVpY2sgUHJvbXB0cyBCYXIgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIG92ZXJmbG93LXgtYXV0byBwYi0xIHRleHQteHNcIj5cbiAgICAgICAge3F1aWNrUHJvbXB0cy5tYXAoKHByb21wdCwgaWR4KSA9PiAoXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAga2V5PXtpZHh9XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTZW5kTWVzc2FnZShwcm9tcHQpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTMwMCBob3Zlcjp0ZXh0LXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHB4LTMgcHktMS41IHJvdW5kZWQteGwgd2hpdGVzcGFjZS1ub3dyYXAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtwcm9tcHR9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICkpfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBDaGF0IE1lc3NhZ2VzIFBhbmVsICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC01IHNoYWRvdy14bCBtaW4taC1bNTAwcHhdIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIHNwYWNlLXktNFwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCBvdmVyZmxvdy15LWF1dG8gbWF4LWgtWzU1MHB4XSBwci0yXCI+XG4gICAgICAgICAge21lc3NhZ2VzLm1hcCgobXNnLCBpZHgpID0+IChcbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAga2V5PXtpZHh9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtc3RhcnQgZ2FwLTMgJHtcbiAgICAgICAgICAgICAgICBtc2cuc2VuZGVyID09PSAndXNlcicgPyAnZmxleC1yb3ctcmV2ZXJzZScgOiAnZmxleC1yb3cnXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHctOCBoLTggcm91bmRlZC14bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmbGV4LXNocmluay0wIHRleHQtd2hpdGUgc2hhZG93LW1kICR7XG4gICAgICAgICAgICAgICAgbXNnLnNlbmRlciA9PT0gJ3VzZXInID8gJ2JnLWJsdWUtNjAwJyA6ICdiZy1ncmFkaWVudC10by10ciBmcm9tLWFtYmVyLTUwMCB0by1pbmRpZ28tNjAwJ1xuICAgICAgICAgICAgICB9YH0+XG4gICAgICAgICAgICAgICAge21zZy5zZW5kZXIgPT09ICd1c2VyJyA/IDxVc2VyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiA6IDxCb3QgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+fVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YG1heC13LTJ4bCByb3VuZGVkLTJ4bCBwLTQgdGV4dC14cyBsZWFkaW5nLXJlbGF4ZWQgJHtcbiAgICAgICAgICAgICAgICBtc2cuc2VuZGVyID09PSAndXNlcidcbiAgICAgICAgICAgICAgICAgID8gJ2JnLWJsdWUtNjAwIHRleHQtd2hpdGUgc2hhZG93LW1kIHNoYWRvdy1ibHVlLTYwMC8yMCdcbiAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTk1MCB0ZXh0LXNsYXRlLTIwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzaGFkb3ctbWQnXG4gICAgICAgICAgICAgIH1gfT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIndoaXRlc3BhY2UtcHJlLWxpbmUgc2VsZWN0LXRleHRcIj5cbiAgICAgICAgICAgICAgICAgIHttc2cudGV4dH1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMi41IHB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMC84MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPnttc2cudGltZXN0YW1wfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHttc2cuc2VuZGVyID09PSAnYXNzaXN0YW50JyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDb3B5KG1zZy50ZXh0LCBpZHgpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtd2hpdGUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAge2NvcGllZEluZGV4ID09PSBpZHggPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2sgY2xhc3NOYW1lPVwidy0zIGgtMyB0ZXh0LWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTQwMFwiPkNvcGllZDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8Q29weSBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+Q29weSBUZXh0PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkpfVxuXG4gICAgICAgICAge2lzTG9hZGluZyAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc2xhdGUtNDAwIHRleHQteHMgaXRhbGljIHBsLTExXCI+XG4gICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJ3LTQgaC00IGFuaW1hdGUtc3BpbiB0ZXh0LWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPkFuYWx5emluZyBnb3Zlcm5tZW50IHJ1bGVzIGFuZCBwcm9jZWR1cmUuLi48L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogSW5wdXQgQmFyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgIDxmb3JtXG4gICAgICAgICAgICBvblN1Ym1pdD17KGUpID0+IHtcbiAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICBoYW5kbGVTZW5kTWVzc2FnZSgpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFzayBhbnl0aGluZyBhYm91dCBBYWRoYWFyLCBMYWRraSBCYWhpbiwgUEFOLCBQVkMsIFJhdGlvbiBDYXJkLi4uXCJcbiAgICAgICAgICAgICAgdmFsdWU9e2lucHV0fVxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldElucHV0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTQgcHktMyB0ZXh0LXNtIHRleHQtd2hpdGUgcGxhY2Vob2xkZXItc2xhdGUtNTAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItYW1iZXItNTAwXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICBkaXNhYmxlZD17aXNMb2FkaW5nIHx8ICFpbnB1dC50cmltKCl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1hbWJlci01MDAgdG8taW5kaWdvLTYwMCBob3Zlcjpmcm9tLWFtYmVyLTQwMCBob3Zlcjp0by1pbmRpZ28tNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHAtMyByb3VuZGVkLXhsIHNoYWRvdy1sZyB0cmFuc2l0aW9uLXRyYW5zZm9ybSBhY3RpdmU6c2NhbGUtOTUgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxTZW5kIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9mb3JtPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==