const { contextBridge } = require('electron');

contextBridge.exposeInMainWorld('electronDesktop', {
  isDesktopApp: true,
  platform: process.platform,
  version: '98.0.0'
});
