const { app, BrowserWindow, Menu, shell } = require('electron');
const path = require('path');
const { spawn } = require('child_process');

let mainWindow;
let serverProcess = null;

// Start embedded background server silently (no black window)
function startLocalServer() {
  try {
    const isDev = !app.isPackaged;
    if (isDev) {
      // In development mode
      return;
    }

    // In production packaged mode: start server.js in background
    const serverPath = path.join(__dirname, '../server.js');
    serverProcess = spawn(process.execPath, [serverPath], {
      detached: true,
      stdio: 'ignore',
      windowsHide: true,
      env: { ...process.env, PORT: '3000', NODE_ENV: 'production' }
    });
  } catch (err) {
    console.error('Failed to spawn background server:', err);
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 920,
    minWidth: 1024,
    minHeight: 700,
    title: 'Muzammil Online service pc',
    icon: path.join(__dirname, '../public/favicon.ico'),
    backgroundColor: '#020617', // match slate-950
    show: false, // show after ready to prevent white flash
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.cjs')
    }
  });

  // Maximized by default for dedicated cyber cafe workstation feel
  mainWindow.maximize();

  // Load production file or localhost
  const isDev = !app.isPackaged && process.env.NODE_ENV !== 'production';
  const startUrl = isDev 
    ? 'http://localhost:3000' 
    : `file://${path.join(__dirname, '../dist/index.html')}`;

  mainWindow.loadURL(startUrl);

  // Remove menu bar for clean software experience
  Menu.setApplicationMenu(null);

  // Show window smoothly when content is ready
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  // Open external links in user default browser (UIDAI, Aaple Sarkar, etc.)
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(() => {
  startLocalServer();
  createWindow();
});

app.on('window-all-closed', () => {
  if (serverProcess) {
    try {
      process.kill(-serverProcess.pid);
    } catch {}
  }
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (mainWindow === null) {
    createWindow();
  }
});
