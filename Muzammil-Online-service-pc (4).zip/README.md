# Muzammil Online Service - CSC & Cyber Cafe Workstation Suite
## Version: v98.0 PC Suite (Standalone Standalone Edition)
**Owner:** Imran Khan | **Contact:** 9561460313
**Address:** Naya Munshi Shaban Nagar, Main Road, Maharashtra, India

---

### Features & Workstation Modules:
1. **Strict 1-Device Security Locking**: Each Operator ID is permanently bound to a single computer/phone.
2. **PVC Smart Card Studio**: CR-80 85.6x54mm instant dual card 300 DPI layout for 4x6 photo paper with center cut line.
3. **Passport Photo Studio Pro**:
   - 4x6 Landscape (8 Copies @ 300 DPI) & A4 Landscape sheet layout.
   - Connected Flood-Fill Magic Wand Background Cutout.
   - Vector Pen Tool with Anchor Points & Live Dual Preview.
   - AI Auto Beauty Face Effect with Skin Smoothing & Facial Radiance.
   - Official Exam Stamp (Candidate Name & Date for SSC/Police Bharti).
4. **PDF to HD JPG High-Resolution Rasterizer**: Convert PDF Aadhaar/PAN/Voter slips to 300 DPI images.
5. **Fast Thermal Billing Desk & POS**: 58mm & 80mm thermal receipt generator with QR code payment.
6. **Customer CRM & Delivery Tracker**: Token tracking, pending work alerts, WhatsApp notifications.
7. **BioData & CV Maker**: Hindi, English, and Islamic wedding biodata templates.
8. **50+ Government Portals Directory**: Direct links to all Central & Maharashtra State Citizen Portals.
9. **Cyber Cafe Daily SOP Workflow Engine**: Interactive checklist for day-to-day cyber operations.
10. **Master Admin Panel**: Device lock resets, operator management, and security audit logs.

---

### How to Run Locally:
```bash
# 1. Install dependencies
npm install

# 2. Run development server (Port 3000)
npm run dev

# 3. Build for production
npm run build
```
