@echo off
title Muzammil Online service pc
color 0b
echo ========================================================
echo   MUZAMMIL ONLINE SERVICE PC - WORKSTATION v98.0
echo   Starting Local Server and Launching App...
echo ========================================================

:: Check if node_modules exists
if not exist node_modules (
    echo [INFO] First time setup detected! Installing dependencies...
    call npm install
)

:: Launch browser in background after 3 seconds
start "" cmd /c "timeout /t 3 >nul && start http://localhost:3000"

:: Start the application
call npm run dev
pause
