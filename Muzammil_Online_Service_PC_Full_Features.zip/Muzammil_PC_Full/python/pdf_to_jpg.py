import sys, os
try:
    import fitz
except Exception as e:
    print('PyMuPDF missing:', e)
    sys.exit(1)

def convert(src, outdir):
    doc=fitz.open(src)
    os.makedirs(outdir, exist_ok=True)
    for i,page in enumerate(doc):
        pix=page.get_pixmap(dpi=300, alpha=False)
        pix.save(os.path.join(outdir, f'page_{i+1:03d}.jpg'), output='jpg')
    return len(doc)

if __name__=='__main__':
    if len(sys.argv)<3:
        print('Usage: pdf_to_jpg.exe input.pdf output_folder')
        sys.exit(2)
    print(f'Converted {convert(sys.argv[1],sys.argv[2])} page(s).')
