# Muzammil Online Service - Native Windows

Native Win32 desktop application with the Muzammil dark-blue theme.

Modules: Dashboard, Passport Size Photo, PVC Card 4x6, PDF to JPG, PDF Tools, CV/Bio Data, Banner Maker, Bill/Receipt, Government Services, Maharashtra Services, Central Schemes, Banking Services, Downloads and Settings.

Build on GitHub Actions using MSVC + Python/PyMuPDF + Inno Setup.
