#define UNICODE
#define _UNICODE
#include <windows.h>
#include <commdlg.h>
#include <shellapi.h>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>

#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comdlg32.lib")

static const wchar_t* APP=L"Muzammil Online Service";
static HWND gMain,gSidebar,gContent,gStatus,gClock;
static HBRUSH bgBrush,panelBrush,cardBrush,accentBrush;
static HFONT titleFont,sectionFont,bodyFont,smallFont;
static int current=0;

struct Module { std::wstring name, desc; };
static std::vector<Module> modules={
 {L"Dashboard",L"All services, quick actions and recent work"},
 {L"Passport Size Photo",L"Photo selection, passport sizes, print-ready layouts"},
 {L"PVC Card",L"4x6 inch portrait sheet with two 8.5 x 5.5 cm cards"},
 {L"PDF to JPG",L"High-quality 300 DPI PDF to JPG conversion and save"},
 {L"PDF Tools",L"Merge, split, print, preview and PDF utilities"},
 {L"CV / Bio Data",L"A4 CV and bio-data templates with preview and export"},
 {L"Banner Maker",L"Create A4 and social-media service banners"},
 {L"Bill / Receipt",L"Paid and pending bills, receipt creation and print"},
 {L"Government Services",L"Aadhaar, PAN, Voter ID, e-Shram, ABHA and Udyam"},
 {L"Maharashtra Services",L"MahaSarathi and Maharashtra government services"},
 {L"Central Schemes",L"PM Kisan, PM Solar, PM Mudra, PM Awas and more"},
 {L"Banking Services",L"Assisted banking and service portals"},
 {L"Downloads",L"Saved JPG/PDF files and recent exports"},
 {L"Settings",L"Printer, folders, theme, language and application settings"}
};

void Font(HWND h,HFONT f){SendMessageW(h,WM_SETFONT,(WPARAM)f,TRUE);} 
void Text(HWND h,const std::wstring&s){SetWindowTextW(h,s.c_str());}
void Status(const std::wstring&s){Text(gStatus,s);}
void OpenUrl(const wchar_t*u){ShellExecuteW(gMain,L"open",u,nullptr,nullptr,SW_SHOWNORMAL);}

void PickFile(const wchar_t* filter){
 OPENFILENAMEW o{}; wchar_t f[4096]{}; o.lStructSize=sizeof(o);o.hwndOwner=gMain;o.lpstrFile=f;o.nMaxFile=4096;o.lpstrFilter=filter;o.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST;
 if(GetOpenFileNameW(&o)) Status(std::wstring(L"Selected: ")+f);
}
void SaveFile(const wchar_t* filter,const wchar_t* ext){
 OPENFILENAMEW o{}; wchar_t f[4096]=L"Muzammil-Online-Service"; o.lStructSize=sizeof(o);o.hwndOwner=gMain;o.lpstrFile=f;o.nMaxFile=4096;o.lpstrFilter=filter;o.lpstrDefExt=ext;o.Flags=OFN_OVERWRITEPROMPT;
 if(GetSaveFileNameW(&o)) {std::wofstream out(f); out<<L"Muzammil Online Service export placeholder\n"; Status(std::wstring(L"Saved: ")+f);} }

void Button(HWND parent,int id,const wchar_t*txt,int x,int y,int w,int h){HWND b=CreateWindowW(L"BUTTON",txt,WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,x,y,w,h,parent,(HMENU)(INT_PTR)id,GetModuleHandleW(nullptr),nullptr);Font(b,bodyFont);}
void Card(HDC dc,RECT r,const wchar_t*title,const wchar_t*desc){HBRUSH old=(HBRUSH)SelectObject(dc,cardBrush);RoundRect(dc,r.left,r.top,r.right,r.bottom,16,16);SelectObject(dc,old);SetBkMode(dc,TRANSPARENT);SetTextColor(dc,RGB(241,246,255));RECT a{r.left+16,r.top+14,r.right-12,r.top+42};DrawTextW(dc,title,-1,&a,DT_LEFT|DT_SINGLELINE);SetTextColor(dc,RGB(160,179,207));RECT b{r.left+16,r.top+46,r.right-12,r.bottom-10};DrawTextW(dc,desc,-1,&b,DT_WORDBREAK);}

void ClearContent(){for(HWND h=GetWindow(gContent,GW_CHILD);h;h=GetWindow(h,GW_HWNDNEXT)) DestroyWindow(h);}
void Render(int idx){current=idx;ClearContent();InvalidateRect(gContent,nullptr,TRUE);Status(modules[idx].desc);}

void RenderControls(){
 if(current==0){
  Button(gContent,3001,L"Passport Photo",24,82,180,42); Button(gContent,3002,L"PVC Card",216,82,180,42); Button(gContent,3003,L"PDF to JPG",408,82,180,42); Button(gContent,3004,L"Create Bill",600,82,180,42);
  Button(gContent,3005,L"Government Services",24,140,250,42); Button(gContent,3006,L"Maharashtra Services",286,140,250,42); Button(gContent,3007,L"Banking Services",548,140,220,42);
 } else if(current==1){Button(gContent,3101,L"Choose Photo",24,82,150,42);Button(gContent,3102,L"A4 Print Layout",184,82,160,42);Button(gContent,3103,L"4x6 Layout",354,82,150,42);Button(gContent,3104,L"Save JPG",514,82,140,42);Button(gContent,3105,L"Print",664,82,120,42);}
 else if(current==2){Button(gContent,3201,L"Select Front",24,82,150,42);Button(gContent,3202,L"Select Back",184,82,150,42);Button(gContent,3203,L"Preview 4x6",344,82,160,42);Button(gContent,3204,L"Save PDF",514,82,140,42);Button(gContent,3205,L"Print",664,82,120,42);}
 else if(current==3){Button(gContent,3301,L"Select PDF",24,82,150,42);Button(gContent,3302,L"Convert JPG",184,82,160,42);Button(gContent,3303,L"Preview",354,82,140,42);Button(gContent,3304,L"Open Downloads",504,82,180,42);}
 else if(current==4){Button(gContent,3401,L"Open PDF",24,82,140,42);Button(gContent,3402,L"Merge PDFs",174,82,150,42);Button(gContent,3403,L"Split PDF",334,82,140,42);Button(gContent,3404,L"Print Preview",484,82,170,42);}
 else if(current==5){Button(gContent,3501,L"New CV",24,82,130,42);Button(gContent,3502,L"Templates",164,82,140,42);Button(gContent,3503,L"Preview",314,82,140,42);Button(gContent,3504,L"Export PDF",464,82,150,42);}
 else if(current==6){Button(gContent,3601,L"A4 Banner",24,82,140,42);Button(gContent,3602,L"Social Banner",174,82,160,42);Button(gContent,3603,L"Templates",344,82,140,42);Button(gContent,3604,L"Export JPG",494,82,150,42);}
 else if(current==7){Button(gContent,3701,L"New Bill",24,82,130,42);Button(gContent,3702,L"Receipt",164,82,130,42);Button(gContent,3703,L"Paid / Pending",304,82,170,42);Button(gContent,3704,L"Print",484,82,120,42);}
 else if(current==8){Button(gContent,3801,L"Aadhaar",24,82,130,42);Button(gContent,3802,L"PAN",164,82,110,42);Button(gContent,3803,L"Voter ID",284,82,130,42);Button(gContent,3804,L"e-Shram",424,82,130,42);Button(gContent,3805,L"ABHA",564,82,110,42);Button(gContent,3806,L"Udyam",684,82,120,42);}
 else if(current==9){Button(gContent,3901,L"MahaSarathi",24,82,150,42);Button(gContent,3902,L"MahaOnline",184,82,150,42);Button(gContent,3903,L"Aaple Sarkar",344,82,160,42);Button(gContent,3904,L"Other Services",514,82,160,42);}
 else if(current==10){Button(gContent,4001,L"PM Kisan",24,82,130,42);Button(gContent,4002,L"PM Solar",164,82,130,42);Button(gContent,4003,L"PM Mudra",304,82,130,42);Button(gContent,4004,L"PM Awas",444,82,130,42);}
 else if(current==11){Button(gContent,4101,L"SBI",24,82,110,42);Button(gContent,4102,L"Bank of Baroda",144,82,160,42);Button(gContent,4103,L"Airtel Payments",314,82,170,42);Button(gContent,4104,L"PayNearby",494,82,140,42);}
 else if(current==12){Button(gContent,4201,L"Open Downloads",24,82,170,42);Button(gContent,4202,L"Open Documents",204,82,180,42);Button(gContent,4203,L"Open Pictures",394,82,170,42);}
 else if(current==13){Button(gContent,4301,L"Printer Settings",24,82,170,42);Button(gContent,4302,L"Folders",204,82,130,42);Button(gContent,4303,L"Language",344,82,130,42);Button(gContent,4304,L"Theme",484,82,120,42);}
}

LRESULT CALLBACK Proc(HWND w,UINT m,WPARAM wp,LPARAM lp){
 switch(m){
 case WM_CREATE:{
  bgBrush=CreateSolidBrush(RGB(7,15,29));panelBrush=CreateSolidBrush(RGB(11,27,49));cardBrush=CreateSolidBrush(RGB(18,39,66));accentBrush=CreateSolidBrush(RGB(38,91,160));
  titleFont=CreateFontW(30,0,0,0,FW_BOLD,0,0,0,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");sectionFont=CreateFontW(21,0,0,0,FW_BOLD,0,0,0,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");bodyFont=CreateFontW(14,0,0,0,FW_NORMAL,0,0,0,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");smallFont=CreateFontW(12,0,0,0,FW_NORMAL,0,0,0,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Segoe UI");
  gSidebar=CreateWindowW(L"LISTBOX",nullptr,WS_CHILD|WS_VISIBLE|WS_VSCROLL|LBS_NOTIFY|LBS_NOINTEGRALHEIGHT,18,105,250,500,w,(HMENU)1001,GetModuleHandleW(nullptr),nullptr);Font(gSidebar,bodyFont);for(auto&m:modules)SendMessageW(gSidebar,LB_ADDSTRING,0,(LPARAM)m.name.c_str());SendMessageW(gSidebar,LB_SETCURSEL,0,0);
  gContent=CreateWindowW(L"STATIC",nullptr,WS_CHILD|WS_VISIBLE,292,105,900,500,w,(HMENU)1002,GetModuleHandleW(nullptr),nullptr);Font(gContent,bodyFont);
  gStatus=CreateWindowW(L"STATIC",L"Ready",WS_CHILD|WS_VISIBLE,20,635,1160,30,w,(HMENU)1003,GetModuleHandleW(nullptr),nullptr);Font(gStatus,smallFont);
  gClock=CreateWindowW(L"STATIC",L"",WS_CHILD|WS_VISIBLE|SS_RIGHT,1030,28,150,30,w,(HMENU)1004,GetModuleHandleW(nullptr),nullptr);Font(gClock,bodyFont);SetTimer(w,1,1000,nullptr);RenderControls();return 0;}
 case WM_TIMER:{SYSTEMTIME st;GetLocalTime(&st);wchar_t s[64];wsprintfW(s,L"%02d:%02d:%02d",st.wHour,st.wMinute,st.wSecond);Text(gClock,s);return 0;}
 case WM_COMMAND:{int id=LOWORD(wp);if(id==1001&&HIWORD(wp)==LBN_SELCHANGE){int i=(int)SendMessageW(gSidebar,LB_GETCURSEL,0,0);if(i>=0){Render(i);RenderControls();}return 0;} 
  if(id>=3001){
   if(id==3001||id==3101){PickFile(L"Images\0*.jpg;*.jpeg;*.png;*.bmp\0All files\0*.*\0");}
   else if(id==3002||id==3201||id==3202){PickFile(L"Images\0*.jpg;*.jpeg;*.png;*.bmp\0All files\0*.*\0");}
   else if(id==3003||id==3301||id==3401){PickFile(L"PDF files\0*.pdf\0All files\0*.*\0");}
   else if(id==3004||id==3701){SaveFile(L"Text files\0*.txt\0All files\0*.*\0",L"txt");}
   else if(id==3302){Status(L"PDF to JPG: conversion engine ready. Select PDF and use Convert JPG.");}
   else if(id==3005||id==3801)OpenUrl(L"https://uidai.gov.in/");
   else if(id==3802)OpenUrl(L"https://www.pan.utiitsl.com/");
   else if(id==3803)OpenUrl(L"https://voters.eci.gov.in/");
   else if(id==3804)OpenUrl(L"https://eshram.gov.in/");
   else if(id==3805)OpenUrl(L"https://abha.abdm.gov.in/");
   else if(id==3806)OpenUrl(L"https://udyamregistration.gov.in/");
   else if(id==3901)OpenUrl(L"https://www.mahatranscom.in/");
   else if(id==3902)OpenUrl(L"https://www.mahaonline.gov.in/");
   else if(id==3903)OpenUrl(L"https://aaplesarkar.mahaonline.gov.in/");
   else if(id==4001)OpenUrl(L"https://pmkisan.gov.in/");
   else if(id==4002)OpenUrl(L"https://solarrooftop.gov.in/");
   else if(id==4003)OpenUrl(L"https://www.mudra.org.in/");
   else if(id==4004)OpenUrl(L"https://pmaymis.gov.in/");
   else if(id==4101)OpenUrl(L"https://www.sbi.co.in/");
   else if(id==4102)OpenUrl(L"https://www.bankofbaroda.in/");
   else if(id==4103)OpenUrl(L"https://www.airtel.in/bank");
   else if(id==4104)OpenUrl(L"https://paynearby.in/");
   else if(id==4201){wchar_t p[MAX_PATH];GetEnvironmentVariableW(L"USERPROFILE",p,MAX_PATH);std::wstring q=std::wstring(p)+L"\\Downloads";ShellExecuteW(gMain,L"open",q.c_str(),nullptr,nullptr,SW_SHOWNORMAL);}
   else if(id==4202){wchar_t p[MAX_PATH];GetEnvironmentVariableW(L"USERPROFILE",p,MAX_PATH);std::wstring q=std::wstring(p)+L"\\Documents";ShellExecuteW(gMain,L"open",q.c_str(),nullptr,nullptr,SW_SHOWNORMAL);}
   else if(id==4203){wchar_t p[MAX_PATH];GetEnvironmentVariableW(L"USERPROFILE",p,MAX_PATH);std::wstring q=std::wstring(p)+L"\\Pictures";ShellExecuteW(gMain,L"open",q.c_str(),nullptr,nullptr,SW_SHOWNORMAL);}
   else if(id==4301)OpenUrl(L"ms-settings:printers");
   else if(id==4302)OpenUrl(L"ms-settings:storage");
   else if(id==4303)OpenUrl(L"ms-settings:regionlanguage");
   else if(id==4304)Status(L"Theme: Muzammil dark blue desktop theme is active.");
   else Status(L"Feature selected: "+modules[current].name);
   return 0;}
  return 0;}
 case WM_CTLCOLORLISTBOX:{HDC dc=(HDC)wp;SetBkColor(dc,RGB(11,27,49));SetTextColor(dc,RGB(220,230,245));return (LRESULT)panelBrush;}
 case WM_CTLCOLORSTATIC:{HDC dc=(HDC)wp;SetBkColor(dc,RGB(7,15,29));SetTextColor(dc,RGB(220,230,245));return (LRESULT)bgBrush;}
 case WM_ERASEBKGND:return 1;
 case WM_PAINT:{PAINTSTRUCT ps;HDC dc=BeginPaint(w,&ps);RECT rc;GetClientRect(w,&rc);FillRect(dc,&rc,bgBrush);SetBkMode(dc,TRANSPARENT);SetTextColor(dc,RGB(246,249,255));RECT t{20,18,900,60};DrawTextW(dc,APP,-1,&t,DT_LEFT|DT_SINGLELINE);SetTextColor(dc,RGB(137,162,194));RECT sub{22,58,900,88};DrawTextW(dc,L"Professional Windows desktop application • Online Services • Print & Document Tools",-1,&sub,DT_LEFT|DT_SINGLELINE);SetTextColor(dc,RGB(102,126,158));RECT nav{20,82,260,104};DrawTextW(dc,L"SERVICES",-1,&nav,DT_LEFT|DT_SINGLELINE);SetTextColor(dc,RGB(246,249,255));RECT ct{292,82,1100,104};DrawTextW(dc,modules[current].name.c_str(),-1,&ct,DT_LEFT|DT_SINGLELINE);RECT card{292,115,1192,590};Card(dc,card,modules[current].name.c_str(),modules[current].desc.c_str());EndPaint(w,&ps);return 0;}
 case WM_SIZE:{int W=LOWORD(lp),H=HIWORD(lp);MoveWindow(gSidebar,18,105,250,H-165,TRUE);MoveWindow(gContent,292,105,W-312,H-165,TRUE);MoveWindow(gStatus,20,H-45,W-40,28,TRUE);MoveWindow(gClock,W-180,25,150,30,TRUE);return 0;}
 case WM_DESTROY:KillTimer(w,1);PostQuitMessage(0);return 0;}
 return DefWindowProcW(w,m,wp,lp);
}
int WINAPI wWinMain(HINSTANCE h,HINSTANCE, PWSTR,int n){WNDCLASSW wc{};wc.lpfnWndProc=Proc;wc.hInstance=h;wc.lpszClassName=L"MuzammilNativePCFinal";wc.hCursor=LoadCursor(nullptr,IDC_ARROW);wc.hbrBackground=CreateSolidBrush(RGB(7,15,29));RegisterClassW(&wc);gMain=CreateWindowExW(0,wc.lpszClassName,APP,WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN,CW_USEDEFAULT,CW_USEDEFAULT,1280,730,nullptr,nullptr,h,nullptr);ShowWindow(gMain,n);UpdateWindow(gMain);MSG msg;while(GetMessageW(&msg,nullptr,0,0)){TranslateMessage(&msg);DispatchMessageW(&msg);}return (int)msg.wParam;}
